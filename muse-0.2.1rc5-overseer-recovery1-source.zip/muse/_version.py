"""Single source of truth for the Muse package version.

All schema_version fields across the codebase read from here rather than
hardcoding a number.  The version itself lives in ``pyproject.toml``.

Editable installs read pyproject.toml directly so that bumping the version
is immediately reflected without reinstalling.  Packaged installs (tarballs)
have no pyproject.toml alongside the source and fall through to
importlib.metadata, which reads the dist-info stamped at build time.
The two install modes never interfere with each other.
"""

import pathlib as _pathlib
import re as _re


def _read_version() -> str:
    _toml = _pathlib.Path(__file__).parent.parent / "pyproject.toml"
    if _toml.is_file():
        _m = _re.search(r'^version\s*=\s*"([^"]+)"', _toml.read_text(), _re.MULTILINE)
        if _m:
            return _m.group(1)
    from importlib.metadata import PackageNotFoundError, version as _meta_version
    try:
        return _meta_version("muse")
    except PackageNotFoundError:
        return "0.0.0+dev"


__version__: str = _read_version()
