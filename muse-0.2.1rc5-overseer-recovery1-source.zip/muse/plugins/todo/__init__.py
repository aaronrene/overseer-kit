"""Todo domain plugin — a minimal real reference implementation.

Built live in Build With Muse, Episode 06 ("Build a Domain"), starting
from ``muse/plugins/scaffold``. See ``plugin.py`` for the six-method
implementation and ``docs/guide/plugin-authoring-guide.md`` for the
general walkthrough this domain follows.
"""
