"""Todo domain plugin — a flat, content-addressed set of tasks.

Built live in Build With Muse, Episode 06, starting from
``muse/plugins/scaffold``. Implements only the required six-method core
protocol (no address-keyed merge extension, no CRDT) — the simplest
possible real domain: one tracked file, ``todo.txt``, one task per line.

Tasks are addressed by their own content, not by line position. Two
branches adding two different tasks never conflict, no matter what —
that's the whole point of an address-keyed set.
"""

import hashlib
import os
import pathlib
import stat as _stat

from muse._version import __version__
from muse.core.object_store import read_object, write_object
from muse.core.schema import DomainSchema, SetSchema
from muse.core.types import Manifest, blob_id
from muse.domain import (
    AddressedDeleteOp,
    AddressedInsertOp,
    DriftReport,
    LiveState,
    MergeResult,
    PatchOp,
    SnapshotManifest,
    StateDelta,
    StateSnapshot,
    StructuredDelta,
)

_DOMAIN_NAME = "todo"
_TASK_FILE = "todo.txt"


def _task_address(task: str) -> str:
    digest = hashlib.sha256(task.encode("utf-8")).hexdigest()[:12]
    return f"{_TASK_FILE}::{digest}"


def _task_content_id(task: str) -> str:
    return blob_id(task.encode("utf-8"))


def _load_tasks(repo_root: pathlib.Path | None, snap: StateSnapshot) -> set[str]:
    object_id = snap["files"].get(_TASK_FILE)
    if object_id is None or repo_root is None:
        return set()
    raw = read_object(repo_root, object_id)
    if raw is None:
        # Uncommitted working-tree state: snapshot() hashes the live file
        # but never writes it to the object store (only `commit` does that,
        # for whichever paths actually get committed) -- so for drift/diff
        # against live state, fall back to reading the file straight off
        # disk rather than the store.
        live_path = repo_root / _TASK_FILE
        if not live_path.is_file():
            return set()
        raw = live_path.read_bytes()
    return {line for line in raw.decode("utf-8").splitlines() if line.strip()}


def _write_tasks(repo_root: pathlib.Path, tasks: set[str]) -> str:
    body = "\n".join(sorted(tasks))
    if body:
        body += "\n"
    raw = body.encode("utf-8")
    object_id = blob_id(raw)
    write_object(repo_root, object_id, raw)
    return object_id


class TodoPlugin:
    """A flat todo list. One file, one task per line, content-addressed."""

    def snapshot(self, live_state: LiveState) -> StateSnapshot:
        if isinstance(live_state, pathlib.Path):
            workdir = live_state
            todo_path = workdir / _TASK_FILE
            files: Manifest = {}
            if todo_path.is_file():
                st = os.lstat(todo_path)
                if _stat.S_ISREG(st.st_mode):
                    raw = todo_path.read_bytes()
                    files[_TASK_FILE] = blob_id(raw)
            return SnapshotManifest(files=files, domain=_DOMAIN_NAME, directories=[])
        return live_state

    def diff(
        self,
        base: StateSnapshot,
        target: StateSnapshot,
        *,
        repo_root: pathlib.Path | None = None,
    ) -> StateDelta:
        base_oid = base["files"].get(_TASK_FILE)
        target_oid = target["files"].get(_TASK_FILE)
        if base_oid == target_oid:
            return StructuredDelta(domain=_DOMAIN_NAME, ops=[], summary="no change")

        base_tasks = _load_tasks(repo_root, base)
        target_tasks = _load_tasks(repo_root, target)

        # Task-level detail, nested inside the file-level op below. This is
        # what makes the diff *structured* rather than "todo.txt changed" --
        # each task is its own address, so two different additions never
        # collide, no matter which file they both happen to live in.
        child_ops: list[AddressedInsertOp | AddressedDeleteOp] = []
        for task in sorted(target_tasks - base_tasks):
            child_ops.append(AddressedInsertOp(
                op="insert", address=_task_address(task),
                content_id=_task_content_id(task), content_summary=f"added: {task}",
            ))
        for task in sorted(base_tasks - target_tasks):
            child_ops.append(AddressedDeleteOp(
                op="delete", address=_task_address(task),
                content_id=_task_content_id(task), content_summary=f"removed: {task}",
            ))

        added = len(target_tasks - base_tasks)
        removed = len(base_tasks - target_tasks)
        summary = f"{added} task(s) added, {removed} task(s) removed"

        # The outer op is keyed by the *file* (todo.txt) -- this is what
        # `muse checkout` actually reads to know which object to restore or
        # delete on disk. The task-level child_ops above are for display and
        # merge reasoning; checkout only ever looks at the outer address.
        if base_oid is None:
            ops = [PatchOp(
                op="patch", address=_TASK_FILE, child_ops=child_ops,
                child_domain=_DOMAIN_NAME, child_summary=summary, file_change="added",
            )]
        elif target_oid is None:
            ops = [PatchOp(
                op="patch", address=_TASK_FILE, child_ops=child_ops,
                child_domain=_DOMAIN_NAME, child_summary=summary, file_change="deleted",
            )]
        else:
            ops = [PatchOp(
                op="patch", address=_TASK_FILE, child_ops=child_ops,
                child_domain=_DOMAIN_NAME, child_summary=summary, file_change="modified",
            )]

        return StructuredDelta(domain=_DOMAIN_NAME, ops=ops, summary=summary)

    def merge(
        self,
        base: StateSnapshot,
        left: StateSnapshot,
        right: StateSnapshot,
        *,
        repo_root: pathlib.Path | None = None,
    ) -> MergeResult:
        base_tasks = _load_tasks(repo_root, base)
        left_tasks = _load_tasks(repo_root, left)
        right_tasks = _load_tasks(repo_root, right)

        removed = (base_tasks - left_tasks) | (base_tasks - right_tasks)
        merged_tasks = (base_tasks | left_tasks | right_tasks) - removed

        if repo_root is not None:
            object_id = _write_tasks(repo_root, merged_tasks)
            files: Manifest = {_TASK_FILE: object_id} if merged_tasks else {}
        else:
            files = {}

        # Address-keyed elements never conflict with each other — only a
        # true same-address edit could, and this domain has no edit op,
        # only add/remove of whole, content-addressed tasks.
        return MergeResult(
            merged=SnapshotManifest(files=files, domain=_DOMAIN_NAME, directories=[]),
            conflicts=[],
        )

    def drift(self, committed: StateSnapshot, live: LiveState) -> DriftReport:
        current = self.snapshot(live)
        repo_root = live if isinstance(live, pathlib.Path) else None
        delta = self.diff(committed, current, repo_root=repo_root)
        return DriftReport(
            has_drift=len(delta["ops"]) > 0,
            summary=delta["summary"],
            delta=delta,
        )

    def apply(self, delta: StateDelta, live_state: LiveState) -> LiveState:
        # The core engine already restores todo.txt's bytes from the object
        # store during checkout — nothing domain-specific to do here.
        return live_state

    def schema(self) -> DomainSchema:
        return DomainSchema(
            domain=_DOMAIN_NAME,
            description=(
                "A flat todo list. Tasks are content-addressed, unordered "
                "elements in a single file (todo.txt) — order never matters, "
                "so two people adding two different tasks never conflicts."
            ),
            top_level=SetSchema(kind="set", element_type="task", identity="by_content"),
            dimensions=[],
            merge_mode="three_way",
            schema_version=__version__,
        )
