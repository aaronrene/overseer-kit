"""Mist domain plugin — content-addressed, signed, agent-native artifact hosting.

A *mist* is a single versioned artifact stored under a content-derived filename.
The filename **is** the identity: the first 12 characters of the base-58 encoding
of its SHA-256 digest, optionally suffixed with a human-readable extension.

Design goals
------------
- **Content-addressed** — same bytes always produce the same mist ID; no
  collision with any other content is possible under SHA-256.
- **Domain-agnostic** — MIDI files, Solidity ABIs, JSON Schemas, code,
  images, and arbitrary binary blobs are all first-class citizens.
- **Signed** — every mist carries an MSign Ed25519 author signature; AI-produced
  mists also embed ``agent_id`` + ``model_id`` for provenance.
- **VCS-native** — because MistPlugin satisfies ``MuseDomainPlugin``, all 14
  ``muse`` CLI commands (status, diff, merge, log, …) work on mist repos without
  any core engine changes.

Phase 1 scope
-------------
Pure domain layer only.  No CLI sub-commands, no MuseHub API routes, no UI.
Those land in Phases 2–4.

See ``docs/mists.md`` for the full architecture document.
"""

import hashlib
import os
import pathlib
import stat as _stat

from muse._version import __version__
from muse.core.diff_algorithms import snapshot_diff
from muse.core.schema import (
    DimensionSpec,
    DomainSchema,
    SetSchema,
)
from muse.core.stat_cache import load_cache
from muse.core.types import Manifest

type _ArtifactInfo = dict[str, str]
from muse.domain import (
    DriftReport,
    LiveState,
    MergeResult,
    SnapshotManifest,
    StateDelta,
    StateSnapshot,
)


# ---------------------------------------------------------------------------
# Module-level constants
# ---------------------------------------------------------------------------

_DOMAIN_NAME = "mist"

# Valid visibility values for a mist artifact.  Exported so that musehub and
# other consumers can validate against the same authoritative set.
MIST_VISIBILITIES: frozenset[str] = frozenset({"public", "secret"})

# Bitcoin base-58 alphabet — omits visually ambiguous characters: 0, O, I, l.
# Same bytes always produce the same base-58 string, making mist IDs
# deterministic and URL-safe.
_BASE58_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"

# Length of the mist ID prefix taken from the full base-58 encoding.
# 12 characters from SHA-256 → ~10^21 distinct values; collision probability is
# negligible for any realistic corpus.
_MIST_ID_LENGTH = 12

# Known artifact type → (category, language/subtype) pairs.
# Checked after magic-byte and JSON-key inspection — extension is the last resort.
_EXT_MAP: dict[str, tuple[str, str]] = {
    # Code
    ".py": ("code", "python"),
    ".js": ("code", "javascript"),
    ".ts": ("code", "typescript"),
    ".tsx": ("code", "typescript"),
    ".jsx": ("code", "javascript"),
    ".rs": ("code", "rust"),
    ".go": ("code", "go"),
    ".java": ("code", "java"),
    ".c": ("code", "c"),
    ".cpp": ("code", "cpp"),
    ".h": ("code", "c"),
    ".hpp": ("code", "cpp"),
    ".rb": ("code", "ruby"),
    ".swift": ("code", "swift"),
    ".kt": ("code", "kotlin"),
    ".sol": ("code", "solidity"),
    ".vy": ("code", "vyper"),
    # Prose — classified as code (same domain, plain text artifacts)
    ".md": ("code", "markdown"),
    ".txt": ("code", "text"),
    ".rst": ("code", "restructuredtext"),
    # Data
    ".csv": ("data", "csv"),
    ".toml": ("data", "toml"),
    ".yaml": ("data", "yaml"),
    ".yml": ("data", "yaml"),
    ".xml": ("data", "xml"),
    # MIDI — also detected by magic bytes (MThd)
    ".mid": ("midi", "midi"),
    ".midi": ("midi", "midi"),
}

# ---------------------------------------------------------------------------
# Pure functions — the domain's intelligence layer
# ---------------------------------------------------------------------------

def compute_mist_id(content: bytes) -> str:
    """Derive the globally unique mist ID from raw artifact bytes.

    The ID is the first :data:`_MIST_ID_LENGTH` characters of the base-58
    encoding of the artifact's SHA-256 digest.  The same bytes always produce
    the same ID.

    Args:
        content: Raw bytes of the artifact.

    Returns:
        A 12-character URL-safe base-58 string, e.g. ``"aB3xQ9fWmK2r"``.

    Examples:
        >>> compute_mist_id(b"hello")
        'GJGvdqT2tQ5j'
        >>> compute_mist_id(b"") != compute_mist_id(b"x")
        True
    """
    digest = hashlib.sha256(content).digest()
    # Encode the 32-byte digest as a big-endian integer then convert to base-58.
    n = int.from_bytes(digest, "big")
    chars: list[str] = []
    while n:
        n, remainder = divmod(n, 58)
        chars.append(_BASE58_ALPHABET[remainder])
    # Preserve leading zero bytes as base-58 '1' characters.
    for byte in digest:
        if byte == 0:
            chars.append(_BASE58_ALPHABET[0])
        else:
            break
    encoded = "".join(reversed(chars))
    return encoded[:_MIST_ID_LENGTH]

def detect_artifact_type(filename: str, content: bytes) -> _ArtifactInfo:
    """Infer the artifact type and language from filename and raw content.

    Detection order (most-to-least reliable):
    1. Magic bytes — MIDI ``MThd`` header; catches mis-named files.
    2. JSON key inspection — ABI arrays, JSON Schema ``$schema`` key.
    3. Extension map — falls back gracefully to ``("unknown", "binary")``.

    Args:
        filename: Bare filename (no path separators), e.g. ``"contract.abi.json"``.
        content:  Raw bytes of the artifact.

    Returns:
        A dict with keys ``"artifact_type"`` and ``"language"``, e.g.
        ``{"artifact_type": "midi", "language": "midi"}`` or
        ``{"artifact_type": "code", "language": "python"}``.

    Examples:
        >>> detect_artifact_type("track.mid", b"MThd\\x00\\x00\\x00\\x06")
        {'artifact_type': 'midi', 'language': 'midi'}
        >>> detect_artifact_type("schema.json", b'{"$schema":"http://..."}')
        {'artifact_type': 'json_schema', 'language': 'json'}
    """
    # 1. Magic bytes — MIDI
    if content[:4] == b"MThd":
        return {"artifact_type": "midi", "language": "midi"}

    # 2. JSON key inspection
    if filename.endswith(".json") or filename.endswith(".abi"):
        try:
            import json as _json

            parsed = _json.loads(content.decode("utf-8", errors="replace"))
            if isinstance(parsed, list) and parsed and isinstance(parsed[0], dict):
                # Ethereum ABI is an array of objects each with "type" and "name"
                if "type" in parsed[0] and "name" in parsed[0]:
                    return {"artifact_type": "abi", "language": "json"}
            if isinstance(parsed, dict):
                if "$schema" in parsed:
                    return {"artifact_type": "json_schema", "language": "json"}
        except Exception:
            pass

    # 3. Extension map
    ext = pathlib.PurePosixPath(filename).suffix.lower()
    if ext in _EXT_MAP:
        artifact_type, language = _EXT_MAP[ext]
        return {"artifact_type": artifact_type, "language": language}

    return {"artifact_type": "unknown", "language": "binary"}

def validate_mist_filename(filename: str) -> None:
    """Validate a proposed mist filename for safety and correctness.

    This is the security gate for all user-supplied filenames.  It rejects
    any name that could be used to escape the mist store or inject control
    sequences into terminals.

    Enforced rules
    --------------
    - No null bytes (``\\x00``).
    - No path separators (``/`` or ``\\``).
    - No directory traversal sequences (``..``).
    - No control characters (``\\x01``–``\\x1f``, ``\\x7f``).
    - No ANSI escape sequences (``\\x1b[``).
    - Length ≤ 255 characters.

    Args:
        filename: The filename to validate (must be a bare name, no path).

    Raises:
        ValueError: Describing exactly which rule was violated.

    Examples:
        >>> validate_mist_filename("aB3xQ9fWmK2r.py")   # valid — no error
        >>> validate_mist_filename("../traversal")
        Traceback (most recent call last):
            ...
        ValueError: Mist filename must not contain path traversal sequences: '../traversal'
    """
    if len(filename) > 255:
        raise ValueError(
            f"Mist filename exceeds 255-character limit: {len(filename)} chars"
        )
    if "\x00" in filename:
        raise ValueError(f"Mist filename must not contain null bytes: {filename!r}")
    if ".." in filename:
        raise ValueError(
            f"Mist filename must not contain path traversal sequences: {filename!r}"
        )
    if "/" in filename or "\\" in filename:
        raise ValueError(
            f"Mist filename must not contain path separators: {filename!r}"
        )
    if "\x1b[" in filename:
        raise ValueError(
            f"Mist filename must not contain ANSI escape sequences: {filename!r}"
        )
    for ch in filename:
        cp = ord(ch)
        if 0x01 <= cp <= 0x1F or cp == 0x7F:
            raise ValueError(
                f"Mist filename must not contain control characters: {filename!r}"
            )

def extract_mist_symbol_anchors(filename: str, content: bytes) -> list[str]:
    """Extract symbol anchors for code and structured mist artifacts.

    Delegates to the ``muse.plugins.code.ast_parser`` layer, which supports
    Python, TypeScript, Solidity, Markdown headings, TOML sections, and more.
    Returns an empty list for binary or unrecognised file types — these are
    still valid mists; they just have no intra-file anchor points.

    Args:
        filename: Bare filename (no path separators), e.g. ``"utils.py"``.
        content:  Raw bytes of the artifact.

    Returns:
        A list of symbol address strings in ``"filename::SymbolName"`` format,
        e.g. ``["utils.py::compute_checksum", "utils.py::BaseHandler"]``.

    Examples:
        >>> anchors = extract_mist_symbol_anchors("add.py", b"def add(a, b): return a + b")
        >>> "add.py::add" in anchors
        True
    """
    try:
        from muse.plugins.code.ast_parser import parse_symbols

        tree = parse_symbols(content, filename)
        # SymbolTree keys are full addresses: "filename.py::SymbolName"
        # Filter out import pseudo-symbols (kind == "import") by checking address.
        return [addr for addr in tree if "::import::" not in addr]
    except Exception:
        return []

# ---------------------------------------------------------------------------
# MistPlugin — MuseDomainPlugin implementation
# ---------------------------------------------------------------------------

class MistPlugin:
    """Domain plugin for mist repositories.

    Satisfies the full :class:`~muse.domain.MuseDomainPlugin` protocol plus the
    optional address-keyed merge extension (:class:`~muse.domain.AddressedMergePlugin`).
    No explicit inheritance needed — structural duck-typing applies.

    All 14 ``muse`` CLI commands work immediately on any mist repo once this
    plugin is registered.  The mist-specific behaviour is:

    - Every tracked file is a *mist*: a single content-addressed artifact.
    - The snapshot manifest maps mist IDs (filenames) to their SHA-256 hashes.
    - Merges are set-algebraic at file granularity — a mist either exists or not.
    - Symbol anchors are extracted for code/structured mists; binary mists have none.
    """

    # ------------------------------------------------------------------
    # MuseDomainPlugin — required core protocol
    # ------------------------------------------------------------------

    def snapshot(self, live_state: LiveState) -> StateSnapshot:
        """Capture the current mist store as a content-addressed manifest.

        Walks every file under ``live_state`` (respecting ``.museignore``),
        hashing raw bytes with SHA-256.  Returns a ``SnapshotManifest`` whose
        ``files`` dict maps workspace-relative POSIX paths to their digests.

        Args:
            live_state: Either a ``pathlib.Path`` pointing to the mist store
                directory, or a ``SnapshotManifest`` dict for in-memory use.

        Returns:
            A ``SnapshotManifest`` mapping mist filenames to SHA-256 digests.
        """
        if isinstance(live_state, pathlib.Path):
            from muse.core.ignore import is_ignored, load_ignore_config, resolve_patterns

            workdir = live_state
            patterns = resolve_patterns(load_ignore_config(workdir), _DOMAIN_NAME)
            cache = load_cache(workdir)
            files: Manifest = {}
            root_str = str(workdir)
            prefix_len = len(root_str) + 1

            for dirpath, dirnames, filenames in os.walk(root_str, followlinks=False):
                dirnames[:] = sorted(d for d in dirnames if not d.startswith("."))
                for fname in sorted(filenames):
                    if fname.startswith("."):
                        continue
                    abs_str = os.path.join(dirpath, fname)
                    try:
                        st = os.lstat(abs_str)
                    except OSError:
                        continue
                    if not _stat.S_ISREG(st.st_mode):
                        continue
                    rel = abs_str[prefix_len:]
                    if os.sep != "/":
                        rel = rel.replace(os.sep, "/")
                    if is_ignored(rel, patterns):
                        continue
                    files[rel] = cache.get_cached(
                        rel, abs_str, st.st_mtime, st.st_size, st.st_ino
                    )

            cache.prune(set(files))
            cache.save()
            return SnapshotManifest(files=files, domain=_DOMAIN_NAME, directories=[])

        # SnapshotManifest dict path — used by merge / diff in memory
        return live_state

    def diff(
        self,
        base: StateSnapshot,
        target: StateSnapshot,
        *,
        repo_root: pathlib.Path | None = None,
    ) -> StateDelta:
        """Compute the typed operation list between two mist snapshots.

        Delegates to ``snapshot_diff`` which performs set algebra on the
        ``files`` dicts: new mists → InsertOp, removed mists → DeleteOp,
        replaced mists → ReplaceOp.

        Args:
            base:   Snapshot of the earlier state (e.g. HEAD).
            target: Snapshot of the later state (e.g. working tree).

        Returns:
            A ``StructuredDelta`` whose ``ops`` list describes every change.
        """
        return snapshot_diff(self.schema(), base, target)

    def merge(
        self,
        base: StateSnapshot,
        left: StateSnapshot,
        right: StateSnapshot,
        *,
        repo_root: pathlib.Path | None = None,
    ) -> MergeResult:
        """Three-way merge of two mist snapshots against a common ancestor.

        Mists are content-addressed, so set-algebraic merge is correct by
        construction: if both branches added the same bytes, they added the same
        mist and there is no conflict.

        Conflict rules
        ~~~~~~~~~~~~~~
        - Both sides agree → consensus wins.
        - Only one side changed → take that side.
        - Both sides changed differently → conflict (same path, different content).

        Args:
            base:  Common ancestor snapshot.
            left:  Snapshot from the current branch (ours).
            right: Snapshot from the incoming branch (theirs).

        Returns:
            A ``MergeResult`` with ``merged`` snapshot and ``conflicts`` list.
        """
        base_files = base["files"]
        left_files = left["files"]
        right_files = right["files"]

        merged: Manifest = dict(base_files)
        conflicts: list[str] = []

        all_paths = set(base_files) | set(left_files) | set(right_files)
        for path in sorted(all_paths):
            b_val = base_files.get(path)
            l_val = left_files.get(path)
            r_val = right_files.get(path)

            if l_val == r_val:
                # Both sides agree — consensus wins (including both deleted)
                if l_val is None:
                    merged.pop(path, None)
                else:
                    merged[path] = l_val
            elif b_val == l_val:
                # Only right changed
                if r_val is None:
                    merged.pop(path, None)
                else:
                    merged[path] = r_val
            elif b_val == r_val:
                # Only left changed
                if l_val is None:
                    merged.pop(path, None)
                else:
                    merged[path] = l_val
            else:
                # Both changed differently — conflict; keep left as placeholder
                conflicts.append(path)
                merged[path] = l_val or r_val or b_val or ""

        return MergeResult(
            merged=SnapshotManifest(files=merged, domain=_DOMAIN_NAME, directories=[]),
            conflicts=conflicts,
        )

    def drift(self, committed: StateSnapshot, live: LiveState) -> DriftReport:
        """Report how much the mist store has drifted from the last commit.

        Called by ``muse status``.  Snapshots the current working tree, diffs
        it against the committed state, and returns a ``DriftReport``.

        Args:
            committed: The last committed snapshot.
            live:      Current live state (path or snapshot manifest).

        Returns:
            A ``DriftReport`` with ``has_drift``, ``summary``, and ``delta``.
        """
        current = self.snapshot(live)
        delta = self.diff(committed, current)
        has_drift = len(delta["ops"]) > 0
        return DriftReport(
            has_drift=has_drift,
            summary=delta["summary"],
            delta=delta,
        )

    def apply(self, delta: StateDelta, live_state: LiveState) -> LiveState:
        """Apply a delta to the mist store.

        Mists are atomic blobs — the core engine already handles file-level
        object restoration during ``muse checkout``.  No domain-level
        post-processing is needed.

        Args:
            delta:      The typed operation list to apply.
            live_state: Current live state.

        Returns:
            The unchanged live state.
        """
        return live_state

    # ------------------------------------------------------------------
    # Domain schema — required
    # ------------------------------------------------------------------

    def schema(self) -> DomainSchema:
        """Declare the structural shape of the mist domain.

        Mists are a **set** of content-addressed artifacts identified by
        content (same bytes = same mist).  The schema drives diff algorithm
        selection and merge routing.

        Dimensions
        ----------
        ``artifacts``
            The primary dimension: the set of mist files.  Identity is
            ``"by_content"`` — the mist ID *is* the content hash prefix.

        ``metadata``
            A set of key-value annotation pairs (tags, descriptions, provenance
            fields).  Added in Phase 3 when MuseHub-side metadata is versioned.

        Returns:
            A ``DomainSchema`` describing the mist domain's structure.
        """
        return DomainSchema(
            domain=_DOMAIN_NAME,
            description=(
                "Mist domain — content-addressed, signed, agent-native artifact hosting. "
                "A mist is a single versioned artifact (code, MIDI, ABI, or any "
                "binary blob) identified by the first 12 characters of its SHA-256 "
                "base-58 digest. Same bytes = same mist ID, always."
            ),
            top_level=SetSchema(
                kind="set",
                element_type="artifact",
                identity="by_content",
            ),
            dimensions=[
                DimensionSpec(
                    name="artifacts",
                    description=(
                        "The set of mist artifacts in this store. "
                        "Identity is by content — the mist ID is the hash prefix."
                    ),
                    schema=SetSchema(
                        kind="set",
                        element_type="artifact",
                        identity="by_content",
                    ),
                    independent_merge=True,
                ),
                DimensionSpec(
                    name="metadata",
                    description=(
                        "Annotation metadata for mists: tags, descriptions, "
                        "provenance fields (agent_id, model_id, signature)."
                    ),
                    schema=SetSchema(
                        kind="set",
                        element_type="annotation",
                        identity="by_content",
                    ),
                    independent_merge=True,
                ),
            ],
            merge_mode="three_way",
            schema_version=__version__,
        )
