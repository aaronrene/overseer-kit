"""Mist domain plugin — content-addressed, signed, agent-native artifact hosting."""
