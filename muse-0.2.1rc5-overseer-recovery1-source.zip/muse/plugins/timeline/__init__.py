"""Muse video timeline domain plugin (VID-1)."""

from muse.plugins.timeline.plugin import TimelinePlugin, plugin

__all__ = ["TimelinePlugin", "plugin"]
