"""Timeline domain plugin — VID-1 canonical model + snapshot."""

from __future__ import annotations

import os
import pathlib
import stat as _stat

from muse._version import __version__
from muse.core.diff_algorithms import snapshot_diff
from muse.core.schema import (
    DimensionSpec,
    DomainSchema,
    MapSchema,
    SequenceSchema,
    SetSchema,
    TreeSchema,
)
from muse.core.stat_cache import load_cache
from muse.core.types import Manifest
from muse.domain import (
    DriftReport,
    LiveState,
    MergeResult,
    MuseDomainPlugin,
    SnapshotManifest,
    StateDelta,
    StateSnapshot,
    StructuredDelta,
)

from muse.plugins.timeline._otio_bridge import BridgeError, load_otio_json, parse_otio_to_project
from muse.plugins.timeline.entity import IdentifiedProject, assign_identities, project_content_id
from muse.plugins.timeline.manifest import build_timeline_manifest

_DOMAIN_TAG = "timeline"
_OTIO_SUFFIX = ".otio"


class TimelinePlugin:
    """Video timeline domain plugin (OTIO-compatible canonical IR)."""

    def snapshot(self, live_state: LiveState) -> StateSnapshot:
        if isinstance(live_state, pathlib.Path):
            from muse.core.ignore import is_ignored, load_ignore_config, resolve_patterns

            workdir = live_state
            patterns = resolve_patterns(load_ignore_config(workdir), _DOMAIN_TAG)
            cache = load_cache(workdir)
            files: Manifest = {}
            directories: list[str] = []
            projects: dict[str, IdentifiedProject] = {}
            project_hashes: dict[str, str] = {}
            root_str = str(workdir)
            prefix_len = len(root_str) + 1

            for dirpath, dirnames, filenames in os.walk(root_str, followlinks=False):
                dirnames[:] = sorted(d for d in dirnames if not d.startswith("."))
                for fname in sorted(filenames):
                    if fname.startswith(".") or not fname.endswith(_OTIO_SUFFIX):
                        continue
                    abs_str = os.path.join(dirpath, fname)
                    try:
                        st = os.lstat(abs_str)
                    except OSError:
                        continue
                    if not _stat.S_ISREG(st.st_mode):
                        continue
                    rel = abs_str[prefix_len:]
                    if os.sep != "/":
                        rel = rel.replace(os.sep, "/")
                    if is_ignored(rel, patterns):
                        continue
                    otio_path = pathlib.Path(abs_str)
                    raw = load_otio_json(otio_path)
                    project = parse_otio_to_project(raw, otio_path, workdir)
                    cid = project_content_id(project)
                    files[rel] = cid
                    identified = assign_identities(project)
                    projects[rel] = identified
                    project_hashes[rel] = cid

            cache.prune(set(files))
            cache.save()

            snap = SnapshotManifest(files=files, domain=_DOMAIN_TAG, directories=sorted(directories))
            if files:
                manifest = build_timeline_manifest(files, projects, project_hashes, snapshot_id="pending")
                sidecar_dir = workdir / ".muse" / "timeline_manifests"
                sidecar_dir.mkdir(parents=True, exist_ok=True)
                sidecar_path = sidecar_dir / "_latest_build.json"
                import json

                sidecar_path.write_text(
                    json.dumps(manifest, indent=2, sort_keys=True) + "\n"
                )
            return snap

        return live_state

    def diff(
        self,
        base: StateSnapshot,
        target: StateSnapshot,
        *,
        repo_root: pathlib.Path | None = None,
    ) -> StateDelta:
        return snapshot_diff(self.schema(), base, target)

    def merge(
        self,
        base: StateSnapshot,
        left: StateSnapshot,
        right: StateSnapshot,
        *,
        repo_root: pathlib.Path | None = None,
    ) -> MergeResult:
        base_files = base["files"]
        left_files = left["files"]
        right_files = right["files"]
        merged: Manifest = dict(base_files)
        conflicts: list[str] = []
        all_paths = set(base_files) | set(left_files) | set(right_files)
        for path in sorted(all_paths):
            b_val = base_files.get(path)
            l_val = left_files.get(path)
            r_val = right_files.get(path)
            if l_val == r_val:
                if l_val is None:
                    merged.pop(path, None)
                else:
                    merged[path] = l_val
            elif b_val == l_val:
                if r_val is None:
                    merged.pop(path, None)
                else:
                    merged[path] = r_val
            elif b_val == r_val:
                if l_val is None:
                    merged.pop(path, None)
                else:
                    merged[path] = l_val
            else:
                conflicts.append(path)
                merged[path] = l_val or r_val or b_val or ""
        return MergeResult(
            merged=SnapshotManifest(files=merged, domain=_DOMAIN_TAG, directories=[]),
            conflicts=conflicts,
        )

    def drift(self, committed: StateSnapshot, live: LiveState) -> DriftReport:
        current = self.snapshot(live)
        delta = self.diff(committed, current)
        has_drift = len(delta["ops"]) > 0
        return DriftReport(
            has_drift=has_drift,
            summary=delta["summary"],
            delta=delta,
        )

    def apply(self, delta: StateDelta, live_state: LiveState) -> LiveState:
        return live_state

    def schema(self) -> DomainSchema:
        return DomainSchema(
            domain=_DOMAIN_TAG,
            description="Video editing timelines (OTIO-compatible canonical model).",
            top_level=TreeSchema(
                kind="tree",
                node_type="timeline_element",
                diff_algorithm="zhang_shasha",
            ),
            dimensions=[
                DimensionSpec(
                    name="structure",
                    description="Project→sequence→track hierarchy",
                    schema=TreeSchema(
                        kind="tree",
                        node_type="track",
                        diff_algorithm="zhang_shasha",
                    ),
                    independent_merge=False,
                ),
                DimensionSpec(
                    name="clips",
                    description="Ordered clips/gaps/transitions per lane",
                    schema=SequenceSchema(
                        kind="sequence",
                        element_type="clip",
                        identity="by_id",
                        diff_algorithm="myers",
                        alphabet=None,
                    ),
                    independent_merge=True,
                ),
                DimensionSpec(
                    name="effects",
                    description="Clip/track effects + keyframes",
                    schema=SetSchema(
                        kind="set",
                        element_type="effect",
                        identity="by_id",
                    ),
                    independent_merge=True,
                ),
                DimensionSpec(
                    name="markers",
                    description="Markers (union-mergeable)",
                    schema=SetSchema(
                        kind="set",
                        element_type="marker",
                        identity="by_id",
                    ),
                    independent_merge=True,
                ),
                DimensionSpec(
                    name="captions",
                    description="Subtitle/caption events",
                    schema=SequenceSchema(
                        kind="sequence",
                        element_type="caption",
                        identity="by_id",
                        diff_algorithm="myers",
                        alphabet=None,
                    ),
                    independent_merge=True,
                ),
                DimensionSpec(
                    name="media_pool",
                    description="Deduplicated source media assets",
                    schema=MapSchema(
                        kind="map",
                        key_type="content_id",
                        value_schema=SetSchema(
                            kind="set",
                            element_type="external_reference",
                            identity="by_content",
                        ),
                        identity="by_key",
                    ),
                    independent_merge=True,
                ),
            ],
            merge_mode="three_way",
            schema_version=__version__,
        )


plugin = TimelinePlugin()

__all__ = ["TimelinePlugin", "plugin", "BridgeError"]
