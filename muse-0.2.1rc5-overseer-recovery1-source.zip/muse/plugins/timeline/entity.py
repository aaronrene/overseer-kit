"""Canonical timeline IR dataclasses and stable identity (VID-1 §1, §3)."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Literal

from muse.core.types import JsonObject, JsonValue, content_hash

from muse.plugins.timeline.rational_time import (
    RationalTime,
    TimeRange,
    canonical_rational_time,
)

type MetadataValue = str
type Metadata = tuple[tuple[str, MetadataValue], ...]


def meta_get(md: Metadata, key: str) -> str | None:
    for k, v in md:
        if k == key:
            return v
    return None


def canonical_metadata(md: Metadata) -> list[tuple[str, str]]:
    return list(md)


def canonical_time_range(tr: TimeRange | None) -> str:
    if tr is None:
        return ""
    return (
        f"{canonical_rational_time(tr.start_time)}/"
        f"{canonical_rational_time(tr.duration)}"
    )


@dataclass(frozen=True, slots=True)
class ExternalReference:
    target_url: str
    available_range: TimeRange | None
    essence_hash: str | None
    is_offline: bool
    metadata: Metadata


@dataclass(frozen=True, slots=True)
class ColorMetadata:
    color_space: str
    transfer_function: str
    primaries: str
    color_range: Literal["full", "legal", "unknown"]
    lut_ref: ExternalReference | None
    metadata: Metadata


@dataclass(frozen=True, slots=True)
class SourceMedia:
    content_id: str
    name: str
    references: tuple[tuple[str, ExternalReference], ...]
    active_reference_key: str
    available_range: TimeRange | None
    color: ColorMetadata | None
    metadata: Metadata


@dataclass(frozen=True, slots=True)
class RenderCacheMetadata:
    source_range: TimeRange
    output_ref: ExternalReference | None
    cache_key: str
    is_valid: bool
    metadata: Metadata


@dataclass(frozen=True, slots=True)
class Keyframe:
    time: RationalTime
    value: str
    interpolation: Literal["hold", "linear", "bezier", "constant"]
    metadata: Metadata


@dataclass(frozen=True, slots=True)
class Effect:
    name: str
    effect_type: str
    parameters: tuple[tuple[str, str], ...]
    keyframes: tuple[Keyframe, ...]
    metadata: Metadata


@dataclass(frozen=True, slots=True)
class Marker:
    name: str
    marked_range: TimeRange
    color: str
    comment: str
    metadata: Metadata


@dataclass(frozen=True, slots=True)
class Caption:
    text: str
    marked_range: TimeRange
    style: str
    metadata: Metadata


@dataclass(frozen=True, slots=True)
class Gap:
    duration: RationalTime
    metadata: Metadata


@dataclass(frozen=True, slots=True)
class Clip:
    name: str
    source_media_id: str
    source_range: TimeRange
    enabled: bool
    effects: tuple[Effect, ...]
    markers: tuple[Marker, ...]
    color: ColorMetadata | None
    nested_sequence_id: str | None
    metadata: Metadata


@dataclass(frozen=True, slots=True)
class Transition:
    transition_type: str
    in_offset: RationalTime
    out_offset: RationalTime
    metadata: Metadata


type TrackItem = Clip | Gap | Transition


@dataclass(frozen=True, slots=True)
class Track:
    name: str
    kind: Literal["video", "subtitle"]
    ordinal: int
    enabled: bool
    items: tuple[TrackItem, ...]
    captions: tuple[Caption, ...]
    metadata: Metadata


@dataclass(frozen=True, slots=True)
class AudioLane:
    name: str
    ordinal: int
    enabled: bool
    sample_rate: int
    channel_count: int
    channel_layout: str
    items: tuple[TrackItem, ...]
    metadata: Metadata


@dataclass(frozen=True, slots=True)
class Sequence:
    name: str
    ordinal: int
    global_start_time: RationalTime | None
    video_tracks: tuple[Track, ...]
    audio_lanes: tuple[AudioLane, ...]
    subtitle_tracks: tuple[Track, ...]
    markers: tuple[Marker, ...]
    metadata: Metadata


@dataclass(frozen=True, slots=True)
class Project:
    project_key: str
    name: str
    sequences: tuple[Sequence, ...]
    media_pool: tuple[SourceMedia, ...]
    render_cache: tuple[RenderCacheMetadata, ...]
    metadata: Metadata


@dataclass(frozen=True, slots=True)
class IdentifiedClip:
    clip: Clip
    clip_id: str
    occurrence: int


@dataclass(frozen=True, slots=True)
class IdentifiedTrack:
    track: Track | AudioLane
    track_identity: str
    kind: Literal["video", "audio", "subtitle"]
    clips: tuple[IdentifiedClip, ...]


@dataclass(frozen=True, slots=True)
class IdentifiedSequence:
    sequence: Sequence
    sequence_identity: str
    tracks: tuple[IdentifiedTrack, ...]


@dataclass(frozen=True, slots=True)
class IdentifiedProject:
    project: Project
    sequences: tuple[IdentifiedSequence, ...]
    media_ids: dict[str, str]


def media_content_id(
    target_url: str,
    available_range: TimeRange | None,
    essence_hash: str | None,
) -> str:
    return content_hash(
        {
            "essence_hash": essence_hash or "",
            "target_url": target_url,
            "available_range": canonical_time_range(available_range),
        }
    )


def project_identity(project_key: str) -> str:
    return project_key


def sequence_identity(project_key: str, name: str, ordinal: int) -> str:
    return content_hash(
        {"project": project_key, "name": name, "ordinal": ordinal}
    )


def track_identity(
    sequence_id: str,
    kind: Literal["video", "audio", "subtitle"],
    ordinal: int,
) -> str:
    return content_hash(
        {"sequence": sequence_id, "kind": kind, "ordinal": ordinal}
    )


def clip_identity(
    track_id: str,
    source_media_id: str,
    source_range: TimeRange,
    occurrence: int,
) -> str:
    return content_hash(
        {
            "track": track_id,
            "media": source_media_id,
            "src_in": canonical_rational_time(source_range.start_time),
            "src_dur": canonical_rational_time(source_range.duration),
            "occurrence": occurrence,
        }
    )


def _clip_fingerprint(clip: Clip) -> tuple[str, str, str]:
    return (
        clip.source_media_id,
        canonical_rational_time(clip.source_range.start_time),
        canonical_rational_time(clip.source_range.duration),
    )


def assign_clip_occurrences(
    track_id: str,
    items: tuple[TrackItem, ...],
) -> dict[int, tuple[str, int]]:
    """Return mapping item_index → (clip_id, occurrence) for Clip items."""
    result: dict[int, tuple[str, int]] = {}
    counters: dict[tuple[str, str, str], int] = {}
    for idx, item in enumerate(items):
        if not isinstance(item, Clip):
            continue
        fp = _clip_fingerprint(item)
        occ = counters.get(fp, 0)
        counters[fp] = occ + 1
        cid = clip_identity(track_id, item.source_media_id, item.source_range, occ)
        result[idx] = (cid, occ)
    return result


def assign_identities(project: Project) -> IdentifiedProject:
    """Top-down identity assignment (VID-1 §3)."""
    pkey = project.project_key
    id_sequences: list[IdentifiedSequence] = []
    for seq in project.sequences:
        seq_id = sequence_identity(pkey, seq.name, seq.ordinal)
        id_tracks: list[IdentifiedTrack] = []
        for tr in seq.video_tracks:
            tid = track_identity(seq_id, "video", tr.ordinal)
            occ_map = assign_clip_occurrences(tid, tr.items)
            id_clips = tuple(
                IdentifiedClip(
                    clip=item,
                    clip_id=occ_map[idx][0],
                    occurrence=occ_map[idx][1],
                )
                for idx, item in enumerate(tr.items)
                if isinstance(item, Clip) and idx in occ_map
            )
            id_tracks.append(
                IdentifiedTrack(track=tr, track_identity=tid, kind="video", clips=id_clips)
            )
        for lane in seq.audio_lanes:
            tid = track_identity(seq_id, "audio", lane.ordinal)
            occ_map = assign_clip_occurrences(tid, lane.items)
            id_clips = tuple(
                IdentifiedClip(
                    clip=item,
                    clip_id=occ_map[idx][0],
                    occurrence=occ_map[idx][1],
                )
                for idx, item in enumerate(lane.items)
                if isinstance(item, Clip) and idx in occ_map
            )
            id_tracks.append(
                IdentifiedTrack(
                    track=lane, track_identity=tid, kind="audio", clips=id_clips
                )
            )
        for tr in seq.subtitle_tracks:
            tid = track_identity(seq_id, "subtitle", tr.ordinal)
            occ_map = assign_clip_occurrences(tid, tr.items)
            id_clips = tuple(
                IdentifiedClip(
                    clip=item,
                    clip_id=occ_map[idx][0],
                    occurrence=occ_map[idx][1],
                )
                for idx, item in enumerate(tr.items)
                if isinstance(item, Clip) and idx in occ_map
            )
            id_tracks.append(
                IdentifiedTrack(
                    track=tr, track_identity=tid, kind="subtitle", clips=id_clips
                )
            )
        id_sequences.append(
            IdentifiedSequence(
                sequence=seq, sequence_identity=seq_id, tracks=tuple(id_tracks)
            )
        )
    media_ids = {m.content_id: m.content_id for m in project.media_pool}
    return IdentifiedProject(
        project=project,
        sequences=tuple(id_sequences),
        media_ids=media_ids,
    )


def _metadata_dict(md: Metadata) -> JsonObject:
    return {k: v for k, v in md}


def project_canonical_dict(project: Project) -> JsonObject:
    """Canonical serialisable dict for content_hash (VID-1 §4)."""
    identified = assign_identities(project)
    sequences_out: list[JsonValue] = []
    for id_seq in identified.sequences:
        seq = id_seq.sequence
        tracks_out: list[JsonValue] = []
        for id_tr in id_seq.tracks:
            clips_out: list[JsonValue] = [
                {
                    "clip_id": ic.clip_id,
                    "name": ic.clip.name,
                    "source_media_id": ic.clip.source_media_id,
                    "occurrence": ic.occurrence,
                }
                for ic in id_tr.clips
            ]
            track_entry: JsonObject = {
                "track_identity": id_tr.track_identity,
                "kind": id_tr.kind,
                "ordinal": id_tr.track.ordinal,
                "name": id_tr.track.name,
                "clips": clips_out,
            }
            tracks_out.append(track_entry)
        seq_entry: JsonObject = {
            "sequence_identity": id_seq.sequence_identity,
            "name": seq.name,
            "ordinal": seq.ordinal,
            "tracks": tracks_out,
        }
        sequences_out.append(seq_entry)
    media_out: list[JsonValue] = [
        {
            "content_id": m.content_id,
            "name": m.name,
            "active_reference_key": m.active_reference_key,
        }
        for m in sorted(project.media_pool, key=lambda x: x.content_id)
    ]
    render_out: list[JsonValue] = [
        {
            "cache_key": rc.cache_key,
            "source_range": canonical_time_range(rc.source_range),
        }
        for rc in sorted(
            project.render_cache,
            key=lambda r: (
                canonical_time_range(r.source_range),
                r.cache_key,
            ),
        )
    ]
    return {
        "project_key": project.project_key,
        "name": project.name,
        "metadata": _metadata_dict(project.metadata),
        "sequences": sequences_out,
        "media_pool": media_out,
        "render_cache": render_out,
    }


def project_content_id(project: Project) -> str:
    return content_hash(project_canonical_dict(project))


def stringify_metadata_value(value: JsonValue) -> str:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    )
