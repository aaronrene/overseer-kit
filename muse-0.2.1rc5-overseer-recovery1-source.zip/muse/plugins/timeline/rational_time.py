"""Exact rational time types for the Muse timeline domain (VID-1 §2)."""

from __future__ import annotations

import math
from dataclasses import dataclass
from fractions import Fraction

# Frozen NTSC float → exact rational table (VID-1 §2).
_NTSC_FLOAT_TABLE: dict[float, tuple[int, int]] = {
    23.976: (24000, 1001),
    23.98: (24000, 1001),
    29.97: (30000, 1001),
    59.94: (60000, 1001),
    47.952: (48000, 1001),
}

_DROP_FRAME_RATES: frozenset[tuple[int, int]] = frozenset(
    {(30000, 1001), (60000, 1001)}
)


def _drop_frame_nominal(rate: RationalRate) -> int:
    if (rate.num, rate.den) == (60000, 1001):
        return 60
    return 30


def _drop_per_minute(rate: RationalRate) -> int:
    return 4 if _drop_frame_nominal(rate) == 60 else 2


def _frames_from_drop_frame_timecode(
    hours: int,
    minutes: int,
    seconds: int,
    frames: int,
    rate: RationalRate,
) -> int:
    nominal = _drop_frame_nominal(rate)
    drop_per_min = _drop_per_minute(rate)
    total = (hours * 3600 + minutes * 60 + seconds) * nominal + frames
    drops = drop_per_min * (minutes - minutes // 10)
    return total - drops


def _drop_frame_timecode_from_frames(frames: int, rate: RationalRate) -> str:
    nominal = _drop_frame_nominal(rate)
    drop_per_min = _drop_per_minute(rate)
    frames_per_10_min = nominal * 600 - drop_per_min * 9
    frames_per_min = nominal * 60 - drop_per_min

    d = frames // frames_per_10_min
    remaining = frames - d * frames_per_10_min

    minutes_in_ten = remaining // frames_per_min
    remaining %= frames_per_min

    seconds = remaining // nominal
    frame_rem = remaining % nominal

    total_minutes = d * 10 + minutes_in_ten
    hours = total_minutes // 60
    minutes = total_minutes % 60

    return f"{hours:02d}:{minutes:02d}:{seconds:02d};{frame_rem:02d}"


@dataclass(frozen=True, slots=True)
class RationalRate:
    """Exact frame/sample rate as a reduced positive rational num/den."""

    num: int
    den: int

    def __post_init__(self) -> None:
        if self.den <= 0:
            raise ValueError("RationalRate.den must be positive")
        if self.num <= 0:
            raise ValueError("RationalRate.num must be positive")
        g = math.gcd(self.num, self.den)
        if g != 1:
            object.__setattr__(self, "num", self.num // g)
            object.__setattr__(self, "den", self.den // g)

    @classmethod
    def from_float(cls, fps: float) -> RationalRate:
        """Map a float rate to an exact rational (VID-1 §2 table)."""
        for key, pair in _NTSC_FLOAT_TABLE.items():
            if abs(fps - key) < 1e-9:
                return cls(num=pair[0], den=pair[1])
        if abs(fps - round(fps)) < 1e-9:
            return cls(num=int(round(fps)), den=1)
        frac = Fraction(fps).limit_denominator(1001)
        if abs(float(frac) - fps) > 1e-6:
            raise ValueError(f"undeclared fractional rate: {fps}")
        g = math.gcd(frac.numerator, frac.denominator)
        return cls(num=frac.numerator // g, den=frac.denominator // g)

    def __str__(self) -> str:
        if self.den == 1:
            return str(self.num)
        return f"{self.num}/{self.den}"


@dataclass(frozen=True, slots=True)
class RationalTime:
    """Exact instant/duration: integer ticks at an exact rate."""

    value: int
    rate: RationalRate

    @classmethod
    def from_frames(cls, frames: int, rate: RationalRate) -> RationalTime:
        return cls(value=frames, rate=rate)

    @classmethod
    def from_timecode(
        cls,
        tc: str,
        rate: RationalRate,
        *,
        drop_frame: bool | None = None,
    ) -> RationalTime:
        """Parse HH:MM:SS:FF or HH:MM:SS;FF timecode at *rate*."""
        use_df = drop_frame
        if ";" in tc:
            main, frames_str = tc.rsplit(";", 1)
            parts = main.split(":")
            if len(parts) != 3:
                raise ValueError(f"invalid timecode: {tc!r}")
            hours = int(parts[0])
            minutes = int(parts[1])
            seconds = int(parts[2])
            frames = int(frames_str)
            if use_df is False:
                raise ValueError("drop-frame separator with drop_frame=False")
            use_df = True
        else:
            parts = tc.split(":")
            if len(parts) != 4:
                raise ValueError(f"invalid timecode: {tc!r}")
            hours = int(parts[0])
            minutes = int(parts[1])
            seconds = int(parts[2])
            frames = int(parts[3])
        if use_df is None:
            use_df = (rate.num, rate.den) in _DROP_FRAME_RATES
        if use_df:
            frame_number = _frames_from_drop_frame_timecode(
                hours, minutes, seconds, frames, rate
            )
        else:
            if ";" in tc:
                raise ValueError("non-drop timecode cannot use ';' separator")
            fps_num = rate.num
            fps_den = rate.den
            frame_number = (
                (hours * 3600 + minutes * 60 + seconds) * fps_num + frames * fps_den
            ) // fps_den
        return cls(value=frame_number, rate=rate)

    def to_fraction_seconds(self) -> Fraction:
        return Fraction(self.value * self.rate.den, self.rate.num)

    def rescaled_to(self, rate: RationalRate) -> RationalTime:
        numerator = self.value * rate.num * self.rate.den
        denominator = self.rate.num * rate.den
        if numerator % denominator != 0:
            raise ValueError("non-exact rescale")
        return RationalTime(value=numerator // denominator, rate=rate)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, RationalTime):
            return NotImplemented
        left = self.value * self.rate.den * other.rate.num
        right = other.value * other.rate.den * self.rate.num
        return left == right

    def __lt__(self, other: RationalTime) -> bool:
        left = self.value * self.rate.den * other.rate.num
        right = other.value * other.rate.den * self.rate.num
        return left < right

    def __le__(self, other: RationalTime) -> bool:
        return self == other or self < other

    def __gt__(self, other: RationalTime) -> bool:
        return other < self

    def __ge__(self, other: RationalTime) -> bool:
        return self == other or self > other

    def __hash__(self) -> int:
        frac = self.to_fraction_seconds()
        return hash((frac.numerator, frac.denominator))

    def is_identical(self, other: RationalTime) -> bool:
        return self.value == other.value and self.rate == other.rate

    def to_frames(self) -> int:
        return self.value

    def to_timecode(self, *, drop_frame: bool | None = None) -> str:
        use_df = drop_frame
        if use_df is None:
            use_df = (self.rate.num, self.rate.den) in _DROP_FRAME_RATES
        if use_df:
            return _drop_frame_timecode_from_frames(self.value, self.rate)
        fps = self.rate.num // self.rate.den if self.rate.den == 1 else None
        if fps is None:
            total_seconds_frac = self.to_fraction_seconds()
            total_frames = self.value
            total_seconds = int(total_seconds_frac)
            frame_rem = total_frames - total_seconds * (self.rate.num // self.rate.den)
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            seconds = total_seconds % 60
            return f"{hours:02d}:{minutes:02d}:{seconds:02d}:{frame_rem:02d}"
        total_seconds = self.value // fps
        frame_rem = self.value % fps
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}:{frame_rem:02d}"


@dataclass(frozen=True, slots=True)
class TimeRange:
    """Half-open range [start_time, start_time + duration)."""

    start_time: RationalTime
    duration: RationalTime

    def __post_init__(self) -> None:
        if self.duration.value < 0:
            raise ValueError("TimeRange duration must be non-negative")

    @property
    def end_time_exclusive(self) -> RationalTime:
        end_frac = self.start_time.to_fraction_seconds() + self.duration.to_fraction_seconds()
        return _time_from_fraction(end_frac, self.start_time.rate)

    def end_time_inclusive(self) -> RationalTime | None:
        if self.duration.value == 0:
            return None
        end_frac = (
            self.start_time.to_fraction_seconds()
            + self.duration.to_fraction_seconds()
            - Fraction(1, 1) / Fraction(self.start_time.rate.num, self.start_time.rate.den)
        )
        return _time_from_fraction(end_frac, self.start_time.rate)

    def contains(self, instant: RationalTime) -> bool:
        return self.start_time <= instant and instant < self.end_time_exclusive

    def overlaps(self, other: TimeRange) -> bool:
        return (
            self.start_time < other.end_time_exclusive
            and other.start_time < self.end_time_exclusive
        )


def _time_from_fraction(frac: Fraction, rate: RationalRate) -> RationalTime:
    num = frac.numerator * rate.num
    den = frac.denominator * rate.den
    if num % den != 0:
        raise ValueError("non-exact rational time conversion")
    return RationalTime(value=num // den, rate=rate)


def canonical_rational_time(rt: RationalTime) -> str:
    """Rate-agnostic canonical hash form (VID-1 §2)."""
    frac = rt.to_fraction_seconds()
    return f"{frac.numerator}/{frac.denominator}"
