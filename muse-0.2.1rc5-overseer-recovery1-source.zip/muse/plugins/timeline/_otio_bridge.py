"""Pure-JSON OTIO bridge — no compiled opentimelineio (VID-1 §5)."""

from __future__ import annotations

import json
import pathlib
from typing import Literal

from muse.core.types import JsonObject, JsonValue, load_json_file

from muse.plugins.timeline.entity import (
    AudioLane,
    Caption,
    Clip,
    Effect,
    ExternalReference,
    Gap,
    Keyframe,
    Marker,
    Metadata,
    Project,
    Sequence,
    SourceMedia,
    Track,
    TrackItem,
    Transition,
    media_content_id,
    meta_get,
    stringify_metadata_value,
)
from muse.plugins.timeline.rational_time import RationalRate, RationalTime, TimeRange

_VOLATILE_METADATA_KEYS: frozenset[str] = frozenset(
    {"generator", "otio_schema_version", "created", "modified", "timestamp"}
)

_KNOWN_SCHEMA_PREFIXES: frozenset[str] = frozenset(
    {
        "Timeline.",
        "Stack.",
        "Track.",
        "Clip.",
        "Gap.",
        "Transition.",
        "ExternalReference.",
        "MissingReference.",
        "RationalTime.",
        "TimeRange.",
        "SerializableCollection.",
        "Effect.",
        "Marker.",
    }
)


class BridgeError(Exception):
    """Raised when OTIO JSON cannot be bridged to the canonical IR."""


def load_otio_json(path: pathlib.Path) -> JsonObject:
    raw = load_json_file(path)
    if raw is None or not isinstance(raw, dict):
        raise BridgeError(f"invalid OTIO JSON: {path}")
    return raw


def _schema_version(obj: JsonObject) -> tuple[str, int]:
    schema = obj.get("OTIO_SCHEMA")
    if not isinstance(schema, str) or "." not in schema:
        raise BridgeError("missing OTIO_SCHEMA")
    name, ver_str = schema.rsplit(".", 1)
    if not ver_str.isdigit():
        raise BridgeError(f"invalid OTIO_SCHEMA version: {schema}")
    known = any(schema.startswith(p) for p in _KNOWN_SCHEMA_PREFIXES)
    if not known:
        raise BridgeError(f"unknown OTIO_SCHEMA family: {schema}")
    return name, int(ver_str)


def _check_schema(obj: JsonObject, family: str, max_version: int = 99) -> None:
    name, ver = _schema_version(obj)
    if name != family:
        raise BridgeError(f"expected {family}, got {name}")
    if ver > max_version:
        raise BridgeError(f"unsupported {family} version {ver}")


def _parse_rate(raw: JsonValue) -> RationalRate:
    if isinstance(raw, (int, float)):
        return RationalRate.from_float(float(raw))
    if isinstance(raw, dict):
        val = raw.get("value", raw.get("num"))
        den = raw.get("rate", raw.get("den", 1))
        if isinstance(val, (int, float)) and isinstance(den, (int, float)):
            if float(den) == 1.0:
                return RationalRate.from_float(float(val))
            num_i = int(val)
            den_i = int(den)
            return RationalRate(num=num_i, den=den_i)
    raise BridgeError("invalid rate in RationalTime")


def _exact_int(value: JsonValue, field: str) -> int:
    if isinstance(value, bool):
        raise BridgeError(f"non-integral {field}")
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        rounded = round(value)
        if abs(value - rounded) > 1e-9:
            raise BridgeError(f"non-integral {field}: {value}")
        return int(rounded)
    raise BridgeError(f"invalid {field}")


def _parse_rational_time(obj: JsonObject) -> RationalTime:
    _check_schema(obj, "RationalTime")
    rate = _parse_rate(obj.get("rate", 1))
    value = _exact_int(obj["value"], "RationalTime.value")
    return RationalTime(value=value, rate=rate)


def _parse_time_range(obj: JsonObject | None) -> TimeRange | None:
    if obj is None:
        return None
    _check_schema(obj, "TimeRange")
    start_raw = obj.get("start_time")
    dur_raw = obj.get("duration")
    if not isinstance(start_raw, dict) or not isinstance(dur_raw, dict):
        raise BridgeError("invalid TimeRange")
    return TimeRange(
        start_time=_parse_rational_time(start_raw),
        duration=_parse_rational_time(dur_raw),
    )


def _canonicalize_metadata(raw: JsonValue) -> Metadata:
    if not isinstance(raw, dict):
        return ()
    pairs: list[tuple[str, str]] = []
    for key in sorted(raw.keys()):
        if key in _VOLATILE_METADATA_KEYS or key.endswith("_abspath"):
            continue
        pairs.append((key, stringify_metadata_value(raw[key])))
    return tuple(pairs)


def _relativise_url(
    target_url: str,
    otio_path: pathlib.Path,
    repo_root: pathlib.Path | None,
) -> str:
    if "://" in target_url:
        return target_url
    if ".." in pathlib.PurePosixPath(target_url.replace("\\", "/")).parts:
        raise BridgeError(f"path traversal in target_url: {target_url!r}")
    if repo_root is None:
        return target_url.replace("\\", "/")
    if target_url.startswith("file://"):
        path_part = target_url[7:]
    else:
        path_part = target_url
    candidate = pathlib.Path(path_part)
    if not candidate.is_absolute():
        candidate = (otio_path.parent / candidate).resolve()
    try:
        rel = candidate.relative_to(repo_root.resolve())
    except ValueError:
        return target_url.replace("\\", "/")
    return rel.as_posix()


def _parse_external_reference(
    obj: JsonObject,
    otio_path: pathlib.Path,
    repo_root: pathlib.Path | None,
    *,
    force_offline: bool = False,
) -> ExternalReference:
    _check_schema(obj, "ExternalReference")
    raw_url = obj.get("target_url", "")
    if not isinstance(raw_url, str):
        raise BridgeError("ExternalReference.target_url must be string")
    url = _relativise_url(raw_url, otio_path, repo_root)
    is_offline = force_offline
    if repo_root is not None and not force_offline and "://" not in url:
        resolved = repo_root / url
        is_offline = not resolved.exists()
    md = _canonicalize_metadata(obj.get("metadata"))
    essence = meta_get(md, "essence_hash")
    return ExternalReference(
        target_url=url,
        available_range=_parse_time_range(
            obj.get("available_range")  # type: ignore[arg-type]
            if isinstance(obj.get("available_range"), dict)
            else None
        ),
        essence_hash=essence,
        is_offline=is_offline,
        metadata=md,
    )


def _parse_media_reference(
    obj: JsonObject | None,
    otio_path: pathlib.Path,
    repo_root: pathlib.Path | None,
) -> ExternalReference:
    if obj is None:
        raise BridgeError("clip missing media_reference")
    schema = obj.get("OTIO_SCHEMA", "")
    if isinstance(schema, str) and schema.startswith("MissingReference"):
        _schema_version(obj)
        return ExternalReference(
            target_url="",
            available_range=None,
            essence_hash=None,
            is_offline=True,
            metadata=_canonicalize_metadata(obj.get("metadata")),
        )
    return _parse_external_reference(obj, otio_path, repo_root)


def _parse_keyframe(obj: JsonObject) -> Keyframe:
    time_obj = obj.get("time")
    if not isinstance(time_obj, dict):
        raise BridgeError("invalid keyframe time")
    interp_raw = obj.get("interpolation", "linear")
    interp = str(interp_raw) if isinstance(interp_raw, str) else "linear"
    if interp not in ("hold", "linear", "bezier", "constant"):
        interp = "linear"
    return Keyframe(
        time=_parse_rational_time(time_obj),
        value=stringify_metadata_value(obj.get("value", "")),
        interpolation=interp,  # type: ignore[arg-type]
        metadata=_canonicalize_metadata(obj.get("metadata")),
    )


def _parse_effect(obj: JsonObject) -> Effect:
    _check_schema(obj, "Effect")
    params_raw = obj.get("parameters")
    params: list[tuple[str, str]] = []
    if isinstance(params_raw, dict):
        for k in sorted(params_raw):
            if isinstance(k, str):
                params.append((k, stringify_metadata_value(params_raw[k])))
    kf_raw = obj.get("keyframes")
    keyframes: list[Keyframe] = []
    if isinstance(kf_raw, list):
        for item in kf_raw:
            if isinstance(item, dict):
                keyframes.append(_parse_keyframe(item))
    keyframes.sort(key=lambda k: (k.time, k.value))
    return Effect(
        name=str(obj.get("name", "")),
        effect_type=str(obj.get("effect_name", obj.get("name", "Effect"))),
        parameters=tuple(params),
        keyframes=tuple(keyframes),
        metadata=_canonicalize_metadata(obj.get("metadata")),
    )


def _parse_marker(obj: JsonObject) -> Marker:
    _check_schema(obj, "Marker")
    marked = obj.get("marked_range")
    if not isinstance(marked, dict):
        raise BridgeError("marker missing marked_range")
    return Marker(
        name=str(obj.get("name", "")),
        marked_range=_parse_time_range(marked) or TimeRange(
            start_time=RationalTime(0, RationalRate(24, 1)),
            duration=RationalTime(0, RationalRate(24, 1)),
        ),
        color=str(obj.get("color", "")),
        comment=str(obj.get("comment", "")),
        metadata=_canonicalize_metadata(obj.get("metadata")),
    )


def _parse_caption(obj: JsonObject, default_rate: RationalRate) -> Caption:
    marked = obj.get("marked_range")
    if isinstance(marked, dict):
        tr = _parse_time_range(marked)
    else:
        tr = None
    if tr is None:
        tr = TimeRange(
            start_time=RationalTime(0, default_rate),
            duration=RationalTime(0, default_rate),
        )
    return Caption(
        text=str(obj.get("text", obj.get("name", ""))),
        marked_range=tr,
        style=str(obj.get("style", "")),
        metadata=_canonicalize_metadata(obj.get("metadata")),
    )


def _parse_transition(obj: JsonObject, default_rate: RationalRate) -> Transition:
    _check_schema(obj, "Transition")
    in_off = obj.get("in_offset")
    out_off = obj.get("out_offset")
    in_rt = (
        _parse_rational_time(in_off)
        if isinstance(in_off, dict)
        else RationalTime(0, default_rate)
    )
    out_rt = (
        _parse_rational_time(out_off)
        if isinstance(out_off, dict)
        else RationalTime(0, default_rate)
    )
    return Transition(
        transition_type=str(obj.get("transition_type", obj.get("name", ""))),
        in_offset=in_rt,
        out_offset=out_rt,
        metadata=_canonicalize_metadata(obj.get("metadata")),
    )


def _parse_gap(obj: JsonObject, default_rate: RationalRate) -> Gap:
    _check_schema(obj, "Gap")
    sr = obj.get("source_range")
    if isinstance(sr, dict):
        tr = _parse_time_range(sr)
        if tr is not None:
            return Gap(duration=tr.duration, metadata=_canonicalize_metadata(obj.get("metadata")))
    dur = obj.get("duration")
    if isinstance(dur, dict):
        return Gap(
            duration=_parse_rational_time(dur),
            metadata=_canonicalize_metadata(obj.get("metadata")),
        )
    return Gap(
        duration=RationalTime(0, default_rate),
        metadata=_canonicalize_metadata(obj.get("metadata")),
    )


def _parse_clip(
    obj: JsonObject,
    media_pool: dict[str, SourceMedia],
    otio_path: pathlib.Path,
    repo_root: pathlib.Path | None,
    nested_map: dict[str, str],
) -> Clip:
    _check_schema(obj, "Clip")
    media_ref = obj.get("media_reference")
    ext = _parse_media_reference(
        media_ref if isinstance(media_ref, dict) else None,
        otio_path,
        repo_root,
    )
    mid = media_content_id(ext.target_url, ext.available_range, ext.essence_hash)
    if mid not in media_pool:
        media_pool[mid] = SourceMedia(
            content_id=mid,
            name=str(obj.get("name", mid)),
            references=(("default", ext),),
            active_reference_key="default",
            available_range=ext.available_range,
            color=None,
            metadata=(),
        )
    sr = obj.get("source_range")
    if not isinstance(sr, dict):
        raise BridgeError("clip missing source_range")
    source_range = _parse_time_range(sr)
    if source_range is None:
        raise BridgeError("invalid clip source_range")
    effects_raw = obj.get("effects")
    effects: list[Effect] = []
    if isinstance(effects_raw, list):
        for ef in effects_raw:
            if isinstance(ef, dict):
                effects.append(_parse_effect(ef))
    effects.sort(key=lambda e: (e.effect_type, e.name))
    markers_raw = obj.get("markers")
    markers: list[Marker] = []
    if isinstance(markers_raw, list):
        for mk in markers_raw:
            if isinstance(mk, dict):
                markers.append(_parse_marker(mk))
    markers.sort(key=lambda m: (m.marked_range.start_time, m.name))
    nested_id: str | None = None
    md = _canonicalize_metadata(obj.get("metadata"))
    nested_meta = meta_get(md, "nested_sequence_id")
    if nested_meta:
        nested_id = nested_meta
    active_ref = obj.get("active_media_reference_key")
    if isinstance(active_ref, str) and active_ref in nested_map:
        nested_id = nested_map[active_ref]
    return Clip(
        name=str(obj.get("name", "")),
        source_media_id=mid,
        source_range=source_range,
        enabled=bool(obj.get("enabled", True)),
        effects=tuple(effects),
        markers=tuple(markers),
        color=None,
        nested_sequence_id=nested_id,
        metadata=_canonicalize_metadata(obj.get("metadata")),
    )


def _parse_track_items(
    children: list[JsonValue],
    media_pool: dict[str, SourceMedia],
    otio_path: pathlib.Path,
    repo_root: pathlib.Path | None,
    nested_map: dict[str, str],
    default_rate: RationalRate,
) -> tuple[TrackItem, ...]:
    items: list[TrackItem] = []
    for child in children:
        if not isinstance(child, dict):
            continue
        schema = child.get("OTIO_SCHEMA", "")
        if not isinstance(schema, str):
            continue
        if schema.startswith("Clip."):
            items.append(_parse_clip(child, media_pool, otio_path, repo_root, nested_map))
        elif schema.startswith("Gap."):
            items.append(_parse_gap(child, default_rate))
        elif schema.startswith("Transition."):
            items.append(_parse_transition(child, default_rate))
    return tuple(items)


def _track_kind(raw: JsonValue) -> Literal["video", "subtitle"]:
    if isinstance(raw, str) and raw.lower() in ("subtitle", "subtitles", "caption"):
        return "subtitle"
    return "video"


def _parse_track(
    obj: JsonObject,
    ordinal: int,
    media_pool: dict[str, SourceMedia],
    otio_path: pathlib.Path,
    repo_root: pathlib.Path | None,
    nested_map: dict[str, str],
    default_rate: RationalRate,
) -> Track:
    _check_schema(obj, "Track")
    kind = _track_kind(obj.get("kind"))
    children = obj.get("children")
    child_list = children if isinstance(children, list) else []
    items = _parse_track_items(
        child_list, media_pool, otio_path, repo_root, nested_map, default_rate
    )
    caps_raw = obj.get("metadata", {})
    captions: list[Caption] = []
    if isinstance(caps_raw, dict):
        cap_list = caps_raw.get("captions")
        if isinstance(cap_list, list):
            for cap in cap_list:
                if isinstance(cap, dict):
                    captions.append(_parse_caption(cap, default_rate))
    captions.sort(key=lambda c: (c.marked_range.start_time, c.text))
    return Track(
        name=str(obj.get("name", f"track_{ordinal}")),
        kind=kind,
        ordinal=ordinal,
        enabled=bool(obj.get("enabled", True)),
        items=items,
        captions=tuple(captions),
        metadata=_canonicalize_metadata(obj.get("metadata")),
    )


def _parse_audio_lane(
    obj: JsonObject,
    ordinal: int,
    media_pool: dict[str, SourceMedia],
    otio_path: pathlib.Path,
    repo_root: pathlib.Path | None,
    nested_map: dict[str, str],
    default_rate: RationalRate,
) -> AudioLane:
    _check_schema(obj, "Track")
    children = obj.get("children")
    child_list = children if isinstance(children, list) else []
    items = _parse_track_items(
        child_list, media_pool, otio_path, repo_root, nested_map, default_rate
    )
    md = _canonicalize_metadata(obj.get("metadata"))
    sample_rate = 48000
    sr_raw = meta_get(md, "sample_rate")
    if sr_raw is not None and sr_raw.isdigit():
        sample_rate = int(sr_raw)
    return AudioLane(
        name=str(obj.get("name", f"audio_{ordinal}")),
        ordinal=ordinal,
        enabled=bool(obj.get("enabled", True)),
        sample_rate=sample_rate,
        channel_count=2,
        channel_layout="stereo",
        items=items,
        metadata=md,
    )


def _parse_sequence(
    obj: JsonObject,
    ordinal: int,
    project_key: str,
    media_pool: dict[str, SourceMedia],
    otio_path: pathlib.Path,
    repo_root: pathlib.Path | None,
    nested_map: dict[str, str],
) -> Sequence:
    default_rate = RationalRate(24, 1)
    gst = obj.get("global_start_time")
    global_start: RationalTime | None = None
    if isinstance(gst, dict):
        global_start = _parse_rational_time(gst)
        default_rate = global_start.rate
    tracks_raw = obj.get("tracks")
    video_tracks: list[Track] = []
    audio_lanes: list[AudioLane] = []
    subtitle_tracks: list[Track] = []
    markers: list[Marker] = []
    if isinstance(tracks_raw, dict):
        children = tracks_raw.get("children")
        if isinstance(children, list):
            v_ord = 0
            a_ord = 0
            s_ord = 0
            for child in children:
                if not isinstance(child, dict):
                    continue
                schema = child.get("OTIO_SCHEMA", "")
                if not isinstance(schema, str) or not schema.startswith("Track."):
                    continue
                kind_raw = child.get("kind")
                if isinstance(kind_raw, str) and kind_raw.lower() == "audio":
                    lane = _parse_audio_lane(
                        child, a_ord, media_pool, otio_path, repo_root, nested_map, default_rate
                    )
                    audio_lanes.append(lane)
                    a_ord += 1
                elif _track_kind(kind_raw) == "subtitle":
                    tr = _parse_track(
                        child, s_ord, media_pool, otio_path, repo_root, nested_map, default_rate
                    )
                    subtitle_tracks.append(
                        Track(
                            name=tr.name,
                            kind="subtitle",
                            ordinal=s_ord,
                            enabled=tr.enabled,
                            items=tr.items,
                            captions=tr.captions,
                            metadata=tr.metadata,
                        )
                    )
                    s_ord += 1
                else:
                    tr = _parse_track(
                        child, v_ord, media_pool, otio_path, repo_root, nested_map, default_rate
                    )
                    video_tracks.append(tr)
                    v_ord += 1
    markers_raw = obj.get("markers")
    if isinstance(markers_raw, list):
        for mk in markers_raw:
            if isinstance(mk, dict):
                markers.append(_parse_marker(mk))
    markers.sort(key=lambda m: (m.marked_range.start_time, m.name))
    return Sequence(
        name=str(obj.get("name", project_key)),
        ordinal=ordinal,
        global_start_time=global_start,
        video_tracks=tuple(sorted(video_tracks, key=lambda t: t.ordinal)),
        audio_lanes=tuple(sorted(audio_lanes, key=lambda t: t.ordinal)),
        subtitle_tracks=tuple(sorted(subtitle_tracks, key=lambda t: t.ordinal)),
        markers=tuple(markers),
        metadata=_canonicalize_metadata(obj.get("metadata")),
    )


def _project_key_from(obj: JsonObject, otio_path: pathlib.Path) -> str:
    md = obj.get("metadata")
    if isinstance(md, dict):
        pk = md.get("muse.project_key")
        if isinstance(pk, str) and pk:
            return pk
    return otio_path.stem


def parse_otio_to_project(
    raw: JsonObject,
    otio_path: pathlib.Path,
    repo_root: pathlib.Path | None = None,
) -> Project:
    """Map OTIO JSON → canonical :class:`Project` IR."""
    schema = raw.get("OTIO_SCHEMA", "")
    media_pool: dict[str, SourceMedia] = {}
    nested_map: dict[str, str] = {}
    if isinstance(schema, str) and schema.startswith("SerializableCollection."):
        _check_schema(raw, "SerializableCollection")
        project_key = _project_key_from(raw, otio_path)
        sequences: list[Sequence] = []
        children = raw.get("children")
        if isinstance(children, list):
            for idx, child in enumerate(children):
                if isinstance(child, dict):
                    sequences.append(
                        _parse_sequence(
                            child, idx, project_key, media_pool, otio_path, repo_root, nested_map
                        )
                    )
        return Project(
            project_key=project_key,
            name=str(raw.get("name", project_key)),
            sequences=tuple(sorted(sequences, key=lambda s: s.ordinal)),
            media_pool=tuple(sorted(media_pool.values(), key=lambda m: m.content_id)),
            render_cache=(),
            metadata=_canonicalize_metadata(raw.get("metadata")),
        )
    if isinstance(schema, str) and schema.startswith("Timeline."):
        _check_schema(raw, "Timeline")
        project_key = _project_key_from(raw, otio_path)
        seq = _parse_sequence(raw, 0, project_key, media_pool, otio_path, repo_root, nested_map)
        return Project(
            project_key=project_key,
            name=str(raw.get("name", project_key)),
            sequences=(seq,),
            media_pool=tuple(sorted(media_pool.values(), key=lambda m: m.content_id)),
            render_cache=(),
            metadata=_canonicalize_metadata(raw.get("metadata")),
        )
    raise BridgeError(f"unsupported root OTIO_SCHEMA: {schema!r}")
