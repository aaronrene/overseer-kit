"""Identity domain plugin — version-controlled human/agent/org identity graph.

Implements:
  - MuseDomainPlugin (6 required methods)
  - AddressedMergePlugin (merge_ops for per-entity address-keyed map merge)
  - HarmonyPlugin (conflict_fingerprint for semantic replay)

Working tree layout
-------------------
  identities/<handle>.json               — one IdentityRecord per node
  relationships/<from>--<edge>--<to>.json — one RelationshipRecord per edge

Invariants enforced
-------------------
  I1 Acyclicity — merge() rejects any new relationship that would introduce
                  a cycle in the combined edge set.  The graph is never left
                  in a cyclic state.
  I2 Root distance — derived property; not enforced at merge time.
  I3 Quorum soundness — hub-level concern; not enforced at merge time.
"""

import json
import os
import pathlib
import stat as _stat

from muse._version import __version__
from muse.core.types import blob_id
from muse.core.diff_algorithms import snapshot_diff
from muse.core.schema import DimensionSpec, DomainSchema, SetSchema
from muse.domain import (
    DomainOp,
    DriftReport,
    LiveState,
    MergeResult,
    SnapshotManifest,
    StateDelta,
    StateSnapshot,
    StructuredDelta,
)

from .dag import _DAG, build_dag_from_paths
from .records import parse_relationship_path

_DOMAIN = "identity"
_VALID_DIRS = {"identities", "relationships"}

class IdentityPlugin:
    """Identity domain plugin — satisfies MuseDomainPlugin, AddressedMergePlugin, HarmonyPlugin."""

    # ── MuseDomainPlugin — required ────────────────────────────────────────────

    def snapshot(self, live_state: LiveState) -> StateSnapshot:
        if isinstance(live_state, pathlib.Path):
            return self._snapshot_dir(live_state)
        return live_state  # already a SnapshotManifest

    def diff(
        self,
        base: StateSnapshot,
        target: StateSnapshot,
        *,
        repo_root: pathlib.Path | None = None,
    ) -> StateDelta:
        return snapshot_diff(self.schema(), base, target)

    def merge(
        self,
        base: StateSnapshot,
        left: StateSnapshot,
        right: StateSnapshot,
        *,
        repo_root: pathlib.Path | None = None,
    ) -> MergeResult:
        base_files  = base["files"]
        left_files  = left["files"]
        right_files = right["files"]

        merged: dict[str, str] = dict(base_files)
        conflicts: list[str]   = []

        all_paths = set(base_files) | set(left_files) | set(right_files)
        for path in sorted(all_paths):
            b = base_files.get(path)
            l = left_files.get(path)
            r = right_files.get(path)

            if l == r:
                if l is None:
                    merged.pop(path, None)
                else:
                    merged[path] = l
            elif b == l:
                if r is None:
                    merged.pop(path, None)
                else:
                    merged[path] = r
            elif b == r:
                if l is None:
                    merged.pop(path, None)
                else:
                    merged[path] = l
            else:
                conflicts.append(path)
                merged[path] = l or r or b or ""

        # I1 — reject new relationship edges that would create cycles
        i1_conflicts = self._check_i1(base_files, merged)
        for bad_path in i1_conflicts:
            if bad_path not in conflicts:
                conflicts.append(bad_path)
            merged.pop(bad_path, None)

        return MergeResult(
            merged=SnapshotManifest(files=merged, domain=_DOMAIN, directories=[]),
            conflicts=conflicts,
        )

    def drift(self, committed: StateSnapshot, live: LiveState) -> DriftReport:
        current = self.snapshot(live)
        delta = self.diff(committed, current)
        has_drift = len(delta["ops"]) > 0
        return DriftReport(has_drift=has_drift, summary=delta["summary"], delta=delta)

    def apply(self, delta: StateDelta, live_state: LiveState) -> LiveState:
        return live_state

    def schema(self) -> DomainSchema:
        return DomainSchema(
            domain=_DOMAIN,
            description=(
                "Identity graph domain — version-controlled humans, agents, and orgs "
                "with acyclicity enforcement (I1), root-distance indexing (I2), "
                "and recursive quorum soundness (I3)."
            ),
            top_level=SetSchema(kind="set", element_type="record", identity="by_content"),
            dimensions=[
                DimensionSpec(
                    name="identities",
                    description="Identity nodes — human, agent, or org records keyed by handle.",
                    schema=SetSchema(kind="set", element_type="identity", identity="by_id"),
                    independent_merge=True,
                ),
                DimensionSpec(
                    name="relationships",
                    description=(
                        "Directed edges (SPAWNS, MEMBER_OF) keyed by (from, edge_type, to). "
                        "Additions are independently mergeable unless they introduce a cycle (I1)."
                    ),
                    schema=SetSchema(kind="set", element_type="relationship", identity="by_id"),
                    independent_merge=True,
                ),
            ],
            merge_mode="three_way",
            schema_version=__version__,
        )

    # ── AddressedMergePlugin — address-keyed map merge ────────────────────────

    def merge_ops(
        self,
        base: StateSnapshot,
        ours_snap: StateSnapshot,
        theirs_snap: StateSnapshot,
        ours_ops: list[DomainOp],
        theirs_ops: list[DomainOp],
        *,
        repo_root: pathlib.Path | None = None,
    ) -> MergeResult:
        return self.merge(base, ours_snap, theirs_snap, repo_root=repo_root)

    # ── HarmonyPlugin — semantic conflict fingerprinting ──────────────────────

    def conflict_fingerprint(
        self,
        path: str,
        ours_id: str,
        theirs_id: str,
        repo_root: pathlib.Path,
    ) -> str:
        """Stable ``sha256:``-prefixed fingerprint of the conflict's structural shape.

        For relationship records: hashes (from, edge_type, to) — ignoring
        timestamps and signatures so the same structural conflict is recognized
        across different signing times, enabling Harmony to replay resolutions.

        For identity records: hashes (handle, type) — ignoring pubkey rotation
        timestamps.
        """
        parsed_rel = parse_relationship_path(path)
        if parsed_rel is not None:
            frm, edge, to = parsed_rel
            canonical = json.dumps({"from": frm, "edge_type": edge, "to": to}, sort_keys=True)
        else:
            # Identity path — hash the path itself as the structural key
            canonical = json.dumps({"path": path}, sort_keys=True)

        # Fingerprint is commutative over ours/theirs ordering
        ids_sorted = sorted([ours_id, theirs_id])
        ids_block = "\n".join(ids_sorted)
        payload = f"{canonical}\n{ids_block}"
        return blob_id(payload.encode())

    # ── internals ─────────────────────────────────────────────────────────────

    def _snapshot_dir(self, workdir: pathlib.Path) -> SnapshotManifest:
        files: dict[str, str] = {}
        root_str   = str(workdir)
        prefix_len = len(root_str) + 1

        for dirpath, dirnames, filenames in os.walk(root_str, followlinks=False):
            rel_dir = dirpath[prefix_len:] if len(dirpath) > len(root_str) else ""
            top_dir = rel_dir.split("/")[0] if rel_dir else ""
            if top_dir and top_dir not in _VALID_DIRS:
                dirnames[:] = []
                continue
            dirnames[:] = sorted(d for d in dirnames if not d.startswith("."))

            for fname in sorted(filenames):
                if not fname.endswith(".json"):
                    continue
                abs_str = os.path.join(dirpath, fname)
                try:
                    st = os.lstat(abs_str)
                except OSError:
                    continue
                if not _stat.S_ISREG(st.st_mode):
                    continue
                rel = abs_str[prefix_len:]
                if os.sep != "/":
                    rel = rel.replace(os.sep, "/")
                # Only track identities/ and relationships/ paths
                top = rel.split("/")[0]
                if top not in _VALID_DIRS:
                    continue
                raw = pathlib.Path(abs_str).read_bytes()
                digest = blob_id(raw)
                files[rel] = digest

        return SnapshotManifest(files=files, domain=_DOMAIN, directories=[])

    def _check_i1(
        self,
        base_files: dict[str, str],
        merged_files: dict[str, str],
    ) -> list[str]:
        """Return relationship paths in merged_files that introduce a cycle over base."""
        # New relationships = in merged but not in base
        new_rels = {
            p for p in merged_files
            if p not in base_files and parse_relationship_path(p) is not None
        }
        if not new_rels:
            return []

        # Build DAG from base edges
        dag = build_dag_from_paths(set(base_files.keys()))

        bad: list[str] = []
        for path in sorted(new_rels):
            parsed = parse_relationship_path(path)
            if parsed is None:
                continue
            frm, _edge, to = parsed
            if dag.would_cycle(frm, to):
                bad.append(path)
            else:
                dag.add_edge(frm, to)

        return bad
