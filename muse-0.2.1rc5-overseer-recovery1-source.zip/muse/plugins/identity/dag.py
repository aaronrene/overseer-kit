"""Lightweight DAG cycle detector for the identity domain plugin.

Self-contained — no external deps, no imports from musehub.
Enforces I1 (acyclicity) during merge by running a DFS from each proposed
target node and rejecting edges that would reach the source.
"""

from collections import defaultdict

class _DAG:
    def __init__(self) -> None:
        self._adj: dict[str, list[str]] = defaultdict(list)

    def add_edge(self, frm: str, to: str) -> None:
        self._adj[frm].append(to)

    def would_cycle(self, frm: str, to: str) -> bool:
        """Return True if adding frm→to would create a cycle (or is a self-loop)."""
        if frm == to:
            return True
        from muse.core.graph import walk_dag
        for node in walk_dag(to, lambda n: self._adj.get(n, []), order="dfs"):
            if node == frm:
                return True
        return False

def build_dag_from_paths(relationship_paths: set[str]) -> _DAG:
    """Build a DAG from a set of canonical relationship file paths."""
    from .records import parse_relationship_path

    dag = _DAG()
    for path in relationship_paths:
        parsed = parse_relationship_path(path)
        if parsed is not None:
            frm, _edge, to = parsed
            dag.add_edge(frm, to)
    return dag
