"""Chess domain plugin — built live in Build With Muse, Episode 22
("Build Something Weird With Muse"), the season finale.

Proves the six-method protocol scales to a domain nobody asked for:
a chess game as an ordered sequence of moves, where two branches
diverging after the same position is a real, meaningful "variation"
conflict — not a metaphor borrowed from code or music, an actual
correct description of how chess analysis works.

See ``plugin.py`` for the implementation and
``docs/guide/plugin-authoring-guide.md`` for the general walkthrough.
"""
