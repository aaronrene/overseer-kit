"""Guard rail: refuse mutating commands against a protected canonical repo
when running from an editable (live-source) build.

Phase 3 of musehub staging #185. The hazard: an editable install (e.g. the
`muse-dev` entry point created in Phase 2, `pip install -e ~/ecosystem/muse`)
loads code straight from a repo it can also mutate. A mid-edit, syntactically
valid but semantically broken build can corrupt that repo's own `.muse`
object store. This module makes that require an explicit, loud opt-in
instead of happening by default.

Only applies to editable builds — a stable, non-editable `muse` (installed
via the official installer venv) has no live-source hazard and is never
blocked by this guard, regardless of target.

Scope: local object-store-mutating commands only. `hub` subcommands go over
the network to a remote server and are a different risk category (remote
data correctness, not local object-store corruption) — deliberately out of
scope here.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path

DEFAULT_PROTECTED_ROOTS = [
    str(Path.home() / "ecosystem" / "muse"),
    str(Path.home() / "ecosystem" / "musehub"),
]

OVERRIDE_ENV_VAR = "MUSE_DEV_ALLOW_CANONICAL"
PROTECTED_ROOTS_ENV_VAR = "MUSE_DEV_PROTECTED_ROOTS"

# Top-level commands that write to the local object store, refs, or working
# tree in a way that's hard to reverse if the code producing them is broken.
_MUTATING_TOP_LEVEL_COMMANDS = {
    "commit", "merge", "push", "pull", "reset", "rm", "revert",
    "cherry-pick", "rebase", "restore", "apply", "apply-patch",
    "unpack-objects", "update-ref", "prune", "gc", "clean",
    "checkout-symbol", "mv", "commit-tree", "symbolic-ref", "bundle",
    "sparse-checkout",
}

# `code <subcommand>` is a mixed namespace — most of it is pure read/analysis
# (grep, impact, hotspots, ...); only these actually mutate tracked content.
_MUTATING_CODE_SUBCOMMANDS = {
    "add", "reset", "patch", "rename", "migrate", "semantic-cherry-pick",
}


class GuardBlocked(SystemExit):
    """Raised (as a SystemExit subclass) when a mutating command is refused."""


def is_editable_build() -> bool:
    """True if this process is running muse's code straight from a source
    checkout rather than a venv's copied ``site-packages`` tree."""
    import muse
    return "site-packages" not in str(Path(muse.__file__).resolve().parent.parent)


def _protected_roots_from_env() -> list[str]:
    raw = os.environ.get(PROTECTED_ROOTS_ENV_VAR)
    if raw:
        return [p for p in raw.split(":") if p]
    return DEFAULT_PROTECTED_ROOTS


def is_protected_root(path: str, *, protected_roots: list[str] | None = None) -> bool:
    """True if ``path`` is, or is nested inside, any protected canonical repo root."""
    roots = protected_roots if protected_roots is not None else _protected_roots_from_env()
    resolved = Path(path).resolve()
    for root in roots:
        root_resolved = Path(root).resolve()
        if resolved == root_resolved or root_resolved in resolved.parents:
            return True
    return False


def classify_is_mutating(args: argparse.Namespace) -> bool:
    """True if the parsed CLI args represent a local-object-store-mutating command."""
    command = getattr(args, "command", None)
    if command == "code":
        return getattr(args, "code_command", None) in _MUTATING_CODE_SUBCOMMANDS
    return command in _MUTATING_TOP_LEVEL_COMMANDS


def check_guard(
    args: argparse.Namespace,
    *,
    cwd: str | None = None,
    protected_roots: list[str] | None = None,
    is_editable: bool | None = None,
) -> None:
    """Raise :class:`GuardBlocked` if this call should be refused.

    All keyword params default to the real live values (current process's
    editable-ness, real cwd, env-configured protected roots) — tests pass
    them explicitly to avoid ever touching the real canonical repos.
    """
    editable = is_editable_build() if is_editable is None else is_editable
    if not editable:
        return
    if not classify_is_mutating(args):
        return

    effective_cwd = os.getcwd() if cwd is None else cwd
    if not is_protected_root(effective_cwd, protected_roots=protected_roots):
        return

    if os.environ.get(OVERRIDE_ENV_VAR) == "1":
        return

    command = getattr(args, "command", "?")
    sub = getattr(args, "code_command", None)
    full_command = f"{command} {sub}" if sub else command
    raise GuardBlocked(
        f"❌ Refusing to run mutating command `muse {full_command}` from an editable "
        f"build against a protected canonical repo ({effective_cwd}).\n"
        f"   This is muse-dev's guard rail (musehub staging #185) — an editable "
        f"install can corrupt the object store of the very repo it was built from.\n"
        f"   Set {OVERRIDE_ENV_VAR}=1 to override, only if you're certain this is "
        f"intentional."
    )
