"""Registry mapping a domain name to its dedicated CLI subcommand names.

Populated as a side effect of argparse tree construction (muse.cli.app's
`main()`, and the `register()` functions of domain-named command modules
like `mist.py`/`social.py`) — never hand-typed anywhere. See muse#74: a
domain's `supported_commands` manifest field was previously a literal
Python list hardcoded into `muse domains publish`, identical for every
domain regardless of what it actually supports.

A domain with no dedicated top-level `muse <name> <verb>` namespace (e.g.
"identity") simply has no entry — querying it returns `[]`, which is the
honest answer, not a borrowed list from an unrelated domain.

This module has zero dependencies on `app.py` or any command module, by
design — it must be importable from anywhere (including `domains.py`)
without risking a circular import.
"""

from collections.abc import Iterable

_REGISTRY: dict[str, list[str]] = {}


def register_namespace(domain_name: str, commands: Iterable[str]) -> None:
    """Record *domain_name*'s CLI subcommand names, replacing any prior entry.

    Called once per CLI invocation, immediately after a domain-named
    top-level command (``muse code``, ``muse mist``, ``muse social``, ...)
    finishes building its own subparser tree — the same object argparse
    itself dispatches from, so this can never drift from reality.

    Idempotent: registering the same *domain_name* again replaces the
    stored list rather than merging or appending to it.
    """
    _REGISTRY[domain_name] = sorted(commands)


def get_supported_commands(domain_name: str) -> list[str]:
    """Return the live list of ``muse <domain_name> <verb>`` subcommand
    names, or ``[]`` if *domain_name* has no dedicated top-level CLI
    namespace.

    Returns a fresh copy — mutating the result never affects the registry.
    """
    return list(_REGISTRY.get(domain_name, []))
