"""Shared CLI pre-flight guards for operations that modify the working tree.

Any command that calls :func:`muse.core.workdir.apply_manifest` — merge,
checkout, reset, revert, cherry-pick, pull — should call
:func:`require_clean_workdir` first so users never lose uncommitted work
silently.  The check mirrors Git's behaviour: modified/deleted tracked files
block the operation; newly untracked files are left alone.
"""

import json
import pathlib
import sys

from muse.core.types import load_json_file
from muse.core.paths import repo_json_path as _repo_json_path
from muse.core.errors import ExitCode
from muse.core.snapshot import diff_workdir_vs_snapshot
from muse.core.refs import read_head
from muse.core.snapshots import get_head_snapshot_manifest
from muse.core.validation import sanitize_display

def require_clean_workdir(
    root: pathlib.Path,
    operation: str,
    *,
    force: bool = False,
    target_manifest: dict[str, str] | None = None,
    json_out: bool = False,
) -> None:
    """Abort with a friendly error if the working tree has uncommitted changes.

    Protects against silent data loss when *operation* (merge, checkout,
    reset, …) is about to overwrite files via ``apply_manifest``.  Pass
    ``force=True`` to bypass the check (e.g. for ``--force`` flags).

    Only modified and deleted tracked files are considered dangerous —
    brand-new files that have never been committed are left untouched by any
    manifest-apply, so they are not flagged.

    ``target_manifest`` is accepted for API compatibility but is no longer
    used to narrow the dirty-file set.  Previously, only files that differed
    between the current HEAD and the target manifest were blocked; this
    "carry through" behaviour caused dirty working-tree state to silently
    bleed onto branches the user never touched (see TestDirtyWorkdirBleedThrough).
    The guard now refuses on *any* dirty tracked file regardless of whether
    the target branch shares the same committed version.

    When *json_out* is ``True``, a machine-readable error object is emitted to
    stdout before exiting so that agents using ``--json`` still receive an
    actionable response.

    Args:
        root:            Repository root (directory that contains ``.muse/``).
        operation:       Human-readable name of the operation (used in the message).
        force:           When ``True`` the guard is a no-op.
        target_manifest: Accepted for API compatibility; no longer used.
        json_out:        Emit JSON error to stdout instead of human text to stderr.

    Raises:
        SystemExit: With :attr:`ExitCode.USER_ERROR` when dirty files exist.
    """
    if force:
        return

    _head_state = read_head(root)
    _repo_meta = load_json_file(_repo_json_path(root)) or {}
    repo_id = str(_repo_meta.get("repo_id", ""))
    if _head_state["kind"] == "branch":
        head_manifest = get_head_snapshot_manifest(root, _head_state["branch"]) or {}
    else:
        # Detached HEAD: read manifest from the HEAD commit directly.
        from muse.core.commits import read_commit
        from muse.core.snapshots import read_snapshot
        _det_commit = read_commit(root, _head_state["commit_id"])
        if _det_commit is None:
            head_manifest = {}
        else:
            _snap = read_snapshot(root, _det_commit.snapshot_id)
            head_manifest = dict(_snap.manifest) if _snap else {}

    # If the branch has no commits yet there is nothing to protect.
    if not head_manifest:
        return

    added, modified, deleted, _, _added_dirs, _deleted_dirs = diff_workdir_vs_snapshot(root, head_manifest)

    # Added paths are brand-new files never seen in a snapshot; apply_manifest
    # won't touch them, so they are safe to ignore.  Modified and deleted
    # paths ARE in the snapshot and would be overwritten or removed.
    dirty = modified | deleted
    if not dirty:
        return

    dirty_sorted = sorted(dirty)
    if json_out:
        print(json.dumps({
            "error": "dirty_workdir",
            "operation": operation,
            "message": (
                f"uncommitted changes would be overwritten by {operation}"
            ),
            "files": dirty_sorted,
            "hint": (
                f"use 'muse shelf save' then retry, "
                f"'muse {operation} --autoshelf', or "
                f"'muse {operation} --force' to discard changes"
            ),
        }))
        raise SystemExit(ExitCode.USER_ERROR)

    print(
        f"❌ error: Your local changes to the following files would be "
        f"overwritten by {sanitize_display(operation)}:",
        file=sys.stderr,
    )
    shown = dirty_sorted[:10]
    for path in shown:
        print(f"        {sanitize_display(path)}", file=sys.stderr)
    if len(dirty) > 10:
        print(f"        … and {len(dirty) - 10} more", file=sys.stderr)
    print(
        f"\nRun one of:\n"
        f"  muse shelf save                  — shelve changes and retry\n"
        f"  muse {sanitize_display(operation)} --merge         — carry changes forward (three-way merge)\n"
        f"  muse {sanitize_display(operation)} --force         — discard changes\n"
        f"  muse {sanitize_display(operation)} --autoshelf     — shelf automatically, switch, pop on arrival",
        file=sys.stderr,
    )
    raise SystemExit(ExitCode.USER_ERROR)
