"""``muse code add`` — stage files (or hunks) for the next commit.

Mirrors ``git add`` exactly.  Files added to the stage are the *only* ones
that ``muse commit`` will include; all other tracked files carry their
last-committed state forward unchanged.

Usage::

    muse code add <path> [<path> …]   # stage specific files/dirs
    muse code add .                   # stage everything (like current muse commit)
    muse code add -u                  # stage all tracked modified/deleted files
    muse code add -A / --all          # stage all changes including new files
    muse code add -p <file>           # interactive hunk-by-hunk staging
    muse code add --patch <file>      # same as -p
    muse code add --json              # machine-readable output for agents

``muse code reset`` (or ``muse code reset HEAD <file>``) removes files from
the stage without touching the working tree::

    muse code reset              # unstage everything
    muse code reset HEAD <file>  # unstage a specific file
    muse code reset '*.py'       # glob — unstage all staged .py files
    muse code reset -n           # dry-run preview
    muse code reset --json        # machine-readable output

Exit codes::

    0 — one or more files staged successfully
    1 — user error (path not found, not a code repo, etc.)
    3 — I/O error
"""

import argparse
import difflib
import logging
import os
import pathlib
import re
import stat as _stat
import sys
import tempfile
from collections.abc import Mapping
from typing import Literal, TypedDict

from muse.core.errors import ExitCode
from muse.core.ignore import is_ignored, load_ignore_config, resolve_patterns
from muse.core.object_store import read_object, write_object_from_path
from muse.core.repo import require_repo
from muse.core.stat_cache import load_cache
from muse.core.types import Manifest
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import read_commit
from muse.core.snapshots import read_snapshot
from muse.core.timing import start_timer
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.validation import sanitize_display
from muse.plugins.code.stage import (
    EMPTY_DIR_OID,
    StagedEntry,
    StagedFileMap,
    clear_stage,
    make_entry,
    read_stage,
    read_stage_dir_renames,
    write_stage,
)
from muse.core.object_store import write_object

type _ModeLabel = dict[str, str]
from muse.plugins.registry import read_domain

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module-level constants (computed once; never recreated per call)
# ---------------------------------------------------------------------------

# Directories that are never version-controlled.  Mirrors _ALWAYS_IGNORE_DIRS
# in the code plugin to avoid importing from the plugin layer.
_IGNORE_DIRS: frozenset[str] = frozenset({
    "__pycache__", "node_modules", ".git", ".hg", ".svn",
    ".venv", "venv", ".tox", "dist", "build", ".eggs", ".DS_Store",
})

# VCS storage directory name — files inside it must never enter the snapshot.
# Staging .muse/ internals corrupts checkout: switching to a branch whose
# snapshot omits them would delete live VCS state from disk.
_MUSE_DIR_NAME = ".muse"

# Precompiled regex for the unified-diff hunk header.
# Captures: src_start, src_count (optional), dst_start, dst_count (optional).
_HUNK_HEADER_RE = re.compile(
    r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@"
)

# ---------------------------------------------------------------------------
# Typed JSON schemas
# ---------------------------------------------------------------------------

class _CodeAddFileEntry(TypedDict):
    """One entry in the files list from ``muse code add --json``."""

    path: str
    mode: str

class _CodeAddJson(EnvelopeJson):
    """JSON output of ``muse code add --json``."""

    staged: int
    added: int
    modified: int
    deleted: int
    files: list[_CodeAddFileEntry]
    dry_run: bool

class _CodeAddErrorJson(EnvelopeJson):
    """JSON output for muse code add error paths."""

    error: str
    staged: int

class _CodeResetJson(EnvelopeJson):
    """JSON output of ``muse code reset --json``."""

    unstaged: int
    files: list[str]
    not_staged: list[str]
    dry_run: bool

class _CodeResetErrorJson(EnvelopeJson):
    """JSON output for muse code reset error paths."""

    error: str
    unstaged: int

# ---------------------------------------------------------------------------
# argparse registration
# ---------------------------------------------------------------------------

def register_add(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``muse code add`` subcommand."""
    parser = subparsers.add_parser(
        "add",
        help="Stage file(s) for the next commit.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "paths",
        nargs="*",
        metavar="PATH",
        help="File or directory to stage.  Use '.' to stage everything.",
    )
    parser.add_argument(
        "-p", "--patch",
        action="store_true",
        dest="patch",
        help="Interactively select hunks to stage (like git add -p).",
    )
    parser.add_argument(
        "-u", "--update",
        action="store_true",
        dest="update",
        help="Stage all tracked modified and deleted files (no new files).",
    )
    parser.add_argument(
        "-A", "--all",
        action="store_true",
        dest="all_files",
        help="Stage all changes including new (untracked) files.",
    )
    parser.add_argument(
        "-n", "--dry-run",
        action="store_true",
        dest="dry_run",
        help="Show what would be staged without actually staging.",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Show each file as it is staged.",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON.",
    )
    parser.set_defaults(func=run_add)

def register_reset(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``muse code reset`` subcommand."""
    parser = subparsers.add_parser(
        "reset",
        help="Unstage file(s) without touching the working tree.",
        description=(
            "Remove files from the stage index.  The working tree is unchanged.\n\n"
            "    muse code reset              # unstage everything\n"
            "    muse code reset HEAD <file>  # unstage a specific file\n"
            "    muse code reset <file>       # same as above\n"
            "    muse code reset '*.py'       # glob — unstage all staged .py files\n"
            "    muse code reset -n           # preview without writing\n"
            "    muse code reset --json        # machine-readable output\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "paths",
        nargs="*",
        metavar="PATH",
        help=(
            "File(s) or glob pattern(s) to unstage.  Omit or pass 'HEAD' "
            "alone to unstage everything."
        ),
    )
    parser.add_argument(
        "-n", "--dry-run",
        action="store_true",
        dest="dry_run",
        help="Show what would be unstaged without actually writing.",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON.",
    )
    parser.set_defaults(func=run_reset)

# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

def _head_manifest(root: pathlib.Path) -> Manifest:
    """Return the manifest from the current HEAD commit, or ``{}`` if none.

    Resolves the branch through ``get_head_commit_id`` (the store
    abstraction) rather than reading the ref file directly, so the result
    is always consistent with the rest of the store layer.

    Returns an empty dict for repositories with no commits yet (fresh init).
    Never raises — callers treat an empty manifest as "nothing committed."
    """
    try:
        branch = read_current_branch(root)
        commit_id = get_head_commit_id(root, branch)
        if not commit_id:
            return {}
        commit = read_commit(root, commit_id)
        if commit is None:
            return {}
        snap = read_snapshot(root, commit.snapshot_id)
        return dict(snap.manifest) if snap else {}
    except Exception:
        return {}

def _head_snapshot_dirs(root: pathlib.Path) -> set[str]:
    """Return the committed empty-directory set from HEAD, or empty set."""
    try:
        branch = read_current_branch(root)
        commit_id = get_head_commit_id(root, branch)
        if not commit_id:
            return set()
        commit = read_commit(root, commit_id)
        if commit is None:
            return set()
        snap = read_snapshot(root, commit.snapshot_id)
        return set(snap.directories) if snap else set()
    except Exception:
        return set()

def _is_ignorable_dir(name: str) -> bool:
    """Return True when a directory should be skipped during tree walks."""
    return name.startswith(".") or name in _IGNORE_DIRS

def _is_inside_muse_dir(root: pathlib.Path, path: pathlib.Path) -> bool:
    """Return True when *path* is inside (or is) the VCS storage directory.

    Data-integrity invariant: ``.muse/`` is the repo's own storage — its
    contents must never appear in a working-tree snapshot.  If they did,
    checkout to a branch whose snapshot omits them would delete live VCS
    internals from disk.

    Args:
        root: Absolute repository root.
        path: Absolute path to test.
    """
    muse_dir = root / _MUSE_DIR_NAME
    try:
        path.relative_to(muse_dir)
        return True
    except ValueError:
        return path == muse_dir

def _walk_tree(base: pathlib.Path) -> list[pathlib.Path]:
    """Recursively yield regular files under *base*, honouring ignore rules.

    Skips hidden files/directories and directories in :data:`_IGNORE_DIRS`.
    Results are sorted for determinism.
    """
    result: list[pathlib.Path] = []
    for dirpath, dirnames, filenames in os.walk(str(base), followlinks=False):
        dirnames[:] = sorted(
            d for d in dirnames
            if not _is_ignorable_dir(d)
            and not os.path.isdir(os.path.join(dirpath, d, ".muse"))
        )
        for fname in sorted(filenames):
            abs_path = pathlib.Path(dirpath) / fname
            try:
                st = abs_path.lstat()
            except OSError:
                continue
            if _stat.S_ISREG(st.st_mode):
                result.append(abs_path)
    return result

def _collect_paths(
    root: pathlib.Path,
    raw_paths: list[str],
    update_only: bool,
    all_files: bool,
    head_manifest: Manifest,
    quiet: bool = False,
    head_dirs: set[str] | None = None,
) -> list[pathlib.Path]:
    """Resolve user-supplied paths to absolute file paths for staging.

    Priority order (first matching rule wins):

    1. **``-u`` / ``update_only``** — every path in ``head_manifest``,
       whether it still exists on disk or not.  Deleted files are included
       so they can be recorded as mode-D entries.  New untracked files are
       excluded.
    2. **``-A`` / ``all_files``** — full ``os.walk`` of the working tree
       (new files + modifications) *plus* every tracked file that has been
       deleted from disk (so deletions are staged too).
    3. **No paths given** — full ``os.walk`` of the repo root (new files,
       modifications, *and* deletions), matching ``git add .`` in Git 2+.
    4. **Explicit paths** — expanded recursively if a directory; allowed to
       name files that are absent from disk *iff* they appear in
       ``head_manifest`` (staged deletion).

    Args:
        root:          Repository root directory.
        raw_paths:     User-supplied path strings (may be relative or absolute).
        update_only:   ``-u`` flag — only tracked files, including deletions.
        all_files:     ``-A`` flag — everything: new, modified, and deleted.
        head_manifest: The committed manifest (path → object_id).

    Returns:
        List of absolute :class:`pathlib.Path` values to stage.
    """
    paths: list[pathlib.Path] = []

    if update_only:
        # Stage all tracked files — modified ones and deleted ones.
        # Deleted files (absent from disk) receive mode "D" later in run_add.
        for rel in head_manifest:
            if rel.startswith(".muse/"):
                continue  # never stage VCS-internal paths
            paths.append(root / pathlib.Path(rel))

    elif all_files:
        # Stage the entire working tree (new + modified) …
        paths = _walk_tree(root)
        # … plus tracked files that have been deleted from disk.
        on_disk = {str(p.relative_to(root)).replace("\\", "/") for p in paths}
        for rel in head_manifest:
            if rel.startswith(".muse/"):
                continue  # never stage VCS-internal paths
            if rel not in on_disk:
                paths.append(root / pathlib.Path(rel))

    elif not raw_paths:
        # No explicit paths: stage everything — new files, modifications,
        # and deletions — matching the behaviour of `git add .` in Git 2+.
        paths = _walk_tree(root)
        on_disk = {str(p.relative_to(root)).replace("\\", "/") for p in paths}
        for rel in head_manifest:
            if rel.startswith(".muse/"):
                continue  # never stage VCS-internal paths
            if rel not in on_disk:
                paths.append(root / pathlib.Path(rel))

    else:
        for raw in raw_paths:
            p = pathlib.Path(raw)
            if not p.is_absolute():
                p = pathlib.Path.cwd() / p
            p = p.resolve()

            # Fallback: when the CWD-relative path lands outside the repo root
            # (e.g. tests or scripted invocations where CWD != repo root), try
            # interpreting the raw path as repo-relative.
            try:
                p.relative_to(root)
            except ValueError:
                alt = (root / raw).resolve()
                try:
                    alt.relative_to(root)
                    p = alt
                except ValueError:
                    pass

            # Data-integrity guard: never stage anything inside .muse/ — it is
            # the VCS storage directory.  Silently skip, same as an out-of-repo
            # path. Note: the agent-config canonical source lives at
            # .museagent.md (repo root, outside .muse/) precisely so it is
            # NOT caught by this guard and stages/commits normally — see
            # muse issue #78.
            if _is_inside_muse_dir(root, p):
                logger.debug("Skipping VCS-internal path: %s", p)
                continue

            if p.is_dir():
                dir_files = _walk_tree(p)
                paths.extend(dir_files)
                # Include tracked files that have been deleted from under this
                # directory — matches `git add .` behaviour (Git 2+ stages
                # deletions whenever a directory is given as the path scope).
                on_disk = {str(f.relative_to(root)).replace("\\", "/") for f in dir_files}
                try:
                    rel_dir = str(p.relative_to(root)).replace("\\", "/")
                except ValueError:
                    rel_dir = ""
                prefix = "" if rel_dir in (".", "") else f"{rel_dir}/"
                for rel in head_manifest:
                    if rel not in on_disk and rel.startswith(prefix):
                        paths.append(root / pathlib.Path(rel))
            elif p.exists():
                paths.append(p)
            else:
                # Allow staging a deleted tracked file by name.
                try:
                    rel_guess = str(p.relative_to(root)).replace("\\", "/")
                except ValueError:
                    rel_guess = raw
                if rel_guess in head_manifest:
                    paths.append(p)
                elif (head_dirs or set()) & {rel_guess, rel_guess.rstrip("/")}:
                    pass  # committed dir deleted from disk — handled by deleted_committed_dirs
                else:
                    if not quiet:
                        print(
                            f"❌ Path not found: {sanitize_display(raw)}",
                            file=sys.stderr,
                        )

    return paths

def _infer_mode(
    rel: str,
    head_manifest: Manifest,
    exists_on_disk: bool,
) -> Literal["A", "M", "D"]:
    """Return the staging mode for a file.

    - ``"D"`` — the file no longer exists on disk; the next commit should
      remove it from the snapshot.
    - ``"M"`` — the file exists on disk *and* is already tracked (present
      in ``head_manifest``); the next commit replaces the committed version.
    - ``"A"`` — the file exists on disk but was not in the previous commit;
      the next commit introduces it as a new tracked file.

    Args:
        rel:             Workspace-relative POSIX path of the file.
        head_manifest:   The committed manifest (path → object_id).
        exists_on_disk:  Whether the file is currently present in the working tree.

    Returns:
        One of ``"A"``, ``"M"``, or ``"D"``.
    """
    if not exists_on_disk:
        return "D"
    if rel in head_manifest:
        return "M"
    return "A"

# ---------------------------------------------------------------------------
# Patch-mode (interactive hunk staging)
# ---------------------------------------------------------------------------

def _split_into_hunks(unified_diff_lines: list[str]) -> list[list[str]]:
    """Split unified-diff output into individual hunks.

    The file-header lines (``--- a/file`` / ``+++ b/file``) are prepended
    to every hunk so that each hunk can be displayed standalone with full
    file context.  This matches ``git add -p`` display behaviour.

    Args:
        unified_diff_lines: Lines produced by :func:`difflib.unified_diff`,
                            each line terminating with ``\\n``.

    Returns:
        A list of hunks, where each hunk is a list of lines starting with
        the file header followed by the ``@@ … @@`` marker.
    """
    header: list[str] = []
    hunks: list[list[str]] = []
    current: list[str] = []

    for line in unified_diff_lines:
        if line.startswith("@@"):
            if current:
                hunks.append(current)
            current = header[:] + [line]
        elif not hunks and not current:
            header.append(line)
        else:
            if current:
                current.append(line)

    if current:
        hunks.append(current)

    return hunks

def _colorize_hunk(lines: list[str]) -> str:
    """Return *lines* as a terminal-colored string for interactive display.

    Colors: added lines → green, removed lines → red, ``@@`` headers → cyan.
    File header lines (``---`` / ``+++``) are left unstyled.

    Args:
        lines: Hunk lines (including the file header and ``@@ … @@`` line).

    Returns:
        A single string with embedded ANSI escape codes, ready to print.
    """
    _GREEN = "\x1b[32m"
    _RED = "\x1b[31m"
    _CYAN = "\x1b[36m"
    _RESET = "\x1b[0m"
    out: list[str] = []
    for line in lines:
        if line.startswith("+") and not line.startswith("+++"):
            out.append(f"{_GREEN}{line}{_RESET}")
        elif line.startswith("-") and not line.startswith("---"):
            out.append(f"{_RED}{line}{_RESET}")
        elif line.startswith("@@"):
            out.append(f"{_CYAN}{line}{_RESET}")
        else:
            out.append(line)
    return "".join(out)

def _apply_hunks_to_bytes(
    original: bytes,
    accepted_hunks: list[list[str]],
) -> bytes:
    """Produce a partial file by applying only the *accepted_hunks*.

    This is the core of ``--patch`` mode: the user may accept some hunks
    and reject others.  The result is a version of the file that includes
    exactly the accepted changes on top of the original content.

    Algorithm:

    1. Decode *original* as UTF-8 (with replacement) into a mutable line list.
    2. Iterate accepted hunks in **reverse order** (highest line numbers first)
       so that earlier hunks' line indices remain valid after applying later
       ones.
    3. For each hunk: parse the ``@@ -start,count … @@`` header to find the
       source line range, then rebuild that range from the hunk's context
       (``' '``-prefixed) and added (``'+'``-prefixed) lines, discarding
       removed (``'-'``-prefixed) lines.
    4. Re-encode the result as UTF-8.

    Args:
        original:       Raw bytes of the file before any changes.
        accepted_hunks: Hunks the user chose to stage (output of
                        :func:`_split_into_hunks`, filtered by user input).

    Returns:
        Raw bytes of the partially-staged file containing only the accepted
        changes.  Binary files that cannot be decoded as UTF-8 will have
        replacement characters (U+FFFD) for non-decodable bytes.
    """
    original_lines = original.decode("utf-8", errors="replace").splitlines(keepends=True)
    result: list[str] = list(original_lines)

    for hunk in reversed(accepted_hunks):
        hunk_header = next((l for l in hunk if l.startswith("@@")), None)
        if hunk_header is None:
            continue

        m = _HUNK_HEADER_RE.search(hunk_header)
        if m is None:
            continue

        src_start = int(m.group(1)) - 1  # convert from 1-based to 0-based
        src_count = int(m.group(2)) if m.group(2) is not None else 1

        # Collect diff body lines (exclude file header and @@ marker).
        hunk_lines = [
            l for l in hunk
            if not l.startswith("---")
            and not l.startswith("+++")
            and not l.startswith("@@")
        ]

        new_block: list[str] = []
        for line in hunk_lines:
            if line.startswith(" ") or line.startswith("+"):
                # Context and added lines both go into the result.
                # Strip the leading diff prefix character.
                new_block.append(line[1:])
            # Lines starting with '-' are removed — intentionally dropped.

        result[src_start : src_start + src_count] = new_block

    return "".join(result).encode("utf-8")

def _interactive_patch(
    root: pathlib.Path,
    abs_path: pathlib.Path,
    rel: str,
    head_manifest: Manifest,
    current_stage: StagedFileMap,
) -> StagedFileMap:
    """Interactively select hunks from *abs_path* to stage.

    Presents each diff hunk in the terminal with color, then prompts:

    - ``y`` — stage this hunk
    - ``n`` — skip this hunk
    - ``q`` — quit; commit whatever has been accepted so far
    - ``a`` — accept this and all remaining hunks
    - ``d`` — skip the rest of this file
    - ``?`` — show help

    The "before" content is determined in priority order:

    1. The currently-staged version (if the file is already partially staged).
    2. The HEAD-committed version.
    3. Empty bytes (new file with no prior state).

    The accepted hunks are applied to the "before" bytes with
    :func:`_apply_hunks_to_bytes`, the result is hashed and written to the
    object store, and the stage entry is updated.

    Args:
        root:          Repository root directory.
        abs_path:      Absolute path to the working-tree file.
        rel:           Workspace-relative POSIX path (for display and stage key).
        head_manifest: Committed manifest (path → object_id).
        current_stage: The stage index as it stands before this call.

    Returns:
        An updated stage entries dict (copy of *current_stage* with any new
        or changed entry for *rel* merged in).
    """
    before_bytes: bytes = b""
    if rel in current_stage:
        try:
            blob = read_object(root, current_stage[rel]["object_id"])
            if blob is not None:
                before_bytes = blob
        except OSError:
            pass
    elif rel in head_manifest:
        try:
            blob = read_object(root, head_manifest[rel])
            if blob is not None:
                before_bytes = blob
        except OSError:
            pass

    if not abs_path.exists():
        print(
            f"⚠️  {sanitize_display(rel)}: file not found — cannot stage hunks.",
            file=sys.stderr,
        )
        return current_stage

    after_bytes = abs_path.read_bytes()

    before_lines = before_bytes.decode("utf-8", errors="replace").splitlines(keepends=True)
    after_lines = after_bytes.decode("utf-8", errors="replace").splitlines(keepends=True)

    diff_lines = list(
        difflib.unified_diff(
            before_lines,
            after_lines,
            fromfile=f"a/{rel}",
            tofile=f"b/{rel}",
            lineterm="",
        )
    )
    diff_with_newlines = [f"{l}\n" for l in diff_lines]

    hunks = _split_into_hunks(diff_with_newlines)
    if not hunks:
        print(f"  (no changes in {sanitize_display(rel)})")
        return current_stage

    accepted: list[list[str]] = []
    total = len(hunks)

    for idx, hunk in enumerate(hunks, 1):
        print(f"\n{_colorize_hunk(hunk)}", end="")
        print(f"\nHunk {idx}/{total} — Stage this hunk?")
        print("  y = yes, n = no, q = quit, a = stage all remaining, d = skip rest of file, ? = help")

        choice = "n"
        while True:
            try:
                choice = input("Stage hunk? [y/n/q/a/d/?] ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print("\nAborted.")
                raise SystemExit(ExitCode.USER_ERROR)

            if choice == "y":
                accepted.append(hunk)
                break
            elif choice == "n":
                break
            elif choice == "q":
                break
            elif choice == "a":
                accepted.append(hunk)
                accepted.extend(hunks[idx:])
                break
            elif choice == "d":
                break
            elif choice == "?":
                print(
                    "  y — stage this hunk\n"
                    "  n — do not stage this hunk\n"
                    "  q — quit; do not stage this or any remaining hunks\n"
                    "  a — stage this and all remaining hunks\n"
                    "  d — skip the rest of this file\n"
                    "  ? — print this help\n"
                )
            else:
                print("  Unknown key. Press ? for help.")

            if choice in ("q", "d"):
                break

        if choice == "q":
            break
        if choice == "d":
            break

    if not accepted:
        return current_stage

    partial_bytes = _apply_hunks_to_bytes(before_bytes, accepted)

    with tempfile.NamedTemporaryFile(delete=False, suffix=".partial") as tf:
        tf.write(partial_bytes)
        tmp_path = pathlib.Path(tf.name)

    try:
        object_id = hash_file(tmp_path)
        write_object_from_path(root, object_id, tmp_path)
    finally:
        tmp_path.unlink(missing_ok=True)

    mode = _infer_mode(rel, head_manifest, abs_path.exists())
    updated = dict(current_stage)
    updated[rel] = make_entry(object_id, mode)
    print(f"  ✅ Staged {len(accepted)}/{total} hunk(s) from {sanitize_display(rel)}")
    return updated

# ---------------------------------------------------------------------------
# run_add
# ---------------------------------------------------------------------------

def run_add(args: argparse.Namespace) -> None:
    """Stage files or hunks for the next ``muse commit``.

    Stages additions, modifications, and deletions into the Muse index.
    ``muse code add .`` stages all tracked changes including deleted files.
    ``-u`` / ``--update`` stages only already-tracked files.  Agents should
    avoid ``--patch`` which requires an interactive terminal.

    Agent quickstart
    ----------------
    ::

        muse code add . --json
        muse code add src/billing.py --json
        muse code add -u --json

    JSON fields
    -----------
    staged    Total number of files staged.
    added     Number of new files staged.
    modified  Number of modified files staged.
    deleted   Number of deleted files staged.
    files     List of staged file objects: ``path`` and ``mode``
              (``"new file"``, ``"modified"``, ``"deleted"``).
    dry_run   ``true`` when ``--dry-run`` was passed.

    Exit codes
    ----------
    0  Files staged successfully (or nothing to stage).
    1  No matching files found, invalid path, or wrong domain.
    2  Not inside a Muse repository.
    """
    import json as _json

    elapsed = start_timer()
    raw_paths: list[str] = args.paths
    patch: bool = args.patch
    update: bool = args.update
    all_files: bool = args.all_files
    dry_run: bool = args.dry_run
    verbose: bool = args.verbose
    json_out: bool = args.json_out

    root = require_repo()

    if read_domain(root) != "code":
        if json_out:
            print(_json.dumps(_CodeAddErrorJson(
                **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                error="'muse code add' requires a code-domain repository.",
                staged=0,
            )))
        else:
            print("❌ 'muse code add' requires a code-domain repository.", file=sys.stderr)
            print("   Initialise one with: muse init --domain code", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    head_manifest = _head_manifest(root)
    head_dirs = _head_snapshot_dirs(root)
    current_stage = read_stage(root)

    # Patch mode: interactive hunk-by-hunk staging.
    if patch:
        if not raw_paths:
            print("❌ --patch requires at least one file path.", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        for raw in raw_paths:
            p = pathlib.Path(raw)
            if not p.is_absolute():
                p = pathlib.Path.cwd() / p
            p = p.resolve()
            try:
                rel = str(p.relative_to(root)).replace("\\", "/")
            except ValueError:
                print(
                    f"❌ {sanitize_display(raw)} is outside the repo root.",
                    file=sys.stderr,
                )
                raise SystemExit(ExitCode.USER_ERROR)
            current_stage = _interactive_patch(
                root, p, rel, head_manifest, current_stage
            )
        write_stage(root, current_stage)
        return

    # Non-patch mode: stage whole files.
    collected = _collect_paths(
        root, raw_paths, update_only=update, all_files=all_files,
        head_manifest=head_manifest, quiet=(json_out), head_dirs=head_dirs,
    )

    # Detect explicitly-named empty directories that _collect_paths skips
    # (it only returns files).  These are staged as content-addressed entries
    # (all empty dirs share EMPTY_DIR_OID) so empty dirs are first-class in the snapshot.
    empty_dirs_to_stage: list[str] = []
    if not update and not patch:
        if raw_paths and not all_files:
            # Walk each named directory for empty subdirs (and the dir itself
            # if empty).  _collect_paths only returns files, so we supplement.
            _dir_patterns = resolve_patterns(load_ignore_config(root), "code")
            roots_to_scan: list[pathlib.Path] = []
            for raw in raw_paths:
                p = pathlib.Path(raw)
                if not p.is_absolute():
                    p = pathlib.Path.cwd() / p
                p = p.resolve()
                if p.is_dir() and not _is_inside_muse_dir(root, p):
                    roots_to_scan.append(p)
            for scan_root in roots_to_scan:
                scan_root_str = str(scan_root)
                scan_prefix = len(str(root)) + 1
                for dp, dns, fns in os.walk(scan_root_str, followlinks=False):
                    dns[:] = sorted(
                        d for d in dns
                        if not _is_ignorable_dir(d)
                        and not os.path.isdir(os.path.join(dp, d, ".muse"))
                    )
                    if fns:
                        continue  # has files — covered by _collect_paths
                    abs_dp = pathlib.Path(dp)
                    if abs_dp == root:
                        continue  # skip repo root itself
                    try:
                        rel_dp = str(abs_dp.relative_to(root)).replace("\\", "/")
                    except ValueError:
                        continue
                    if not is_ignored(rel_dp + "/", _dir_patterns):
                        empty_dirs_to_stage.append(rel_dp)

    # Filter out files matched by .museignore so that staging never silently
    # commits files the user has explicitly excluded from version control.
    # Deleted tracked files (mode "D") are exempt — they must always be
    # stageable so the user can record their removal.
    _ignore_patterns = resolve_patterns(load_ignore_config(root), "code")
    root_str = str(root)
    prefix_len = len(root_str) + 1
    filtered: list[pathlib.Path] = []
    for p in collected:
        rel = str(p)[prefix_len:].replace("\\", "/") if str(p).startswith(root_str) else str(p)
        if not p.exists() and rel in head_manifest:
            filtered.append(p)   # staged deletion — always allowed
        elif not is_ignored(rel, _ignore_patterns):
            filtered.append(p)
    collected = filtered

    # Committed empty dirs deleted from disk — _collect_paths skips these because
    # it only handles file paths and head_manifest. We need a separate pass over
    # head_dirs to detect committed empty dirs that are now gone.
    _cover_all = all_files or update or not raw_paths
    deleted_committed_dirs: list[str] = []
    for _rel_dir in sorted(head_dirs):
        if (root / _rel_dir).is_dir():
            continue  # still exists on disk
        _existing = current_stage.get(_rel_dir)
        if _existing and _existing.get("object_id") == EMPTY_DIR_OID:
            continue  # already staged (mode A or D)
        if not _cover_all:
            # Only include if a named path covers this dir.
            _covered = False
            for _raw in raw_paths:
                _rp = pathlib.Path(_raw)
                if not _rp.is_absolute():
                    _rp = pathlib.Path.cwd() / _rp
                try:
                    _rel_guess = str(_rp.resolve().relative_to(root)).replace("\\", "/").rstrip("/")
                except ValueError:
                    continue
                if _rel_guess in ("", ".") or _rel_dir == _rel_guess or _rel_dir.startswith(_rel_guess + "/"):
                    _covered = True
                    break
            if not _covered:
                continue
        deleted_committed_dirs.append(_rel_dir)

    if not collected and not empty_dirs_to_stage and not deleted_committed_dirs and not update:
        if raw_paths:
            if json_out:
                print(_json.dumps(_CodeAddErrorJson(
                    **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                    error="No matching files found.",
                    staged=0,
                )))
            else:
                print("❌ No matching files found.", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        if json_out:
            print(_json.dumps(_CodeAddJson(
                **make_envelope(elapsed),
                staged=0, added=0, modified=0, deleted=0, files=[], dry_run=dry_run,
            )))
        else:
            print("Nothing to stage.")
        return

    added_count = 0
    modified_count = 0
    deleted_count = 0
    dirs_count = 0
    staged_files: list[_CodeAddFileEntry] = []
    # Strip any VCS-internal entries that may have leaked into the current stage
    # (e.g. written directly, or left behind when a commit was a no-op because
    # plugin.py stripped them from the snapshot before the identity check).
    updated_stage = {
        k: v for k, v in current_stage.items() if not k.startswith(".muse/")
    }

    _mode_label: _ModeLabel = {"A": "new file", "M": "modified", "D": "deleted"}

    cache = load_cache(root)

    for abs_path in collected:
        try:
            rel = str(abs_path.relative_to(root)).replace("\\", "/")
        except ValueError:
            print(
                f"⚠️  {sanitize_display(str(abs_path))} is outside the repo root — skipped.",
                file=sys.stderr,
            )
            continue

        exists = abs_path.exists()
        mode = _infer_mode(rel, head_manifest, exists)
        label = _mode_label[mode]

        if dry_run:
            if not json_out:
                print(f"  {label}: {sanitize_display(rel)}")
            staged_files.append({"path": rel, "mode": label})
            if mode == "A":
                added_count += 1
            elif mode == "M":
                modified_count += 1
            else:
                deleted_count += 1
            continue

        if mode == "D":
            existing = updated_stage.get(rel)
            if existing and existing.get("mode") == "D":
                continue  # already staged as deletion
            # Record the deletion with a sentinel empty object_id.
            # snapshot() will pop this path from the committed manifest.
            updated_stage[rel] = make_entry("", "D")
            if verbose and not json_out:
                print(f"  deleted:  {sanitize_display(rel)}")
            staged_files.append({"path": rel, "mode": label})
            deleted_count += 1
            continue

        try:
            object_id = cache.get_object_hash(root, abs_path)
            write_object_from_path(root, object_id, abs_path)
        except OSError as exc:
            print(f"❌ Cannot read {sanitize_display(rel)}: {exc}", file=sys.stderr)
            raise SystemExit(ExitCode.INTERNAL_ERROR)

        # Skip if the file's content is identical to the last committed version.
        # Without this check, `muse code add .` would stage every file in the
        # working tree regardless of whether anything actually changed — because
        # the "skip if already staged" guard below only fires after the first
        # `muse code add` run.
        committed_id = head_manifest.get(rel)
        if committed_id == object_id:
            if verbose and not json_out:
                print(f"  (unchanged) {sanitize_display(rel)}")
            continue

        # Skip if the staged version is already current.
        existing = updated_stage.get(rel)
        if existing and existing["object_id"] == object_id:
            if verbose and not json_out:
                print(f"  (unchanged) {sanitize_display(rel)}")
            continue

        updated_stage[rel] = make_entry(object_id, mode)
        if verbose and not json_out:
            print(f"  {label}:  {sanitize_display(rel)}")
        staged_files.append({"path": rel, "mode": label})
        if mode == "A":
            added_count += 1
        else:
            modified_count += 1

    if dry_run:
        total = added_count + modified_count + deleted_count
        if json_out:
            print(_json.dumps(_CodeAddJson(
                **make_envelope(elapsed),
                staged=total,
                added=added_count,
                modified=modified_count,
                deleted=deleted_count,
                files=staged_files,
                dry_run=True,
            )))
        else:
            print(f"\n{total} file(s) would be staged.")
        return

    # Stage empty directories (new additions) as content-addressed entries.
    write_object(root, EMPTY_DIR_OID, b"")  # ensure zero-byte object exists in store
    for rel_dir in empty_dirs_to_stage:
        if rel_dir in head_dirs:
            continue  # already committed — not a new addition
        existing = updated_stage.get(rel_dir)
        if existing and existing.get("object_id") == EMPTY_DIR_OID:
            continue  # already staged
        updated_stage[rel_dir] = make_entry(EMPTY_DIR_OID, "A")
        if verbose and not json_out:
            print(f"  new dir: {sanitize_display(rel_dir)}")
        staged_files.append({"path": rel_dir, "mode": "new dir"})
        dirs_count += 1

    # Stage committed empty directories deleted from disk (D sentinels).
    for rel_dir in deleted_committed_dirs:
        updated_stage[rel_dir] = make_entry(EMPTY_DIR_OID, "D")
        if verbose and not json_out:
            print(f"  deleted dir: {sanitize_display(rel_dir)}")
        staged_files.append({"path": rel_dir + "/", "mode": "deleted dir"})
        dirs_count += 1

    total = added_count + modified_count + deleted_count + dirs_count

    cache.save()
    write_stage(root, updated_stage)

    # Idiomatic git behaviour: staging a conflicted file marks it resolved.
    # Clear each newly-staged path from MERGE_STATE conflict_paths if a merge
    # is in progress — no explicit `muse resolve` step required.
    if not dry_run and staged_files:
        from muse.core.merge_engine import read_merge_state, resolve_path
        merge_state = read_merge_state(root)
        if merge_state and merge_state.conflict_paths:
            conflict_set = set(merge_state.conflict_paths)
            for entry in staged_files:
                if entry["path"] in conflict_set:
                    resolve_path(root, entry["path"])

    if json_out:
        print(_json.dumps(_CodeAddJson(
            **make_envelope(elapsed),
            staged=total,
            added=added_count,
            modified=modified_count,
            deleted=deleted_count,
            files=staged_files,
            dry_run=False,
        )))
    elif total == 0:
        print("Nothing new to stage — all files already up to date.")
    else:
        parts: list[str] = []
        if dirs_count:
            parts.append(f"{dirs_count} director{'ies' if dirs_count != 1 else 'y'}")
        if added_count:
            parts.append(f"{added_count} added file{'s' if added_count != 1 else ''}")
        if modified_count:
            parts.append(f"{modified_count} modified")
        if deleted_count:
            parts.append(f"{deleted_count} deleted")
        print(f"Staged {', '.join(parts)}.")

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _unstage_summary(paths: list[str], stage: Mapping[str, Mapping[str, str]]) -> str:
    """Return a human-readable summary of unstaged paths broken down by kind.

    Classifies each path as:
    - directory  — stage entry has object_id == EMPTY_DIR_OID
    - symbol     — path contains "::"
    - file       — everything else
    """
    dirs = sum(1 for p in paths if stage.get(p, {}).get("object_id") == EMPTY_DIR_OID)
    symbols = sum(1 for p in paths if "::" in p and stage.get(p, {}).get("object_id") != EMPTY_DIR_OID)
    files = len(paths) - dirs - symbols
    parts: list[str] = []
    if dirs:
        parts.append(f"{dirs} director{'ies' if dirs != 1 else 'y'}")
    if files:
        parts.append(f"{files} file{'s' if files != 1 else ''}")
    if symbols:
        parts.append(f"{symbols} symbol{'s' if symbols != 1 else ''}")
    return ", ".join(parts) if parts else "0 files"


# ---------------------------------------------------------------------------
# run_reset
# ---------------------------------------------------------------------------

def run_reset(args: argparse.Namespace) -> None:
    """Remove files from the stage without touching the working tree.

    With no arguments clears the entire stage.  With a file path unstages only
    that file, leaving the working-tree copy untouched.  Glob patterns are
    supported: ``muse code reset '*.py'`` unstages all staged Python files.

    Agent quickstart
    ----------------
    ::

        muse code reset --json
        muse code reset src/billing.py --json
        muse code reset --dry-run --json

    JSON fields
    -----------
    unstaged    Number of files removed from the stage.
    files       List of file paths that were unstaged.
    not_staged  List of paths requested but not found in the stage.
    dry_run     ``true`` when ``--dry-run`` was passed.

    Exit codes
    ----------
    0  Unstaged successfully (or nothing to unstage).
    1  Wrong domain.
    2  Not inside a Muse repository.
    """
    import fnmatch
    import json as _json

    elapsed = start_timer()
    raw_paths: list[str] = [p for p in args.paths if p != "HEAD"]
    json_out: bool = args.json_out
    dry_run: bool = getattr(args, "dry_run", False)

    root = require_repo()

    if read_domain(root) != "code":
        if json_out:
            print(_json.dumps(_CodeResetErrorJson(
                **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                error="'muse code reset' requires a code-domain repository.",
                unstaged=0,
            )))
        else:
            print("❌ 'muse code reset' requires a code-domain repository.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    current_stage = read_stage(root)

    if not current_stage:
        if json_out:
            print(_json.dumps(_CodeResetJson(
                **make_envelope(elapsed),
                unstaged=0, files=[], not_staged=[], dry_run=dry_run,
            )))
        else:
            print("Nothing staged.")
        return

    # ---- No paths given: unstage everything --------------------------------
    if not raw_paths:
        count = len(current_stage)
        cleared = sorted(current_stage.keys())
        if not dry_run:
            clear_stage(root)
        if json_out:
            print(_json.dumps(_CodeResetJson(
                **make_envelope(elapsed),
                unstaged=count,
                files=cleared,
                not_staged=[],
                dry_run=dry_run,
            )))
        elif dry_run:
            for f in cleared:
                print(f"  would unstage: {sanitize_display(f)}")
            print(f"\nWould unstage {_unstage_summary(cleared, current_stage)}.")
        else:
            print(f"Unstaged {_unstage_summary(cleared, current_stage)}.")
        return

    # ---- Specific paths / globs given --------------------------------------
    staged_keys = set(current_stage.keys())
    to_unstage: list[str] = []
    not_staged: list[str] = []

    for raw in raw_paths:
        # Try treating the input as a glob pattern against staged keys.
        # A pattern matches if any staged key matches it via fnmatch.
        # First attempt exact / path resolution (handles relative and absolute
        # paths unambiguously); fall back to glob if resolution shows it's
        # not a literal staged path.
        is_glob = any(c in raw for c in ("*", "?", "["))

        if is_glob:
            matched = [k for k in staged_keys if fnmatch.fnmatch(k, raw)]
            if matched:
                for m in matched:
                    if m not in to_unstage:
                        to_unstage.append(m)
            else:
                not_staged.append(raw)
            continue

        # Literal path — resolve to repo-relative POSIX key.
        p = pathlib.Path(raw)
        if not p.is_absolute():
            p = pathlib.Path.cwd() / p
        try:
            rel = str(p.resolve().relative_to(root)).replace("\\", "/")
        except ValueError:
            # Path is outside the repo root — cannot be staged.
            logger.warning("⚠️ Path %r is outside the repo root — skipping.", raw)
            if not json_out:
                print(
                    f"  ⚠️  {sanitize_display(raw)} is outside the repo root — skipped.",
                    file=sys.stderr,
                )
            not_staged.append(raw)
            continue

        if rel in staged_keys:
            if rel not in to_unstage:
                to_unstage.append(rel)
        else:
            not_staged.append(rel)

    # ---- Apply / preview ---------------------------------------------------
    if dry_run:
        if json_out:
            print(_json.dumps(_CodeResetJson(
                **make_envelope(elapsed),
                unstaged=len(to_unstage),
                files=to_unstage,
                not_staged=not_staged,
                dry_run=True,
            )))
        else:
            for f in to_unstage:
                print(f"  would unstage: {sanitize_display(f)}")
            for f in not_staged:
                print(f"  (not staged) {sanitize_display(f)}")
            print(f"\nWould unstage {_unstage_summary(to_unstage, current_stage)}.")
        return

    if to_unstage:
        updated = {k: v for k, v in current_stage.items() if k not in to_unstage}
        # Remove any dir rename where either the old or new path was unstaged.
        unstaged_set = set(to_unstage)
        cleaned_renames = {
            old: new for old, new in read_stage_dir_renames(root).items()
            if old not in unstaged_set and new not in unstaged_set
        }
        write_stage(root, updated, dir_renames=cleaned_renames)

    if json_out:
        print(_json.dumps(_CodeResetJson(
            **make_envelope(elapsed),
            unstaged=len(to_unstage),
            files=to_unstage,
            not_staged=not_staged,
            dry_run=False,
        )))
    else:
        for f in to_unstage:
            _is_dir = current_stage.get(f, {}).get("object_id") == EMPTY_DIR_OID
            _disp = sanitize_display(f) + ("/" if _is_dir and not f.endswith("/") else "")
            print(f"  unstaged: {_disp}")
        for f in not_staged:
            print(f"  (not staged) {sanitize_display(f)}")
        if to_unstage:
            print(f"Unstaged {_unstage_summary(to_unstage, current_stage)}.")
