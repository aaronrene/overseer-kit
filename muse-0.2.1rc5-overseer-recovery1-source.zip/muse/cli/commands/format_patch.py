"""``muse format-patch [<ref>|-N]`` — export commits as content-addressed .mpatch files.

A Muse patch is a domain-aware, content-addressed, agent-first exchange object.
Unlike a traditional unified diff, a ``.mpatch`` file:

- Has a stable ``patch_id = sha256(canonical JSON)`` — any tampering is
  immediately detectable before touching the working tree.
- Carries **Cohen action labels** on every op (``"inserted"``, ``"deleted"``,
  ``"modified"``, ``"moved"``, ``"renamed"``), so agents know *what* each side
  did without parsing raw diffs.
- Embeds **agent provenance**: ``agent_id``, ``model_id``, and signature.
- Declares **applicability**: which snapshot the target must be at, which
  dimensions are unaffected, and whether the patch is conflict-free.
- Is **domain-tagged** so apply-time validation can verify plugin compatibility.

Output schema (JSON, ``--json``)::

    {
      "patch_id":          "sha256:<64hex>",
      "from_snapshot_id":  "sha256:<64hex>",
      "to_snapshot_id":    "sha256:<64hex>",
      "from_commit_id":    "sha256:<64hex>",
      "to_commit_id":      "sha256:<64hex>",
      "domain":            "code",
      "format_version":    "1.0",
      "created_at":        "2026-01-01T00:00:00+00:00",
      "agent_id":          "",
      "model_id":          "",
      "signer_public_key": "",
      "signature":         "",
      "intent":            "",
      "sem_ver_bump":      "minor",
      "breaking_changes":  [],
      "summary":           "1 file added",
      "ops": [
        {
          "op":            "insert",
          "address":       "hello.py",
          "position":      null,
          "content_id":    "sha256:<64hex>",
          "content_summary": "hello.py added",
          "action_label":  "inserted"
        }
      ],
      "files_added":       ["hello.py"],
      "files_modified":    [],
      "files_deleted":     [],
      "files_renamed":     {},
      "required_objects":  ["sha256:<64hex>"],
      "from_manifest":     {},
      "to_manifest":       {"hello.py": "sha256:<64hex>"},
      "applicability": {
        "requires_snapshot":        "sha256:<64hex>",
        "independent_dimensions":   [],
        "conflict_free":            true
      },
      "duration_ms":       4.521,
      "exit_code":         0
    }

Targeting
---------
``muse format-patch``
    Produce one patch for the HEAD commit.

``muse format-patch <branch-or-commit>``
    Produce one patch for the named ref.

Flags
-----
``--output-dir <dir>``
    Write the patch to a ``.mpatch`` file in this directory.  The filename
    is ``<subject-slug>.mpatch``.  The directory must already exist.

``--json``
    Emit the full patch JSON to stdout instead of writing a file.

``--agent-id <id>``
    Agent identifier to embed in the patch record (e.g. ``"claude-code"``).
    Included in ``patch_id`` computation so different agents produce different
    patch IDs for the same commit.

``--model-id <id>``
    Model identifier to embed in the patch record (e.g. ``"claude-sonnet-4-6"``).

``--intent <text>``
    Human-readable intent description to embed in the patch record.  Useful
    for agents to communicate *why* a patch was produced.

``--no-blobs``
    Omit base64-encoded object content from the patch file.  ``required_objects``
    still lists which content objects the target needs; blobs must be fetched
    separately.  Produces significantly smaller patch files for large repos.

Exit codes::

    0 — success
    1 — user error: bad ref, empty repo
    2 — not a Muse repository
    3 — I/O error

Examples::

    muse format-patch --json
    muse format-patch --output-dir /tmp/patches
    muse format-patch feat/my-thing --json
"""

import argparse
import base64
import json as _json
import logging
import pathlib
import re
import sys

from muse.core.errors import ExitCode
from muse.core.object_store import read_object
from muse.core.patch_record import PatchApplicability, PatchOp, PatchRecord, PatchRecordDict, compute_patch_id, serialize_patch
from muse.core.repo import require_repo
from muse.core.refs import read_ref
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import (
    CommitRecord,
    read_commit,
    resolve_commit_ref,
)
from muse.core.snapshots import read_snapshot
from muse.core.validation import sanitize_display
from muse.core.types import NULL_LONG_ID, Manifest, long_id, now_utc_iso
from muse.core.paths import ref_path as _ref_path
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.timing import start_timer
from muse.plugins.registry import read_domain

logger = logging.getLogger(__name__)

class _FormatPatchJson(EnvelopeJson):
    """JSON output for ``muse format-patch --json``.

    Inherits the 6 standard envelope fields from :class:`~muse.core.envelope.EnvelopeJson`.
    All remaining fields mirror :class:`~muse.core.patch_record.PatchRecord`.
    """

    patch_id: str
    from_snapshot_id: str | None
    to_snapshot_id: str
    from_commit_id: str | None
    to_commit_id: str
    domain: str
    format_version: str
    created_at: str
    agent_id: str | None
    model_id: str | None
    signer_public_key: str | None
    signature: str | None
    intent: str | None
    sem_ver_bump: str | None
    breaking_changes: list[str]
    summary: str | None
    ops: list[PatchOp]
    files_added: list[str]
    files_modified: list[str]
    files_deleted: list[str]
    files_renamed: dict[str, str]
    required_objects: list[str]
    from_manifest: dict[str, str]
    to_manifest: dict[str, str]
    applicability: PatchApplicability
    blobs: dict[str, str]

_FORMAT_VERSION = "1.0"
_MAX_SUBJECT_LEN = 52

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _action_label(op_type: str) -> str:
    """Map a DomainOp ``op`` field to a Cohen action label.

    Args:
        op_type: The ``"op"`` field value from a DomainOp dict.

    Returns:
        One of ``"inserted"``, ``"deleted"``, ``"modified"``, ``"moved"``,
        ``"renamed"``.
    """
    if op_type == "insert":
        return "inserted"
    if op_type == "delete":
        return "deleted"
    if op_type in ("replace", "mutate", "patch"):
        return "modified"
    if op_type == "move":
        return "moved"
    if op_type == "rename":
        return "renamed"
    return "modified"

def _build_file_level_ops(
    base_manifest: Manifest,
    target_manifest: Manifest,
) -> tuple[list[dict], list[str], list[str], list[str], dict[str, str]]:
    """Derive file-level DomainOps from manifest deltas.

    Computes added/modified/deleted sets and detects renames (same object ID
    removed from one path and added at another).  Returns a list of DomainOp-like
    dicts (each with an ``action_label`` Cohen extension) plus the four
    file-change collections.

    Rename detection: when a path is deleted and a path is added that share the
    same content object ID, the pair is treated as a rename rather than a
    separate delete+insert.  The deleted path maps to the added path in
    ``files_renamed``; neither appears in ``files_added`` or ``files_deleted``.
    A single ``"move"`` op with ``action_label="moved"`` is emitted.

    Args:
        base_manifest:   Parent commit manifest.
        target_manifest: This commit manifest.

    Returns:
        ``(ops, files_added, files_modified, files_deleted, files_renamed)``
        where ``files_renamed`` maps old path → new path.
    """
    base_paths = set(base_manifest)
    target_paths = set(target_manifest)

    raw_added = sorted(target_paths - base_paths)
    raw_deleted = sorted(base_paths - target_paths)
    modified = sorted(
        p for p in base_paths & target_paths
        if base_manifest[p] != target_manifest[p]
    )

    # ── Rename detection ──────────────────────────────────────────────────────
    # Build OID → [deleted paths] and OID → [added paths] maps.
    # A deleted path whose OID appears exactly once on each side is a rename.
    deleted_by_oid: dict[str, list[str]] = {}
    for path in raw_deleted:
        oid = base_manifest[path]
        deleted_by_oid.setdefault(oid, []).append(path)

    added_by_oid: dict[str, list[str]] = {}
    for path in raw_added:
        oid = target_manifest[path]
        added_by_oid.setdefault(oid, []).append(path)

    files_renamed: dict[str, str] = {}
    renamed_old: set[str] = set()
    renamed_new: set[str] = set()

    for oid, del_paths in deleted_by_oid.items():
        add_paths = added_by_oid.get(oid, [])
        if len(del_paths) == 1 and len(add_paths) == 1:
            old_path = del_paths[0]
            new_path = add_paths[0]
            files_renamed[old_path] = new_path
            renamed_old.add(old_path)
            renamed_new.add(new_path)

    added = [p for p in raw_added if p not in renamed_new]
    deleted = [p for p in raw_deleted if p not in renamed_old]

    ops: list[dict] = []

    for path in added:
        ops.append({
            "op": "insert",
            "address": path,
            "position": None,
            "content_id": target_manifest[path],
            "content_summary": f"{sanitize_display(path)} added",
            "action_label": "inserted",
        })

    for path in deleted:
        ops.append({
            "op": "delete",
            "address": path,
            "position": None,
            "content_id": base_manifest[path],
            "content_summary": f"{sanitize_display(path)} deleted",
            "action_label": "deleted",
        })

    for path in modified:
        ops.append({
            "op": "replace",
            "address": path,
            "position": None,
            "old_content_id": base_manifest[path],
            "new_content_id": target_manifest[path],
            "old_summary": f"{sanitize_display(path)} before",
            "new_summary": f"{sanitize_display(path)} after",
            "action_label": "modified",
        })

    for old_path, new_path in sorted(files_renamed.items()):
        ops.append({
            "op": "move",
            "address": old_path,
            "new_address": new_path,
            "position": None,
            "content_id": base_manifest[old_path],
            "content_summary": f"{sanitize_display(old_path)} renamed to {sanitize_display(new_path)}",
            "action_label": "moved",
        })

    return ops, added, modified, deleted, files_renamed

def _sem_ver_bump(commit_message: str, files_added: list[str], files_deleted: list[str]) -> str:
    """Heuristic semantic version bump from commit message and file changes.

    - ``major`` if message starts with ``break:`` / ``feat!:`` or contains
      ``BREAKING CHANGE``.
    - ``minor`` if message starts with ``feat:``, or new files are added.
    - ``patch`` otherwise.

    Args:
        commit_message: The commit message string.
        files_added:    List of added file paths.
        files_deleted:  List of deleted file paths.

    Returns:
        ``"major"``, ``"minor"``, or ``"patch"``.
    """
    msg_lower = commit_message.lower().strip()
    if msg_lower.startswith(("break:", "feat!:")) or "breaking change" in msg_lower:
        return "major"
    if msg_lower.startswith("feat:") or files_added:
        return "minor"
    return "patch"

def _breaking_changes(commit_message: str) -> list[str]:
    """Extract breaking change descriptions from commit message.

    Looks for lines starting with ``BREAKING CHANGE:`` and returns them.

    Args:
        commit_message: The full commit message string.

    Returns:
        List of breaking change description strings.
    """
    changes = []
    for line in commit_message.splitlines():
        stripped = line.strip()
        if stripped.upper().startswith("BREAKING CHANGE:"):
            changes.append(stripped[len("BREAKING CHANGE:"):].strip())
    return changes

def _make_patch_filename(subject: str) -> str:
    """Build a filesystem-safe ``.mpatch`` filename from a commit subject.

    Args:
        subject: Commit message subject (first line).

    Returns:
        Filename like ``"feat-add-hello.mpatch"``.
    """
    safe = re.sub(r"[^\x20-\x7e]", "", subject)
    safe = re.sub(r"[/\\:*?\"<>|.]", "-", safe)
    safe = re.sub(r"\s+", "-", safe.strip())
    safe = re.sub(r"-{2,}", "-", safe)
    safe = safe.strip("-")
    if len(safe) > _MAX_SUBJECT_LEN:
        safe = safe[:_MAX_SUBJECT_LEN].rstrip("-")
    if not safe:
        safe = "patch"
    return f"{safe}.mpatch"

def _resolve_commit(root: pathlib.Path, treeish: str) -> CommitRecord:
    """Resolve *treeish* to a CommitRecord.

    Args:
        root:    Absolute repo root.
        treeish: Branch name, commit ID prefix, or ``"HEAD"``.

    Returns:
        CommitRecord.

    Raises:
        SystemExit(USER_ERROR): ref not found or empty repo.
    """
    try:
        branch = read_current_branch(root)

        if treeish.upper() == "HEAD":
            commit_id = get_head_commit_id(root, branch)
            if not commit_id:
                print("❌ Repository has no commits yet.", file=sys.stderr)
                raise SystemExit(ExitCode.USER_ERROR)
            commit = read_commit(root, commit_id)
        else:
            branch_ref = _ref_path(root, treeish)
            commit_id = read_ref(branch_ref)
            if commit_id is not None:
                commit = read_commit(root, commit_id)
            else:
                commit = resolve_commit_ref(root, branch, treeish)

        if commit is None:
            print(
                f"❌ '{sanitize_display(treeish)}' is not a known branch or commit ID.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)

        return commit

    except SystemExit:
        raise
    except Exception as exc:
        print(f"❌ Failed to resolve '{sanitize_display(treeish)}': {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``muse format-patch`` subcommand."""
    parser = subparsers.add_parser(
        "format-patch",
        help="Export a commit as a content-addressed .mpatch file.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "treeish",
        metavar="REF",
        nargs="?",
        default="HEAD",
        help="Commit to export (default: HEAD). Branch name or commit ID.",
    )
    parser.add_argument(
        "--output-dir", "-o",
        dest="output_dir",
        default=None,
        metavar="DIR",
        help="Directory to write the .mpatch file (must already exist).",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit the full patch JSON to stdout.",
    )
    parser.add_argument(
        "--agent-id",
        dest="agent_id",
        default="",
        metavar="ID",
        help="Agent identifier to embed in the patch record (e.g. 'claude-code').",
    )
    parser.add_argument(
        "--model-id",
        dest="model_id",
        default="",
        metavar="ID",
        help="Model identifier to embed in the patch record (e.g. 'claude-sonnet-4-6').",
    )
    parser.add_argument(
        "--intent",
        dest="intent",
        default="",
        metavar="TEXT",
        help="Human-readable intent description to embed in the patch record.",
    )
    parser.add_argument(
        "--no-blobs",
        action="store_true",
        dest="no_blobs",
        help="Omit base64 blob content from the patch file (required_objects still listed).",
    )
    parser.set_defaults(func=run)

# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Export a commit as a content-addressed Muse patch object.

    Produces a ``.mpatch`` JSON file (or stdout with ``--json``) that can be
    applied to another repo or agent working tree with ``muse apply-patch``.
    The patch is content-addressed — identical commits always produce the same
    patch ID, enabling deduplication across repos.

    Agent quickstart
    ----------------
    ::

        muse format-patch --json
        muse format-patch HEAD~3 --json
        muse format-patch HEAD --output-dir /tmp/patches --json
        muse format-patch HEAD --no-blobs --json

    JSON fields
    -----------
    patch_id      Content-addressed ID of the patch object.
    commit_id     Source commit ID.
    domain        Domain name the patch belongs to.
    from_manifest File manifest at the parent commit.
    to_manifest   File manifest after the commit.
    blobs         Embedded blob objects (omitted with ``--no-blobs``).

    Exit codes
    ----------
    0  Success.
    1  Bad ref or empty repository.
    2  Not inside a Muse repository.
    3  I/O error writing ``.mpatch`` file.
    """
    elapsed = start_timer()
    treeish: str = args.treeish or "HEAD"
    output_dir_raw: str | None = args.output_dir
    json_out: bool = args.json_out
    agent_id: str = getattr(args, "agent_id", "")
    model_id: str = getattr(args, "model_id", "")
    intent: str = getattr(args, "intent", "")
    no_blobs: bool = getattr(args, "no_blobs", False)

    root = require_repo()
    domain = read_domain(root)

    # ── Resolve commit ────────────────────────────────────────────────────────
    commit = _resolve_commit(root, treeish)

    # ── Load parent manifest ──────────────────────────────────────────────────
    base_manifest: Manifest = {}
    from_snapshot_id = NULL_LONG_ID  # sentinel for initial commit
    from_commit_id = ""

    if commit.parent_commit_id:
        parent = read_commit(root, commit.parent_commit_id)
        if parent:
            from_commit_id = parent.commit_id
            snap = read_snapshot(root, parent.snapshot_id)
            if snap:
                base_manifest = dict(snap.manifest)
                from_snapshot_id = parent.snapshot_id

    # ── Load this commit's manifest ───────────────────────────────────────────
    snap = read_snapshot(root, commit.snapshot_id)
    target_manifest: Manifest = dict(snap.manifest) if snap else {}
    to_snapshot_id = commit.snapshot_id

    # ── Build ops and file lists ──────────────────────────────────────────────
    ops, files_added, files_modified, files_deleted, files_renamed = _build_file_level_ops(
        base_manifest, target_manifest
    )

    # ── Build delta manifests (changed paths only) ────────────────────────────
    # Renamed paths: old path in from_manifest, new path in to_manifest
    renamed_old = set(files_renamed.keys())
    renamed_new = set(files_renamed.values())
    changed_paths = set(files_added) | set(files_modified) | set(files_deleted) | renamed_old | renamed_new
    from_manifest_delta = {p: base_manifest[p] for p in changed_paths if p in base_manifest}
    to_manifest_delta = {p: target_manifest[p] for p in changed_paths if p in target_manifest}

    # ── Required objects: to_manifest delta values ───────────────────────────
    required_objects = sorted(set(to_manifest_delta.values()))

    # ── Embed blobs for self-contained transport ──────────────────────────────
    blobs: dict[str, str] = {}
    if not no_blobs:
        for oid in required_objects:
            content = read_object(root, oid)
            if content is not None:
                blobs[oid] = base64.b64encode(content).decode("ascii")

    # ── Semantic version impact ───────────────────────────────────────────────
    message = commit.message or ""
    subject = message.splitlines()[0] if message else ""
    bump = _sem_ver_bump(message, files_added, files_deleted)
    breaking = _breaking_changes(message)

    # ── Summary ───────────────────────────────────────────────────────────────
    parts = []
    if files_added:
        n = len(files_added)
        parts.append(f"{n} file{'s' if n > 1 else ''} added")
    if files_modified:
        n = len(files_modified)
        parts.append(f"{n} file{'s' if n > 1 else ''} modified")
    if files_deleted:
        n = len(files_deleted)
        parts.append(f"{n} file{'s' if n > 1 else ''} deleted")
    summary = ", ".join(parts) if parts else "no file changes"

    # ── Applicability ─────────────────────────────────────────────────────────
    applicability = {
        "requires_snapshot": from_snapshot_id,
        "independent_dimensions": [],
        "conflict_free": True,
    }

    # ── Build PatchRecord ─────────────────────────────────────────────────────
    # Use the commit's timestamp as created_at so patch_id is deterministic
    # for the same commit regardless of when format-patch is invoked.
    created_at = commit.committed_at.isoformat() if commit.committed_at else now_utc_iso()
    rec = PatchRecord(
        patch_id="",
        from_snapshot_id=from_snapshot_id,
        to_snapshot_id=to_snapshot_id,
        from_commit_id=from_commit_id,
        to_commit_id=commit.commit_id,
        domain=domain,
        format_version=_FORMAT_VERSION,
        created_at=created_at,
        agent_id=agent_id,
        model_id=model_id,
        signer_public_key="",
        signature="",
        intent=intent,
        sem_ver_bump=bump,
        breaking_changes=breaking,
        summary=summary,
        ops=ops,
        files_added=files_added,
        files_modified=files_modified,
        files_deleted=files_deleted,
        files_renamed=files_renamed,
        required_objects=required_objects,
        from_manifest=from_manifest_delta,
        to_manifest=to_manifest_delta,
        applicability=applicability,
        blobs=blobs,
    )
    rec.patch_id = compute_patch_id(rec)

    # ── Output ────────────────────────────────────────────────────────────────
    if json_out:
        print(_json.dumps(_FormatPatchJson(**make_envelope(elapsed), **_record_to_json_dict(rec)), separators=(",", ":")))
        return

    if output_dir_raw is not None:
        out_dir = pathlib.Path(output_dir_raw)
        if not out_dir.is_dir():
            print(
                f"❌ Output directory does not exist: {sanitize_display(output_dir_raw)}",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.IO_ERROR)
        filename = _make_patch_filename(subject)
        dest = out_dir / filename
        try:
            dest.write_bytes(serialize_patch(rec))
        except OSError as exc:
            print(f"❌ Could not write {filename}: {exc}", file=sys.stderr)
            raise SystemExit(ExitCode.IO_ERROR)
        print(filename)
        return

    # Default: print filename hint
    print(serialize_patch(rec).decode("utf-8"))

def _record_to_json_dict(rec: PatchRecord) -> PatchRecordDict:
    """Convert a PatchRecord to a plain dict for JSON output."""
    return {
        "patch_id": rec.patch_id,
        "from_snapshot_id": rec.from_snapshot_id,
        "to_snapshot_id": rec.to_snapshot_id,
        "from_commit_id": rec.from_commit_id,
        "to_commit_id": rec.to_commit_id,
        "domain": rec.domain,
        "format_version": rec.format_version,
        "created_at": rec.created_at,
        "agent_id": rec.agent_id,
        "model_id": rec.model_id,
        "signer_public_key": rec.signer_public_key,
        "signature": rec.signature,
        "intent": rec.intent,
        "sem_ver_bump": rec.sem_ver_bump,
        "breaking_changes": list(rec.breaking_changes),
        "summary": rec.summary,
        "ops": list(rec.ops),
        "files_added": list(rec.files_added),
        "files_modified": list(rec.files_modified),
        "files_deleted": list(rec.files_deleted),
        "files_renamed": dict(rec.files_renamed),
        "required_objects": list(rec.required_objects),
        "from_manifest": dict(rec.from_manifest),
        "to_manifest": dict(rec.to_manifest),
        "applicability": dict(rec.applicability),
        "blobs": dict(rec.blobs),
    }
