"""``muse apply <patch-file>`` — apply .patch files to the working tree.

Reads unified diff patch files (as produced by ``muse format-patch``) and
applies them to the working tree.  Supports mail-format patches with commit
metadata headers.

Flags
-----
``--check``
    Validate the patch can apply cleanly without modifying any files.
    Exits 0 if the patch applies cleanly, non-zero if there are conflicts.

``--staged``
    After applying, stage the modified files (add them to the index).

``--json``
    Emit a JSON summary::

        {"applied": ["a.py", "b.py"], "failed": ["c.py"]}

Exit codes::

    0 — success (all hunks applied)
    1 — user error: patch file not found, conflicts, path traversal
    2 — not a Muse repository

Examples::

    muse apply 0001-feat-add-login.patch
    muse apply 0001-feat.patch --check
    muse apply 0001-feat.patch --json
    muse apply 0001-feat.patch --staged
"""

import argparse
import json as _json
import logging
import pathlib
import re
import sys
from typing import Iterator, TypedDict

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.timing import start_timer
from muse.core.validation import contain_path, sanitize_display

logger = logging.getLogger(__name__)

class _PatchHunk(TypedDict, total=False):
    old_start: int
    context_before: list[str]
    removes: list[str]
    adds: list[str]
    context_after: list[str]
    _phase: str

class _FileDiff(TypedDict):
    path: str | None
    hunks: list[_PatchHunk]
    is_new: bool
    is_delete: bool

class _ApplyJson(EnvelopeJson):
    """JSON output of ``muse apply --json``."""

    applied: list[str]
    failed: list[str]

# Matches unified diff file headers: --- a/path or +++ b/path
_FROM_RE = re.compile(r"^--- (?:a/)?(.+?)(?:\t.*)?$")
_TO_RE = re.compile(r"^\+\+\+ (?:b/)?(.+?)(?:\t.*)?$")
# Matches hunk headers: @@ -old_start[,old_count] +new_start[,new_count] @@
_HUNK_RE = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")
# Mail-format headers to skip
_MAIL_HEADERS = re.compile(r"^(From |Date: |Subject: |X-Muse-Commit-ID: |From: )")

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _strip_mail_headers(lines: list[str]) -> list[str]:
    """Remove mail-format header block from the beginning of a patch."""
    # Find the start of the actual diff content (--- line or diff --git line)
    for i, line in enumerate(lines):
        if line.startswith("--- ") or line.startswith("diff --"):
            return lines[i:]
    return lines

def _parse_patch(patch_text: str) -> list[_FileDiff]:
    """Parse a unified diff patch string into a list of per-file diffs.

    Args:
        patch_text: Full patch file content (may include mail-format headers).

    Returns:
        List of dicts, each with keys:
            - ``path``: target file path (str)
            - ``hunks``: list of hunk dicts
            - ``is_new``: True if this is a new file (no base)
            - ``is_delete``: True if this deletes a file
    """
    lines = patch_text.splitlines(keepends=True)
    lines = _strip_mail_headers(lines)

    file_diffs: list[_FileDiff] = []
    current: _FileDiff | None = None
    current_hunk: _PatchHunk | None = None
    i = 0

    while i < len(lines):
        line = lines[i]

        # File header: --- a/path
        if line.startswith("--- "):
            m = _FROM_RE.match(line.rstrip("\n"))
            from_path = m.group(1) if m else None
            i += 1
            # Next should be +++ b/path
            if i < len(lines) and lines[i].startswith("+++ "):
                m2 = _TO_RE.match(lines[i].rstrip("\n"))
                to_path = m2.group(1) if m2 else None
                i += 1
            else:
                to_path = from_path

            # Flush previous file
            if current is not None:
                if current_hunk is not None:
                    current["hunks"].append(current_hunk)
                    current_hunk = None
                file_diffs.append(current)

            path = to_path if to_path and to_path != "/dev/null" else from_path
            is_new = from_path == "/dev/null"
            is_delete = to_path == "/dev/null"

            current = {
                "path": path,
                "hunks": [],
                "is_new": is_new,
                "is_delete": is_delete,
            }
            continue

        # Hunk header: @@ -old_start,old_count +new_start,new_count @@
        if line.startswith("@@") and current is not None:
            m = _HUNK_RE.match(line)
            if m:
                if current_hunk is not None:
                    current["hunks"].append(current_hunk)
                old_start = int(m.group(1))
                current_hunk = {
                    "old_start": old_start,
                    "context_before": [],
                    "removes": [],
                    "adds": [],
                    "context_after": [],
                    "_phase": "removes",  # internal state
                }
            i += 1
            continue

        # Diff content lines
        if current_hunk is not None:
            stripped = line.rstrip("\n")
            # Mail trailer "-- " or "--" signals end of patch content
            if stripped in ("--", "-- "):
                current["hunks"].append(current_hunk)
                current_hunk = None
            elif stripped.startswith("+"):
                current_hunk["adds"].append(f"{stripped[1:]}\n")
                current_hunk["_phase"] = "adds_seen"
            elif stripped.startswith("-"):
                current_hunk["removes"].append(f"{stripped[1:]}\n")
            elif stripped.startswith(" "):
                ctx_line = f"{stripped[1:]}\n"
                if current_hunk["_phase"] == "adds_seen":
                    current_hunk["context_after"].append(ctx_line)
                else:
                    current_hunk["context_before"].append(ctx_line)
            elif stripped == "":
                # Bare blank line: encoding artifact from lineterm="" — skip.
                pass
            elif stripped.startswith("\\"):
                pass  # "\ No newline at end of file"
            else:
                # Non-diff line — end of hunk
                if current_hunk is not None:
                    current["hunks"].append(current_hunk)
                    current_hunk = None

        i += 1

    # Flush last hunk and file
    if current is not None:
        if current_hunk is not None:
            current["hunks"].append(current_hunk)
        file_diffs.append(current)

    # Clean up internal state keys
    for fd in file_diffs:
        for h in fd["hunks"]:
            h.pop("_phase", None)

    return file_diffs

def _apply_hunk(lines: list[str], hunk: _PatchHunk) -> tuple[list[str], bool]:
    """Apply a single unified diff hunk to a list of file lines.

    Searches for the hunk's context + remove lines starting near ``old_start``,
    then replaces them with the add lines.

    Args:
        lines:  Current file lines (with newlines).
        hunk:   Hunk dict as returned by ``_parse_patch``.

    Returns:
        ``(result_lines, success)`` — modified lines and a success flag.
    """
    old_start = hunk["old_start"]
    removes = hunk["removes"]
    adds = hunk["adds"]
    ctx_before = hunk["context_before"]
    ctx_after = hunk["context_after"]

    # Build the sequence of lines we expect to find (context + removes).
    expected = list(ctx_before) + list(removes)

    if not expected and not removes:
        # Pure insertion — find insertion point at old_start
        insert_at = min(old_start - 1, len(lines))
        return lines[:insert_at] + list(adds) + lines[insert_at:], True

    # Search for the expected lines near old_start (1-indexed → 0-indexed).
    search_start = max(0, old_start - 1)

    for offset in range(len(lines) + 1):
        for direction in (0, 1, -1):
            pos = search_start + direction * offset
            if pos < 0 or pos + len(expected) > len(lines):
                continue
            if lines[pos : pos + len(expected)] == expected:
                # Found it — replace removes with adds, keep context
                result = (
                    lines[:pos]
                    + list(ctx_before)
                    + list(adds)
                    + lines[pos + len(expected):]
                )
                return result, True
        if offset > max(10, len(lines)):
            break

    return lines, False

def _validate_path(root: pathlib.Path, path: str) -> pathlib.Path | None:
    """Validate and resolve a patch path against the repo root.

    Returns the absolute path if safe, or None if the path is unsafe.
    """
    # Reject paths that are absolute or contain traversal components
    if ".." in pathlib.PurePosixPath(path).parts:
        return None
    if pathlib.Path(path).is_absolute():
        return None

    # Reject writes to .muse/ internals
    parts = pathlib.PurePosixPath(path).parts
    if parts and parts[0] == ".muse":
        return None

    try:
        abs_path = contain_path(root, path)
        return abs_path
    except (ValueError, Exception):
        return None

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``muse apply`` subcommand."""
    parser = subparsers.add_parser(
        "apply",
        help="Apply .patch files to the working tree.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "patch_file",
        metavar="PATCH",
        help="Path to the .patch file to apply.",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Validate the patch without modifying files.",
    )
    parser.add_argument(
        "--staged",
        action="store_true",
        help="Stage modified files after applying.",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit a JSON summary of applied/failed files.",
    )
    parser.set_defaults(func=run)

# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Apply a unified diff patch file to the working tree.

    Use ``--check`` to validate the patch without writing any files.
    Generates patches with ``muse format-patch``.

    Agent quickstart
    ----------------
    ::

        muse apply my.patch --json
        muse apply my.patch --check --json   # dry-run: validate only

    JSON fields
    -----------
    applied     List of file paths successfully patched.
    skipped     List of file paths skipped (already applied or conflicts).
    conflicts   List of file paths with unresolvable conflicts.
    check_only  ``true`` when ``--check`` was passed (no writes occurred).

    Exit codes
    ----------
    0  Patch applied successfully.
    1  Patch conflicts or bad paths.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    patch_path = pathlib.Path(args.patch_file)
    check_only: bool = args.check
    json_out: bool = args.json_out

    if not patch_path.exists():
        print(f"❌ Patch file not found: {sanitize_display(str(patch_path))}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    try:
        patch_text = patch_path.read_text(encoding="utf-8")
    except OSError as exc:
        print(f"❌ Cannot read patch file: {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.IO_ERROR)

    root = require_repo()

    file_diffs = _parse_patch(patch_text)

    if not file_diffs:
        print("❌ No file diffs found in patch.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    applied: list[str] = []
    failed: list[str] = []

    for fd in file_diffs:
        raw_path = fd["path"]
        abs_path = _validate_path(root, raw_path)

        if abs_path is None:
            print(
                f"❌ Unsafe path in patch: {sanitize_display(raw_path)}",
                file=sys.stderr,
            )
            failed.append(raw_path)
            if not json_out:
                raise SystemExit(ExitCode.USER_ERROR)
            continue

        # Load current file content
        if abs_path.exists():
            current_lines = abs_path.read_text(encoding="utf-8").splitlines(keepends=True)
        else:
            current_lines = []

        # Apply all hunks in order
        result_lines = list(current_lines)
        all_ok = True
        for hunk in fd["hunks"]:
            result_lines, ok = _apply_hunk(result_lines, hunk)
            if not ok:
                all_ok = False
                break

        if not all_ok:
            failed.append(raw_path)
            if check_only and not json_out:
                raise SystemExit(ExitCode.USER_ERROR)
            continue

        applied.append(raw_path)

        if not check_only:
            try:
                abs_path.parent.mkdir(parents=True, exist_ok=True)
                abs_path.write_text("".join(result_lines), encoding="utf-8")
            except OSError as exc:
                print(f"❌ Cannot write {sanitize_display(raw_path)}: {exc}", file=sys.stderr)
                failed.append(raw_path)
                applied.remove(raw_path)

    # Output
    if json_out:
        print(_json.dumps(_ApplyJson(**make_envelope(elapsed), applied=applied, failed=failed)))
    else:
        for p in applied:
            print(f"✓ {p}")
        for p in failed:
            print(f"✗ {p}")

    if failed:
        raise SystemExit(ExitCode.USER_ERROR)
