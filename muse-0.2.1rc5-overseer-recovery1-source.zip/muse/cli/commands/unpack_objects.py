"""muse unpack-objects — read a MPack from stdin and write to store.

Reads a MPack msgpack binary from stdin and idempotently writes its
commits, snapshots, blobs, and tags into the local ``.muse/`` store.

Usage::

    cat pack.muse | muse unpack-objects
    muse pack-objects HEAD | muse unpack-objects

Output::

    {
      "commits_written":   12,
      "snapshots_written": 12,
      "blobs_written":     47,
      "blobs_skipped":     3,
      "tags_written":      2,
      "duration_ms":        8.3,
      "exit_code":         0
    }

Output contract
---------------

- Exit 0: blobs unpacked (idempotent — already-present blobs are skipped).
- Exit 1: invalid input (bad format flag, malformed msgpack, not a top-level map).
- Exit 3: write failure (``apply_mpack`` raised ``OSError``).

JSON error contract
-------------------

When ``--json`` (or ``--format json``) is active, **all** errors are emitted
to **stdout** (not stderr) so agents can always parse a structured response::

    {"error": "<key>", "message": "<description>", "duration_ms": 0.3, "exit_code": 1}

Exit codes::

    0 — success
    1 — user error (bad format, invalid msgpack, not a map)
    3 — write failure (OSError from apply_mpack)
"""

import argparse
import json
import logging
import sys
from typing import TypeGuard

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.mpack import MPack, apply_mpack
from muse.core.repo import require_repo
from muse.core.io import MAX_PACK_MSGPACK_BYTES, safe_unpackb
from muse.core.types import MsgpackValue
from muse.core.commits import CommitDict
from muse.core.snapshots import SnapshotDict
from muse.core.types import BranchHeads
from muse.core.timing import start_timer

class _UnpackObjectsJson(EnvelopeJson):
    commits_written: int
    snapshots_written: int
    blobs_written: int
    blobs_skipped: int
    tags_written: int

logger = logging.getLogger(__name__)

def _is_commit_dict(v: MsgpackValue) -> TypeGuard[CommitDict]:
    """TypeGuard for narrowing MsgpackValue → CommitDict at the wire boundary."""
    return isinstance(v, dict)

def _is_snapshot_dict(v: MsgpackValue) -> TypeGuard[SnapshotDict]:
    """TypeGuard for narrowing MsgpackValue → SnapshotDict at the wire boundary."""
    return isinstance(v, dict)

def _as_branch_heads(v: MsgpackValue) -> BranchHeads:
    """Extract branch_heads from a wire payload, narrowing safely."""
    if not isinstance(v, dict):
        return {}
    return {str(k): str(val) for k, val in v.items() if isinstance(val, str)}

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the unpack-objects subcommand."""
    parser = subparsers.add_parser(
        "unpack-objects",
        help="Read a MPack JSON from stdin, write to the local store.",
        description=__doc__,
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON on stdout.",
    )
    parser.set_defaults(func=run, json_out=False)

def run(args: argparse.Namespace) -> None:
    """Read a MPack from stdin and write to the local store.

    Idempotently writes commits, snapshots, blobs, and tags from a msgpack
    binary on stdin.  Already-present blobs are silently skipped.  Partial
    packs are safe to re-apply — the store is always consistent after the call.

    Agent quickstart::

        cat pack.muse | muse unpack-objects --json
        muse pack-objects HEAD | muse unpack-objects --json

    JSON fields::

        commits_written   Number of commit records written to the store.
        snapshots_written Number of snapshot records written to the store.
        blobs_written     Number of content blobs written.
        blobs_skipped     Number of blobs already present (skipped).
        tags_written      Number of tag records written.
        muse_version      Muse release that produced this output.
        schema            Envelope schema version (int).
        exit_code         0 on success, 1 on user error, 3 on write failure.
        duration_ms       Wall-clock milliseconds for the command.
        timestamp         ISO-8601 UTC timestamp of command completion.
        warnings          List of non-fatal advisory messages.

    Exit codes::

        0  Objects unpacked successfully.
        1  User error (bad format, malformed msgpack, not a top-level map).
        3  Write failure (OSError from apply_mpack).
    """
    elapsed = start_timer()
    json_out: bool = args.json_out

    def _emit_error(msg: str, code: int, error_key: str = "error") -> None:
        if json_out:
            print(json.dumps({**make_envelope(elapsed, exit_code=code), "error": error_key, "message": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(code)

    root = require_repo()

    raw_bytes = sys.stdin.buffer.read()
    try:
        raw_dict = safe_unpackb(
            raw_bytes,
            context="stdin",
            max_bytes=MAX_PACK_MSGPACK_BYTES,
            allow_binary=True,
        )
    except Exception as exc:
        _emit_error(f"Invalid msgpack from stdin: {exc}", ExitCode.USER_ERROR, "invalid_msgpack")

    if not isinstance(raw_dict, dict):
        _emit_error("Expected a msgpack map at the top level.", ExitCode.USER_ERROR, "invalid_format")

    from muse.core.mpack import BlobPayload

    raw_blobs: list[BlobPayload] = []
    raw_blobs_v = raw_dict.get("blobs")
    for item in (raw_blobs_v if isinstance(raw_blobs_v, list) else []):
        if isinstance(item, dict):
            oid = item.get("object_id")
            content = item.get("content")
            if isinstance(oid, str) and isinstance(content, (bytes, bytearray)):
                raw_blobs.append(BlobPayload(object_id=oid, content=bytes(content)))

    raw_commits = raw_dict.get("commits")
    raw_snapshots = raw_dict.get("snapshots")
    mpack = MPack(
        commits=[r for r in raw_commits if _is_commit_dict(r)] if isinstance(raw_commits, list) else [],
        snapshots=[r for r in raw_snapshots if _is_snapshot_dict(r)] if isinstance(raw_snapshots, list) else [],
        blobs=raw_blobs,
        branch_heads=_as_branch_heads(raw_dict.get("branch_heads")),
    )

    try:
        result = apply_mpack(root, mpack)
    except OSError as exc:
        _emit_error(str(exc), ExitCode.INTERNAL_ERROR, "write_error")

    if not json_out:
        print(
            f"Wrote {result['commits_written']} commits, "
            f"{result['snapshots_written']} snapshots, "
            f"{result['blobs_written']} blobs, "
            f"{result['tags_written']} tags "
            f"({result['blobs_skipped']} skipped)."
        )
        return

    print(json.dumps(_UnpackObjectsJson(
        **make_envelope(elapsed),
        commits_written=result["commits_written"],
        snapshots_written=result["snapshots_written"],
        blobs_written=result["blobs_written"],
        blobs_skipped=result["blobs_skipped"],
        tags_written=result["tags_written"],
    )))
