"""muse code compare — semantic comparison between any two historical snapshots.

``muse diff`` compares the working tree to HEAD.  ``muse code compare``
compares any two historical commits — a full semantic diff between a release
tag and the current HEAD, between the start and end of a sprint, between two
branches.

Unlike a line-level diff, ``muse code compare`` tracks:

- Functions / classes **added** or **removed**
- Symbols **renamed** or **moved** across files (not just deleted + re-added)
- **Signature changes** vs **implementation-only** changes

Pass ``--semver`` to get an automatic MAJOR / MINOR / PATCH recommendation
based on public API changes: removed symbols → MAJOR, added symbols → MINOR,
implementation-only changes → PATCH.

Usage::

    muse code compare HEAD~10 HEAD          (use commit SHAs, not ~ notation)
    muse code compare a3f2c9 cb4afa
    muse code compare a3f2c9 cb4afa --kind function
    muse code compare a3f2c9 cb4afa --file billing.py
    muse code compare a3f2c9 cb4afa --semver
    muse code compare a3f2c9 cb4afa --stat
    muse code compare a3f2c9 cb4afa --json

Output::

    Semantic comparison
      From: a3f2c9e1  "Add billing module"
      To:   cb4afaed  "Merge: release v1.0"

    src/billing.py
      added     compute_invoice_total        (renamed from calculate_total)
      modified  Invoice.to_dict              (signature changed)
      moved     validate_amount              → src/validation.py

    src/validation.py  (new file)
      added     validate_amount              (moved from src/billing.py)

    7 symbol change(s) across 3 file(s)
    SemVer impact: MINOR
"""

import argparse
import json
import logging
import pathlib
import sys
from typing import TypedDict

from muse.core.types import Manifest
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.refs import read_current_branch
from muse.core.commits import resolve_commit_ref
from muse.core.snapshots import get_commit_snapshot_manifest
from muse.core.timing import start_timer
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.symbol_cache import load_symbol_cache
from muse.domain import DomainOp
from muse.plugins.code._query import language_of, normalise_language, symbols_for_snapshot
from muse.plugins.code.symbol_diff import build_diff_ops
from muse.core.validation import sanitize_display

logger = logging.getLogger(__name__)

class _OpSummary(TypedDict):
    op: str
    address: str
    detail: str

class _CommitRef(TypedDict):
    commit_id: str
    message: str

class _CompareFilters(TypedDict):
    kind: str | None
    file: str | None
    language: str | None

class _CompareStat(TypedDict):
    files_changed: int
    symbols_added: int
    symbols_removed: int
    symbols_modified: int
    semver_impact: str

# ``from`` is a Python keyword, so use the functional TypedDict form for the
# domain payload, then inherit into a class-based TypedDict that also inherits
# EnvelopeJson — giving us proper wire-shape typing without workarounds.
_ComparePayload = TypedDict("_ComparePayload", {
    "from": _CommitRef,
    "to": _CommitRef,
    "filters": _CompareFilters,
    "stat": _CompareStat,
    "ops": list[_OpSummary],
})

class _CompareJson(_ComparePayload, EnvelopeJson):
    """Full wire shape for ``muse code compare --json``."""

def _first_line(message: str) -> str:
    """Return the first non-empty line of a commit message."""
    for line in message.splitlines():
        stripped = line.strip()
        if stripped:
            return stripped
    return message.strip()

def _is_public_name(address: str) -> bool:
    """Return True if the symbol is a public, non-import API symbol.

    Excludes:
    - Import pseudo-symbols (``::import::*``) — dependency management, not API.
    - Private names starting with ``_``.
    """
    if "::import::" in address:
        return False
    name = address.split("::")[-1] if "::" in address else address
    return not name.startswith("_")

def _assess_semver(ops: list[DomainOp]) -> tuple[str, list[str]]:
    """Return (bump_level, reasons) from the diff ops.

    Rules applied to public symbols only (names not starting with ``_``):

    MAJOR — symbol removed, or signature / rename / move change.
    MINOR — symbol added (no MAJOR triggers).
    PATCH — only implementation changes.
    NONE  — empty diff.
    """
    reasons: list[str] = []
    has_major = False
    has_minor = False
    has_patch = False

    for op in ops:
        if op["op"] == "patch":
            for child in op["child_ops"]:
                addr: str = child["address"]
                if not _is_public_name(addr):
                    continue
                if child["op"] == "delete":
                    has_major = True
                    reasons.append(f"removed: {addr}")
                elif child["op"] == "insert":
                    has_minor = True
                elif child["op"] == "replace":
                    ns: str = child["new_summary"]
                    if any(kw in ns for kw in ("signature", "renamed", "moved")):
                        has_major = True
                        reasons.append(f"breaking: {addr} — {ns}")
                    else:
                        has_patch = True
        elif op["op"] == "delete":
            addr2: str = op["address"]
            if _is_public_name(addr2):
                has_major = True
                reasons.append(f"file removed: {addr2}")
        elif op["op"] == "insert":
            if _is_public_name(op["address"]):
                has_minor = True

    if has_major:
        return "MAJOR", reasons
    if has_minor:
        return "MINOR", []
    if has_patch:
        return "PATCH", []
    return "NONE", []

def _count_ops(ops: list[DomainOp]) -> tuple[int, int, int, int]:
    """Return (added, removed, modified, files_changed) from diff ops."""
    added = removed = modified = 0
    files: set[str] = set()
    for op in ops:
        if op["op"] == "patch":
            if op["child_ops"]:
                files.add(op["address"])
            for child in op["child_ops"]:
                if child["op"] == "insert":
                    added += 1
                elif child["op"] == "delete":
                    removed += 1
                elif child["op"] == "replace":
                    modified += 1
        elif op["op"] == "insert":
            files.add(op["address"])
            added += 1
        elif op["op"] == "delete":
            files.add(op["address"])
            removed += 1
        elif op["op"] == "replace":
            files.add(op["address"])
            modified += 1
    return added, removed, modified, len(files)

def _format_child_op(op: DomainOp) -> str:
    """Return a compact one-line description of a symbol-level op."""
    addr: str = op["address"]
    name = addr.split("::")[-1] if "::" in addr else addr
    if op["op"] == "insert":
        summary: str = op["content_summary"]
        moved = (
            f"  (moved from {summary.split('moved from')[-1].strip()})"
            if "moved from" in summary else ""
        )
        return f"  added     {name}{moved}"
    if op["op"] == "delete":
        summary2: str = op["content_summary"]
        moved2 = (
            f"  (moved to {summary2.split('moved to')[-1].strip()})"
            if "moved to" in summary2 else ""
        )
        return f"  removed   {name}{moved2}"
    if op["op"] == "replace":
        ns: str = op["new_summary"]
        detail = f"  ({ns})" if ns else ""
        return f"  modified  {name}{detail}"
    return f"  changed   {name}"

def _flatten_ops(ops: list[DomainOp]) -> list[_OpSummary]:
    """Flatten all ops to a serialisable summary list."""
    result: list[_OpSummary] = []
    for op in ops:
        if op["op"] == "patch":
            for child in op["child_ops"]:
                if child["op"] == "insert":
                    detail: str = child["content_summary"]
                elif child["op"] == "delete":
                    detail = child["content_summary"]
                elif child["op"] == "replace":
                    detail = child["new_summary"]
                else:
                    detail = ""
                result.append(_OpSummary(
                    op=child["op"],
                    address=child["address"],
                    detail=detail,
                ))
        elif op["op"] == "insert":
            result.append(_OpSummary(op="insert", address=op["address"], detail=op["content_summary"]))
        elif op["op"] == "delete":
            result.append(_OpSummary(op="delete", address=op["address"], detail=op["content_summary"]))
        elif op["op"] == "replace":
            result.append(_OpSummary(op="replace", address=op["address"], detail=op["new_summary"]))
        else:
            result.append(_OpSummary(op=op["op"], address=op["address"], detail=""))
    return result

def _filter_manifest_by_language(
    manifest: Manifest, language: str
) -> Manifest:
    return {p: h for p, h in manifest.items() if language_of(p) == language}

def _filter_ops_by_file(ops: list[DomainOp], file_filter: str) -> list[DomainOp]:
    """Keep only ops whose address is or ends with *file_filter*."""
    return [
        op for op in ops
        if op.get("address", "") == file_filter
        or op.get("address", "").endswith(f"/{file_filter}")
    ]

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the compare subcommand."""
    parser = subparsers.add_parser(
        "compare",
        help="Deep semantic comparison between any two historical snapshots.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("ref_a", metavar="REF-A", help="Base commit (older).")
    parser.add_argument("ref_b", metavar="REF-B", help="Target commit (newer).")
    parser.add_argument(
        "--kind", "-k", default=None, metavar="KIND", dest="kind_filter",
        help="Restrict to symbols of this kind (function, class, method, …).",
    )
    parser.add_argument(
        "--file", "-f", default=None, metavar="FILE", dest="file_filter",
        help="Only show changes in this file (accepts a path suffix, e.g. 'billing.py').",
    )
    parser.add_argument(
        "--language", "-l", default=None, metavar="LANG", dest="language_filter",
        help="Only show changes in files of this language (case-insensitive).",
    )
    parser.add_argument(
        "--stat",
        action="store_true",
        help="Print a summary (counts + SemVer impact) instead of the full listing.",
    )
    parser.add_argument(
        "--semver",
        action="store_true",
        help=(
            "Append a MAJOR / MINOR / PATCH recommendation based on public API changes: "
            "symbol removed → MAJOR, symbol added → MINOR, impl-only → PATCH."
        ),
    )
    parser.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit results as JSON.",
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Deep semantic comparison between any two historical snapshots.

    Reads both commits from the object store, parses AST symbol trees for all
    semantic files, and produces a full symbol-level delta: added, removed,
    renamed, moved, and modified symbols.  Use it to understand the semantic
    scope of a release, sprint, or branch divergence at the function level.

    Agent quickstart
    ----------------
    ::

        muse code compare HEAD~10 HEAD --json
        muse code compare v0.1.0 dev --kind function --json
        muse code compare main feat/new --semver --json

    JSON fields
    -----------
    ref_a        First (older) ref.
    ref_b        Second (newer) ref.
    added        List of symbol addresses added in ref_b.
    removed      List of symbol addresses removed from ref_a.
    modified     List of symbol addresses present in both but changed.
    renamed      List of ``{from, to}`` rename objects.
    moved        List of ``{address, from_file, to_file}`` move objects.
    total        Total change count.
    sem_ver_bump Inferred bump (with ``--semver``): ``"major"``, ``"minor"``,
                 ``"patch"``, or ``"none"``.
    exit_code    Integer exit code (see below).

    Exit codes
    ----------
    0  Comparison complete.
    1  Ref not found or invalid arguments.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    ref_a: str = args.ref_a
    ref_b: str = args.ref_b
    kind_filter: str | None = args.kind_filter
    file_filter: str | None = args.file_filter
    language_filter: str | None = args.language_filter
    stat_only: bool = args.stat
    show_semver: bool = args.semver
    json_out: bool = args.json_out

    if language_filter is not None:
        language_filter = normalise_language(language_filter)
    if kind_filter is not None:
        kind_filter = kind_filter.strip().lower()

    root = require_repo()
    branch = read_current_branch(root)

    commit_a = resolve_commit_ref(root, branch, ref_a)
    if commit_a is None:
        print(f"❌ Commit '{ref_a}' not found.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    commit_b = resolve_commit_ref(root, branch, ref_b)
    if commit_b is None:
        print(f"❌ Commit '{ref_b}' not found.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    manifest_a: Manifest = get_commit_snapshot_manifest(root, commit_a.commit_id) or {}
    manifest_b: Manifest = get_commit_snapshot_manifest(root, commit_b.commit_id) or {}

    # Apply language filter at the manifest level so cross-file move detection
    # in build_diff_ops only considers the requested language.
    if language_filter is not None:
        manifest_a = _filter_manifest_by_language(manifest_a, language_filter)
        manifest_b = _filter_manifest_by_language(manifest_b, language_filter)

    # Load the symbol cache once and share it across both snapshot loads.
    shared_cache = load_symbol_cache(root)

    trees_a = symbols_for_snapshot(
        root, manifest_a, kind_filter=kind_filter, cache=shared_cache
    )
    trees_b = symbols_for_snapshot(
        root, manifest_b, kind_filter=kind_filter, cache=shared_cache
    )

    ops = build_diff_ops(manifest_a, manifest_b, trees_a, trees_b)

    # Post-filter by --file (applied after build_diff_ops so cross-file move
    # detection still runs on the full op set).
    if file_filter is not None:
        ops = _filter_ops_by_file(ops, file_filter)

    semver_bump, semver_reasons = _assess_semver(ops)
    added, removed, modified, files_changed = _count_ops(ops)
    total_symbols = added + removed + modified

    msg_a = _first_line(commit_a.message)
    msg_b = _first_line(commit_b.message)

    if json_out:
        print(json.dumps(_CompareJson(**make_envelope(elapsed), **{
            "from": _CommitRef(commit_id=commit_a.commit_id, message=msg_a),
            "to":   _CommitRef(commit_id=commit_b.commit_id, message=msg_b),
            "filters": _CompareFilters(kind=kind_filter, file=file_filter, language=language_filter),
            "stat": _CompareStat(
                files_changed=files_changed,
                symbols_added=added,
                symbols_removed=removed,
                symbols_modified=modified,
                semver_impact=semver_bump,
            ),
            "ops": list(_flatten_ops(ops)),
        })))
        return

    # ── Human-readable ────────────────────────────────────────────────────────

    print("\nSemantic comparison")
    print(f'  From: {commit_a.commit_id}  "{sanitize_display(msg_a)}"')
    print(f'  To:   {commit_b.commit_id}  "{sanitize_display(msg_b)}"')

    if stat_only:
        print(f"\n  Files changed:     {files_changed}")
        print(f"  Symbols added:     {added}")
        print(f"  Symbols removed:   {removed}")
        print(f"  Symbols modified:  {modified}")
        print(f"  Net change:        {added - removed:+d} symbols")
        print(f"  SemVer impact:     {semver_bump}")
        if semver_reasons:
            for r in semver_reasons[:5]:
                print(f"    → {r}")
        return

    if not ops:
        print("\n  (no semantic changes between these two commits)")
        return

    for op in ops:
        if op["op"] == "patch":
            fp = op["address"]
            child_ops = op.get("child_ops", [])
            if not child_ops:
                continue
            is_new = fp not in manifest_a
            is_gone = fp not in manifest_b
            suffix = "  (new file)" if is_new else ("  (removed)" if is_gone else "")
            print(f"\n{sanitize_display(fp)}{suffix}")
            for child in child_ops:
                print(_format_child_op(child))
        else:
            fp = op["address"]
            if op["op"] == "insert":
                print(f"\n{sanitize_display(fp)}  (new file)")
                print(f"  added     {sanitize_display(fp)}  (file)")
            elif op["op"] == "delete":
                print(f"\n{sanitize_display(fp)}  (removed)")
                print(f"  removed   {sanitize_display(fp)}  (file)")
            else:
                print(f"\n{sanitize_display(fp)}")
                print(f"  modified  {sanitize_display(fp)}  (file)")

    print(f"\n{total_symbols} symbol change(s) across {files_changed} file(s)")

    if show_semver or semver_bump in ("MAJOR",):
        print(f"SemVer impact: {semver_bump}")
        for r in semver_reasons[:5]:
            print(f"  → {r}")
