"""``muse coord heartbeat`` — extend a reservation's TTL without modifying it.

Long-running agents use heartbeats to keep their reservations alive past the
original TTL.  Each heartbeat call atomically rewrites a single keep-alive file
at ``.muse/coordination/heartbeats/<reservation-id>.json``, updating
``extended_expires_at`` to ``now + extension_seconds``.

The immutable reservation record is never modified.  :func:`active_reservations`
and :func:`filter_reservations` automatically use
``max(reservation.expires_at, heartbeat.extended_expires_at)`` as the effective
expiry, so the heartbeat transparently extends the reservation's liveness window.

Usage::

    muse coord heartbeat <reservation-id> --run-id AGENT-42
    muse coord heartbeat <reservation-id> --run-id AGENT-42 --extension 7200
    muse coord heartbeat <reservation-id> --run-id AGENT-42 --json

Recommended pattern
-------------------
Poll every ``extension_seconds / 2`` to keep a safety margin::

    while working:
        do_work()
        muse coord heartbeat $RES_ID --run-id $RUN_ID --extension 3600

Exit code 1 (``already_released``) is a hard signal to stop — the reservation
was cancelled by another agent or coordinator.  Agents should treat it the same
as a graceful shutdown request.

JSON output schema::

    {
      "status":               "ok" | "already_released" | "not_found",
      "reservation_id":       str,
      "run_id":               str,
      "last_beat_at":         str,   // ISO 8601
      "extended_expires_at":  str,   // ISO 8601
      "ttl_extended_seconds": int,
      "duration_ms":      float
    }

Exit codes::

    0  — heartbeat written successfully
    1  — bad arguments (--run-id too long, --extension out of range, bad content ID)
         or reservation already released (stop sending heartbeats)
    4  — reservation not found

Flags:

``--run-id ID``
    Agent/pipeline identifier for the audit trail (required).
    Maximum length: 256 characters.

``--extension SECONDS``
    Number of seconds from now to set as the new expiry (default: 3600).
    Range: 1–31 536 000 (1 s to 1 year).
"""

import argparse
import json
import sys

from muse.core.coordination import (
    _validate_reservation_id,
    create_heartbeat,
    load_all_reservations,
    load_released_ids,
)
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.validation import clamp_int, sanitize_display
from muse.core.timing import start_timer

# ── Input constraints ─────────────────────────────────────────────────────────

#: Maximum byte-length of the ``--run-id`` value.  Mirrors the limit in
#: ``reserve.py`` and ``release_coord.py`` so audit records stay bounded.
_MAX_RUN_ID_LEN: int = 256

#: Maximum value for ``--extension``.  Same ceiling as ``reserve.py``'s
#: ``--ttl`` so a single heartbeat cannot pin a reservation open indefinitely.
_MAX_EXTENSION_SECONDS: int = 31_536_000  # 1 year

class _HeartbeatJson(EnvelopeJson):
    """JSON output for ``muse coord heartbeat --json``.

    Inherits the 6 standard envelope fields from :class:`~muse.core.envelope.EnvelopeJson`.

    Fields
    ------
    status                ``"ok"`` on success; ``"already_released"`` when the
                          reservation is cancelled (agent should stop);
                          ``"not_found"`` when the reservation ID is unknown.
    reservation_id        content-addressed ID of the reservation whose TTL was extended.
    run_id                Agent/pipeline identifier from ``--run-id``, echoed
                          back for audit correlation.
    last_beat_at          ISO-8601 UTC timestamp of this heartbeat write.
    extended_expires_at   ISO-8601 UTC timestamp of the new effective expiry
                          (``now + extension_seconds``).
    ttl_extended_seconds  Number of seconds from now used as the new expiry
                          (the ``--extension`` value that was applied).
    """

    status: str
    reservation_id: str
    run_id: str
    last_beat_at: str
    extended_expires_at: str
    ttl_extended_seconds: int

class _HeartbeatErrorJson(EnvelopeJson):
    """JSON error output for ``muse coord heartbeat --json`` on invalid reservation."""

    status: str
    reservation_id: str

# ── CLI registration ──────────────────────────────────────────────────────────

def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``heartbeat`` subcommand on *subparsers* (under ``muse coord``).

    Wires all flags with their defaults, choices, and help text so that
    ``--help`` output is accurate.  Sets ``func`` to :func:`run`.
    """
    parser = subparsers.add_parser(
        "heartbeat",
        help="Extend a reservation's TTL by writing a heartbeat.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "reservation_id",
        metavar="RESERVATION_ID",
        help="content-addressed ID of the reservation to keep alive.",
    )
    parser.add_argument(
        "--run-id",
        required=True,
        dest="run_id",
        metavar="ID",
        help=(
            "Agent run-id sending the heartbeat (for audit trail).  "
            f"Max {_MAX_RUN_ID_LEN} characters."
        ),
    )
    parser.add_argument(
        "--extension",
        type=int,
        default=3600,
        dest="extension_seconds",
        metavar="SECONDS",
        help=(
            f"Seconds from now to set as the new expiry "
            f"(default: 3600; range: 1–{_MAX_EXTENSION_SECONDS:,})."
        ),
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON.",
    )
    parser.set_defaults(func=run)

# ── Command implementation ────────────────────────────────────────────────────

def run(args: argparse.Namespace) -> None:
    """Write or refresh a heartbeat for an active reservation.

    Atomically rewrites ``.muse/coordination/heartbeats/<id>.json`` to
    extend the reservation's TTL.  Call this periodically while holding a
    reservation; if ``status == "released"`` the agent must stop work
    immediately.  Exit 4 means the reservation was never created or has
    already expired.

    Agent quickstart
    ----------------
    ::

        muse coord heartbeat <reservation-id> --run-id agent-42 --format json
        muse coord heartbeat <sha256:...> --extension 120 --run-id agent-42 --format json

    JSON fields
    -----------
    status                 ``"ok"`` on success; ``"released"`` if evicted.
    reservation_id         content-addressed ID of the reservation updated.
    run_id                 Agent run ID that sent the heartbeat.
    last_beat_at           ISO 8601 timestamp of this heartbeat.
    extended_expires_at    New expiry after the extension is applied.
    ttl_extended_seconds   Seconds the TTL was extended by.

    Exit codes
    ----------
    0  Heartbeat written successfully.
    1  Invalid arguments; or reservation already released (stop work).
    4  Reservation not found.
    """
    elapsed = start_timer()
    reservation_id: str = args.reservation_id
    run_id: str = args.run_id
    extension_seconds: int = args.extension_seconds
    json_out: bool = args.json_out
        # ── Input validation (before any file I/O) ────────────────────────────────

    if len(run_id) > _MAX_RUN_ID_LEN:
        msg = f"--run-id is too long ({len(run_id)} chars; max {_MAX_RUN_ID_LEN})"
        if json_out:
            print(json.dumps({"error": msg, "status": "bad_args"}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    try:
        extension_seconds = clamp_int(
            extension_seconds, 1, _MAX_EXTENSION_SECONDS, "--extension"
        )
    except ValueError as exc:
        msg = str(exc)
        if json_out:
            print(json.dumps({"error": msg, "status": "bad_args"}))
        else:
            print(f"❌ Invalid --extension: {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    try:
        _validate_reservation_id(reservation_id)
    except ValueError as exc:
        if json_out:
            print(json.dumps({"error": str(exc), "status": "bad_id"}))
        else:
            print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()

    # ── Released guard ────────────────────────────────────────────────────────
    # Stem-only scan — no JSON parsing, O(released_count).
    released_ids = load_released_ids(root)
    if reservation_id in released_ids:
        if json_out:
            print(json.dumps(_HeartbeatErrorJson(
                **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                status="already_released",
                reservation_id=reservation_id,
            )))
        else:
            rid = sanitize_display(reservation_id)
            print(
                f"❌ reservation {rid} is already released — "
                "stop sending heartbeats",
                file=sys.stderr,
            )
        raise SystemExit(ExitCode.USER_ERROR)

    # ── Existence check ───────────────────────────────────────────────────────
    all_res = load_all_reservations(root)
    known_ids = {r.reservation_id for r in all_res}
    if reservation_id not in known_ids:
        if json_out:
            print(json.dumps(_HeartbeatErrorJson(
                **make_envelope(elapsed, exit_code=ExitCode.NOT_FOUND),
                status="not_found",
                reservation_id=reservation_id,
            )))
        else:
            rid = sanitize_display(reservation_id)
            print(f"❌ reservation {rid} not found", file=sys.stderr)
        raise SystemExit(ExitCode.NOT_FOUND)

    # ── Write heartbeat ───────────────────────────────────────────────────────
    hb = create_heartbeat(root, reservation_id, run_id, extension_seconds)

    if json_out:
        print(json.dumps(_HeartbeatJson(
            **make_envelope(elapsed),
            status="ok",
            reservation_id=hb.reservation_id,
            run_id=hb.run_id,
            last_beat_at=hb.last_beat_at.isoformat(),
            extended_expires_at=hb.extended_expires_at.isoformat(),
            ttl_extended_seconds=extension_seconds,
        )))
    else:
        rid = sanitize_display(hb.reservation_id)
        run_label = sanitize_display(hb.run_id)
        exp_str = hb.extended_expires_at.isoformat()[:19]
        print(
            f"💓 heartbeat {rid}  run={run_label}"
            f"  extended until {exp_str}Z  (+{extension_seconds}s)"
        )
