"""muse snapshot-diff — diff two snapshot manifests.

Compares two Muse snapshots and categorises every path change into one of three
buckets: added, modified, or deleted.  Accepts snapshot IDs directly or commit
IDs / branch names (in which case the commit's snapshot is resolved first).

Single-pair mode (default)
--------------------------

Output (JSON, default)::

    {
      "snapshot_a":      "<sha256>",
      "snapshot_b":      "<sha256>",
      "added":           [{"path": "src/foo.py", "object_id": "<sha256>"}],
      "modified":        [{"path": "src/bar.py",
                           "object_id_a": "<sha256>", "object_id_b": "<sha256>"}],
      "deleted":         [{"path": "src/old.py",  "object_id": "<sha256>"}],
      "added_count":     1,
      "modified_count":  1,
      "deleted_count":   1,
      "total_changes":   3,
      "duration_ms":      4.2,
      "exit_code":       0
    }

Text output (``--format text``)::

    A  src/foo.py
    M  src/bar.py
    D  src/old.py

Text output with ``--raw`` (includes object IDs)::

    A  <oid_b>  src/foo.py
    M  <oid_a>  <oid_b>  src/bar.py
    D  <oid_a>  src/old.py

Filtering
---------

``--only added|modified|deleted``
    Restrict output to one change category.  In JSON mode the suppressed
    lists are emitted as empty arrays; only the matching list is populated.
    In text mode only the matching status letters are printed.

``--path-prefix PREFIX``
    Only include paths whose workspace-relative path starts with *PREFIX*.
    Applied after the diff, before output — counts and ``total_changes``
    reflect the filtered view.

Batch mode (``--stdin``)
------------------------

Reads ref pairs from stdin (one ``<ref_a> <ref_b>`` per line) and processes
each pair.

JSON mode emits one JSON object per pair (newline-delimited)::

    {"snapshot_a": "...", "snapshot_b": "...", "added": [...], ...}
    {"snapshot_a": "...", "snapshot_b": "...", "added": [...], ...}

Text mode emits the text diff for each pair separated by a blank line.

Invalid or unresolvable pairs emit an error object/line and continue.

Output contract
---------------

- Exit 0: diff computed (even when zero changes).
- Exit 1: snapshot or commit ID cannot be resolved; bad ``--format`` value;
          bad ``--only`` value.
- Exit 3: I/O error reading snapshot records.
- Batch mode (``--stdin``) always exits 0; individual errors are reported inline.

Agent quickstart
----------------

::

    # Diff two snapshots — full ID
    muse snapshot-diff <snap_a> <snap_b>

    # Diff using short hex prefixes (same as muse snapshot read)
    muse snapshot-diff 0d972e55324c b01270f28f05

    # Diff two branches
    muse snapshot-diff main dev

    # Only show added files
    muse snapshot-diff main dev --only added

    # Scope to a subdirectory
    muse snapshot-diff <snap_a> <snap_b> --path-prefix src/

    # Batch — one pair per line from stdin
    echo "<id_a> <id_b>" | muse snapshot-diff --stdin

    # Quick summary counts only
    muse snapshot-diff main dev | jq '{added_count, modified_count, deleted_count}'
"""

import argparse
import json
import logging
import pathlib
import sys
from typing import TypedDict

from muse.core.types import long_id
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import read_commit
from muse.core.snapshots import read_snapshot
from muse.core.validation import sanitize_display, validate_object_id
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

_ONLY_CHOICES = ("added", "modified", "deleted")

# Column widths for --raw text output alignment.
_OID_WIDTH = 64

class _AddedEntry(TypedDict):
    """One added-file entry in a ``snapshot-diff`` JSON result.

    Fields
    ------
    path
        Workspace-relative path of the file that was added in snapshot B.
    object_id
        SHA-256 object ID of the file's content in snapshot B.
    """

    path: str
    object_id: str

class _ModifiedEntry(TypedDict):
    """One modified-file entry in a ``snapshot-diff`` JSON result.

    Fields
    ------
    path
        Workspace-relative path of the file whose content changed.
    object_id_a
        SHA-256 object ID of the file's content in snapshot A (before).
    object_id_b
        SHA-256 object ID of the file's content in snapshot B (after).
    """

    path: str
    object_id_a: str
    object_id_b: str

class _DeletedEntry(TypedDict):
    """One deleted-file entry in a ``snapshot-diff`` JSON result.

    Fields
    ------
    path
        Workspace-relative path of the file that was present in snapshot A
        but absent in snapshot B.
    object_id
        SHA-256 object ID of the file's content in snapshot A.
    """

    path: str
    object_id: str

class _DiffResult(TypedDict):
    """Internal diff result (no envelope fields) for one ``snapshot-diff`` pair."""

    snapshot_a: str
    snapshot_b: str
    added: list[_AddedEntry]
    modified: list[_ModifiedEntry]
    deleted: list[_DeletedEntry]
    added_count: int
    modified_count: int
    deleted_count: int
    total_changes: int

class _DiffResultJson(EnvelopeJson):
    """JSON wire format for ``muse snapshot-diff --json``."""

    snapshot_a: str
    snapshot_b: str
    added: list[_AddedEntry]
    modified: list[_ModifiedEntry]
    deleted: list[_DeletedEntry]
    added_count: int
    modified_count: int
    deleted_count: int
    total_changes: int

_HEX_CHARS = frozenset("0123456789abcdef")

def _resolve_snapshot_prefix(root: pathlib.Path, prefix: str) -> str | None:
    """Resolve a short ``sha256:``-prefixed hex string to a full snapshot ID.

    Requires the ``sha256:`` prefix — bare hex is never accepted.  This
    mirrors the CLI boundary rule: the algorithm prefix is a type tag, not
    decoration.

    Returns the full ``sha256:<64hex>`` snapshot ID on an unambiguous match,
    or ``None`` when no match is found or the prefix is bare hex.
    """
    if not prefix.startswith("sha256:"):
        return None  # bare hex — rejected; caller must supply sha256: prefix
    bare = long_id(prefix, strip=True)
    safe_prefix = "".join(c for c in bare[:64] if c in _HEX_CHARS)
    if not safe_prefix:
        return None
    from muse.core.object_store import iter_stored_objects, read_muse_object
    from muse.core.types import split_id
    import json as _json
    for object_id, _ in iter_stored_objects(root):
        _, hex_id = split_id(object_id)
        if not hex_id.startswith(safe_prefix):
            continue
        result = read_muse_object(root, object_id)
        if result is None or result[0] != "snapshot":
            continue
        try:
            snap = read_snapshot(root, object_id)
            if snap is not None:
                return snap.snapshot_id
        except Exception:
            continue
    return None

def _resolve_to_snapshot_id(root: pathlib.Path, ref: str) -> str | None:
    """Return the snapshot ID for *ref*, or ``None`` if it cannot be resolved.

    Resolution order
    ----------------
    1. ``HEAD`` — reads the current branch and its tip commit's snapshot.
    2. Branch name — resolves via :func:`~muse.core.store.get_head_commit_id`
       and follows to the commit's snapshot.
    3. Full object ID (``sha256:<64hex>``) — tries to load it as a snapshot
       first, then as a commit.  Returns the snapshot ID in either case.
    4. Short hex prefix (bare hex or ``sha256:<prefix>``) — glob-scans
       ``.muse/objects/sha256/`` for an unambiguous match, mirroring
       ``muse snapshot read``'s prefix resolution.

    Parameters
    ----------
    root:
        Repository root (the directory containing ``.muse/``).
    ref:
        Any of: ``HEAD``, a branch name, a full snapshot or commit ID
        (``sha256:<64hex>``), or a short prefix (``sha256:<hex>``).  Bare
        hex without the ``sha256:`` prefix is rejected — the prefix is a
        type tag identifying the algorithm, not decoration.

    Returns
    -------
    str | None
        The resolved snapshot ID (``sha256:<64hex>``), or ``None`` when *ref*
        cannot be resolved to a known snapshot.
    """
    if ref.upper() == "HEAD":
        branch = read_current_branch(root)
        commit_id = get_head_commit_id(root, branch)
        if commit_id is None:
            return None
        commit = read_commit(root, commit_id)
        return commit.snapshot_id if commit else None

    try:
        commit_id = get_head_commit_id(root, ref)
    except ValueError:
        commit_id = None
    if commit_id is not None:
        commit = read_commit(root, commit_id)
        return commit.snapshot_id if commit else None

    try:
        validate_object_id(ref)
        is_full_id = True
    except ValueError:
        is_full_id = False

    if is_full_id:
        snap = read_snapshot(root, ref)
        if snap is not None:
            return snap.snapshot_id
        commit = read_commit(root, ref)
        if commit is not None:
            return commit.snapshot_id
        return None

    # Not a full ID — try as a snapshot prefix (bare hex or sha256:<prefix>).
    return _resolve_snapshot_prefix(root, ref)

def _compute_diff(
    root: pathlib.Path,
    ref_a: str,
    ref_b: str,
    only: str | None = None,
    path_prefix: str | None = None,
) -> "_DiffResult | dict[str, str]":
    """Compute the manifest diff between *ref_a* and *ref_b*.

    Resolves both refs to snapshot IDs, loads their manifests, and categorises
    every path into added, modified, or deleted.  Results are sorted
    lexicographically by path within each category.

    Parameters
    ----------
    root:
        Repository root.
    ref_a:
        First ref (before).  Passed to :func:`_resolve_to_snapshot_id`.
    ref_b:
        Second ref (after).  Passed to :func:`_resolve_to_snapshot_id`.
    only:
        When set to ``"added"``, ``"modified"``, or ``"deleted"``, the other
        two lists are returned empty.  Counts and ``total_changes`` reflect
        the filtered view.
    path_prefix:
        When set, only paths starting with this prefix are included in the
        result.  Applied before the ``only`` filter.

    Returns
    -------
    _DiffResult | dict[str, str]
        A complete :class:`_DiffResult` on success, or a ``{"error": "..."}``
        dict when either ref cannot be resolved or a snapshot cannot be read.
        The ``duration_ms`` field is left at 0.0 and must be filled in by the
        caller after calling :func:`time.monotonic`.
    """
    snap_id_a = _resolve_to_snapshot_id(root, ref_a)
    if snap_id_a is None:
        return {"error": f"Cannot resolve ref: {ref_a!r}"}

    snap_id_b = _resolve_to_snapshot_id(root, ref_b)
    if snap_id_b is None:
        return {"error": f"Cannot resolve ref: {ref_b!r}"}

    try:
        snap_a = read_snapshot(root, snap_id_a)
        snap_b = read_snapshot(root, snap_id_b)
    except Exception as exc:
        return {"error": str(exc)}

    if snap_a is None:
        return {"error": f"Snapshot not found: {snap_id_a}"}
    if snap_b is None:
        return {"error": f"Snapshot not found: {snap_id_b}"}

    manifest_a = snap_a.manifest
    manifest_b = snap_b.manifest

    # Apply path-prefix filter before computing diff sets.
    if path_prefix:
        manifest_a = {p: v for p, v in manifest_a.items() if p.startswith(path_prefix)}
        manifest_b = {p: v for p, v in manifest_b.items() if p.startswith(path_prefix)}

    keys_a = set(manifest_a)
    keys_b = set(manifest_b)

    added: list[_AddedEntry] = sorted(
        [{"path": p, "object_id": manifest_b[p]} for p in (keys_b - keys_a)],
        key=lambda e: e["path"],
    )
    deleted: list[_DeletedEntry] = sorted(
        [{"path": p, "object_id": manifest_a[p]} for p in (keys_a - keys_b)],
        key=lambda e: e["path"],
    )
    modified: list[_ModifiedEntry] = sorted(
        [
            {"path": p, "object_id_a": manifest_a[p], "object_id_b": manifest_b[p]}
            for p in (keys_a & keys_b)
            if manifest_a[p] != manifest_b[p]
        ],
        key=lambda e: e["path"],
    )

    # Apply --only filter: zero out the suppressed categories.
    if only == "added":
        modified = []
        deleted = []
    elif only == "modified":
        added = []
        deleted = []
    elif only == "deleted":
        added = []
        modified = []

    return _DiffResult(
        snapshot_a=snap_id_a,
        snapshot_b=snap_id_b,
        added=added,
        modified=modified,
        deleted=deleted,
        added_count=len(added),
        modified_count=len(modified),
        deleted_count=len(deleted),
        total_changes=len(added) + len(modified) + len(deleted),
    )

def _emit_text(result: _DiffResult, raw: bool, stat: bool, only: str | None) -> None:
    """Print text-format diff output for *result* to stdout.

    Parameters
    ----------
    result:
        A successfully computed :class:`_DiffResult`.
    raw:
        When ``True``, prefix each line with the object ID(s) of the entry.
        When ``False``, only the status letter and path are printed.
    stat:
        When ``True``, append a summary line after the diff lines:
        ``N added, M modified, D deleted``.
    only:
        When set, only lines for that category are printed (the ``only``
        filter has already been applied to *result*'s lists, so this
        parameter is unused here — it is accepted for symmetry with
        :func:`_compute_diff`).
    """
    if raw:
        for entry in result["added"]:
            oid = entry["object_id"]
            print(f"A  {oid}  {sanitize_display(entry['path'])}")
        for entry in result["modified"]:
            oid_a = entry["object_id_a"]
            oid_b = entry["object_id_b"]
            print(f"M  {oid_a}  {oid_b}  {sanitize_display(entry['path'])}")
        for entry in result["deleted"]:
            oid = entry["object_id"]
            print(f"D  {oid}  {sanitize_display(entry['path'])}")
    else:
        for entry in result["added"]:
            print(f"A  {sanitize_display(entry['path'])}")
        for entry in result["modified"]:
            print(f"M  {sanitize_display(entry['path'])}")
        for entry in result["deleted"]:
            print(f"D  {sanitize_display(entry['path'])}")

    if stat:
        na = len(result["added"])
        nm = len(result["modified"])
        nd = len(result["deleted"])
        print(f"\n{na} added, {nm} modified, {nd} deleted")

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the snapshot-diff subcommand."""
    parser = subparsers.add_parser(
        "snapshot-diff",
        help="Diff two snapshot manifests: added, modified, deleted paths.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "ref_a",
        nargs="?",
        default=None,
        help=(
            "First snapshot ID, commit ID, branch name, or HEAD.  "
            "Required in single-pair mode; omit when using --stdin."
        ),
    )
    parser.add_argument(
        "ref_b",
        nargs="?",
        default=None,
        help=(
            "Second snapshot ID, commit ID, branch name, or HEAD.  "
            "Required in single-pair mode; omit when using --stdin."
        ),
    )
    parser.add_argument(
        "--stdin",
        action="store_true",
        dest="from_stdin",
        help=(
            "Batch mode: read '<ref_a> <ref_b>' pairs from stdin (one per line) "
            "and process each.  JSON mode emits one object per line; "
            "text mode separates pairs with a blank line."
        ),
    )
    parser.add_argument(
        "--raw",
        action="store_true",
        dest="raw",
        help=(
            "Include object IDs in text-format output.  "
            "Has no effect on JSON output (which always includes OIDs).  "
            "Format: 'A <oid>  <path>', 'M <oid_a>  <oid_b>  <path>', 'D <oid>  <path>'."
        ),
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit JSON output (default: human-readable text).",
    )
    parser.add_argument(
        "--stat", "-s",
        action="store_true",
        help="Append a summary line: N added, M modified, D deleted (text mode only).",
    )
    parser.add_argument(
        "--only",
        dest="only",
        default=None,
        metavar="CATEGORY",
        choices=_ONLY_CHOICES,
        help=(
            "Restrict output to one change category: added, modified, or deleted.  "
            "In JSON mode the other two lists are emitted as empty arrays.  "
            "In text mode only the matching status letters are printed."
        ),
    )
    parser.add_argument(
        "--path-prefix",
        dest="path_prefix",
        default=None,
        metavar="PREFIX",
        help=(
            "Filter diff to paths starting with PREFIX.  "
            "Applied before --only.  Counts and total_changes reflect the filtered view."
        ),
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Diff two snapshots and report added, modified, and deleted paths.

    Resolves both refs to snapshot IDs (accepting snapshot IDs, commit IDs,
    branch names, or ``HEAD``), computes the manifest diff, and emits the
    result.  In batch mode (``--stdin``) one result object per line is
    emitted; errors are reported inline.

    Agent quickstart::

        muse snapshot-diff main dev --json
        muse snapshot-diff sha256:abc sha256:def --json
        muse snapshot-diff main dev --only added --json
        muse snapshot-diff main dev --path-prefix src/ --json

    JSON fields::

        snapshot_a      str     Resolved snapshot ID for the first (before) ref
        snapshot_b      str     Resolved snapshot ID for the second (after) ref
        added           list    Files added: [{path, object_id}]
        modified        list    Files modified: [{path, object_id_a, object_id_b}]
        deleted         list    Files deleted: [{path, object_id}]
        added_count     int     len(added)
        modified_count  int     len(modified)
        deleted_count   int     len(deleted)
        total_changes   int     Sum of all three counts

    Exit codes::

        0  Success (zero-change diffs also exit 0).
        1  Ref cannot be resolved, bad --format, or bad --only.
        3  I/O error reading snapshot records.
    """
    json_out: bool = args.json_out
    ref_a: str | None = args.ref_a
    ref_b: str | None = args.ref_b
    from_stdin: bool = args.from_stdin
    raw: bool = args.raw
    stat: bool = args.stat
    only: str | None = args.only
    path_prefix: str | None = args.path_prefix

    elapsed = start_timer()

    root = require_repo()

    # ── Batch (--stdin) mode ──────────────────────────────────────────────────
    if from_stdin:
        first = True
        for raw_line in sys.stdin:
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) < 2:
                if json_out:
                    print(json.dumps({"error": f"Expected '<ref_a> <ref_b>', got: {line!r}"}))
                else:
                    print(f"error: expected '<ref_a> <ref_b>', got: {sanitize_display(line)}")
                    if not first:
                        print()
                first = False
                continue

            pair_a, pair_b = parts[0], parts[1]
            result = _compute_diff(root, pair_a, pair_b, only=only, path_prefix=path_prefix)

            if "error" in result:
                if json_out:
                    print(json.dumps(result))
                else:
                    if not first:
                        print()
                    print(f"error: {sanitize_display(result['error'])}")  # type: ignore[index]
            elif json_out:
                print(json.dumps({**result, **make_envelope(elapsed)}))
            else:
                if not first:
                    print()
                _emit_text(result, raw=raw, stat=stat, only=only)  # type: ignore[arg-type]

            first = False
        return

    # ── Single-pair mode ──────────────────────────────────────────────────────
    if ref_a is None or ref_b is None:
        print(
            json.dumps({"error": "ref_a and ref_b are required in single-pair mode "
                        "(or use --stdin for batch processing)"}),
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    # Bare hex is rejected at the CLI boundary.  sha256: prefix is required —
    # it is a type tag (algorithm identifier), not decoration.  Branch names
    # and HEAD contain non-hex characters and are never caught by this check.
    for _label, _ref in (("ref_a", ref_a), ("ref_b", ref_b)):
        if all(c in _HEX_CHARS for c in _ref):
            _safe = sanitize_display(_ref)
            print(
                json.dumps({
                    "error": (
                        f"Bare hex IDs are not accepted ({_label}={_ref!r}) — "
                        f"use 'sha256:{_safe}' instead."
                    )
                }),
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)

    result = _compute_diff(root, ref_a, ref_b, only=only, path_prefix=path_prefix)

    if "error" in result:
        print(json.dumps(result), file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    if not json_out:
        _emit_text(result, raw=raw, stat=stat, only=only)  # type: ignore[arg-type]
        return

    print(json.dumps(_DiffResultJson(**make_envelope(elapsed), **result)))
