"""muse log — display commit history.

Output modes
------------

Default (long form)::

    commit a1b2c3d4 (HEAD -> main)
    Author: gabriel
    Date:   2026-03-16 12:00:00 UTC

        Add verse melody

--oneline::

    a1b2c3d4 (HEAD -> main) Add verse melody
    f9e8d7c6 Initial commit

--graph::

    * a1b2c3d4 (HEAD -> main) Add verse melody
    * f9e8d7c6 Initial commit

--stat::

    commit a1b2c3d4 (HEAD -> main)
    Date:   2026-03-16 12:00:00 UTC

        Add verse melody

     + tracks/drums.mid
     1 added, 0 removed

--json (agent-native, always stable)::

    {
      "status":      "ok",
      "error":       "",
      "truncated":   false,
      "total":       1,
      "branch":      "main",
      "repo_id":     "…",
      "commits": [
        {
          "commit_id": "sha256:a1b2c3d4…",
          "branch": "main",
          "message": "Add verse melody",
          "author": "gabriel",
          "agent_id": "",
          "model_id": "",
          "committed_at": "2026-03-16T12:00:00+00:00",
          "parent_commit_id": "sha256:f9e8d7c6…",
          "parent2_commit_id": null,
          "snapshot_id": "sha256:…",
          "sem_ver_bump": "minor",
          "breaking_changes": [],
          "metadata": {},
          "files_added": ["tracks/drums.mid"],
          "files_removed": [],
          "files_modified": [],
          "structured_delta": {"ops": [...]}
        }
      ],
      "duration_ms": 4.2,
      "exit_code":   0
    }

``files_added``, ``files_removed``, and ``files_modified`` are always
populated in ``--json`` mode — agents do not need ``--stat``.

``structured_delta`` is the domain-specific symbol-level diff computed at
commit time.  It is a ``dict`` with an ``"ops"`` key for code commits, and
``null`` when no code-intelligence data was produced (non-code domains or
commits with no tracked changes).

All keys are always present so agents can read them without ``dict.get``
guards.  ``"status"`` is always ``"ok"`` on success.

JSON error schema (exit non-zero)::

    {
      "status":    "error",
      "error":     "<human-readable message>",
      "exit_code": 2
    }

When ``--json`` is active all errors go to stdout as JSON — no prose on
stderr.  Agents should parse stdout and check ``status``.

SemVer bumps are coloured: PATCH  MINOR  MAJOR

Filters: --since, --until, --author, --section, --track, --emotion

Pathspec (git-compatible)::

    muse log -- path/to/file.py          # commits touching a specific file
    muse log -n 5 -- src/               # last 5 commits touching anything in src/
    muse log dev -- README.md            # commits on branch dev that touched README.md

Paths are matched as prefixes: ``src/`` matches ``src/foo.py`` and ``src/bar/baz.py``.
Exact paths match only that exact file.  The ``--`` separator is optional when the
path cannot be mistaken for a branch name, but is always safe to include.
"""

import argparse
import heapq
import json
import logging
import pathlib
import re
import sys
import textwrap
from collections.abc import Mapping
from datetime import datetime, timedelta, timezone
from typing import TypedDict

from muse.cli.config import get_limit
from muse.core.types import long_id
from muse.core.paths import ref_path as _ref_path, remote_ref_path as _remote_ref_path
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.repo import read_repo_id, require_repo
from muse.core.refs import iter_branch_refs
from muse.core.types import Metadata
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import (
    CommitRecord,
    get_commits_for_branch,
    read_commit,
    resolve_commit_ref,
)
from muse.core.graph import ancestor_ids
from muse.core.snapshots import get_commit_snapshot_manifest
from muse.core.validation import clamp_int, sanitize_display
from muse.core.timing import start_timer

type CommitIndex = dict[str, CommitRecord]
type BranchTips = dict[str, list[str]]
type CounterMap = dict[str, int]
type _DeltaMap = dict[str, timedelta]
type _FileManifest = dict[str, str]
type _ManifestCache = dict[str, _FileManifest]

def _get_manifest(
    root: pathlib.Path, commit_id: str | None, cache: _ManifestCache
) -> _FileManifest:
    """Return the snapshot manifest for *commit_id*, using *cache* to avoid re-reads.

    Each commit_id is fetched from disk at most once per *cache* lifetime.
    An empty dict is returned (and cached) for ``None`` commit_ids so callers
    can treat initial commits uniformly.
    """
    if commit_id is None:
        return {}
    if commit_id not in cache:
        cache[commit_id] = get_commit_snapshot_manifest(root, commit_id) or {}
    return cache[commit_id]

_HEX_CHARS = frozenset("0123456789abcdefABCDEF")

def _is_known_ref(root: pathlib.Path, ref: str) -> bool:
    """Return True if *ref* resolves to a local branch, remote tracking branch, or commit ID.

    Used to disambiguate ``muse log <ref>`` (branch/commit) from
    ``muse log -- <path>`` (pathspec that argparse mistakenly assigned to ref).

    Accepts both bare hex commit IDs (legacy) and canonical ``sha256:<hex>``
    prefixed IDs produced by ``hash_commit``.
    """
    # Canonical sha256:-prefixed commit ID (full or abbreviated, min 8 hex chars).
    if ref.startswith("sha256:"):
        hex_part = long_id(ref, strip=True)
        if len(hex_part) >= 8 and all(c in _HEX_CHARS for c in hex_part):
            return True
    # Bare hex commit ID (min 8 chars) — accepted for backwards compatibility.
    if len(ref) >= 8 and all(c in _HEX_CHARS for c in ref):
        return True
    # Local branch: .muse/refs/heads/<ref>
    if _ref_path(root, ref).exists():
        return True
    # Remote-tracking branch: .muse/remotes/<remote>/<branch>
    # ref may be "origin/dev" → remote="origin", branch="dev"
    if "/" in ref:
        remote, _, branch = ref.partition("/")
        if branch and _remote_ref_path(root, remote, branch).exists():
            return True
    return False

logger = logging.getLogger(__name__)

_DEFAULT_LIMIT = 1000

# ANSI colour helpers — only emitted when stdout is a TTY.
_RESET  = "\033[0m"
_BOLD   = "\033[1m"
_YELLOW = "\033[33m"
_GREEN  = "\033[32m"
_RED    = "\033[31m"
_CYAN   = "\033[36m"
_DIM    = "\033[2m"

class _CommitJson(TypedDict):
    """Stable JSON wire format for a single commit in ``muse log --json``.

    All keys are always present so agents can read them without ``dict.get``
    guards.

    ``files_added``, ``files_removed``, and ``files_modified`` are always
    populated in ``--json`` mode — agents do not need to pass ``--stat``.

    ``agent_id`` and ``model_id`` are empty strings for human commits and
    populated for agent-authored commits (committed with ``--agent-id`` /
    ``--model-id``).
    """

    commit_id: str
    branch: str
    message: str
    author: str
    agent_id: str
    model_id: str
    committed_at: str
    parent_commit_id: str | None
    parent2_commit_id: str | None
    snapshot_id: str | None
    sem_ver_bump: str | None
    breaking_changes: list[str]
    metadata: Metadata
    files_added: list[str]
    files_removed: list[str]
    files_modified: list[str]
    structured_delta: Mapping[str, object] | None
    signer_public_key: str

class _LogJson(EnvelopeJson):
    """Stable top-level JSON envelope for ``muse log --json``.

    Inherits the 6 standard envelope fields from :class:`~muse.core.envelope.EnvelopeJson`.

    All keys are always present so agents can read them without ``dict.get``
    guards.  ``status`` is ``"ok"`` on success.
    """
    status: str           # "ok"
    error: str            # always "" on success
    truncated: bool
    total: int            # len(commits)
    branch: str           # branch that was walked
    repo_id: str
    commits: list[_CommitJson]

class _LogErrorJson(EnvelopeJson):
    """Error payload for ``muse log --json`` when a usage error occurs."""
    status: str           # "error"
    error: str

_SEMVER_COLOUR: Metadata = {
    "major": _RED,
    "minor": _YELLOW,
    "patch": _GREEN,
}

def _c(text: str, *codes: str, tty: bool) -> str:
    """Wrap *text* in ANSI *codes* when *tty* is True."""
    if not tty:
        return text
    return "".join(codes) + text + _RESET

def _ref_label(branch: str, is_head: bool, tty: bool) -> str:
    """Format the ``(HEAD -> branch)`` decoration for a commit line."""
    if not is_head:
        return ""
    if not tty:
        return f" (HEAD -> {branch})"
    head = _c("HEAD", _BOLD, _CYAN, tty=tty)
    arrow = _c(" -> ", _RESET, tty=tty)
    br = _c(branch, _BOLD, _GREEN, tty=tty)
    paren_open  = _c("(", _YELLOW, tty=tty)
    paren_close = _c(")", _YELLOW, tty=tty)
    return f" {paren_open}{head}{arrow}{br}{paren_close}"

def _parse_date(text: str) -> datetime:
    """Parse a human-readable date string into an aware UTC datetime.

    Accepted formats:
    - ``"today"`` / ``"yesterday"``
    - ``"<n> days|weeks|months|years ago"``  (months = 30 days, years = 365 days)
    - ``"YYYY-MM-DD"``
    - ``"YYYY-MM-DDTHH:MM:SS"`` or ``"YYYY-MM-DD HH:MM:SS"``

    Raises:
        ValueError: When the input does not match any recognised format.
    """
    text = text.strip().lower()
    now = datetime.now(timezone.utc)
    if text == "today":
        return now.replace(hour=0, minute=0, second=0, microsecond=0)
    if text == "yesterday":
        return (now - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    m = re.match(r"^(\d+)\s+(day|week|month|year)s?\s+ago$", text)
    if m:
        n = int(m.group(1))
        unit = m.group(2)
        deltas: _DeltaMap = {
            "day": timedelta(days=n),
            "week": timedelta(weeks=n),
            "month": timedelta(days=n * 30),
            "year": timedelta(days=n * 365),
        }
        return now - deltas[unit]
    for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(text, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    raise ValueError(f"Cannot parse date: {text!r}")

def _commit_touches_path(
    root: pathlib.Path,
    commit: CommitRecord,
    path: str,
    manifest_cache: _ManifestCache | None = None,
) -> bool:
    """Return True if *commit* changed *path* (added, modified, or removed).

    *path* is matched as a prefix so that ``src/`` matches any file under
    ``src/``, while ``src/foo.py`` matches only that exact file.  Trailing
    slashes on directory prefixes are normalised away before comparison.

    *manifest_cache* is a shared dict keyed by commit_id.  Pass one from the
    ``run`` call site to avoid re-reading the same snapshot for the same commit
    across multiple calls (e.g. once for pathspec filtering, once for stat).
    """
    if manifest_cache is None:
        manifest_cache = {}
    norm = path.rstrip("/")
    current_manifest = _get_manifest(root, commit.commit_id, manifest_cache)
    parent_manifest = _get_manifest(root, commit.parent_commit_id, manifest_cache)
    all_paths = set(current_manifest) | set(parent_manifest)
    for p in all_paths:
        if p == norm or p.startswith(f"{norm}/"):
            if current_manifest.get(p) != parent_manifest.get(p):
                return True
    return False

def _file_diff(
    root: pathlib.Path,
    commit: CommitRecord,
    manifest_cache: _ManifestCache | None = None,
) -> tuple[list[str], list[str], list[str]]:
    """Return ``(added, removed, modified)`` file lists relative to the commit's parent.

    Compares the commit's snapshot manifest against its first parent's manifest.
    For merge commits the second parent is ignored — this is a ``--stat``-style
    summary, not a three-way diff.

    *manifest_cache* is a shared dict keyed by commit_id.  Passing one from
    the ``run`` call site means the same manifest is never read twice within a
    single ``muse log`` invocation.

    Returns:
        A 3-tuple of sorted file-path lists:
        ``added``    — files present in the commit but not in its parent.
        ``removed``  — files present in the parent but not in the commit.
        ``modified`` — files present in both with a different snapshot hash.
    """
    if manifest_cache is None:
        manifest_cache = {}
    current_manifest = _get_manifest(root, commit.commit_id, manifest_cache)
    parent_manifest = _get_manifest(root, commit.parent_commit_id, manifest_cache)
    added = sorted(set(current_manifest) - set(parent_manifest))
    removed = sorted(set(parent_manifest) - set(current_manifest))
    modified = sorted(
        f for f in set(current_manifest) & set(parent_manifest)
        if current_manifest[f] != parent_manifest[f]
    )
    return added, removed, modified

def _format_date(dt: datetime) -> str:
    """Format a datetime as ``YYYY-MM-DD HH:MM:SS UTC`` for display."""
    return dt.strftime("%Y-%m-%d %H:%M:%S UTC") if dt.tzinfo else str(dt)

# ---------------------------------------------------------------------------
# Filter helpers — single implementation shared by JSON and text paths
# ---------------------------------------------------------------------------

def _apply_filters(
    commits: list[CommitRecord],
    *,
    since_dt: datetime | None,
    until_dt: datetime | None,
    author: str | None,
    section: str | None,
    track: str | None,
    emotion: str | None,
    limit: int,
) -> tuple[list[CommitRecord], bool]:
    """Apply all active filters to *commits* and enforce *limit*.

    Previously the filter loop was copy-pasted between the JSON path and the
    text path.  Any new filter would have required updating both.  This
    function is the single source of truth; both paths call it.

    Args:
        commits:   Pre-fetched commit list from ``get_commits_for_branch``.
        since_dt:  Inclusive lower bound on ``committed_at``.
        until_dt:  Inclusive upper bound on ``committed_at``.
        author:    Substring match on ``author`` (case-insensitive).
        section:   Exact match on ``metadata["section"]``.
        track:     Exact match on ``metadata["track"]``.
        emotion:   Exact match on ``metadata["emotion"]``.
        limit:     Maximum number of commits to return (0 = unlimited).

    Returns:
        ``(filtered_commits, truncated)`` where *truncated* is True when the
        walk was capped before the filter had seen all available commits.
    """
    filtered: list[CommitRecord] = []
    for c in commits:
        if since_dt and c.committed_at < since_dt:
            continue
        if until_dt and c.committed_at > until_dt:
            continue
        if author and author.lower() not in c.author.lower():
            continue
        if section and c.metadata.get("section") != section:
            continue
        if track and c.metadata.get("track") != track:
            continue
        if emotion and c.metadata.get("emotion") != emotion:
            continue
        filtered.append(c)
        if limit > 0 and len(filtered) >= limit:
            # We hit the display limit — the walk may have had more commits.
            truncated = len(commits) > len(filtered)
            return filtered, truncated
    return filtered, False

def _commit_to_json(
    c: CommitRecord,
    root: pathlib.Path | None = None,
    *,
    stat: bool = False,
    manifest_cache: _ManifestCache | None = None,
) -> _CommitJson:
    """Serialise *c* to the stable ``--json`` wire format.

    All keys are always present so agents can read them without ``dict.get``
    guards.  Merge commits include ``parent2_commit_id``; linear commits have
    it set to ``null``.

    When *stat* is True and *root* is provided, ``files_added``,
    ``files_removed``, and ``files_modified`` are populated by diffing the
    commit's snapshot against its parent.  Otherwise all three are empty lists.

    The ``--json`` output path always calls this with ``stat=True`` so that
    agents always receive populated file lists without needing to pass
    ``--stat`` explicitly.  The *stat* parameter is kept for callers that
    intentionally want the lightweight (no-diff) form.

    *manifest_cache* is a shared dict keyed by commit_id passed from ``run``
    so that manifests already fetched during pathspec filtering are not
    re-read during stat computation.

    Args:
        c:              The commit to serialise.
        root:           Repository root directory.  Required when *stat* is True.
        stat:           Whether to compute and include per-file change lists.
        manifest_cache: Shared manifest cache from the ``run`` call site.

    Returns:
        JSON-serialisable dict matching the schema documented in the module
        docstring.
    """
    files_added: list[str] = []
    files_removed: list[str] = []
    files_modified: list[str] = []
    if stat and root is not None:
        files_added, files_removed, files_modified = _file_diff(root, c, manifest_cache)
    return _CommitJson(
        commit_id=c.commit_id,
        branch=c.branch,
        message=c.message,
        author=c.author,
        agent_id=c.agent_id,
        model_id=c.model_id,
        committed_at=c.committed_at.isoformat(),
        parent_commit_id=c.parent_commit_id,
        parent2_commit_id=c.parent2_commit_id,
        snapshot_id=c.snapshot_id,
        sem_ver_bump=c.sem_ver_bump,
        breaking_changes=list(c.breaking_changes) if c.breaking_changes else [],
        metadata=c.metadata,
        files_added=files_added,
        files_removed=files_removed,
        files_modified=files_modified,
        structured_delta=c.structured_delta if isinstance(c.structured_delta, dict) else None,
        signer_public_key=c.signer_public_key or "",
    )

# ---------------------------------------------------------------------------
# DAG graph rendering helpers
# ---------------------------------------------------------------------------

def _branch_tips(root: pathlib.Path, *, include_remote: bool = False) -> BranchTips:
    """Return ``{commit_id: [branch_name, …]}`` for all local branch tips.

    When *include_remote* is True, also walks ``.muse/remotes/`` and adds
    remote tracking refs using ``remotes/<remote>/<branch>`` names — matching
    the output of ``muse branch -a`` and git's ``--all`` semantics.
    """
    from muse.core.paths import remotes_dir as _remotes_dir
    from muse.core.refs import read_ref as _read_ref

    tips: BranchTips = {}
    for name, cid in iter_branch_refs(root):
        tips.setdefault(cid, []).append(name)

    if include_remote:
        rd = _remotes_dir(root)
        if rd.is_dir():
            for ref_file in sorted(rd.rglob("*")):
                if ref_file.is_symlink() or not ref_file.is_file():
                    continue
                cid = _read_ref(ref_file)
                if cid:
                    rel = ref_file.relative_to(rd)
                    label = f"remotes/{rel}"
                    tips.setdefault(cid, []).append(label)
    return tips

def _collect_all_commits(
    root: pathlib.Path,
    start_ids: list[str],
    max_commits: int = 50_000,
) -> tuple[CommitIndex, bool]:
    """BFS from *start_ids*, returning every reachable commit up to *max_commits*.

    Args:
        root:        Repository root.
        start_ids:   BFS seed commit IDs (branch tips).
        max_commits: Safety cap — default 50 000.

    Returns:
        ``({commit_id: CommitRecord}, truncated)`` pair where *truncated* is
        True when *max_commits* was reached before the graph was fully walked.
    """
    from muse.core.graph import iter_ancestors
    seen: CommitIndex = {}
    for rec in iter_ancestors(root, start_ids, max_commits=max_commits + 1):
        seen[rec.commit_id] = rec
    truncated = len(seen) > max_commits
    if truncated:
        last_key = next(reversed(seen))
        del seen[last_key]
    return seen, truncated

def _topo_sort(commits: CommitIndex) -> list[CommitRecord]:
    """Return commits newest-first using Kahn's algorithm.

    In-degree counts the number of *child* commits that reference each commit
    as a parent, so commits with no children (branch tips) are processed first.
    Ties are broken by timestamp (most recent first).
    """
    in_degree: CounterMap = {cid: 0 for cid in commits}
    for rec in commits.values():
        for parent in (rec.parent_commit_id, rec.parent2_commit_id):
            if parent and parent in commits:
                in_degree[parent] += 1

    heap: list[tuple[float, str]] = []
    for cid, deg in in_degree.items():
        if deg == 0:
            ts = -commits[cid].committed_at.timestamp()
            heapq.heappush(heap, (ts, cid))

    result: list[CommitRecord] = []
    while heap:
        _, cid = heapq.heappop(heap)
        result.append(commits[cid])
        rec = commits[cid]
        for parent in (rec.parent_commit_id, rec.parent2_commit_id):
            if parent and parent in commits:
                in_degree[parent] -= 1
                if in_degree[parent] == 0:
                    ts = -commits[parent].committed_at.timestamp()
                    heapq.heappush(heap, (ts, parent))
    return result

def _deco_str(
    cid: str,
    head_cid: str,
    current: str,
    tips: BranchTips,
    tty: bool,
) -> str:
    """Format the ``(HEAD -> branch, other-branch)`` decoration for a commit."""
    branches = tips.get(cid, [])
    if not branches:
        return ""
    labels: list[str] = []
    if cid == head_cid and current in branches:
        head = _c("HEAD", _BOLD, _CYAN, tty=tty)
        br = _c(current, _BOLD, _GREEN, tty=tty)
        labels.append(f"{head}{_c(' -> ', _RESET, tty=tty)}{br}")
        for b in branches:
            if b != current:
                labels.append(_c(b, _BOLD, _GREEN, tty=tty))
    else:
        for b in branches:
            labels.append(_c(b, _BOLD, _GREEN, tty=tty))
    inner = ", ".join(labels)
    return f" {_c('(', _YELLOW, tty=tty)}{inner}{_c(')', _YELLOW, tty=tty)}"

def _render_graph(
    root: pathlib.Path,
    branch: str,
    all_branches: bool,
    tty: bool,
) -> None:
    """Render a lane-based ASCII DAG, git-log-style."""
    current = read_current_branch(root)
    tips = _branch_tips(root, include_remote=all_branches)

    if all_branches:
        start_ids = list(tips.keys())
    else:
        head = get_head_commit_id(root, branch)
        start_ids = [head] if head else []

    if not start_ids:
        print("(no commits)")
        return

    graph_cap = get_limit("max_graph_commits", root)
    all_commits, graph_truncated = _collect_all_commits(root, start_ids, max_commits=graph_cap)
    if not all_commits:
        print("(no commits)")
        return
    if graph_truncated:
        print(
            f"⚠️  Graph truncated at {graph_cap:,} commits. "
            "Raise [limits] max_graph_commits in .muse/config.toml to see more."
        )

    head_cid = get_head_commit_id(root, current) or ""
    sorted_commits = _topo_sort(all_commits)

    # lanes: list of commit IDs we're "awaiting" (open lines of descent).
    # None marks a closed / empty column slot.
    lanes: list[str | None] = []

    for idx, commit in enumerate(sorted_commits):
        cid = commit.commit_id
        parents = [
            p for p in (commit.parent_commit_id, commit.parent2_commit_id)
            if p and p in all_commits
        ]

        # Assign this commit to a column.
        col = lanes.index(cid) if cid in lanes else -1
        if col == -1:
            if None in lanes:
                col = lanes.index(None)
                lanes[col] = cid
            else:
                col = len(lanes)
                lanes.append(cid)

        width = len(lanes)
        row: list[str] = []
        for i in range(width):
            if i == col:
                row.append(_c("*", _BOLD, tty=tty))
            elif lanes[i] is not None:
                row.append("|")
            else:
                row.append(" ")

        graph_prefix = " ".join(row).rstrip()
        short_hash = _c(long_id(cid), _YELLOW, tty=tty)
        deco = _deco_str(cid, head_cid, current, tips, tty)
        msg = sanitize_display(commit.message.splitlines()[0])
        print(f"{graph_prefix} {short_hash}{deco} {msg}")

        if parents:
            lanes[col] = parents[0]
            newly_opened: set[int] = set()
            for extra in parents[1:]:
                if extra not in lanes:
                    if None in lanes:
                        ni = lanes.index(None)
                        lanes[ni] = extra
                        newly_opened.add(ni)
                    else:
                        ni = len(lanes)
                        lanes.append(extra)
                        newly_opened.add(ni)
        else:
            lanes[col] = None
            newly_opened = set()

        # Detect lanes that share a target — keep lowest-index, mark others converging.
        _seen: dict[str, int] = {}
        converging: set[int] = set()
        for i, v in enumerate(lanes):
            if v is None:
                continue
            if v in _seen:
                converging.add(i)
            else:
                _seen[v] = i

        if idx < len(sorted_commits) - 1:
            is_merge = len(parents) >= 2
            # Use a character array so "/" can slide into the half-position
            # between two lanes (position 2*i-1) rather than starting a new block.
            char_count = len(lanes) * 2
            chars = [" "] * char_count
            for i in range(len(lanes)):
                pos = 2 * i
                if i == col and is_merge:
                    chars[pos] = "|"
                    if pos + 1 < char_count:
                        chars[pos + 1] = "\\"
                elif i in converging:
                    # "/" slides left into the trailing space of lane i-1
                    if pos > 0:
                        chars[pos - 1] = "/"
                elif i in newly_opened:
                    pass  # leave as spaces — lane just opened, no pipe yet
                elif lanes[i] is not None:
                    chars[pos] = "|"
            line = "".join(chars).rstrip()
            if line:
                print(line)

        for i in converging:
            lanes[i] = None
        while lanes and lanes[-1] is None:
            lanes.pop()

# ---------------------------------------------------------------------------
# CLI registration
# ---------------------------------------------------------------------------

def _emit_error(json_out: bool, msg: str, code: "ExitCode", elapsed: float) -> None:
    """Print an error and raise SystemExit.  Never returns.

    In ``--json`` mode the error is emitted as a JSON payload to stdout so
    that machine consumers can always parse stdout — no prose leaks to stderr.
    In text mode the error is printed to stderr as a human-readable message.
    """
    if json_out:
        print(json.dumps(_LogErrorJson(
            **make_envelope(elapsed, exit_code=int(code)),
            status="error",
            error=msg,
        )))
    else:
        print(f"❌ {sanitize_display(msg)}", file=sys.stderr)
    raise SystemExit(code)

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse log`` subcommand and its flags."""
    parser = subparsers.add_parser(
        "log",
        help="Display commit history.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "ref", nargs="?", default=None,
        help="Branch or commit to start from (default: current branch).",
    )
    parser.add_argument(
        "--branch", "-b", default=None, dest="branch_flag",
        help=(
            "Branch or commit to start from — explicit alias for the "
            "positional ref. Mutually exclusive with it."
        ),
    )
    parser.add_argument(
        "--oneline", action="store_true",
        help="One line per commit.",
    )
    parser.add_argument(
        "--graph", "-g", action="store_true",
        help="ASCII DAG graph.",
    )
    parser.add_argument(
        "--all", "-a", action="store_true", dest="all_branches",
        help="Include all local branches in the graph (implies --graph).",
    )
    parser.add_argument(
        "--stat", action="store_true",
        help="Show added/removed file summary for each commit.",
    )
    parser.add_argument(
        "--max-count", "--limit", "-n", type=int, default=_DEFAULT_LIMIT, dest="limit",
        help="Limit number of commits shown (default: %(default)s).",
    )
    parser.add_argument("--since", default=None, help="Show commits after date.")
    parser.add_argument("--until", default=None, help="Show commits before date.")
    parser.add_argument("--author", default=None, help="Filter by author substring.")
    parser.add_argument("--section", default=None, help="Filter by section metadata.")
    parser.add_argument("--track", default=None, help="Filter by track metadata.")
    parser.add_argument("--emotion", default=None, help="Filter by emotion metadata.")
    parser.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit machine-readable JSON instead of human text.",
    )
    parser.add_argument(
        "pathspec", nargs="*", metavar="path",
        help=(
            "Limit output to commits that touched these paths. "
            "Prefix-matched: 'src/' matches all files under src/. "
            "Separate from options with '--' (e.g. muse log -- src/foo.py)."
        ),
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Display commit history.

    Walks the commit DAG from HEAD (or a specified branch/ref) and emits
    commit records.  ``truncated`` is ``true`` when the walk hit the
    ``-n`` cap.  In ``--json`` mode all file changes are always included
    without needing ``--stat``.

    Agent quickstart
    ----------------
    ::

        muse log --json
        muse log -n 20 --json
        muse log --branch feat/billing --json
        muse log --author gabriel --since 2025-01-01 --json

    JSON fields
    -----------
    status     ``"ok"`` on success.
    truncated  ``true`` if the walk was capped by ``-n``.
    total      Number of commits returned.
    branch     Branch walked.
    repo_id    Repository identifier.
    commits    List of commit objects: ``commit_id``, ``message``,
               ``author``, ``committed_at``, ``parent_commit_id``,
               ``files_added``, ``files_modified``, ``files_removed``.

    Exit codes
    ----------
    0  Success.
    1  Invalid arguments (bad ``--format``, ``--since``/``--until``, etc.).
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()

    ref: str | None = args.ref
    branch_flag: str | None = getattr(args, "branch_flag", None)
    json_out_for_ambiguity: bool = args.json_out
    if branch_flag is not None and ref is not None:
        _emit_error(
            json_out_for_ambiguity,
            "Pass either --branch/-b or a positional ref, not both.",
            ExitCode.USER_ERROR,
            elapsed,
        )
        return
    if branch_flag is not None:
        ref = branch_flag
    oneline: bool = args.oneline
    graph: bool = args.graph
    all_branches: bool = args.all_branches
    stat: bool = args.stat
    # Track whether the user explicitly overrode the limit.  Only the default
    # limit being hit silently warrants a truncation warning in text mode.
    explicit_limit: bool = (args.limit != _DEFAULT_LIMIT)
    limit: int = clamp_int(args.limit, 1, 100000, "limit")
    since: str | None = args.since
    until: str | None = args.until
    author: str | None = args.author
    section: str | None = args.section
    track: str | None = args.track
    emotion: str | None = args.emotion
    json_out: bool = args.json_out
    pathspec: list[str] = list(args.pathspec) if args.pathspec else []

    if all_branches:
        graph = True

    # Support git-style -<n> shorthand (e.g. `muse log -5` as alias for `-n 5`).
    # argparse captures "-5" as the positional `ref`; detect and reinterpret it.
    if ref is not None and ref.lstrip("-").isdigit() and ref.startswith("-"):
        limit = int(ref.lstrip("-"))
        explicit_limit = True
        ref = None

    # Support A..B range syntax: commits reachable from B but not from A.
    exclude_ref: str | None = None
    if ref is not None and ".." in ref:
        exclude_ref, ref = ref.split("..", 1)

    if limit < 1:
        _emit_error(json_out, "--max-count must be at least 1.", ExitCode.USER_ERROR, elapsed)

    # Validate date filters before touching the repository.
    since_dt: datetime | None = None
    until_dt: datetime | None = None
    if since:
        try:
            since_dt = _parse_date(since)
        except ValueError:
            _emit_error(
                json_out,
                f"Cannot parse --since value: {since!r}. "
                "Use YYYY-MM-DD, 'today', 'yesterday', or '<n> days ago'.",
                ExitCode.USER_ERROR,
                elapsed,
            )
    if until:
        try:
            until_dt = _parse_date(until)
        except ValueError:
            _emit_error(
                json_out,
                f"Cannot parse --until value: {until!r}. "
                "Use YYYY-MM-DD, 'today', 'yesterday', or '<n> days ago'.",
                ExitCode.USER_ERROR,
                elapsed,
            )

    root = require_repo()
    repo_id = read_repo_id(root)

    # Resolve the exclude side of an A..B range now that we have a root.
    exclude_ids: set[str] = set()
    if exclude_ref is not None:
        excl_rec = resolve_commit_ref(root, read_current_branch(root), exclude_ref)
        excl_cid = excl_rec.commit_id if excl_rec else None
        if excl_cid is None:
            excl_tip = get_head_commit_id(root, exclude_ref)
            if excl_tip:
                excl_cid = excl_tip
        if excl_cid is None:
            _emit_error(
                json_out,
                f"Cannot resolve exclude ref {sanitize_display(exclude_ref)!r}.",
                ExitCode.USER_ERROR,
                elapsed,
            )
        exclude_ids = ancestor_ids(root, excl_cid)
        exclude_ids.add(excl_cid)

    # When the -N shorthand consumed `ref` (e.g. `muse log -1 dev`), argparse
    # puts the branch name in pathspec[0].  Reclaim it now that we have a repo
    # root available to check whether it's a real ref.
    if ref is None and pathspec and _is_known_ref(root, pathspec[0]):
        ref = pathspec[0]
        pathspec = pathspec[1:]

    # Disambiguate: argparse assigns the first positional after `--` to `ref`
    # (because ref is nargs="?").  If what landed in `ref` is not a known
    # branch or commit ID, treat it as the first pathspec element.
    # Preserve the original value for the "no commits on '<ref>'" message so
    # that nonexistent-branch errors are still contextual.
    # In range mode (A..B) the include side must resolve — don't silently
    # treat an unknown B as a pathspec.
    user_ref = ref  # may be a nonexistent branch name — kept for error display
    if ref is not None and not _is_known_ref(root, ref):
        if exclude_ref is not None:
            _emit_error(
                json_out,
                f"Cannot resolve include ref {sanitize_display(ref)!r}.",
                ExitCode.USER_ERROR,
                elapsed,
            )
        pathspec = [ref] + pathspec
        ref = None

    # Detect whether ref is a direct commit ID (sha256: prefixed or bare hex).
    # Commit IDs must be routed through resolve_commit_ref + a manual walk;
    # get_commits_for_branch only accepts branch names (validate_branch_name
    # rejects ":" which appears in every sha256: commit ID).
    ref_is_commit_id = ref is not None and (
        (ref.startswith("sha256:") and len(ref) > 7 and all(c in _HEX_CHARS for c in long_id(ref, strip=True)))
        or (len(ref) >= 8 and all(c in _HEX_CHARS for c in ref))
    )

    if ref_is_commit_id:
        # Resolve the commit ID (full or abbreviated prefix) to a CommitRecord.
        start_rec = resolve_commit_ref(root, read_current_branch(root), ref)
        start_cid = start_rec.commit_id if start_rec else None
        # Display the branch the resolved commit belongs to; fall back to current.
        branch = (start_rec.branch if start_rec else None) or read_current_branch(root)
    else:
        start_cid = None
        branch = ref if ref is not None else read_current_branch(root)

    if graph and not json_out:
        _render_graph(root, branch=branch, all_branches=all_branches, tty=sys.stdout.isatty())
        return

    has_filters = any([since_dt, until_dt, author, section, track, emotion])
    walk_cap = get_limit("max_walk_commits", root)

    def _walk_from_cid(start: str | None, max_count: int = 0) -> list[CommitRecord]:
        """Walk the parent chain from *start*, returning commits newest-first."""
        commits: list[CommitRecord] = []
        cid = start
        seen: set[str] = set()
        while cid and cid not in seen:
            if max_count > 0 and len(commits) >= max_count:
                break
            seen.add(cid)
            rec = read_commit(root, cid)
            if rec is None:
                break
            commits.append(rec)
            cid = rec.parent_commit_id
        return commits

    # When filters or pathspec are active we must walk the full history first,
    # then apply the limit afterwards (same as git log).  Without filters we
    # fetch limit+1 commits: if we get limit+1 back there are more commits
    # than the display cap — truncated=True; otherwise we got everything.
    # --all with JSON: walk from every local + remote tracking tip, deduplicate.
    if all_branches and not ref_is_commit_id:
        all_tips = _branch_tips(root, include_remote=True)
        seen_cids: set[str] = set()
        raw_commits = []
        for tip_cid in all_tips:
            for rec in _walk_from_cid(tip_cid, max_count=walk_cap):
                if rec.commit_id not in seen_cids:
                    seen_cids.add(rec.commit_id)
                    raw_commits.append(rec)
        raw_commits.sort(key=lambda c: c.committed_at, reverse=True)
        probe_truncated = False
    elif has_filters or pathspec:
        walk_limit = walk_cap
        if ref_is_commit_id:
            raw_commits = _walk_from_cid(start_cid, max_count=walk_limit)
        else:
            raw_commits = get_commits_for_branch(root, branch, max_count=walk_limit)
        probe_truncated = False
    else:
        probe_count = limit + 1
        if ref_is_commit_id:
            raw_commits = _walk_from_cid(start_cid, max_count=probe_count)
        else:
            raw_commits = get_commits_for_branch(root, branch, max_count=probe_count)
        probe_truncated = len(raw_commits) > limit
        if probe_truncated:
            raw_commits = raw_commits[:limit]

    # Apply A..B exclusion: drop commits reachable from the exclude side.
    if exclude_ids:
        raw_commits = [c for c in raw_commits if c.commit_id not in exclude_ids]

    # Shared manifest cache: each commit_id's snapshot is loaded at most once
    # per invocation regardless of how many callers need it (pathspec filter,
    # stat diff, JSON serialisation).
    manifest_cache: _ManifestCache = {}

    # Apply pathspec filter: keep only commits that touched one of the given paths.
    if pathspec:
        raw_commits = [
            c for c in raw_commits
            if any(_commit_touches_path(root, c, p, manifest_cache) for p in pathspec)
        ]

    walk_truncated = probe_truncated or ((has_filters or bool(pathspec)) and len(raw_commits) >= walk_cap)

    filtered, filter_truncated = _apply_filters(
        raw_commits,
        since_dt=since_dt,
        until_dt=until_dt,
        author=author,
        section=section,
        track=track,
        emotion=emotion,
        limit=limit,
    )
    truncated = walk_truncated or filter_truncated

    # ── JSON output ───────────────────────────────────────────────────────────
    if json_out:
        commit_list = [
            _commit_to_json(c, root, stat=True, manifest_cache=manifest_cache)
            for c in filtered
        ]
        print(json.dumps(_LogJson(
            **make_envelope(elapsed),
            status="ok",
            error="",
            truncated=truncated,
            total=len(filtered),
            branch=branch,
            repo_id=repo_id,
            commits=commit_list,
        ), default=str))
        return

    # ── Text output ───────────────────────────────────────────────────────────
    if not filtered:
        if user_ref is not None:
            # Distinguish "branch exists but is empty" from "branch not found".
            print(f"(no commits on '{sanitize_display(user_ref)}')")
        else:
            print("(no commits)")
        return

    # Only warn about truncation when the default cap was hit silently.  If the
    # user explicitly passed -n they know they are asking for a subset — no warning.
    if truncated and not explicit_limit:
        print(
            f"⚠️  History truncated at {len(filtered):,} commits — "
            "use -n or raise [limits] max_walk_commits in .muse/config.toml to see more."
        )

    head_commit_id = filtered[0].commit_id if filtered else None
    tty: bool = sys.stdout.isatty()

    for c in filtered:
        is_head = c.commit_id == head_commit_id
        decoration = _ref_label(branch, is_head, tty)
        short_hash = _c(long_id(c.commit_id), _YELLOW, tty=tty)
        subject = sanitize_display(c.message.splitlines()[0])
        author_display = sanitize_display(c.author)

        if oneline:
            print(f"{short_hash}{decoration} {subject}")
            continue

        commit_word = _c("commit", _YELLOW, tty=tty)
        print(f"{commit_word} {short_hash}{decoration}")
        if author_display:
            print(f"Author: {author_display}")
        print(f"Date:   {_c(_format_date(c.committed_at), _DIM, tty=tty)}")

        if c.sem_ver_bump and c.sem_ver_bump != "none":
            bump_key = c.sem_ver_bump.lower()
            bump_colour = _SEMVER_COLOUR.get(bump_key, "")
            bump_label = (
                _c(c.sem_ver_bump.upper(), bump_colour, tty=tty)
                if bump_colour else c.sem_ver_bump.upper()
            )
            print(f"SemVer: {bump_label}")
            if c.breaking_changes:
                safe_breaks = [sanitize_display(b) for b in c.breaking_changes[:3]]
                breaking_text = ", ".join(safe_breaks)
                if len(c.breaking_changes) > 3:
                    breaking_text += f" +{len(c.breaking_changes) - 3} more"
                print(f"Breaking: {_c(breaking_text, _RED, tty=tty)}")

        if c.metadata:
            meta_parts = [
                f"{sanitize_display(k)}: {sanitize_display(str(v))}"
                for k, v in sorted(c.metadata.items())
            ]
            print(f"Meta:   {', '.join(meta_parts)}")

        # Indent every line of the message body uniformly.
        body = sanitize_display(c.message)
        indented = textwrap.indent(body, "    ")
        print(f"\n{indented}\n")

        if stat:
            added, removed, modified = _file_diff(root, c, manifest_cache)
            for p in added:
                print(_c(f" + {p}", _GREEN, tty=tty))
            for p in modified:
                print(_c(f" ~ {p}", _YELLOW, tty=tty))
            for p in removed:
                print(_c(f" - {p}", _RED, tty=tty))
            if added or removed or modified:
                summary = (
                    f" {len(added)} added, {len(modified)} modified, "
                    f"{len(removed)} removed"
                )
                print(f"{_c(summary, _DIM, tty=tty)}\n")
