"""``muse maintenance`` — scheduled store maintenance orchestration.

Orchestrates multiple store-health tasks under a single command with a shared
schedule configuration and persistent run-history.

Subcommands
-----------
``run [--task <task>]... [--all] [--dry-run] [--json]``
    Execute one or more maintenance tasks.  Available tasks:

    ``gc``
        Remove unreachable objects, commits, and snapshots from the store
        (wraps :func:`muse.core.gc.run_gc` with ``full=True``).

    ``verify-objects``
        Rehash every object in the store and report any whose content does not
        match their filename.  Non-destructive; always safe to run.

    Without ``--task``, runs the tasks listed in the persisted schedule config
    (default: ``gc`` and ``verify-objects``).  ``--all`` runs every known task.

    Unless ``--dry-run`` is set, each task's completion time is written back
    to ``.muse/maintenance.json`` so ``status`` can report freshness.

``status [--json]``
    Show the schedule configuration and the last-run record for each task.

``schedule [--period-hours N] [--enable] [--disable] [--json]``
    Write or update the schedule configuration in ``.muse/maintenance.json``.
    ``--period-hours`` sets the suggested inter-run interval (informational —
    Muse does not run background daemons; callers use this value to decide
    whether to trigger ``run``).  ``--enable`` and ``--disable`` are mutually
    exclusive.

State
-----
All state is stored in ``.muse/maintenance.json``::

    {
      "enabled":      true,
      "period_hours": 24,
      "tasks":        ["gc", "verify-objects"],
      "last_run":     {
        "gc": {
          "timestamp":   "2026-04-14T12:00:00+00:00",
          "status":      "ok",
          "duration_ms": 42.3
        },
        "verify-objects": {
          "timestamp":   "2026-04-14T12:00:00+00:00",
          "status":      "ok",
          "duration_ms": 1200.5
        }
      }
    }

JSON output (``run --json``)::

    {
      "status":      "ok",
      "error":       "",
      "tasks_run":   ["gc"],
      "results":     {"gc": {...}},
      "dry_run":     false,
      "duration_ms": 12.4,
      "exit_code":   0
    }

JSON output (``status --json``)::

    {
      "status":       "ok",
      "error":        "",
      "enabled":      true,
      "period_hours": 24,
      "tasks":        ["gc", "verify-objects"],
      "last_run":     {
        "gc": {"timestamp": "2026-...", "status": "ok", "duration_ms": 42.3}
      },
      "exit_code":    0
    }

JSON output (``schedule --json``)::

    {
      "status":       "ok",
      "error":        "",
      "enabled":      true,
      "period_hours": 24,
      "exit_code":    0
    }

JSON error schema (exit non-zero)::

    {
      "status":    "error",
      "error":     "<human-readable message>",
      "exit_code": <int>
    }

When ``--json`` is active all errors go to stdout as JSON — no prose on
stderr.  Agents should parse stdout and check ``status``.

Exit codes::

    0 — all tasks completed (even if verify-objects found issues)
    1 — a task argument was invalid
    2 — usage error
"""

import argparse
import json as _json
import logging
import sys
from typing import TypedDict

from muse.core.types import load_json_file, long_id, now_utc_iso
from muse.core.paths import maintenance_json_path as _maintenance_json_path
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.gc import _DEFAULT_GRACE_PERIOD_SECONDS, run_gc, prune_stale_remote_refs
from muse.core.object_store import iter_stored_objects
from muse.core.repo import require_repo
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_ALL_TASKS: list[str] = ["gc", "verify-objects"]
_DEFAULT_TASKS: list[str] = ["gc", "verify-objects"]
_DEFAULT_PERIOD_HOURS: int = 24
_CONFIG_FILE = "maintenance.json"

# ---------------------------------------------------------------------------
# Wire-format TypedDicts
# ---------------------------------------------------------------------------

class _GcResultDict(TypedDict):
    collected_count: int
    collected_bytes: int
    reachable_count: int
    commits_collected: int
    snapshots_collected: int
    stale_remote_refs_collected: int
    stale_remote_refs_bytes: int
    dry_run: bool
    duration_ms: float

class _VerifyResultDict(TypedDict):
    checked: int
    failed: int
    failures: list[str]
    duration_ms: float

class _TaskRunRecord(TypedDict):
    """Per-task run record stored in ``last_run`` map."""
    timestamp: str      # ISO-8601 UTC
    status: str         # "ok" | "error" | "unknown"
    duration_ms: float

# last_run values are _TaskRunRecord dicts; hyphens in task names prevent
# expressing this as a TypedDict, so use a plain dict alias.
type _LastRunMap = dict[str, _TaskRunRecord]

class _MaintenanceConfig(TypedDict, total=False):
    enabled: bool
    period_hours: int
    tasks: list[str]
    last_run: _LastRunMap

type _TaskResultsMap = dict[str, _GcResultDict | _VerifyResultDict]

class _MaintenanceRunJson(EnvelopeJson):
    """Stable JSON envelope for ``maintenance run --json``."""
    status: str          # "ok"
    error: str           # always "" on success
    tasks_run: list[str]
    results: _TaskResultsMap
    dry_run: bool

class _MaintenanceStatusJson(EnvelopeJson):
    """Stable JSON envelope for ``maintenance status --json``."""
    status: str          # "ok"
    error: str           # always "" on success
    enabled: bool
    period_hours: int
    tasks: list[str]
    last_run: _LastRunMap

class _MaintenanceScheduleJson(EnvelopeJson):
    """Stable JSON envelope for ``maintenance schedule --json``."""
    status: str          # "ok"
    error: str           # always "" on success
    enabled: bool
    period_hours: int

class _MaintenanceErrorJson(EnvelopeJson):
    """Error payload for any ``maintenance`` subcommand in --json mode."""
    status: str          # "error"
    error: str

# ---------------------------------------------------------------------------
# Config I/O
# ---------------------------------------------------------------------------

def _config_path(root: "pathlib.Path") -> "pathlib.Path":
    return _maintenance_json_path(root)

def _read_config(root: "pathlib.Path") -> _MaintenanceConfig:
    path = _config_path(root)
    _default: _MaintenanceConfig = {
        "enabled": True,
        "period_hours": _DEFAULT_PERIOD_HOURS,
        "tasks": list(_DEFAULT_TASKS),
        "last_run": {},
    }
    if not path.exists():
        return _default
    raw = load_json_file(path)
    if raw is None:
        logger.warning(
            "⚠️ Could not parse %s — using default maintenance config", path.name
        )
        return _default
    cfg: _MaintenanceConfig = {
        "enabled": bool(raw.get("enabled", True)),
        "period_hours": int(raw.get("period_hours", _DEFAULT_PERIOD_HOURS)),
        "tasks": list(raw.get("tasks") or _DEFAULT_TASKS),
        "last_run": raw.get("last_run") or {},
    }
    return cfg

def _write_config(root: "pathlib.Path", cfg: _MaintenanceConfig) -> None:
    _config_path(root).write_text(_json.dumps(cfg), encoding="utf-8")

def _now_iso() -> str:
    return now_utc_iso()

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _emit_error(json_out: bool, msg: str, code: ExitCode, elapsed: float) -> None:
    """Print an error and raise SystemExit.  Never returns.

    In ``--json`` mode the error goes to stdout as a JSON payload so machine
    consumers always get parseable output.  In text mode it goes to stderr.
    """
    if json_out:
        print(_json.dumps(_MaintenanceErrorJson(
            **make_envelope(elapsed, exit_code=int(code)),
            status="error",
            error=msg,
        )))
    else:
        print(f"❌ {msg}", file=sys.stderr)
    raise SystemExit(code)

# ---------------------------------------------------------------------------
# Task implementations
# ---------------------------------------------------------------------------

def _run_gc(root: "pathlib.Path", *, dry_run: bool = False) -> _GcResultDict:
    """Run garbage collection; return a result summary dict."""
    from muse.cli.config import list_remotes
    elapsed = start_timer()
    result = run_gc(
        root,
        dry_run=dry_run,
        grace_period_seconds=0 if dry_run else _DEFAULT_GRACE_PERIOD_SECONDS,
        full=True,
    )
    configured_names = {r["name"] for r in list_remotes(root)}
    prune_stale_remote_refs(root, configured_names, result, dry_run=dry_run)
    return {
        "collected_count": result.collected_count,
        "collected_bytes": result.collected_bytes,
        "reachable_count": result.reachable_count,
        "commits_collected": result.commits_collected,
        "snapshots_collected": result.snapshots_collected,
        "stale_remote_refs_collected": result.stale_remote_refs_collected,
        "stale_remote_refs_bytes": result.stale_remote_refs_bytes,
        "dry_run": dry_run,
        "duration_ms": elapsed(),
    }

def _run_verify_objects(root: "pathlib.Path") -> _VerifyResultDict:
    """Rehash every object; return summary with checked/failed counts.

    All object IDs in the ``failures`` list are ``sha256:``-prefixed for
    consistency with the rest of the Muse API.
    """
    import hashlib

    elapsed = start_timer()
    checked = 0
    failed = 0
    failures: list[str] = []

    for oid, obj_file in sorted(iter_stored_objects(root), key=lambda t: t[0]):
        checked += 1
        try:
            h = hashlib.sha256()
            with obj_file.open("rb") as fh:
                for chunk in iter(lambda: fh.read(65536), b""):
                    h.update(chunk)
            if long_id(h.hexdigest()) != oid:
                failed += 1
                failures.append(oid)
        except OSError:
            failed += 1
            failures.append(oid)

    return {
        "checked": checked,
        "failed": failed,
        "failures": failures[:20],  # cap to avoid huge JSON
        "duration_ms": elapsed(),
    }

# ---------------------------------------------------------------------------
# Subcommand handlers
# ---------------------------------------------------------------------------

_TASK_RUNNERS = {
    "gc": _run_gc,
    "verify-objects": _run_verify_objects,
}

def _cmd_run(args: argparse.Namespace, root: "pathlib.Path") -> None:
    elapsed = start_timer()
    dry_run: bool = args.dry_run
    json_out: bool = args.json_out

    # Validate requested tasks.
    if args.all:
        tasks_to_run = list(_ALL_TASKS)
    elif args.task:
        tasks_to_run = list(args.task)
        unknown = [t for t in tasks_to_run if t not in _TASK_RUNNERS]
        if unknown:
            _emit_error(
                json_out,
                f"Unknown task(s): {', '.join(unknown)}. Available: {', '.join(_ALL_TASKS)}",
                ExitCode.USER_ERROR,
                elapsed,
            )
    else:
        cfg = _read_config(root)
        tasks_to_run = cfg.get("tasks") or list(_DEFAULT_TASKS)

    results: _TaskResultsMap = {}
    task_records: _LastRunMap = {}

    for task in tasks_to_run:
        runner_fn = _TASK_RUNNERS[task]
        t0 = start_timer()
        try:
            if task == "gc":
                results[task] = runner_fn(root, dry_run=dry_run)
            else:
                results[task] = runner_fn(root)
            task_records[task] = _TaskRunRecord(
                timestamp=_now_iso(),
                status="ok",
                duration_ms=t0(),
            )
        except Exception as exc:  # noqa: BLE001
            task_records[task] = _TaskRunRecord(
                timestamp=_now_iso(),
                status="error",
                duration_ms=t0(),
            )
            logger.error("maintenance: task %r failed: %s", task, exc)

    # Persist run records (skipped in dry-run).
    if not dry_run:
        cfg = _read_config(root)
        if "last_run" not in cfg:
            cfg["last_run"] = {}
        cfg["last_run"].update(task_records)
        _write_config(root, cfg)

    if json_out:
        print(_json.dumps(_MaintenanceRunJson(
            **make_envelope(elapsed),
            status="ok",
            error="",
            tasks_run=tasks_to_run,
            results=results,
            dry_run=dry_run,
        )))
    else:
        prefix = "[dry-run] " if dry_run else ""
        for task in tasks_to_run:
            r = results.get(task)
            if r is None:
                print(f"{prefix}❌ {task}: failed (see logs)")
                continue
            if task == "gc":
                action = "Would remove" if dry_run else "Removed"
                print(
                    f"{prefix}{action} {r['collected_count']} unreachable object(s) "
                    f"({r['collected_bytes']} bytes); "
                    f"{r['reachable_count']} reachable"
                )
            elif task == "verify-objects":
                status = "✅" if r["failed"] == 0 else "❌"
                print(
                    f"{prefix}{status} verify-objects: "
                    f"{r['checked']} checked, {r['failed']} failed"
                )
        elapsed_s = elapsed() / 1000
        print(
            f"{prefix}Done in {elapsed_s:.3f}s"
            + (" (no changes written)" if dry_run else "")
        )

def _cmd_status(args: argparse.Namespace, root: "pathlib.Path") -> None:
    elapsed = start_timer()
    cfg = _read_config(root)
    json_out: bool = args.json_out

    enabled = cfg.get("enabled", True)
    period_hours = cfg.get("period_hours", _DEFAULT_PERIOD_HOURS)
    last_run: _LastRunMap = cfg.get("last_run", {})

    if json_out:
        print(_json.dumps(_MaintenanceStatusJson(
            **make_envelope(elapsed),
            status="ok",
            error="",
            enabled=enabled,
            period_hours=period_hours,
            tasks=cfg.get("tasks", list(_DEFAULT_TASKS)),
            last_run=last_run,
        )))
        return

    status_label = "enabled" if enabled else "disabled"
    print(f"Maintenance: {status_label}  (period: {period_hours}h)")
    if not last_run:
        print("  Never run.")
    else:
        for task, record in sorted(last_run.items()):
            ts = record.get("timestamp", "")
            st = record.get("status", "unknown")
            icon = "✅" if st == "ok" else ("❌" if st == "error" else "?")
            print(f"  {task:<20} {icon} {ts}")

def _cmd_schedule(args: argparse.Namespace, root: "pathlib.Path") -> None:
    elapsed = start_timer()
    period_hours: int | None = args.period_hours
    enable: bool = args.enable
    disable: bool = args.disable
    json_out: bool = getattr(args, "json_out", False)

    if enable and disable:
        _emit_error(json_out, "--enable and --disable are mutually exclusive", ExitCode.USER_ERROR, elapsed)

    if period_hours is not None and period_hours < 0:
        _emit_error(json_out, "--period-hours must be ≥ 0", ExitCode.USER_ERROR, elapsed)

    cfg = _read_config(root)

    if period_hours is not None:
        cfg["period_hours"] = period_hours
    if enable:
        cfg["enabled"] = True
    if disable:
        cfg["enabled"] = False

    _write_config(root, cfg)

    enabled_now = cfg.get("enabled", True)
    ph_now = cfg.get("period_hours", _DEFAULT_PERIOD_HOURS)

    if json_out:
        print(_json.dumps(_MaintenanceScheduleJson(
            **make_envelope(elapsed),
            status="ok",
            error="",
            enabled=enabled_now,
            period_hours=ph_now,
        )))
    else:
        status = "enabled" if enabled_now else "disabled"
        print(f"Maintenance schedule updated: {status}, period: {ph_now}h")

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``muse maintenance`` subcommand."""
    parser = subparsers.add_parser(
        "maintenance",
        help="Scheduled store maintenance orchestration.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="maint_command", metavar="SUBCOMMAND")
    sub.required = True

    # run
    p_run = sub.add_parser(
        "run",
        help="Run maintenance tasks.",
    )
    p_run.add_argument(
        "--task",
        action="append",
        metavar="TASK",
        choices=_ALL_TASKS,
        dest="task",
        help=f"Task to run (repeatable). Choices: {', '.join(_ALL_TASKS)}",
    )
    p_run.add_argument(
        "--all", "-a",
        action="store_true",
        default=False,
        help="Run all maintenance tasks.",
    )
    p_run.add_argument(
        "--dry-run", "-n",
        action="store_true",
        default=False,
        dest="dry_run",
        help="Preview without making changes or updating timestamps.",
    )
    p_run.add_argument(
        "--json", "-j",
        action="store_true",
        default=False,
        dest="json_out",
        help="Emit a JSON result object.",
    )
    p_run.set_defaults(maint_func=_cmd_run)

    # status
    p_status = sub.add_parser("status", help="Show schedule and last-run info.")
    p_status.add_argument(
        "--json", "-j",
        action="store_true",
        default=False,
        dest="json_out",
    )
    p_status.set_defaults(maint_func=_cmd_status)

    # schedule
    p_sched = sub.add_parser("schedule", help="Configure maintenance schedule.")
    p_sched.add_argument(
        "--period-hours",
        type=int,
        default=None,
        metavar="N",
        dest="period_hours",
        help="Suggested interval between runs (hours).",
    )
    p_sched.add_argument(
        "--enable",
        action="store_true",
        default=False,
        help="Mark maintenance as enabled.",
    )
    p_sched.add_argument(
        "--disable",
        action="store_true",
        default=False,
        help="Mark maintenance as disabled.",
    )
    p_sched.add_argument(
        "--json", "-j",
        action="store_true",
        default=False,
        dest="json_out",
        help="Emit a JSON result object.",
    )
    p_sched.set_defaults(maint_func=_cmd_schedule)

    parser.set_defaults(func=run)

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Orchestrate scheduled store-maintenance tasks.

    Dispatches to one of three subcommands: ``run`` (execute tasks), ``status``
    (show schedule and last-run timestamps), or ``schedule`` (write schedule
    config).  All subcommands accept ``--json`` for machine-readable output.

    Agent quickstart
    ----------------
    ::

        muse maintenance run --all --json
        muse maintenance run --task gc --json
        muse maintenance status --json
        muse maintenance schedule --period-hours 12 --enable --json

    JSON fields (run)
    -----------------
    status      ``"ok"`` on success.
    tasks_run   List of task names that were executed.
    results     Map of task name → result summary dict.
    dry_run     ``true`` when ``--dry-run`` was passed (no state written).

    JSON fields (status)
    --------------------
    status        ``"ok"`` on success.
    enabled       Whether maintenance is enabled in the schedule config.
    period_hours  Suggested inter-run interval in hours.
    tasks         Tasks listed in the schedule config.
    last_run      Map of task name → ``{timestamp, status, duration_ms}``.

    Exit codes
    ----------
    0  Success.
    1  Unknown task name, invalid ``--period-hours``, or conflicting flags.
    2  Not inside a Muse repository.
    """
    root = require_repo()
    args.maint_func(args, root)
