"""``muse patch-id [<ref>]`` — content-based commit identity.

Computes a stable SHA-256 hash of a commit's diff content — independent of
commit ID, author, timestamp, branch, or merge history.  Two commits that
make the same logical change produce the same patch-id, enabling reliable
cherry-pick detection and duplicate patch identification.

Algorithm
---------
1. Resolve the commit and its parent's snapshot manifests.
2. For each file changed between parent and commit (sorted alphabetically),
   compute the unified diff.
3. Extract only the ``+`` and ``-`` content lines (skip ``@@`` context headers
   and ``---``/``+++`` file headers).
4. Feed those lines — in sorted-file order — into a SHA-256 digest.
5. The 64-char hex digest is the patch-id.

With ``--stable``, each content line is stripped of trailing whitespace before
hashing so that cosmetic whitespace changes don't produce a new patch-id.

Output formats
--------------
Default text::

    <patch_id> <commit_id>

JSON (``--json``)::

    {
      "commit_id":    "<sha256>",
      "patch_id":     "<64-char hex>",
      "subject":      "feat: add something",
      "files_changed": 3,
      "stable":       false,
      "duration_ms":  2.1,
      "exit_code":    0
    }

Exit codes::

    0 — success
    1 — user error: bad ref, ANSI in ref, empty repo
    2 — not a Muse repository

Examples::

    muse patch-id HEAD
    muse patch-id HEAD --json
    muse patch-id HEAD --stable
    muse patch-id <commit-id> --json
    muse patch-id main --json
"""

import argparse
import difflib
import hashlib
import json as _json
import logging
import pathlib
import sys
from typing import TypedDict

from muse.core.errors import ExitCode
from muse.core.object_store import read_object
from muse.core.repo import require_repo
from muse.core.refs import read_ref
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import (
    CommitRecord,
    read_commit,
    resolve_commit_ref,
)
from muse.core.snapshots import read_snapshot
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.validation import sanitize_display
from muse.core.types import Manifest, long_id
from muse.core.paths import ref_path as _ref_path
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Wire-format TypedDicts
# ---------------------------------------------------------------------------

class _PatchIdJson(EnvelopeJson):
    """Stable JSON envelope for ``muse patch-id --json`` output."""
    commit_id: str
    patch_id: str
    subject: str
    files_changed: int
    stable: bool

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _compute_patch_id(
    root: pathlib.Path,
    base_manifest: Manifest,
    target_manifest: Manifest,
    *,
    stable: bool,
) -> str:
    """Compute a patch-id from the diff between two manifests.

    The patch-id is the SHA-256 of the sorted-file unified diff content lines
    (``+`` and ``-`` lines only, not ``@@`` or file headers).

    Args:
        root:            Absolute repo root (for object store reads).
        base_manifest:   Parent commit manifest (path → object_id).
        target_manifest: This commit manifest (path → object_id).
        stable:          When True, strip trailing whitespace from each content
                         line before hashing so cosmetic whitespace changes are
                         ignored.

    Returns:
        ``sha256:``-prefixed SHA-256 string.
    """
    h = hashlib.sha256()

    base_paths = set(base_manifest)
    target_paths = set(target_manifest)
    changed = sorted(
        (target_paths - base_paths)          # added
        | (base_paths - target_paths)        # removed
        | {                                   # modified
            p for p in base_paths & target_paths
            if base_manifest[p] != target_manifest[p]
        }
    )

    for path in changed:
        # Read base lines.
        if path in base_manifest:
            raw = read_object(root, base_manifest[path])
            base_lines = raw.decode("utf-8", errors="replace").splitlines() if raw else []
        else:
            base_lines = []

        # Read target lines.
        if path in target_manifest:
            raw = read_object(root, target_manifest[path])
            target_lines = raw.decode("utf-8", errors="replace").splitlines() if raw else []
        else:
            target_lines = []

        # Generate unified diff and extract content lines (+/-) only.
        for line in difflib.unified_diff(
            base_lines, target_lines,
            fromfile=f"a/{path}", tofile=f"b/{path}",
            lineterm="",
        ):
            if line.startswith("+") or line.startswith("-"):
                if stable:
                    line = line.rstrip()
                h.update(line.encode("utf-8", errors="replace"))
                h.update(b"\n")

    return long_id(h.hexdigest())

def _resolve_commit(root: pathlib.Path, treeish: str) -> CommitRecord:
    """Resolve *treeish* to a CommitRecord.

    Args:
        root:    Absolute repo root.
        treeish: Branch name, commit ID, or ``"HEAD"``.

    Returns:
        CommitRecord.

    Raises:
        SystemExit(USER_ERROR): ref not found or empty repo.
    """
    try:
        branch = read_current_branch(root)

        if treeish.upper() == "HEAD":
            commit_id = get_head_commit_id(root, branch)
            if not commit_id:
                print("❌ Repository has no commits yet.", file=sys.stderr)
                raise SystemExit(ExitCode.USER_ERROR)
            commit = read_commit(root, commit_id)
        else:
            # Try branch name first.
            branch_ref = _ref_path(root, treeish)
            commit_id = read_ref(branch_ref)
            if commit_id is not None:
                commit = read_commit(root, commit_id)
            else:
                commit = resolve_commit_ref(root, branch, treeish)

        if commit is None:
            print(
                f"❌ '{sanitize_display(treeish)}' is not a known branch or commit ID.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)

        return commit
    except SystemExit:
        raise
    except Exception as exc:
        print(f"❌ Failed to resolve '{sanitize_display(treeish)}': {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``muse patch-id`` subcommand."""
    parser = subparsers.add_parser(
        "patch-id",
        help="Compute a stable content-based hash of a commit's diff.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "treeish",
        metavar="REF",
        nargs="?",
        default="HEAD",
        help="Commit ID, branch name, or HEAD (default: HEAD).",
    )
    parser.add_argument(
        "--stable",
        action="store_true",
        dest="stable",
        help=(
            "Strip trailing whitespace from each diff line before hashing "
            "so cosmetic whitespace changes don't produce a new patch-id."
        ),
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON on stdout.",
    )
    parser.set_defaults(func=run)

# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Compute the patch-id for a given commit.

    Hashes the diff between a commit and its parent using a content-stable
    algorithm.  Identical patches applied to different bases produce the same
    patch-id — useful for deduplication and cherry-pick detection.

    Agent quickstart
    ----------------
    ::

        muse patch-id --json
        muse patch-id HEAD~3 --json
        muse patch-id feat/billing --stable --json

    JSON fields
    -----------
    commit_id      Commit ID that was analysed.
    patch_id       Content-stable patch fingerprint (sha256: prefixed).
    subject        First line of the commit message.
    files_changed  Number of files that changed relative to the parent.
    stable         ``true`` when ``--stable`` was passed.

    Exit codes
    ----------
    0  Success.
    1  Bad ref, ANSI in ref, or empty repository.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    treeish: str = args.treeish or "HEAD"
    stable: bool = args.stable
    json_out: bool = args.json_out

    root = require_repo()

    # ── Reject ANSI / control characters in the ref ───────────────────────────
    if any(ord(c) < 32 for c in treeish):
        print(
            f"❌ Invalid ref '{sanitize_display(treeish)}': control characters not allowed.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    # ── Resolve the commit ────────────────────────────────────────────────────
    commit = _resolve_commit(root, treeish)

    # ── Get parent manifest ───────────────────────────────────────────────────
    base_manifest: Manifest = {}
    if commit.parent_commit_id:
        parent = read_commit(root, commit.parent_commit_id)
        if parent:
            snap = read_snapshot(root, parent.snapshot_id)
            if snap:
                base_manifest = dict(snap.manifest)

    # ── Get this commit's manifest ────────────────────────────────────────────
    snap = read_snapshot(root, commit.snapshot_id)
    target_manifest: Manifest = dict(snap.manifest) if snap else {}

    # ── Count changed files (added + removed + modified) ──────────────────────
    base_paths = set(base_manifest)
    target_paths = set(target_manifest)
    files_changed = len(
        (target_paths - base_paths)
        | (base_paths - target_paths)
        | {p for p in base_paths & target_paths if base_manifest[p] != target_manifest[p]}
    )

    # ── Compute patch-id ──────────────────────────────────────────────────────
    patch_id = _compute_patch_id(root, base_manifest, target_manifest, stable=stable)

    # ── Output ───────────────────────────────────────────────────────────────
    if json_out:
        print(_json.dumps(_PatchIdJson(
            **make_envelope(elapsed),
            commit_id=commit.commit_id,
            patch_id=patch_id,
            subject=commit.message.splitlines()[0] if commit.message else "",
            files_changed=files_changed,
            stable=stable,
        )))
    else:
        print(f"{patch_id} {commit.commit_id}")
