"""muse clone — create a local copy of a remote Muse repository.

Downloads the complete commit history, snapshots, and objects from a remote
MuseHub repository into a new local directory.  After cloning:

- A full ``.muse/`` directory is created with the remote's repo_id and domain.
- The ``origin`` remote is configured to point at the source URL.
- The default branch is checked out into the working tree.

Usage
-----

    muse clone <url>            Clone into a directory named after the last URL segment.
    muse clone <url> <dir>      Clone into a specific directory.
    muse clone <url> --branch dev         Clone and check out 'dev'.
    muse clone <url> --dry-run            Show what would happen without writing anything.
    muse clone <url> --no-checkout        Skip working-tree restore after cloning.
    muse clone <url> --json               Emit a machine-readable JSON result to stdout.

Auth
----

Signing identities are read from ``~/.muse/identity.toml`` keyed by hostname.
No signing identity is required for public repositories.

JSON schema (``--json``)
------------------------

::

    {
      "status":           "cloned | dry_run | already_exists",
      "url":              "<remote_url>",
      "directory":        "<local_path>",
      "branch":           "<branch_checked_out>",
      "commits_received": <N>,
      "blobs_written":    <N>,
      "head":             "<sha256> | null",
      "domain":           "<domain>",
      "dry_run":          false
    }

Exit codes
----------

0 — success (including dry-run)
1 — user error (target already exists, empty repository, unknown branch)
2 — internal / transport error
"""

import argparse
import json
import logging
import pathlib
import shutil
import sys
from typing import TYPE_CHECKING, TypedDict

import time

from muse._version import __version__ as _SCHEMA_VERSION
from muse.core.timing import start_timer
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.cli.config import get_signing_identity, set_remote, set_remote_head, set_upstream
from muse.core.types import content_hash, now_utc_iso
from muse.core.paths import muse_dir as _muse_dir, ref_path as _ref_path
from muse.core.errors import ExitCode
from muse.core.mpack import apply_mpack
from muse.core.io import write_text_atomic
from muse.core.refs import (
    write_branch_ref,
    write_head_branch,
)
from muse.core.commits import read_commit
from muse.core.snapshots import read_snapshot
from muse.core.transport import TransportError, make_transport
from muse.core.validation import sanitize_display
from muse.core.workdir import apply_manifest
from muse.core.hooks import install_notice

type _RepoMeta = dict[str, str]
if TYPE_CHECKING:
    from muse.core.mpack import ApplyResult

logger = logging.getLogger(__name__)

# Canonical set of subdirectories — must match muse init's _INIT_SUBDIRS.
_CLONE_SUBDIRS: tuple[str, ...] = (
    "refs",
    "refs/heads",
    "objects",
    "commits",
    "snapshots",
    "tags",
    "cache",
)

_DEFAULT_CONFIG = """\
[user]
name = ""
email = ""

[remotes]

[domain]
# Domain-specific configuration keys depend on the active domain.
"""

class _CloneJson(EnvelopeJson):
    """Stable JSON schema emitted by ``muse clone --json``."""

    status: str           # "cloned" | "dry_run" | "already_exists" | "partial"
    url: str
    directory: str        # resolved local path
    branch: str           # branch checked out
    commits_received: int
    blobs_written: int
    skipped_blobs: int  # blobs skipped due to integrity failure (0 on clean clone)
    head: str | None      # HEAD commit ID after clone, null on dry-run
    domain: str
    dry_run: bool
    shallow_commits: list[str]

class _CloneErrorJson(EnvelopeJson):
    """JSON output for clone transport/network error paths."""

    error: str       # "remote_unreachable" | "empty_repository" | "fetch_failed"
    url: str
    message: str
    retryable: bool  # True when error is a 503 that exhausted the retry budget

def _infer_dir_name(url: str) -> str:
    """Derive a safe local directory name from the last non-empty segment of *url*.

    Strips query strings, fragments, and path-traversal components so that a
    crafted URL like ``http://attacker.example.com/../../../../etc`` cannot escape
    the current working directory.
    """
    # Drop fragment and query before splitting on path separators.
    stripped = url.split("#")[0].split("?")[0].rstrip("/")
    last = stripped.rsplit("/", 1)[-1]
    # pathlib.Path.name always strips leading dots and directory separators,
    # eliminating traversal attempts like ".." or "../../secret".
    safe = pathlib.PurePosixPath(last).name
    return safe if safe and safe not in (".", "..") else "muse-repo"

def _init_muse_dir(
    target: pathlib.Path,
    repo_id: str,
    domain: str,
    default_branch: str,
) -> None:
    """Create the ``.muse/`` directory tree inside *target*.

    Uses the same subdirectory set as ``muse init`` so that every command that
    relies on the standard layout (tags, objects, etc.) works out of the box.
    """
    muse_dir = _muse_dir(target)
    for subdir in _CLONE_SUBDIRS:
        (muse_dir / subdir).mkdir(parents=True, exist_ok=True)

    repo_meta: _RepoMeta = {
        "repo_id": repo_id,
        "schema_version": _SCHEMA_VERSION,
        "created_at": now_utc_iso(),
        "domain": domain,
    }
    write_text_atomic(muse_dir / "repo.json", f"{json.dumps(repo_meta)}\n")
    write_head_branch(muse_dir.parent, default_branch)
    write_text_atomic(_ref_path(target, default_branch), "")
    write_text_atomic(muse_dir / "config.toml", _DEFAULT_CONFIG)

def _restore_working_tree(root: pathlib.Path, commit_id: str) -> None:
    """Restore the working tree to the snapshot referenced by *commit_id*.

    Logs a warning to stderr (rather than silently returning) if the commit or
    snapshot cannot be read — this surfaces bugs where apply_mpack did not write
    the expected objects.
    """
    commit = read_commit(root, commit_id)
    if commit is None:
        logger.warning(
            "⚠️ clone: commit %s not found after apply_mpack — working tree not restored",
            commit_id,
        )
        return
    snap = read_snapshot(root, commit.snapshot_id)
    if snap is None:
        logger.warning(
            "⚠️ clone: snapshot %s not found after apply_mpack — working tree not restored",
            commit.snapshot_id,
        )
        return
    try:
        apply_manifest(root, {}, snap.manifest)
    except RuntimeError as exc:
        logger.warning(
            "⚠️ clone: working tree partially restored — %s",
            exc,
        )

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse clone`` subcommand and all its flags."""
    parser = subparsers.add_parser(
        "clone",
        help="Create a local copy of a remote Muse repository.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "url",
        help="URL of the remote Muse repository to clone.",
    )
    parser.add_argument(
        "directory",
        nargs="?",
        default=None,
        help=(
            "Local directory to clone into. "
            "Defaults to the last path segment of the URL."
        ),
    )
    parser.add_argument(
        "--branch", "-b",
        default=None,
        help="Branch to check out after cloning (default: remote default branch).",
    )
    parser.add_argument(
        "--dry-run", "-n",
        action="store_true",
        default=False,
        dest="dry_run",
        help=(
            "Contact the remote and show what would be cloned without writing "
            "any files or creating any directories."
        ),
    )
    parser.add_argument(
        "--no-checkout",
        action="store_true",
        default=False,
        dest="no_checkout",
        help="Skip restoring the working tree after cloning.",
    )
    parser.add_argument(
        "--depth",
        type=int,
        default=None,
        metavar="N",
        help=(
            "Shallow clone: fetch only the N most recent commits from each branch tip. "
            "Writes .muse/shallow with the boundary commit IDs. "
            "Must be >= 1."
        ),
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit JSON output to stdout.",
    )
    parser.add_argument(
        "--retry-timeout",
        type=float,
        default=None,
        dest="retry_budget_s",
        metavar="SECONDS",
        help=(
            "Maximum seconds to wait for the remote to finish preparing fetch data "
            "(503 Retry-After loop). Default: 120 s or MUSE_FETCH_RETRY_BUDGET_S env."
        ),
    )
    parser.add_argument(
        "--no-retry",
        action="store_const",
        const=0.0,
        dest="retry_budget_s",
        help=(
            "Disable the 503 retry loop — fail immediately on the first 503 response. "
            "Useful for deterministic CI. Overrides --retry-timeout."
        ),
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Clone a remote Muse repository into a new local directory.

    Downloads the full commit history, snapshots, objects, and branch heads.
    Configures ``origin`` remote and upstream tracking.  Checks out the default
    branch unless ``--no-checkout`` is given.  On any error after the target
    directory has been partially created the directory is removed to leave the
    filesystem clean.

    Agent quickstart
    ----------------
    ::

        muse clone https://musehub.ai/gabriel/muse --json
        muse clone https://musehub.ai/gabriel/muse --branch dev --json
        muse clone https://musehub.ai/gabriel/muse mydir --dry-run --json

    JSON fields
    -----------
    status           ``"cloned"``, ``"already_exists"``, or ``"error"``.
    url              The remote URL cloned from.
    directory        Absolute path to the created local directory.
    branch           Branch checked out after cloning.
    commits_received Number of commits received.
    blobs_written    Number of content blobs written.
    head             Full commit ID at the branch tip; ``null`` on error.
    domain           Repository domain (e.g. ``"code"``).
    dry_run          ``true`` when ``--dry-run`` was passed.

    Exit codes
    ----------
    0  Clone completed successfully.
    1  Target already exists or bad URL.
    3  Network or internal error during fetch.
    """
    elapsed = start_timer()
    url: str = args.url
    directory: str | None = args.directory
    branch: str | None = args.branch
    dry_run: bool = args.dry_run
    no_checkout: bool = args.no_checkout
    json_out: bool = args.json_out
    depth: int | None = getattr(args, "depth", None)
    retry_budget_s: float | None = getattr(args, "retry_budget_s", None)

    if depth is not None and depth < 1:
        print("❌ --depth must be >= 1 (got 0)", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    # clone does not need to be inside a Muse repo — it creates a new one.
    # Resolve the target name and path before any network I/O.
    target_name = directory or _infer_dir_name(url)
    target = pathlib.Path.cwd() / target_name

    if dry_run:
        print("(dry run — no files will be created)", file=sys.stderr)

    if _muse_dir(target).exists():
        msg = f"❌ '{sanitize_display(str(target))}' is already a Muse repository."
        print(msg, file=sys.stderr)
        if json_out:
            print(json.dumps(_CloneJson(
                **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                status="already_exists",
                url=url,
                directory=str(target),
                branch=branch or "",
                commits_received=0,
                blobs_written=0,
                head=None,
                domain="",
                dry_run=dry_run,
                shallow_commits=[],
            )))
        raise SystemExit(ExitCode.USER_ERROR)

    signing = get_signing_identity(remote_url=url)

    transport = make_transport(url)

    print(
        f"Cloning from {sanitize_display(url)} …",
        file=sys.stderr,
    )
    try:
        info = transport.fetch_remote_info(url, signing=signing)
    except TransportError as exc:
        if json_out:
            print(json.dumps(_CloneErrorJson(
                **make_envelope(elapsed, exit_code=ExitCode.INTERNAL_ERROR),
                error="remote_unreachable",
                url=url,
                message=str(exc),
                retryable=False,
            )))
        print(f"❌ Cannot reach remote: {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    # Use "code" as the domain fallback — "midi" was the first plugin but is
    # not the canonical default domain for new repositories.
    if info["repo_id"]:
        remote_repo_id = info["repo_id"]
    else:
        _cloned_at = now_utc_iso()
        remote_repo_id = content_hash({"cloned_at": _cloned_at, "url": url})
    domain = info["domain"] or "code"
    default_branch = branch or info["default_branch"] or "main"

    if not info["branch_heads"]:
        if json_out:
            print(json.dumps(_CloneErrorJson(
                **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                error="empty_repository",
                url=url,
                message="remote repository has no branches",
                retryable=False,
            )))
        print(
            "❌ Remote repository has no branches (empty repository).",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    default_commit_id = info["branch_heads"].get(default_branch)
    if default_commit_id is None:
        # Fall back to the first available branch rather than failing hard —
        # a user who requests a non-existent branch gets a clear warning.
        first_branch, default_commit_id = next(iter(info["branch_heads"].items()))
        print(
            f"  ⚠️ Branch '{sanitize_display(default_branch)}' not found on remote; "
            f"checking out '{sanitize_display(first_branch)}' instead.",
            file=sys.stderr,
        )
        default_branch = first_branch

    available = sorted(info["branch_heads"])
    logger.debug(
        "Remote has %d branch(es): %s",
        len(available),
        ", ".join(sanitize_display(b) for b in available),
    )

    # ── dry-run exits here — no filesystem changes after this point ──────────
    if dry_run:
        want_count = len(info["branch_heads"])
        if json_out:
            print(json.dumps(_CloneJson(
                **make_envelope(elapsed),
                status="dry_run",
                url=url,
                directory=str(target),
                branch=default_branch,
                commits_received=0,
                blobs_written=0,
                head=default_commit_id,
                domain=domain,
                dry_run=True,
                shallow_commits=[],
            )))
        else:
            print(
                f"Would clone {sanitize_display(url)} → {sanitize_display(str(target))}",
                file=sys.stderr,
            )
            print(
                f"  branch={sanitize_display(default_branch)}, "
                f"domain={sanitize_display(domain)}, "
                f"{want_count} branch head(s) to fetch",
                file=sys.stderr,
            )
        return

    # ── real clone ────────────────────────────────────────────────────────────
    target.mkdir(parents=True, exist_ok=True)
    try:
        _init_muse_dir(target, remote_repo_id, domain, default_branch)
    except OSError as exc:
        print(
            f"❌ Failed to create repository at '{sanitize_display(str(target))}': {exc}",
            file=sys.stderr,
        )
        shutil.rmtree(target, ignore_errors=True)
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    # ── fetch/mpack ───────────────────────────────────────────────────────────
    # Clone always starts with an empty have list — no local history yet.
    want = list(info["branch_heads"].values())

    t0 = time.perf_counter()
    try:
        fetch_result = transport.fetch_mpack(
            url, signing,
            want=want,
            have=[],
            retry_budget_s=retry_budget_s,
        )
    except TransportError as exc:
        _is_503 = exc.status_code == 503
        if _is_503:
            from muse.core.transport import _resolve_retry_budget
            _budget = _resolve_retry_budget(retry_budget_s)
            _msg = (
                f"Remote still preparing clone data after {int(_budget)}s — try again shortly."
            )
        else:
            _msg = str(exc)
        if json_out:
            print(json.dumps(_CloneErrorJson(
                **make_envelope(elapsed, exit_code=ExitCode.INTERNAL_ERROR),
                error="fetch_failed",
                url=url,
                message=_msg,
                retryable=_is_503,
            )))
        print(f"❌ {_msg}", file=sys.stderr)
        shutil.rmtree(target, ignore_errors=True)
        raise SystemExit(ExitCode.INTERNAL_ERROR)
    t_fetch = time.perf_counter() - t0

    fetched_shallow: list[str] = fetch_result.get("shallow_commits") or []
    _raw_blobs = fetch_result.get("blobs") or []
    _t_apply0 = time.perf_counter()
    print(f"[clone] apply_mpack START  blobs={len(_raw_blobs)} commits={len(fetch_result['commits'])} snaps={len(fetch_result['snapshots'])}", file=sys.stderr, flush=True)
    apply_result: ApplyResult = apply_mpack(
        target,
        {
            "commits":   fetch_result["commits"],
            "snapshots": fetch_result["snapshots"],
            "blobs":     _raw_blobs,
        },
        shallow_commits=set(fetched_shallow),
    )
    _t_apply1 = time.perf_counter()
    blobs_written: int = apply_result["blobs_written"]
    blobs_skipped: int = apply_result["blobs_skipped"]
    print(
        f"[clone] apply_mpack DONE  t={int((_t_apply1-_t_apply0)*1000)}ms"
        f"  blobs_written={blobs_written} blobs_skipped={blobs_skipped}"
        f"  commits_written={apply_result['commits_written']}",
        file=sys.stderr, flush=True,
    )
    print(
        f"[mpack] fetch/mpack: {t_fetch:.2f}s  "
        f"blobs: {fetch_result['blobs_received']}  "
        f"commits: {apply_result['commits_written']}",
        file=sys.stderr,
    )

    # Write branch head refs for every remote branch atomically and record
    # the remote tracking pointer so future fetches can detect staleness.
    # Only advance refs for branches whose tip commit landed cleanly.
    failed = set(apply_result.get("failed_blobs") or [])
    for b, cid in info["branch_heads"].items():
        write_branch_ref(target, b, cid)
        set_remote_head("origin", b, cid, target)

    # Configure origin remote and upstream tracking.
    set_remote("origin", url, target)
    set_upstream(default_branch, "origin", target)

    # Write .muse/shallow for shallow clones so future pull/fetch can recognise boundary.
    if fetched_shallow:
        shallow_path = _muse_dir(target) / "shallow"
        write_text_atomic(shallow_path, "\n".join(fetched_shallow) + "\n")

    # Restore working tree unless the caller opted out.
    if not no_checkout:
        _t_wt0 = time.perf_counter()
        print(f"[clone] apply_manifest START  (working tree restore)", file=sys.stderr, flush=True)
        _restore_working_tree(target, default_commit_id)
        _t_wt1 = time.perf_counter()
        print(f"[clone] apply_manifest DONE  t={int((_t_wt1-_t_wt0)*1000)}ms", file=sys.stderr, flush=True)

        # musehub#192 Phase 4: a fresh clone can never have hooks installed
        # yet (install state is deliberately local-only, never cloned) — so
        # if the repo declares any, surface it immediately rather than
        # leaving it to be discovered only when muse commit later warns.
        notice = install_notice(target)
        if notice:
            print(f"ℹ️  {notice}", file=sys.stderr)

    commits_received = apply_result["commits_written"]
    blobs_failed = len(failed)
    total_skipped = blobs_skipped + blobs_failed
    exit_code = ExitCode.PARTIAL if total_skipped > 0 else ExitCode.SUCCESS

    if json_out:
        print(json.dumps(_CloneJson(
            **make_envelope(elapsed, exit_code=exit_code),
            status="partial" if total_skipped > 0 else "cloned",
            url=url,
            directory=str(target),
            branch=default_branch,
            commits_received=commits_received,
            blobs_written=blobs_written,
            skipped_blobs=total_skipped,
            head=default_commit_id,
            domain=domain,
            dry_run=False,
            shallow_commits=fetched_shallow,
        )))
    else:
        if total_skipped > 0:
            print(
                f"⚠️  Cloned into '{sanitize_display(target_name)}' with {total_skipped} skipped blob(s) — "
                f"{commits_received} commit(s), {blobs_written} blob(s) written, "
                f"domain={sanitize_display(domain)}, "
                f"branch={sanitize_display(default_branch)} ({default_commit_id})",
                file=sys.stderr,
            )
        else:
            print(
                f"✅ Cloned into '{sanitize_display(target_name)}' — "
                f"{commits_received} commit(s), {blobs_written} blob(s), "
                f"domain={sanitize_display(domain)}, "
                f"branch={sanitize_display(default_branch)} ({default_commit_id})",
                file=sys.stderr,
            )

    logger.info(
        "✅ clone: %s → %s  commits=%d blobs=%d skipped=%d",
        url, target, commits_received, blobs_written, total_skipped,
    )

    if exit_code != ExitCode.SUCCESS:
        raise SystemExit(exit_code)
