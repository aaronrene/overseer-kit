"""``muse label`` — attach and query label annotations on commits.

Labels are arbitrary ``namespace:value`` strings (convention, not enforced) that
annotate commits with machine-readable metadata.  All label operations are
idempotent by default: adding the same label twice to the same commit is a
no-op (use ``--allow-duplicate`` to bypass).

Usage::

    muse label add <label> [<ref>]              — label a commit (HEAD if omitted)
    muse label add <label> [<ref>] --dry-run    — preview without writing
    muse label list [<ref>]                     — list labels (all or per-commit)
    muse label list --match "emotion:*"         — filter by glob pattern
    muse label list --sort created              — sort by creation time
    muse label remove <label> [<ref>]           — remove matching labels from a commit

Label conventions (not enforced)::

    emotion:*     — emotional character (emotion:melancholic, emotion:tense)
    section:*     — song section (section:verse, section:chorus)
    stage:*       — production stage (stage:rough-mix, stage:master)
    key:*         — musical key (key:Am, key:Eb)
    tempo:*       — tempo annotation (tempo:120bpm)
    ref:*         — reference track (ref:beatles)

JSON output (``--format json`` / ``--json``) schema for ``label add``::

    {
      "status":     "labelled | already_labelled | dry_run",
      "label_id":   "<sha256:...> | null",
      "commit_id":  "<sha256:...>",
      "label":      "<label_string>",
      "namespace":  "<prefix before ':' | null>",
      "created_at": "<iso8601> | null",
      "dry_run":    false,
      "duration_ms": 1.234,
      "exit_code":  0
    }

Exit codes::

    0 — success
    1 — commit not found, label not found, invalid label name, invalid format
    2 — not inside a Muse repository
"""

import argparse
import datetime
import fnmatch
import json
import logging
import os
import re
import sys
from typing import TypedDict

from muse.core.types import JsonValue, blob_id
from muse.core.errors import ExitCode
from muse.core.repo import read_repo_id, require_repo
from muse.core.refs import read_current_branch
from muse.core.commits import resolve_commit_ref
from muse.core.tags import (
    TagRecord,
    compute_tag_id,
    delete_tag,
    get_all_tags,
    get_tags_for_commit,
    write_tag,
)
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.validation import sanitize_display
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

_MAX_LABEL_LEN: int = 256
_LABEL_FORBIDDEN_RE: re.Pattern[str] = re.compile(r"[\x00-\x1f\x7f]")


class _LabelEntryJson(TypedDict):
    label_id: str
    commit_id: str
    label: str
    namespace: str | None
    created_at: str


class _LabelAddJson(EnvelopeJson):
    status: str
    label_id: str | None
    commit_id: str
    label: str
    namespace: str | None
    created_at: str | None
    dry_run: bool


class _LabelListJson(EnvelopeJson):
    total: int
    labels: list[_LabelEntryJson]


class _LabelRemoveJson(EnvelopeJson):
    status: str
    removed_count: int
    label_ids: list[str]
    commit_id: str
    label: str


def _label_namespace(label: str) -> str | None:
    return label.split(":", 1)[0] if ":" in label else None


def _validate_label_name(name: str) -> str:
    if not name:
        raise ValueError("Label name must not be empty.")
    if len(name) > _MAX_LABEL_LEN:
        raise ValueError(
            f"Label name too long ({len(name)} chars); maximum is {_MAX_LABEL_LEN}."
        )
    if _LABEL_FORBIDDEN_RE.search(name):
        raise ValueError(
            "Label name contains forbidden control characters "
            "(use printable ASCII/Unicode only)."
        )
    return name


def _label_to_json(t: TagRecord) -> _LabelEntryJson:
    return _LabelEntryJson(
        label_id=t.tag_id,
        commit_id=t.commit_id,
        label=t.tag,
        namespace=_label_namespace(t.tag),
        created_at=t.created_at.isoformat(),
    )


def _sort_labels(tags: list[TagRecord], sort_key: str) -> list[TagRecord]:
    if sort_key == "created":
        return sorted(tags, key=lambda t: t.created_at)
    if sort_key == "commit":
        return sorted(tags, key=lambda t: t.commit_id)
    return sorted(tags, key=lambda t: (t.tag, t.commit_id))


def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse label`` subcommand tree."""
    parser = subparsers.add_parser(
        "label",
        help="Attach and query label annotations on commits.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subs = parser.add_subparsers(dest="subcommand", metavar="SUBCOMMAND")
    subs.required = True

    # -- add ------------------------------------------------------------------
    add_p = subs.add_parser(
        "add",
        help="Attach a label annotation to a commit.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    add_p.add_argument("label_name", help="Label string (e.g. emotion:joyful).")
    add_p.add_argument(
        "ref", nargs="?", default=None,
        help="Commit ID or branch name (default: HEAD).",
    )
    add_p.add_argument(
        "--allow-duplicate", action="store_true",
        help="Allow adding the same label twice to the same commit.",
    )
    add_p.add_argument(
        "-n", "--dry-run", action="store_true",
        help="Validate and preview without writing any data.",
    )
    add_p.add_argument("--json", "-j", action="store_true", dest="json_out",
                       help="Emit machine-readable JSON on stdout.")
    add_p.set_defaults(func=run_add, json_out=False)

    # -- list -----------------------------------------------------------------
    list_p = subs.add_parser(
        "list",
        help="List label annotations.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    list_p.add_argument(
        "ref", nargs="?", default=None,
        help="Commit ID or branch name to list labels for (default: all commits).",
    )
    list_p.add_argument(
        "--match", "-m", default=None, dest="match",
        help="Filter by glob pattern (e.g. 'emotion:*', '*:joyful').",
    )
    list_p.add_argument(
        "--sort", choices=["label", "created", "commit"], default="label",
        help="Sort order: label (default), created, commit.",
    )
    list_p.add_argument("--json", "-j", action="store_true", dest="json_out",
                        help="Emit machine-readable JSON on stdout.")
    list_p.set_defaults(func=run_list, json_out=False)

    # -- remove ---------------------------------------------------------------
    remove_p = subs.add_parser(
        "remove",
        help="Remove a label annotation from a commit.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    remove_p.add_argument("label_name", help="Label string to remove (e.g. emotion:joyful).")
    remove_p.add_argument(
        "ref", nargs="?", default=None,
        help="Commit ID or branch name (default: HEAD).",
    )
    remove_p.add_argument("--json", "-j", action="store_true", dest="json_out",
                          help="Emit machine-readable JSON on stdout.")
    remove_p.set_defaults(func=run_remove, json_out=False)


def run_add(args: argparse.Namespace) -> None:
    """Attach a label annotation to a commit."""
    elapsed = start_timer()

    label_name: str = args.label_name
    ref: str | None = args.ref
    json_out: bool = args.json_out
    dry_run: bool = args.dry_run
    allow_duplicate: bool = args.allow_duplicate

    def _emit_error(msg: str, code: int, error_key: str = "error", **extra: JsonValue) -> None:
        if json_out:
            payload = {
                **make_envelope(elapsed, exit_code=code),
                "error": error_key,
                "message": msg,
            }
            payload.update(extra)
            print(json.dumps(payload))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(code)

    try:
        _validate_label_name(label_name)
    except ValueError as exc:
        _emit_error(
            f"Invalid label name: {sanitize_display(str(exc))}",
            ExitCode.USER_ERROR,
            "invalid_label_name",
        )

    root = require_repo()
    repo_id = read_repo_id(root)
    branch = read_current_branch(root)

    commit = resolve_commit_ref(root, branch, ref)
    if commit is None:
        _emit_error(
            f"Commit '{sanitize_display(str(ref))}' not found.",
            ExitCode.USER_ERROR,
            "commit_not_found",
            ref=str(ref),
        )

    namespace = _label_namespace(label_name)

    if dry_run:
        if json_out:
            print(json.dumps(_LabelAddJson(
                **make_envelope(elapsed),
                status="dry_run",
                label_id=None,
                commit_id=commit.commit_id,
                label=label_name,
                namespace=namespace,
                created_at=None,
                dry_run=True,
            )))
        else:
            print(
                f"Would label {commit.commit_id} with '{sanitize_display(label_name)}'"
                " (dry run — nothing written)"
            )
        return

    if not allow_duplicate:
        existing = get_tags_for_commit(root, repo_id, commit.commit_id)
        if any(t.tag == label_name for t in existing):
            if json_out:
                existing_tag = next(t for t in existing if t.tag == label_name)
                print(json.dumps(_LabelAddJson(
                    **make_envelope(elapsed),
                    status="already_labelled",
                    label_id=existing_tag.tag_id,
                    commit_id=commit.commit_id,
                    label=label_name,
                    namespace=namespace,
                    created_at=existing_tag.created_at.isoformat(),
                    dry_run=False,
                )))
            else:
                print(
                    f"Label '{sanitize_display(label_name)}' already on "
                    f"{commit.commit_id} — skipped."
                )
            return

    if allow_duplicate:
        label_id = blob_id(os.urandom(32))
    else:
        label_id = compute_tag_id(repo_id=repo_id, commit_id=commit.commit_id, tag=label_name)
    created_at = datetime.datetime.now(datetime.timezone.utc)
    write_tag(root, TagRecord(
        tag_id=label_id,
        repo_id=repo_id,
        commit_id=commit.commit_id,
        tag=label_name,
        created_at=created_at,
    ))

    if json_out:
        print(json.dumps(_LabelAddJson(
            **make_envelope(elapsed),
            status="labelled",
            label_id=label_id,
            commit_id=commit.commit_id,
            label=label_name,
            namespace=namespace,
            created_at=created_at.isoformat(),
            dry_run=False,
        )))
    else:
        print(f"Labelled {commit.commit_id} with '{sanitize_display(label_name)}'")


def run_list(args: argparse.Namespace) -> None:
    """List label annotations, optionally filtered by commit or glob pattern."""
    elapsed = start_timer()

    ref: str | None = args.ref
    json_out: bool = args.json_out
    match_pattern: str | None = args.match
    sort_key: str = args.sort

    def _emit_error(msg: str, code: int, error_key: str = "error", **extra: JsonValue) -> None:
        if json_out:
            payload = {
                **make_envelope(elapsed, exit_code=code),
                "error": error_key,
                "message": msg,
            }
            payload.update(extra)
            print(json.dumps(payload))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(code)

    root = require_repo()
    repo_id = read_repo_id(root)
    branch = read_current_branch(root)

    if ref:
        commit = resolve_commit_ref(root, branch, ref)
        if commit is None:
            _emit_error(
                f"Commit '{sanitize_display(str(ref))}' not found.",
                ExitCode.USER_ERROR,
                "commit_not_found",
                ref=str(ref),
            )
        tags = get_tags_for_commit(root, repo_id, commit.commit_id)
    else:
        tags = get_all_tags(root, repo_id)

    if match_pattern:
        tags = [t for t in tags if fnmatch.fnmatch(t.tag, match_pattern)]

    tags = _sort_labels(tags, sort_key)

    if json_out:
        print(json.dumps(_LabelListJson(
            **make_envelope(elapsed),
            total=len(tags),
            labels=[_label_to_json(t) for t in tags],
        )))
        return

    if not tags:
        print("No labels.")
        return
    for t in tags:
        print(f"{t.commit_id}  {sanitize_display(t.tag)}")


def run_remove(args: argparse.Namespace) -> None:
    """Remove all matching label annotations from a commit."""
    elapsed = start_timer()

    label_name: str = args.label_name
    ref: str | None = args.ref
    json_out: bool = args.json_out

    def _emit_error(msg: str, code: int, error_key: str = "error", **extra: JsonValue) -> None:
        if json_out:
            payload = {
                **make_envelope(elapsed, exit_code=code),
                "error": error_key,
                "message": msg,
            }
            payload.update(extra)
            print(json.dumps(payload))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(code)

    try:
        _validate_label_name(label_name)
    except ValueError as exc:
        _emit_error(
            f"Invalid label name: {sanitize_display(str(exc))}",
            ExitCode.USER_ERROR,
            "invalid_label_name",
        )

    root = require_repo()
    repo_id = read_repo_id(root)
    branch = read_current_branch(root)

    commit = resolve_commit_ref(root, branch, ref)
    if commit is None:
        _emit_error(
            f"Commit '{sanitize_display(str(ref))}' not found.",
            ExitCode.USER_ERROR,
            "commit_not_found",
            ref=str(ref),
        )

    tags = get_tags_for_commit(root, repo_id, commit.commit_id)
    matching = [t for t in tags if t.tag == label_name]

    if not matching:
        if json_out:
            print(json.dumps(_LabelRemoveJson(
                **make_envelope(elapsed),
                status="not_found",
                removed_count=0,
                label_ids=[],
                commit_id=commit.commit_id,
                label=label_name,
            )))
        else:
            print(
                f"Label '{sanitize_display(label_name)}' not found on "
                f"{commit.commit_id} — nothing removed."
            )
        return

    removed_ids: list[str] = []
    for t in matching:
        delete_tag(root, repo_id, t.tag_id)
        removed_ids.append(t.tag_id)

    if json_out:
        print(json.dumps(_LabelRemoveJson(
            **make_envelope(elapsed),
            status="removed",
            removed_count=len(matching),
            label_ids=removed_ids,
            commit_id=commit.commit_id,
            label=label_name,
        )))
    else:
        print(
            f"Removed {len(matching)} label(s) '{sanitize_display(label_name)}' "
            f"from {commit.commit_id}."
        )
