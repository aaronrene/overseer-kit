"""muse commit-graph — emit the commit DAG as JSON.

Walks the commit graph from a tip commit (defaulting to HEAD) and emits
every reachable commit as a JSON array of nodes, suitable for agent
consumption, visualization, and graph analysis.

New flags extend the original BFS walk:

- ``--count`` — emit only the integer count, not the full node list.
- ``--first-parent`` — follow only ``parent_commit_id``, ignoring merge parents.
  Produces a strict linear history.
- ``--ancestry-path`` — when used with ``--stop-at``, restricts output to
  commits that are on a *direct ancestry path* between the tip and the
  stop-at commit.  Commits that are reachable from the tip but not
  ancestors of ``--stop-at`` are excluded.

Output (JSON, default)::

    {
      "tip": "<sha256>",
      "count": 42,
      "truncated": false,
      "commits": [
        {
          "commit_id":          "<sha256>",
          "parent_commit_id":   "<sha256> | null",
          "parent2_commit_id":  null,
          "message":            "Add verse melody",
          "branch":             "main",
          "committed_at":       "2026-03-18T12:00:00+00:00",
          "snapshot_id":        "<sha256>",
          "author":             "gabriel",
          "agent_id":           "claude-code",
          "model_id":           "claude-sonnet-4-6",
          "sem_ver_bump":       "minor",
          "breaking_changes":   []
        },
        ...
      ],
      "duration_ms": 0.042,
      "exit_code": 0
    }

With ``--count``::

    {"tip": "<sha256>", "count": 42, "truncated": false,
     "duration_ms": 0.001, "exit_code": 0}

``agent_id`` / ``model_id``
    Provenance fields from ``muse commit --agent-id / --model-id``.
    Empty string when the commit was made without agent flags.
``sem_ver_bump``
    Semantic-version classification: ``"none"``, ``"patch"``, ``"minor"``,
    or ``"major"``.  Lets agents filter history for breaking or significant
    changes.
``duration_ms``
    Wall-clock time from argument parsing to output.
``exit_code``
    Mirrors the process exit code (always ``0`` in the success paths).

Output contract
---------------

- Exit 0: graph emitted.
- Exit 1: tip commit not found; ``--ancestry-path`` used without ``--stop-at``;
  unknown ``--format`` value.
"""

import argparse
import json
import logging
import pathlib
import sys
from typing import TypedDict

from muse.core.errors import ExitCode
from muse.core.graph import ancestor_ids, iter_ancestors
from muse.core.repo import require_repo
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import read_commit
from muse.core.timing import start_timer
from muse.core.envelope import EnvelopeJson, make_envelope

logger = logging.getLogger(__name__)

_DEFAULT_MAX = 10_000

class _CommitNode(TypedDict):
    commit_id: str
    parent_commit_id: str | None
    parent2_commit_id: str | None
    message: str
    branch: str
    committed_at: str
    snapshot_id: str
    author: str
    # Agent provenance — empty string when committed by a human without --agent-id.
    agent_id: str
    model_id: str
    sem_ver_bump: str      # "none" | "patch" | "minor" | "major"
    breaking_changes: list[str]

class _CommitGraphCountJson(EnvelopeJson):
    """JSON output for ``muse commit-graph --count-only``."""

    tip: str
    count: int
    truncated: bool

class _CommitGraphJson(EnvelopeJson):
    """JSON output for ``muse commit-graph --json``."""

    tip: str
    count: int
    truncated: bool
    commits: list[_CommitNode]

_ANCESTRY_PATH_MAX = 100_000  # hard ceiling for --ancestry-path BFS

def _ancestors_of(root: pathlib.Path, start: str) -> set[str]:
    """Return the set of all commit IDs reachable from *start* (inclusive).

    Capped at ``_ANCESTRY_PATH_MAX`` to prevent unbounded I/O on very large repos.
    """
    return ancestor_ids(root, start, max_commits=_ANCESTRY_PATH_MAX)

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the commit-graph subcommand."""
    parser = subparsers.add_parser(
        "commit-graph",
        help="Emit commit DAG as JSON.",
        description=__doc__,
    )
    parser.add_argument(
        "--tip",
        default=None,
        metavar="COMMIT_ID",
        help="Commit ID to start from (default: HEAD).",
    )
    parser.add_argument(
        "--stop-at",
        default=None,
        dest="stop_at",
        metavar="COMMIT_ID",
        help="Stop BFS at this commit ID (exclusive).",
    )
    parser.add_argument(
        "--max", "-n",
        type=int,
        default=_DEFAULT_MAX,
        dest="max_commits",
        metavar="N",
        help=f"Maximum commits to traverse (default: {_DEFAULT_MAX}).",
    )
    parser.add_argument(
        "--count", "-c",
        action="store_true",
        dest="count_only",
        help="Emit only the integer commit count, not the full node list.",
    )
    parser.add_argument(
        "--first-parent", "-1",
        action="store_true",
        dest="first_parent",
        help="Follow only first-parent links, producing a linear history.",
    )
    parser.add_argument(
        "--ancestry-path", "-a",
        action="store_true",
        dest="ancestry_path",
        help="With --stop-at: restrict output to commits on the direct ancestry path.",
    )
    parser.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Shorthand for --format json."
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Emit the commit DAG reachable from a tip commit.

    BFS-walks from the tip following ``parent_commit_id`` (and
    ``parent2_commit_id`` unless ``--first-parent``).  Use ``--stop-at`` to
    exclude a commit and its ancestors — useful for computing commits on a
    branch since it diverged from another.

    Agent quickstart
    ----------------
    ::

        muse commit-graph --json
        muse commit-graph --tip dev --stop-at main --json
        muse commit-graph --first-parent --count --json

    JSON fields
    -----------
    tip       Commit ID the walk started from.
    stop_at   Stop-at commit ID (``null`` if not given).
    total     Total number of commits in the result.
    truncated ``true`` if ``--max`` was reached before the full history.
    commits   List of commit objects: ``commit_id``, ``message``,
              ``committed_at``, ``parent_commit_id``, ``parent2_commit_id``.

    Exit codes
    ----------
    0  Walk complete.
    1  Invalid arguments or ancestry-path without stop-at.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    tip: str | None = args.tip
    stop_at: str | None = args.stop_at
    max_commits: int = args.max_commits
    count_only: bool = args.count_only
    first_parent: bool = args.first_parent
    ancestry_path: bool = args.ancestry_path
    if ancestry_path and stop_at is None:
        print(
            json.dumps({"error": "--ancestry-path requires --stop-at to be set."}),
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()

    if tip is None:
        branch = read_current_branch(root)
        tip = get_head_commit_id(root, branch)
        if tip is None:
            print(json.dumps({"error": "No commits on current branch."}), file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

    try:
        tip_record = read_commit(root, tip)
    except ValueError:
        tip_record = None
    if tip_record is None:
        print(json.dumps({"error": f"Tip commit not found: {tip}"}), file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    # For --ancestry-path, pre-compute ancestors of stop_at so we can filter.
    stop_ancestors: set[str] = set()
    if ancestry_path and stop_at is not None:
        stop_ancestors = _ancestors_of(root, stop_at)

    stop_set: set[str] = {stop_at} if stop_at else set()
    nodes: list[_CommitNode] = []

    for record in iter_ancestors(
        root, tip, first_parent_only=first_parent, exclude=stop_set, max_commits=max_commits
    ):
        # --ancestry-path: skip commits not on the path to stop_at.
        if ancestry_path and record.commit_id not in stop_ancestors and record.commit_id != tip:
            continue

        nodes.append(
            _CommitNode(
                commit_id=record.commit_id,
                parent_commit_id=record.parent_commit_id,
                parent2_commit_id=record.parent2_commit_id,
                message=record.message,
                branch=record.branch,
                committed_at=record.committed_at.isoformat(),
                snapshot_id=record.snapshot_id,
                author=record.author,
                agent_id=record.agent_id or "",
                model_id=record.model_id or "",
                sem_ver_bump=record.sem_ver_bump or "none",
                breaking_changes=list(record.breaking_changes or []),
            )
        )

    truncated = len(nodes) >= max_commits

    if count_only:
        print(json.dumps(_CommitGraphCountJson(
            **make_envelope(elapsed),
            tip=tip,
            count=len(nodes),
            truncated=truncated,
        )))
        return

    if not json_out:
        if truncated:
            print(
                f"# TRUNCATED at {max_commits:,} commits — "
                "pass --max-commits N to raise the cap"
            )
        for node in nodes:
            print(node["commit_id"])
        return

    print(json.dumps(_CommitGraphJson(
        **make_envelope(elapsed),
        tip=tip,
        count=len(nodes),
        truncated=len(nodes) >= max_commits,
        commits=nodes,
    )))
