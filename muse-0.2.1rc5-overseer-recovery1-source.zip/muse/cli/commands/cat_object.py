"""muse cat-object — read a stored object from the object store.

Reads the raw bytes of a content-addressed object and writes them to stdout.
Useful for inspecting stored blobs, verifying round-trips, or piping raw
content to other tools.

Single-object mode (default)
-----------------------------

With ``--format raw`` (default): bytes streamed directly to stdout at 64 KiB
at a time — no heap spike, no size ceiling.

With ``--format info`` / ``--json``: JSON metadata about the object (no
content emitted).

    {"object_id": "sha256:<hex>", "present": true, "size_bytes": 1234,
     "duration_ms": 0.001}

Add ``--inline`` to embed the full content in the JSON response as
base64-encoded ``content_b64`` — saves agents a second round-trip for small
objects::

    {"object_id": "sha256:<hex>", "present": true, "size_bytes": 5,
     "content_b64": "aGVsbG8=", "duration_ms": 0.001}

Object IDs
----------

All object IDs use the canonical ``sha256:<64 lowercase hex chars>`` form.
This matches the format produced by every other muse command (``muse log``,
``muse read``, ``muse status``, etc.).  Bare hex (without the ``sha256:``
prefix) is rejected.

Batch mode
----------

``--batch`` reads object IDs from stdin (one per line) and for each emits the
batch-protocol header followed by the raw content::

    <oid> blob <size>\\n
    <raw-content-bytes>\\n

For missing or invalid OIDs the output is::

    <oid> missing\\n

``--batch-check`` is the header-only variant — same protocol but no content
bytes are emitted.  Useful for bulk presence checks without reading blobs.

Batch mode is intended for agent pipelines and migration tools that need to
stream many objects efficiently from a single long-running process.  The OIDs
in stdin may be ``sha256:``-prefixed (as emitted by muse commands) or bare hex
— invalid forms are reported as ``missing``.

Output contract
---------------

- Exit 0: found — bytes written to stdout or metadata printed.
- Exit 1: not found in the store, or invalid object-id format.
- Exit 3: I/O error reading from the store.
- Batch mode always exits 0 (missing objects are reported inline, not as errors).

Agent use
---------

Prefer ``--json`` over ``--format raw`` when only metadata is needed::

    muse cat-object --json sha256:<oid>

For metadata + content in one call (small objects only)::

    muse cat-object --json --inline sha256:<oid>

For bulk presence checks::

    muse log --json | python3 -c "import sys,json; [print(c['commit_id']) for c in json.load(sys.stdin)['commits']]" \\
      | muse cat-object --batch-check

For bulk reads::

    printf '%s\\n' sha256:<oid1> sha256:<oid2> | muse cat-object --batch
"""

import argparse
import base64
import hashlib
import json
import logging
import pathlib
import sys
import time
from typing import TypedDict

from muse.core.types import long_id
from muse.core.errors import ExitCode
from muse.core.object_store import has_object, object_path, read_object
from muse.core.repo import require_repo
from muse.core.validation import sanitize_display, validate_object_id
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

_FORMAT_CHOICES = ("raw", "info")

class _CatObjectInfoJson(EnvelopeJson, total=False):
    """JSON output for ``muse cat-object --json`` (info format)."""

    object_id: str
    present: bool
    size_bytes: int
    content_b64: str  # only present with --inline
_CHUNK = 65536

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the cat-object subcommand."""
    parser = subparsers.add_parser(
        "cat-object",
        help="Emit raw bytes of a stored object to stdout.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "object_id",
        nargs="?",
        default=None,
        help=(
            "Object ID to read in sha256:<hex> form.  "
            "Required in single-object mode; omit when using --batch or --batch-check."
        ),
    )

    batch_group = parser.add_mutually_exclusive_group()
    batch_group.add_argument(
        "--batch",
        action="store_true",
        dest="batch",
        help=(
            "Batch mode: read object IDs from stdin (one per line) and emit "
            "'<oid> blob <size>\\n<content>\\n' for each.  "
            "Missing or invalid OIDs emit '<oid> missing\\n'."
        ),
    )
    batch_group.add_argument(
        "--batch-check",
        action="store_true",
        dest="batch_check",
        help=(
            "Batch-check mode: like --batch but emits only the header line "
            "'<oid> blob <size>\\n' — no content bytes.  "
            "Efficient for bulk presence checks."
        ),
    )

    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit JSON metadata instead of raw bytes.",
    )
    parser.add_argument(
        "--inline",
        action="store_true",
        default=False,
        help=(
            "When used with --json, embed the full object content as base64 in "
            "the 'content_b64' field.  Saves a second round-trip for small objects.  "
            "Requires --json."
        ),
    )
    parser.set_defaults(func=run)

def _run_batch(root: "pathlib.Path", check_only: bool) -> None:
    """Process OIDs from stdin in the git cat-file --batch protocol."""
    out = sys.stdout.buffer

    for raw_line in sys.stdin:
        oid = raw_line.strip()
        if not oid:
            continue

        # Validate format — invalid OIDs are reported as missing, not errors.
        try:
            validate_object_id(oid)
        except ValueError:
            out.write(f"{oid} missing\n".encode())
            out.flush()
            continue

        if not has_object(root, oid):
            out.write(f"{oid} missing\n".encode())
            out.flush()
            continue

        content = read_object(root, oid)
        if content is None:
            out.write(f"{oid} missing\n".encode())
            out.flush()
            continue
        size = len(content)
        out.write(f"{oid} blob {size}\n".encode())

        if not check_only:
            out.write(content)
            out.write(b"\n")

        out.flush()

def run(args: argparse.Namespace) -> None:
    """Read a raw object from the content-addressed object store by its ID.

    In single-object mode with ``--format raw`` (default) raw bytes are streamed
    to stdout in 64 KiB chunks — suitable for piping with no heap spike.  With
    ``--format info`` (or ``--json``) a metadata summary is printed instead.
    In batch mode (``--batch`` or ``--batch-check``) object IDs are read from
    stdin one per line, amortizing subprocess overhead for bulk lookups.

    Agent quickstart
    ----------------
    ::

        muse cat-object sha256:<64hex> --json
        muse cat-object sha256:<64hex> --json --inline
        echo "sha256:<64hex>" | muse cat-object --batch-check --json

    JSON fields
    -----------
    object_id    The full ``sha256:<64hex>`` object ID.
    present      ``true`` if the object exists in the store.
    size_bytes   Size of the stored object in bytes.
    content_b64  Base64-encoded raw bytes (only with ``--inline``).

    Exit codes
    ----------
    0  Object found and emitted.
    1  Object not found, invalid object ID, or invalid arguments.
    2  Not inside a Muse repository.
    3  I/O error or SHA-256 integrity check failure.
    """
    elapsed = start_timer()

    batch: bool = args.batch
    batch_check: bool = args.batch_check
    json_out: bool = args.json_out
    inline: bool = getattr(args, "inline", False)
    object_id: str | None = args.object_id

    # ── Batch mode ────────────────────────────────────────────────────────────
    if batch or batch_check:
        root = require_repo()
        _run_batch(root, check_only=batch_check)
        return

    # ── --inline requires --json ───────────────────────────────────────────────
    if inline and not json_out:
        print(
            "❌ --inline requires --json.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    # ── Single-object mode ────────────────────────────────────────────────────
    if object_id is None:
        print(
            "❌ object_id is required in single-object mode "
            "(or use --batch / --batch-check for stdin processing).",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    try:
        validate_object_id(object_id)
    except ValueError as exc:
        print(f"❌ Invalid object ID: {sanitize_display(str(exc))}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()

    try:
        content = read_object(root, object_id)
    except OSError as exc:
        print(
            f"❌ Failed to read object: {sanitize_display(str(exc))}",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    if content is None:
        if json_out:
            print(json.dumps(_CatObjectInfoJson(
                **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                object_id=object_id,
                present=False,
                size_bytes=0,
            )))
        else:
            print(f"❌ Object not found: {object_id}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    if json_out:
        out = _CatObjectInfoJson(
            **make_envelope(elapsed),
            object_id=object_id,
            present=True,
            size_bytes=len(content),
        )
        if inline:
            out["content_b64"] = base64.b64encode(content).decode()
        print(json.dumps(out))
        return

    sys.stdout.buffer.write(content)
