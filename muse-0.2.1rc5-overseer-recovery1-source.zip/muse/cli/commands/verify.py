"""``muse verify`` — whole-repository integrity check.

Walks every reachable commit from every branch ref and performs a five-tier
integrity check:

1. Every branch ref points to an existing, well-formed commit.
2. Every commit's snapshot exists.
3. Every object referenced by every snapshot exists, and (unless
   ``--no-objects``) its SHA-256 is recomputed to detect silent corruption.
4. For every commit that carries an Ed25519 signature, the signature is verified
   against the embedded ``signer_public_key``.
5. Missing public keys are reported separately as ``kind="key_missing"`` so
   agents can distinguish key-rotation events from genuine tamper detection
   (``kind="signature"``).

This is Muse's equivalent of ``git fsck``.  Run it periodically on long-lived
agent repositories or after recovering from a storage failure.

Usage::

    muse verify                       # full check — re-hashes all objects
    muse verify --no-objects          # existence check only (faster)
    muse verify --branch feat/x       # check one branch only
    muse verify --fail-fast           # stop on first failure (CI-friendly)
    muse verify --quiet               # no output — exit code only
    muse verify --json                # machine-readable report

JSON success schema::

    {
      "repo_id": "<str>",
      "refs_checked": <int>,
      "commits_checked": <int>,
      "snapshots_checked": <int>,
      "objects_checked": <int>,
      "signatures_checked": <int>,
      "all_ok": <bool>,
      "nothing_checked": <bool>,
      "check_objects": <bool>,
      "branch": "<str | null>",
      "fail_fast": <bool>,
      "duration_ms": <float>,
      "exit_code": <int>,
      "failures": [
        {
          "kind": "ref|commit|snapshot|object|signature|key_missing",
          "id": "<str>",
          "error": "<str>"
        }
      ]
    }

JSON error schema (when ``--json`` is active)::

    {"error": "<kind>", "message": "<str>", "duration_ms": <float>, "exit_code": <int>}

Exit codes::

    0 — all checks passed
    1 — one or more integrity failures detected
    3 — I/O error reading repository files
"""

import argparse
import json
import logging
import sys
from typing import TypedDict

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.repo import read_repo_id, require_repo
from muse.core.validation import sanitize_display
from muse.core.verify import VerifyFailure, VerifyResult, run_verify
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

class _VerifyJson(EnvelopeJson):
    """JSON wire format for ``muse verify --json`` on success."""

    repo_id: str
    refs_checked: int
    commits_checked: int
    snapshots_checked: int
    objects_checked: int
    signatures_checked: int
    shallow_commits: int
    promised_objects: int
    is_shallow: bool
    promisor_remotes: list[str]
    all_ok: bool
    nothing_checked: bool
    check_objects: bool
    strict: bool
    branch: str | None
    fail_fast: bool
    failures: list[VerifyFailure]

class _VerifyErrorJson(EnvelopeJson):
    """JSON wire format for ``muse verify --json`` on error."""

    error: str
    message: str

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the verify subcommand."""
    parser = subparsers.add_parser(
        "verify",
        help="Check repository integrity — commits, snapshots, and objects.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--quiet", "-q", action="store_true",
        help="No output — exit code only.",
    )
    parser.add_argument(
        "--no-objects", "-O", action="store_true", dest="no_objects",
        help="Existence check only — skip object re-hashing (faster).",
    )
    parser.add_argument(
        "--branch", "-b", metavar="BRANCH", default=None,
        help="Verify only the named branch instead of all branches.",
    )
    parser.add_argument(
        "--fail-fast", action="store_true", dest="fail_fast",
        help="Stop on the first failure (useful in CI pipelines).",
    )
    parser.add_argument(
        "--strict", action="store_true",
        help="Treat promised (remote-only) objects as failures — full deep integrity check.",
    )
    parser.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit a machine-readable JSON report on stdout.",
    )
    parser.set_defaults(func=run, json_out=False)

def run(args: argparse.Namespace) -> None:
    """Check repository integrity — commits, snapshots, objects, and signatures.

    Walks every reachable commit from every branch ref, verifying existence and
    content hash at each tier.  Failures with ``kind="key_missing"`` indicate a
    signer public key is absent (possible key rotation) and should not be treated
    as hard corruption.  I/O errors are emitted as JSON to stdout when ``--json``
    is active so agent pipelines never receive mixed-mode output.

    Agent quickstart::

        muse verify --json
        muse verify --no-objects --json     # fast existence-only check
        muse verify --branch feat/x --json  # one branch only
        muse verify --fail-fast --json      # abort on first failure
        muse verify --strict --json         # treat promised objects as failures

    JSON fields::

        repo_id           Repository identifier string.
        refs_checked      Number of branch refs checked.
        commits_checked   Number of commit records verified.
        snapshots_checked Number of snapshots verified.
        objects_checked   Number of content objects checked (re-hashed unless --no-objects).
        signatures_checked Number of Ed25519 signatures verified.
        shallow_commits   Number of shallow boundary grafts.
        promised_objects  Number of objects deferred to promisor remotes.
        is_shallow        true if the repo has any shallow grafts.
        promisor_remotes  List of remote names that hold promised objects.
        all_ok            true when every check passed.
        nothing_checked   true when no refs were found to check.
        check_objects     true unless --no-objects was passed.
        strict            true when --strict was passed.
        branch            Branch filter passed via --branch, or null.
        fail_fast         true when --fail-fast was passed.
        failures          List of {kind, id, error} failure records.
        muse_version      Muse release that produced this output.
        schema            Envelope schema version (int).
        exit_code         0 all ok, 1 failures found, 3 I/O error.
        duration_ms       Wall-clock milliseconds for the command.
        timestamp         ISO-8601 UTC timestamp of command completion.
        warnings          List of non-fatal advisory messages.

    Exit codes::

        0  All checks passed.
        1  One or more integrity failures detected.
        3  I/O error reading repository files.
    """
    elapsed = start_timer()

    quiet: bool = args.quiet
    no_objects: bool = args.no_objects
    json_out: bool = args.json_out
    branch: str | None = args.branch
    fail_fast: bool = args.fail_fast
    strict: bool = args.strict

    def _emit_error(msg: str, code: int, error_key: str = "error") -> None:
        if json_out:
            print(json.dumps({**make_envelope(elapsed, exit_code=code), "error": error_key, "message": msg}))
        elif not quiet:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(code)

    root = require_repo()

    try:
        result = run_verify(
            root,
            check_objects=not no_objects,
            branch=branch,
            fail_fast=fail_fast,
            strict=strict,
        )
    except OSError as exc:
        _emit_error(f"I/O error during verify: {exc}", ExitCode.INTERNAL_ERROR, "io_error")

    if quiet:
        raise SystemExit(0 if result["all_ok"] else ExitCode.USER_ERROR)

    exit_code = 0 if result["all_ok"] else int(ExitCode.USER_ERROR)

    if json_out:
        repo_id = read_repo_id(root) or ""
        print(json.dumps(_VerifyJson(
            **make_envelope(elapsed, exit_code=exit_code),
            repo_id=repo_id,
            refs_checked=result["refs_checked"],
            commits_checked=result["commits_checked"],
            snapshots_checked=result["snapshots_checked"],
            objects_checked=result["objects_checked"],
            signatures_checked=result["signatures_checked"],
            shallow_commits=result["shallow_commits"],
            promised_objects=result["promised_objects"],
            is_shallow=result["is_shallow"],
            promisor_remotes=result["promisor_remotes"],
            all_ok=result["all_ok"],
            nothing_checked=result["nothing_checked"],
            check_objects=not no_objects,
            strict=strict,
            branch=branch,
            fail_fast=fail_fast,
            failures=result["failures"],
        )))
    else:
        _print_text(result, no_objects=no_objects, branch=branch)

    raise SystemExit(exit_code)

def _print_text(
    result: VerifyResult,
    *,
    no_objects: bool,
    branch: str | None,
) -> None:
    """Render a human-readable summary of the verify result."""
    if branch:
        print(f"Scope:                  branch '{sanitize_display(branch)}'")
    print(f"Checking refs...        {result['refs_checked']:,} ref(s)")
    print(f"Checking commits...     {result['commits_checked']:,} commit(s)")
    if result["shallow_commits"]:
        print(f"  Shallow boundary:     {result['shallow_commits']:,} graft(s) — history stops here")
    print(f"Checking snapshots...   {result['snapshots_checked']:,} snapshot(s)")
    action = "existence only" if no_objects else "re-hashed"
    print(f"Checking objects...     {result['objects_checked']:,} object(s) [{action}]")
    if result["promised_objects"]:
        remotes = ", ".join(result["promisor_remotes"]) or "(none)"
        print(f"  Promised objects:     {result['promised_objects']:,} — on promisor remote(s): {remotes}")
    print(f"Checking signatures...  {result['signatures_checked']:,} signed commit(s)")

    if result["all_ok"]:
        print("✅ Repository is healthy.")
    else:
        failure_count = len(result["failures"])
        print(f"\n❌ {failure_count:,} integrity failure(s):")
        for f in result["failures"]:
            kind = sanitize_display(f["kind"])
            err = sanitize_display(f["error"])
            print(f"  {kind:<12} {f['id']}  {err}")
