"""muse attributes — query and display ``.museattributes`` merge-strategy rules.

Reads, validates, and pretty-prints the ``.museattributes`` file from the
current repository.  Supports tabular display, path-strategy resolution, and
file validation via three subcommands.

Subcommands
-----------

``muse attributes list``
    Pretty-print all rules in a table showing path pattern, dimension,
    strategy, priority, and comment.  Optionally filter by ``--strategy``
    or ``--dimension``.  This is the **default** when no subcommand is given.

``muse attributes check PATH [PATH ...]``
    Resolve the merge strategy for one or more workspace-relative paths,
    optionally filtered by dimension.  Use ``--match-required`` to exit 1
    when any path falls back to the default ``auto`` strategy.

``muse attributes validate``
    Validate the ``.museattributes`` file for TOML syntax errors, missing
    required fields, and unknown strategy values.

Security model
--------------
- All user-controlled values read from ``.museattributes`` (domain, path
  patterns, dimensions, strategies, comments) are passed through
  ``sanitize_display()`` before appearing in human-readable output.
- TOML parse errors and strategy validation errors are reported to **stderr**
  without printing a raw traceback.
- ``_parse_raw`` enforces a 1 MiB file-size cap, preventing OOM from a
  crafted or corrupted file.
- Null bytes in paths supplied to ``check`` are rejected with a clear error.

Agent UX
--------
Every subcommand accepts ``--json`` for machine-readable output on **stdout**.
All diagnostic and error messages go to **stderr** so that JSON consumers
never see noise on stdout.

JSON schemas
------------

``muse attributes list --json``::

    {
      "domain": "midi",          // always present; empty string when unset
      "rule_count": 1,           // total rules after filtering
      "rules": [
        {
          "path_pattern": "drums/*",
          "dimension": "*",
          "strategy": "ours",
          "comment": "Drums are always authored by branch A.",
          "priority": 10,
          "source_index": 0
        }
      ]
    }

``muse attributes check --json``::

    {
      "results": [
        {
          "path": "drums/kick.mid",
          "dimension": "*",
          "strategy": "ours",
          "rule_index": 0
        }
      ]
    }

``muse attributes validate --json``::

    {
      "valid": true,
      "rule_count": 3,
      "errors": []
    }

Exit codes
----------
- 0 — success
- 1 — user error (bad args, invalid strategy, TOML parse error, invalid path)
- 2 — not inside a Muse repository
"""

import argparse
import fnmatch
import json
import sys
from typing import TYPE_CHECKING, TypedDict

from muse.core.attributes import (
    AttributeRule,
    AttributesMeta,
    load_attributes_full,
)
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.timing import start_timer
from muse.core.validation import sanitize_display

# ---------------------------------------------------------------------------
# JSON TypedDicts — stable, machine-readable output schemas
# ---------------------------------------------------------------------------

class _RuleJson(TypedDict):
    """JSON representation of a single ``.museattributes`` rule."""

    path_pattern: str
    dimension: str
    strategy: str
    comment: str
    priority: int
    source_index: int

class _ListJson(EnvelopeJson):
    """JSON output of ``muse attributes list``.

    ``rule_count`` reflects the number of rules after any ``--strategy`` or
    ``--dimension`` filters have been applied — it equals ``len(rules)``.
    """

    domain: str
    rule_count: int
    rules: list[_RuleJson]

class _CheckResultJson(TypedDict):
    """JSON result for a single path resolution."""

    path: str
    dimension: str
    strategy: str
    rule_index: int  # -1 when no rule matched (default "auto")

class _CheckJson(EnvelopeJson):
    """JSON output of ``muse attributes check``."""

    results: list[_CheckResultJson]

class _ValidateErrorJson(TypedDict):
    """A single validation error entry."""

    kind: str   # "syntax" | "semantic" | "missing"
    message: str

class _ValidateJson(EnvelopeJson):
    """JSON output of ``muse attributes validate``.

    ``rule_count`` is the number of rules successfully parsed.  It is 0 when
    ``valid`` is ``false`` (parse failed before rules could be counted).
    """

    valid: bool
    rule_count: int
    errors: list[_ValidateErrorJson]

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _resolve_with_index(
    rules: list[AttributeRule],
    path: str,
    dimension: str,
) -> tuple[str, int]:
    """Return ``(strategy, rule.source_index)`` for *path* / *dimension*.

    Implements the same first-match semantics as :func:`resolve_strategy` but
    also returns which rule was matched so callers can explain the decision.
    Returns ``("auto", -1)`` when no rule matches.

    Args:
        rules:     Priority-sorted rule list from :func:`load_attributes_full`.
        path:      Workspace-relative POSIX path.
        dimension: Domain axis name or ``"*"`` to match any dimension.
    """
    for rule in rules:
        path_match = fnmatch.fnmatch(path, rule.path_pattern)
        dim_match = (
            rule.dimension == "*"
            or rule.dimension == dimension
            or dimension == "*"
        )
        if path_match and dim_match:
            return rule.strategy, rule.source_index
    return "auto", -1

def _rule_to_json(rule: AttributeRule) -> _RuleJson:
    """Convert an :class:`AttributeRule` to its JSON TypedDict form."""
    return _RuleJson(
        path_pattern=rule.path_pattern,
        dimension=rule.dimension,
        strategy=rule.strategy,
        comment=rule.comment,
        priority=rule.priority,
        source_index=rule.source_index,
    )

# ---------------------------------------------------------------------------
# Command registration
# ---------------------------------------------------------------------------

def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``attributes`` subcommand tree and all its flags.

    Every subcommand accepts ``--json`` for machine-readable output on stdout.
    All diagnostic messages go to stderr.
    """
    parser = subparsers.add_parser(
        "attributes",
        help="Query and display .museattributes merge-strategy rules.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subs = parser.add_subparsers(dest="subcommand", metavar="SUBCOMMAND")
    subs.required = True

    # ── check ─────────────────────────────────────────────────────────────
    check_p = subs.add_parser(
        "check",
        help="Resolve the merge strategy for one or more workspace-relative paths.",
        description=(
            "Apply ``.museattributes`` rule matching to one or more paths and\n"
            "print the resolved strategy for each.  Uses first-match semantics:\n"
            "rules are evaluated in descending priority order; the first rule\n"
            "whose path glob and dimension both match wins.\n\n"
            "``rule_index`` in the output identifies which ``[[rules]]`` entry\n"
            "matched (0-based source order); ``-1`` means no rule matched and\n"
            "the default ``auto`` strategy applies.  Use ``-d`` / ``--dimension``\n"
            "to filter by a specific domain axis.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse attributes check src/foo.py --json\n"
            "  muse attributes check src/foo.py -j\n"
            "  muse attributes check a.mid b.mid -d pitch_bend --json\n"
            "  muse attributes check src/foo.py --match-required  # exit 1 if no rule matched\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"results": [{"path": "<str>", "dimension": "<str>",\n'
            '                "strategy": "<str>", "rule_index": <int>}, ...]}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — all paths resolved (no-match defaults are still success)\n"
            "  1 — null byte in a path arg, TOML parse error, or unknown strategy\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    check_p.add_argument(
        "paths",
        nargs="+",
        metavar="PATH",
        help="Workspace-relative path(s) to resolve.",
    )
    check_p.add_argument(
        "--dimension",
        "-d",
        default="*",
        metavar="DIM",
        help="Domain dimension to match against (default: '*' matches any).",
    )
    check_p.add_argument(
        "--match-required",
        action="store_true",
        dest="match_required",
        default=False,
        help=(
            "Exit 1 if any path resolves to the default 'auto' strategy "
            "(i.e. no rule matched).  Useful in CI or agent scripts that "
            "require every path to have an explicit rule."
        ),
    )
    check_p.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        default=False,
        help="Emit a JSON object with a 'results' array to stdout.",
    )
    check_p.set_defaults(func=run_check)

    # ── list ──────────────────────────────────────────────────────────────
    list_p = subs.add_parser(
        "list",
        help="Pretty-print all rules (path pattern, dimension, strategy, priority, comment).",
        description=(
            "Parse ``.museattributes`` and display every rule as an aligned\n"
            "table showing path pattern, dimension, strategy, priority, and\n"
            "comment.  An optional priority column appears only when at least\n"
            "one rule has a non-zero priority.  A comment column appears only\n"
            "when at least one rule carries a comment.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse attributes list --json\n"
            "  muse attributes list -j\n"
            "  muse attributes list --strategy ours --json\n"
            "  muse attributes list --dimension notes --json\n"
            "  DOMAIN=$(muse attributes list --json | jq -r .domain)\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"domain": "<str>", "rule_count": <int>,\n'
            '   "rules": [{"path_pattern": "<glob>", "dimension": "<str>",\n'
            '              "strategy": "<str>", "comment": "<str>",\n'
            '              "priority": <int>, "source_index": <int>}, ...]}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — success (empty rules list is still success)\n"
            "  1 — TOML parse error or unknown strategy\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    list_p.add_argument(
        "--strategy", "-s",
        default=None,
        metavar="STRATEGY",
        help="Filter output to rules with this strategy value (e.g. ours, theirs).",
    )
    list_p.add_argument(
        "--dimension", "-d",
        default=None,
        metavar="DIM",
        help="Filter output to rules with this dimension value (e.g. notes, *).",
    )
    list_p.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        default=False,
        help="Emit a JSON object to stdout with domain, rule_count, and rules array.",
    )
    list_p.set_defaults(func=run_list)

    # ── validate ──────────────────────────────────────────────────────────
    validate_p = subs.add_parser(
        "validate",
        help="Validate .museattributes for TOML syntax and semantic correctness.",
        description=(
            "Parse ``.museattributes`` and check for TOML syntax errors,\n"
            "missing required rule fields, unknown strategy values, and the\n"
            "1 MiB file-size limit.  Exits 0 only when the file is fully\n"
            "valid; exits 1 for any validation failure.\n\n"
            "In text mode, prints a one-line summary with the rule count and\n"
            "domain on success, or an error message on failure.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse attributes validate --json\n"
            "  muse attributes validate -j\n"
            "  muse attributes validate --json | jq .valid\n"
            "  muse attributes validate --json | jq '.errors[].kind'\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"valid": <bool>,\n'
            '   "errors": [{"kind": "missing"|"syntax"|"semantic",\n'
            '               "message": "<str>"}, ...]}\n\n'
            "Error kinds\n"
            "-----------\n"
            '  "missing"  — .museattributes does not exist\n'
            '  "semantic" — TOML parsed but a rule field is invalid\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — file is valid\n"
            "  1 — file is missing, malformed, or contains unknown strategies\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    validate_p.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        default=False,
        help="Emit a JSON object with 'valid' and 'errors' fields to stdout.",
    )
    validate_p.set_defaults(func=run_validate)

# ---------------------------------------------------------------------------
# Subcommand handlers
# ---------------------------------------------------------------------------

def run_list(args: argparse.Namespace) -> None:
    """Display all ``.museattributes`` rules in tabular or JSON format.

    Parses the file, applies optional ``--strategy`` and ``--dimension`` filters,
    then prints an aligned table or JSON object.  An empty result after filtering
    is still exit 0.  All user-controlled values are sanitized before text output;
    raw values are preserved verbatim in JSON.

    Agent quickstart
    ----------------
    ::

        muse attributes list --json
        muse attributes list --strategy ours --json
        muse attributes list --dimension notes --json

    JSON fields
    -----------
    domain        Repository domain from the ``[meta]`` section; empty string if unset.
    rule_count    Total rules after filtering — equals ``len(rules)``.
    rules         List of rule objects sorted by descending priority.

    Each rule:

    path_pattern  Glob matched against workspace-relative POSIX paths.
    dimension     Domain axis name, or ``"*"`` for any.
    strategy      Merge strategy (e.g. ``"ours"``, ``"theirs"``, ``"auto"``).
    comment       Optional annotation from the file.
    priority      Integer priority; higher values take precedence.
    source_index  Zero-based declaration order in the file.

    Exit codes
    ----------
    0  Success (empty rule list is still success).
    1  TOML parse error or unknown strategy.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    filter_strategy: str | None = args.strategy
    filter_dimension: str | None = args.dimension

    root = require_repo()
    try:
        meta, rules = load_attributes_full(root)
    except ValueError as exc:
        print(f"❌  {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR.value) from exc

    # Apply optional filters.
    if filter_strategy is not None:
        rules = [r for r in rules if r.strategy == filter_strategy]
    if filter_dimension is not None:
        rules = [r for r in rules if r.dimension == filter_dimension]

    domain_raw: str = meta.get("domain") or ""

    if json_out:
        print(json.dumps(_ListJson(
            **make_envelope(elapsed),
            domain=domain_raw,
            rule_count=len(rules),
            rules=[_rule_to_json(r) for r in rules],
        )))
        return

    if not rules:
        attr_file = root / ".museattributes"
        if not attr_file.exists():
            print(
                "No .museattributes file found.",
                file=sys.stderr,
            )
        else:
            print(
                ".museattributes is present but contains no rules.",
                file=sys.stderr,
            )
        print(
            "Create one at the repository root to declare per-path merge strategies.",
            file=sys.stderr,
        )
        return

    if domain_raw:
        print(f"Domain: {sanitize_display(domain_raw)}")
        print()

    has_comments = any(r.comment for r in rules)
    has_nonzero_priority = any(r.priority != 0 for r in rules)

    pat_w = max(len("Path pattern"), max(len(r.path_pattern) for r in rules))
    dim_w = max(len("Dimension"), max(len(r.dimension) for r in rules))
    pri_w = max(len("Pri"), max(len(str(r.priority)) for r in rules))

    header_parts = [
        f"{'Path pattern':<{pat_w}}",
        f"{'Dimension':<{dim_w}}",
        f"{'Pri':>{pri_w}}",
        "Strategy",
    ]
    sep_parts = ["-" * pat_w, "-" * dim_w, "-" * pri_w, "--------"]
    if has_comments:
        header_parts.append("Comment")
        sep_parts.append("-------")

    print("  ".join(header_parts))
    print("  ".join(sep_parts))

    for rule in rules:
        pat = sanitize_display(rule.path_pattern)
        dim = sanitize_display(rule.dimension)
        strat = sanitize_display(rule.strategy)
        pri_str = str(rule.priority) if has_nonzero_priority else ""
        line_parts = [
            f"{pat:<{pat_w}}",
            f"{dim:<{dim_w}}",
            f"{pri_str:>{pri_w}}",
            strat,
        ]
        if has_comments:
            comment = sanitize_display(rule.comment)
            line_parts.append(comment)
        print("  ".join(line_parts))

def run_check(args: argparse.Namespace) -> None:
    """Resolve the merge strategy for each given path.

    Uses first-match rule semantics (same as the merge engine).  Returns
    ``rule_index`` (0-based declaration order) so results can be correlated back
    to ``muse attributes list`` output.  A ``rule_index`` of ``-1`` means no rule
    matched and the default ``"auto"`` strategy applies.

    Agent quickstart
    ----------------
    ::

        muse attributes check src/foo.py --json
        muse attributes check a.mid b.mid --dimension pitch_bend --json
        muse attributes check src/foo.py --match-required --json

    JSON fields
    -----------
    results       List of one result per input path, in argument order.

    Each result:

    path          Input path string (verbatim).
    dimension     Dimension used for resolution (echoed from ``-d``; default ``"*"``).
    strategy      Resolved strategy: ``"ours"``, ``"theirs"``, ``"auto"``, etc.
    rule_index    0-based source index of the matched rule; ``-1`` if no rule matched.

    Exit codes
    ----------
    0  All paths resolved (no-match defaults are still success).
    1  Null byte in path, TOML error, unknown strategy, or ``--match-required`` triggered.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    paths: list[str] = args.paths
    dimension: str = args.dimension
    match_required: bool = args.match_required

    root = require_repo()
    try:
        _, rules = load_attributes_full(root)
    except ValueError as exc:
        print(f"❌  {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR.value) from exc

    results: list[_CheckResultJson] = []
    for raw_path in paths:
        if "\x00" in raw_path:
            print(f"❌  null byte in path: {raw_path!r}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR.value)
        strategy, rule_idx = _resolve_with_index(rules, raw_path, dimension)
        results.append(
            _CheckResultJson(
                path=raw_path,
                dimension=dimension,
                strategy=strategy,
                rule_index=rule_idx,
            )
        )

    unmatched = [r for r in results if r["rule_index"] == -1]

    if json_out:
        print(json.dumps(_CheckJson(**make_envelope(elapsed), results=results)))
        if match_required and unmatched:
            for r in unmatched:
                print(
                    f"❌  no rule matched: {sanitize_display(r['path'])}",
                    file=sys.stderr,
                )
            raise SystemExit(ExitCode.USER_ERROR.value)
        return

    for item in results:
        path_disp = sanitize_display(item["path"])
        strat_disp = sanitize_display(item["strategy"])
        if item["rule_index"] >= 0:
            rule_note = f"  (rule #{item['rule_index']})"
        else:
            rule_note = "  (default)"
        print(f"{path_disp}: {strat_disp}{rule_note}")

    if match_required and unmatched:
        for r in unmatched:
            print(
                f"❌  no rule matched: {sanitize_display(r['path'])}",
                file=sys.stderr,
            )
        raise SystemExit(ExitCode.USER_ERROR.value)

def run_validate(args: argparse.Namespace) -> None:
    """Validate ``.museattributes`` for syntax and semantic correctness.

    Checks: file exists, TOML is valid and within 1 MiB, all rules carry
    required fields (``path``, ``dimension``, ``strategy``), and every strategy
    value is recognised.  Exits 0 only when all checks pass.

    Agent quickstart
    ----------------
    ::

        muse attributes validate --json
        muse attributes validate --json | python3 -c "import sys,json; print(json.load(sys.stdin)['valid'])"

    JSON fields
    -----------
    valid       ``true`` when all checks pass; ``false`` otherwise.
    rule_count  Number of rules parsed; ``0`` when ``valid`` is ``false``.
    errors      List of error objects (empty on success).

    Each error:

    kind        ``"missing"`` (file absent) or ``"semantic"`` (rule field invalid).
    message     Human-readable description of the error.

    Exit codes
    ----------
    0  File is valid.
    1  File missing, malformed, or contains unknown strategies.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out

    root = require_repo()
    attr_file = root / ".museattributes"

    errors: list[_ValidateErrorJson] = []

    if not attr_file.exists():
        errors.append(
            _ValidateErrorJson(
                kind="missing",
                message=".museattributes file does not exist",
            )
        )
        if json_out:
            print(json.dumps(_ValidateJson(**make_envelope(elapsed), valid=False, rule_count=0, errors=errors)))
        else:
            print("❌  .museattributes file does not exist.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR.value)

    try:
        meta, rules = load_attributes_full(root)
    except ValueError as exc:
        errors.append(_ValidateErrorJson(kind="semantic", message=str(exc)))
        if json_out:
            print(json.dumps(_ValidateJson(**make_envelope(elapsed), valid=False, rule_count=0, errors=errors)))
        else:
            print(f"❌  {errors[0]['message']}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR.value) from exc

    if json_out:
        print(json.dumps(_ValidateJson(**make_envelope(elapsed), valid=True, rule_count=len(rules), errors=[])))
        return

    domain_raw = meta.get("domain") or ""
    domain_disp = sanitize_display(domain_raw) if domain_raw else "(not set)"
    print(
        f"✅  .museattributes is valid — {len(rules)} rule(s), "
        f"domain: {domain_disp}"
    )
