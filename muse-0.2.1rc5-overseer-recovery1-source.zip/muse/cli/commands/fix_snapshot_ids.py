"""``muse code fix-snapshot-ids`` — unified-store snapshot-content-ID repair.

Standalone, explicitly-invoked repair tool for muse#83: a commit whose
declared ``snapshot_id`` never matched its own manifest, since creation.
Deliberately separate from ``muse code migrate`` — see
``muse.core.snapshot_content_migrate``'s module docstring and
``docs/issues/snapshot-content-id-migration-plan.md`` for why.

Usage::

    muse code fix-snapshot-ids --dry-run --json    # inspect, zero writes
    muse code fix-snapshot-ids --json               # execute (requires a
                                                      # signing identity —
                                                      # every rewritten
                                                      # commit is re-signed)

Output::

    {
      "snapshot_id_map":     {"sha256:<old>": "sha256:<new>", ...},
      "commit_id_map":       {"sha256:<old>": "sha256:<new>", ...},
      "snapshots_written":   <int>,
      "commits_written":     <int>,
      "commits_signed":      <int>,
      "refs_updated":        <int>,
      "remote_refs_updated": <int>,
      "reflogs_updated":     <int>,
      "dry_run":             true | false
    }
"""

import argparse
import json
import sys

from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.snapshot_content_migrate import migrate_snapshot_content_and_cascade


def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    parser = subparsers.add_parser(
        "fix-snapshot-ids",
        help="Repair commits whose declared snapshot_id never matched their manifest.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Print the id_maps and counts but make no writes (default: False).",
    )
    parser.add_argument(
        "--json", "-j",
        dest="json_out",
        action="store_true",
        default=False,
        help="Emit machine-readable JSON.",
    )
    parser.set_defaults(func=run)


def run(args: argparse.Namespace) -> None:
    json_out: bool = args.json_out
    dry_run: bool = args.dry_run

    root = require_repo()

    signing_identity = None
    from muse.cli.config import get_signing_identity, list_remotes
    signing_identity = get_signing_identity(repo_root=root)
    if signing_identity is None:
        for remote in list_remotes(repo_root=root):
            signing_identity = get_signing_identity(repo_root=root, remote_url=remote["url"])
            if signing_identity is not None:
                break

    if signing_identity is None:
        msg = (
            "No signing identity found. Every commit this tool rewrites is "
            "re-signed — run `muse auth keygen` or connect a hub with "
            "`muse hub connect` so credentials can be resolved."
        )
        if json_out:
            print(json.dumps({"error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    try:
        result = migrate_snapshot_content_and_cascade(
            root, signing_identity=signing_identity, dry_run=dry_run,
        )
    except OSError as exc:
        msg = f"I/O error during snapshot-content-ID repair: {exc}"
        if json_out:
            print(json.dumps({"error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    if json_out:
        print(json.dumps({
            "snapshot_id_map": result.snapshot_id_map,
            "commit_id_map": result.commit_id_map,
            "snapshots_written": result.snapshots_written,
            "commits_written": result.commits_written,
            "commits_signed": result.commits_signed,
            "refs_updated": result.refs_updated,
            "remote_refs_updated": result.remote_refs_updated,
            "reflogs_updated": result.reflogs_updated,
            "dry_run": result.dry_run,
        }))
        return

    prefix = "[dry-run] " if dry_run else ""
    print(f"{prefix}snapshots corrected: {len(result.snapshot_id_map)}")
    print(f"{prefix}commits rewritten:   {len(result.commit_id_map)}")
    print(f"{prefix}commits signed:      {result.commits_signed}")
    print(f"{prefix}refs updated:        {result.refs_updated}")
    print(f"{prefix}remote refs updated: {result.remote_refs_updated}")
    print(f"{prefix}reflogs updated:     {result.reflogs_updated}")
    if result.commit_id_map:
        print(f"\n{prefix}Commit ID map ({len(result.commit_id_map)} changed):")
        for old, new in result.commit_id_map.items():
            print(f"  {old} → {new}")
    else:
        print(f"\n{prefix}No commits needed rewriting.")
