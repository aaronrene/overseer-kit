"""``muse range-diff <base>..<old> <base>..<new>`` — compare two versions of a commit series.

Shows which commits changed, which are new, and which were dropped between
two versions of a patch series — typically before and after a rebase.

Pairing algorithm
-----------------
1. Compute a patch-id (SHA-256 of diff content lines) for every commit in both
   series using the same algorithm as ``muse patch-id``.
2. Exact patch-id matches are always paired as ``equivalent`` — the commits
   make identical logical changes regardless of commit ID or timestamp.
3. Remaining (unmatched) commits are paired positionally in series order when
   ``--creation-factor > 0.0``.  The creation factor controls aggressiveness:
   at ``1.0`` all remaining are paired; at ``0.0`` only exact matches are paired
   and all remaining are reported as ``dropped`` or ``added``.
4. Leftover old commits (no new partner) → ``dropped``.
   Leftover new commits (no old partner) → ``added``.

Output (text, default)::

    =  <old_short> <subject>         (equivalent)
    !  <old_short> → <new_short>     (changed)
    <  <old_short> <subject>         (dropped from new)
    >  <new_short> <subject>         (added in new)

JSON (``--json``)::

    {
      "old_range":            "base..old",
      "new_range":            "base..new",
      "trivially_equivalent": true,
      "old_count":            3,
      "new_count":            3,
      "stable":               false,
      "creation_factor":      0.6,
      "pairs": [
        {
          "old": {
            "commit_id":     "sha256:...",
            "patch_id":      "sha256:...",
            "subject":       "feat: add foo",
            "files_changed": 2
          },
          "new": {
            "commit_id":     "sha256:...",
            "patch_id":      "sha256:...",
            "subject":       "feat: add foo",
            "files_changed": 2
          },
          "status": "equivalent"
        }
      ],
      "duration_ms":  12.3,
      "exit_code":    0
    }

``old`` or ``new`` is ``null`` for ``dropped`` and ``added`` entries respectively.

Flags
-----
``--creation-factor N``
    Float 0.0–1.0. At ``0.6`` (default) remaining (non-exact-match) commits are
    paired positionally as ``changed``.  At ``0.0`` no fuzzy pairing is performed —
    unpaired commits are always ``dropped`` or ``added``.

``--stable``
    Strip trailing whitespace from diff lines before computing patch-ids
    (cosmetic whitespace changes are ignored).

``--json``
    Emit a single JSON object on stdout.

Exit codes::

    0 — series are trivially equivalent (all patch-ids match)
    1 — at least one commit differs, was dropped, or was added; or usage error
    2 — not a Muse repository
"""

import argparse
import hashlib
import json as _json
import logging
import pathlib
import re
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TypedDict

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.graph import ancestor_ids, iter_ancestors
from muse.core.object_store import read_object
from muse.core.repo import require_repo
from muse.core.refs import read_ref
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import read_commit
from muse.core.snapshots import read_snapshot
from muse.core.types import Manifest, blob_id, long_id, short_id
from muse.core.paths import ref_path as _ref_path
from muse.core.validation import sanitize_display
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Wire-format TypedDicts
# ---------------------------------------------------------------------------

class _CommitInfoDict(TypedDict):
    commit_id: str
    patch_id: str
    subject: str
    files_changed: int

class _PairDict(TypedDict, total=False):
    old: _CommitInfoDict | None
    new: _CommitInfoDict | None
    status: str
    _old_idx: int
    _new_idx: int

class _RangeDiffResultDict(TypedDict):
    old_range: str
    new_range: str
    trivially_equivalent: bool
    old_count: int
    new_count: int
    stable: bool
    creation_factor: float
    pairs: list[_PairDict]

class _RangeDiffJson(EnvelopeJson):
    """Stable JSON envelope for ``muse range-diff --json`` output."""
    old_range: str
    new_range: str
    trivially_equivalent: bool
    old_count: int
    new_count: int
    stable: bool
    creation_factor: float
    pairs: list[_PairDict]

# Safe ref characters: alphanumeric, underscore, slash, dot, hyphen, colon.
# The colon is required for ``sha256:``-prefixed commit IDs.
_SAFE_REF_RE = re.compile(r"^[a-zA-Z0-9_/.\-:]+$")
# Range pattern: allows '..' as separator in addition to safe ref chars.
_SAFE_RANGE_RE = re.compile(r"^[a-zA-Z0-9_/.\-:]+(\.\.)[a-zA-Z0-9_/.\-:]+$|^[a-zA-Z0-9_/.\-:]+$")

# ---------------------------------------------------------------------------
# Range parsing
# ---------------------------------------------------------------------------

def _parse_range(ref: str) -> tuple[str | None, str]:
    """Parse ``"base..tip"`` into ``(base, tip)``.

    Returns ``(None, ref)`` for plain refs without ``".."``.
    Leading/trailing whitespace around both parts is stripped.
    """
    if ".." in ref:
        parts = ref.split("..", 1)
        return parts[0].strip(), parts[1].strip()
    return None, ref.strip()

# ---------------------------------------------------------------------------
# Ref resolution
# ---------------------------------------------------------------------------

def _resolve_ref(root: pathlib.Path, treeish: str) -> str | None:
    """Resolve HEAD, a branch name, or a commit ID to a canonical commit ID.

    Accepts both bare 64-char hex and ``sha256:<64hex>`` commit IDs.
    Always returns the ``sha256:``-prefixed form or ``None`` if not found.
    """
    if treeish.upper() == "HEAD":
        try:
            branch = read_current_branch(root)
            return get_head_commit_id(root, branch)
        except Exception:
            return None

    # Accept both bare hex and sha256:-prefixed commit IDs.
    if re.fullmatch(r"sha256:[0-9a-f]{64}", treeish):
        full_id = treeish
    elif re.fullmatch(r"[0-9a-f]{64}", treeish):
        full_id = long_id(treeish)
    else:
        full_id = None
    if full_id is not None:
        if read_commit(root, full_id) is not None:
            return full_id
        return None

    ref_file = _ref_path(root, treeish)
    return read_ref(ref_file)

# ---------------------------------------------------------------------------
# Range walking
# ---------------------------------------------------------------------------

def _exclude_set(root: pathlib.Path, start_id: str | None) -> set[str]:
    """Return all commit IDs reachable from *start_id* (for range exclusion)."""
    if start_id is None:
        return set()
    return ancestor_ids(root, start_id)

def _walk_range(root: pathlib.Path, base_id: str | None, tip_id: str) -> list[str]:
    """Return commit IDs in ``base..tip``, oldest-first.

    Commits reachable from *base_id* are excluded.  When *base_id* equals
    *tip_id* the result is empty (empty range).
    """
    if base_id is not None and base_id == tip_id:
        return []

    exclude = _exclude_set(root, base_id)
    result = [
        c.commit_id
        for c in iter_ancestors(root, tip_id, first_parent_only=True, exclude=exclude)
    ]
    result.reverse()  # oldest-first
    return result

# ---------------------------------------------------------------------------
# Patch-id computation
# ---------------------------------------------------------------------------

def _compute_patch_id(
    root: pathlib.Path,
    base_manifest: Manifest,
    target_manifest: Manifest,
    *,
    stable: bool = False,
) -> tuple[str, int]:
    """Compute a patch-id and files_changed count from the diff between two manifests.

    Args:
        root:            Absolute repo root.
        base_manifest:   Parent commit manifest (path → object_id).
        target_manifest: This commit manifest (path → object_id).
        stable:          When True, strip trailing whitespace before hashing.

    Returns:
        Tuple of (patch_id, files_changed) where patch_id is a
        ``sha256:``-prefixed 64-char hex string and files_changed is the
        count of added + removed + modified files.
    """
    import difflib

    h = hashlib.sha256()
    base_paths = set(base_manifest)
    target_paths = set(target_manifest)
    changed = sorted(
        (target_paths - base_paths)
        | (base_paths - target_paths)
        | {p for p in base_paths & target_paths if base_manifest[p] != target_manifest[p]}
    )

    for path in changed:
        if path in base_manifest:
            raw = read_object(root, base_manifest[path])
            base_lines = raw.decode("utf-8", errors="replace").splitlines() if raw else []
        else:
            base_lines = []

        if path in target_manifest:
            raw = read_object(root, target_manifest[path])
            target_lines = raw.decode("utf-8", errors="replace").splitlines() if raw else []
        else:
            target_lines = []

        for line in difflib.unified_diff(
            base_lines, target_lines,
            fromfile=f"a/{path}", tofile=f"b/{path}",
            lineterm="",
        ):
            if line.startswith("+") or line.startswith("-"):
                if stable:
                    line = line.rstrip()
                h.update(line.encode("utf-8", errors="replace"))
                h.update(b"\n")

    return long_id(h.hexdigest()), len(changed)

def _patch_id_for_commit(
    root: pathlib.Path,
    commit_id: str,
    *,
    stable: bool,
) -> tuple[str, int]:
    """Compute the patch-id and files_changed for a single commit vs its first parent.

    Args:
        root:      Absolute repo root.
        commit_id: ``sha256:``-prefixed commit ID.
        stable:    Strip trailing whitespace before hashing when True.

    Returns:
        Tuple of (patch_id, files_changed).  ``patch_id`` is a
        ``sha256:``-prefixed hex string.  ``files_changed`` counts added +
        removed + modified files in this commit's diff vs its parent.
    """
    commit = read_commit(root, commit_id)
    if commit is None:
        return blob_id(commit_id.encode()), 0

    base_manifest: Manifest = {}
    if commit.parent_commit_id:
        parent = read_commit(root, commit.parent_commit_id)
        if parent:
            snap = read_snapshot(root, parent.snapshot_id)
            if snap:
                base_manifest = dict(snap.manifest)

    snap = read_snapshot(root, commit.snapshot_id)
    target_manifest = dict(snap.manifest) if snap else {}

    return _compute_patch_id(root, base_manifest, target_manifest, stable=stable)

def _commit_info(
    root: pathlib.Path,
    commit_id: str,
    patch_id: str,
    files_changed: int,
) -> _CommitInfoDict:
    """Build a commit info dict for JSON output.

    Args:
        root:          Absolute repo root.
        commit_id:     ``sha256:``-prefixed commit ID.
        patch_id:      ``sha256:``-prefixed patch-id.
        files_changed: Number of files added/removed/modified in this commit.

    Returns:
        Dict with ``commit_id``, ``patch_id``, ``subject``, ``files_changed``.
    """
    commit = read_commit(root, commit_id)
    subject = ""
    if commit and commit.message:
        subject = commit.message.splitlines()[0]
    return {
        "commit_id": commit_id,
        "patch_id": patch_id,
        "subject": subject,
        "files_changed": files_changed,
    }

# ---------------------------------------------------------------------------
# Pairing
# ---------------------------------------------------------------------------

def _pair_series(
    root: pathlib.Path,
    old_ids: list[str],
    new_ids: list[str],
    old_pids: dict[str, str],
    new_pids: dict[str, str],
    old_fcs: dict[str, int],
    new_fcs: dict[str, int],
    creation_factor: float,
) -> list[_PairDict]:
    """Pair old and new commit series into a list of pair dicts.

    Each pair has:
        old:    commit info dict or None (for "added")
        new:    commit info dict or None (for "dropped")
        status: "equivalent" | "changed" | "dropped" | "added"
    """
    # Build reverse maps: patch_id → commit_id
    old_by_pid: dict[str, str] = {v: k for k, v in old_pids.items()}
    new_by_pid: dict[str, str] = {v: k for k, v in new_pids.items()}

    used_old: set[str] = set()
    used_new: set[str] = set()
    pairs: list[_PairDict] = []

    # Pass 1: exact patch-id matches.
    for cid in old_ids:
        pid = old_pids[cid]
        if pid in new_by_pid:
            new_cid = new_by_pid[pid]
            if new_cid not in used_new:
                pairs.append({
                    "old": _commit_info(root, cid, pid, old_fcs.get(cid, 0)),
                    "new": _commit_info(root, new_cid, new_pids[new_cid], new_fcs.get(new_cid, 0)),
                    "status": "equivalent",
                    "_old_idx": old_ids.index(cid),
                    "_new_idx": new_ids.index(new_cid),
                })
                used_old.add(cid)
                used_new.add(new_cid)

    # Pass 2: positional pairing for unmatched commits (if creation_factor > 0).
    remaining_old = [c for c in old_ids if c not in used_old]
    remaining_new = [c for c in new_ids if c not in used_new]

    if creation_factor > 0.0:
        n_pairs = min(len(remaining_old), len(remaining_new))
        for i in range(n_pairs):
            old_cid = remaining_old[i]
            new_cid = remaining_new[i]
            pairs.append({
                "old": _commit_info(root, old_cid, old_pids[old_cid], old_fcs.get(old_cid, 0)),
                "new": _commit_info(root, new_cid, new_pids[new_cid], new_fcs.get(new_cid, 0)),
                "status": "changed",
                "_old_idx": old_ids.index(old_cid),
                "_new_idx": new_ids.index(new_cid),
            })
            used_old.add(old_cid)
            used_new.add(new_cid)

    # Dropped: old commits with no partner.
    for cid in old_ids:
        if cid not in used_old:
            pairs.append({
                "old": _commit_info(root, cid, old_pids[cid], old_fcs.get(cid, 0)),
                "new": None,
                "status": "dropped",
                "_old_idx": old_ids.index(cid),
                "_new_idx": len(new_ids),
            })

    # Added: new commits with no partner.
    for cid in new_ids:
        if cid not in used_new:
            pairs.append({
                "old": None,
                "new": _commit_info(root, cid, new_pids[cid], new_fcs.get(cid, 0)),
                "status": "added",
                "_old_idx": len(old_ids),
                "_new_idx": new_ids.index(cid),
            })

    # Sort by new series order (then old order for dropped).
    pairs.sort(key=lambda p: (p["_new_idx"], p["_old_idx"]))

    # Strip internal sort keys and populate commit info with root.
    for p in pairs:
        del p["_old_idx"]
        del p["_new_idx"]

    return pairs

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``muse range-diff`` subcommand."""
    parser = subparsers.add_parser(
        "range-diff",
        help="Compare two versions of a commit series.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "old_range",
        metavar="OLD_RANGE",
        help="Old commit range (e.g. base..old-branch).",
    )
    parser.add_argument(
        "new_range",
        metavar="NEW_RANGE",
        help="New commit range (e.g. base..new-branch).",
    )
    parser.add_argument(
        "--creation-factor",
        type=float,
        default=0.6,
        dest="creation_factor",
        metavar="N",
        help=(
            "Float 0.0–1.0. How aggressively to pair unmatched commits positionally. "
            "1.0 = pair all remaining; 0.0 = exact patch-id matches only. (default: 0.6)"
        ),
    )
    parser.add_argument(
        "--stable",
        action="store_true",
        help="Ignore trailing whitespace when computing patch-ids.",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit a single JSON object on stdout.",
    )
    parser.set_defaults(func=run)

# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Compare two commit series and report differences.

    Exit codes::

        0 — trivially equivalent (all pairs are equivalent)
        1 — at least one commit differs, dropped, or added
        2 — usage error
    """
    elapsed = start_timer()
    old_range_str: str = args.old_range
    new_range_str: str = args.new_range
    creation_factor: float = max(0.0, min(1.0, args.creation_factor))
    stable: bool = args.stable
    json_out: bool = args.json_out

    # Validate — reject ANSI/control characters.
    for raw in (old_range_str, new_range_str):
        if any(ord(c) < 32 for c in raw):
            print(f"❌ Invalid ref: {sanitize_display(raw)}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        # Validate each part of the range individually.
        for part in raw.split(".."):
            part = part.strip()
            if part and not _SAFE_REF_RE.match(part):
                print(f"❌ Invalid ref: {sanitize_display(raw)}", file=sys.stderr)
                raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()

    # Parse ranges.
    old_base_str, old_tip_str = _parse_range(old_range_str)
    new_base_str, new_tip_str = _parse_range(new_range_str)

    # Resolve refs.
    def _resolve(ref: str, label: str) -> str | None:
        resolved = _resolve_ref(root, ref)
        if resolved is None:
            print(f"❌ Cannot resolve ref: {sanitize_display(ref)} ({label})", file=sys.stderr)
        return resolved

    old_base_id = _resolve(old_base_str, "old base") if old_base_str else None
    old_tip_id = _resolve(old_tip_str, "old tip")
    new_base_id = _resolve(new_base_str, "new base") if new_base_str else None
    new_tip_id = _resolve(new_tip_str, "new tip")

    if old_tip_id is None or new_tip_id is None:
        raise SystemExit(ExitCode.USER_ERROR)
    if old_base_str and old_base_id is None:
        raise SystemExit(ExitCode.USER_ERROR)
    if new_base_str and new_base_id is None:
        raise SystemExit(ExitCode.USER_ERROR)

    # Collect commit series.
    old_ids = _walk_range(root, old_base_id, old_tip_id)
    new_ids = _walk_range(root, new_base_id, new_tip_id)

    # Compute patch-ids (and files_changed counts) in parallel.
    old_pids: dict[str, str] = {}
    new_pids: dict[str, str] = {}
    old_fcs: dict[str, int] = {}
    new_fcs: dict[str, int] = {}

    all_ids = [(cid, "old") for cid in old_ids] + [(cid, "new") for cid in new_ids]

    def _compute(item: tuple[str, str]) -> tuple[str, str, str, int]:
        cid, side = item
        pid, fc = _patch_id_for_commit(root, cid, stable=stable)
        return cid, side, pid, fc

    with ThreadPoolExecutor(max_workers=min(8, max(1, len(all_ids)))) as pool:
        for cid, side, pid, fc in pool.map(_compute, all_ids):
            if side == "old":
                old_pids[cid] = pid
                old_fcs[cid] = fc
            else:
                new_pids[cid] = pid
                new_fcs[cid] = fc

    # Pair the series.
    pairs = _pair_series(
        root, old_ids, new_ids,
        old_pids, new_pids,
        old_fcs, new_fcs,
        creation_factor,
    )

    trivially_equivalent = all(p["status"] == "equivalent" for p in pairs)
    exit_code = 0 if trivially_equivalent else int(ExitCode.USER_ERROR)

    result: _RangeDiffResultDict = {
        "old_range": old_range_str,
        "new_range": new_range_str,
        "trivially_equivalent": trivially_equivalent,
        "old_count": len(old_ids),
        "new_count": len(new_ids),
        "stable": stable,
        "creation_factor": creation_factor,
        "pairs": pairs,
    }

    if json_out:
        print(_json.dumps(_RangeDiffJson(
            **make_envelope(elapsed, exit_code=exit_code),
            **result,
        )))
    else:
        _print_text(result)

    if not trivially_equivalent:
        raise SystemExit(ExitCode.USER_ERROR)

def _print_text(result: _RangeDiffResultDict) -> None:
    """Print a human-readable range-diff summary."""
    print(f"# range-diff  {sanitize_display(result['old_range'])}  →  {sanitize_display(result['new_range'])}")
    print()

    if not result["pairs"]:
        print("(empty — both series are empty)")
        return

    for p in result["pairs"]:
        status = p["status"]
        if status == "equivalent":
            old = p["old"]
            print(f"=  {short_id(old['commit_id'])}  {sanitize_display(old['subject'])}")
        elif status == "changed":
            old = p["old"]
            new = p["new"]
            print(f"!  {short_id(old['commit_id'])} → {short_id(new['commit_id'])}  {sanitize_display(new['subject'])}")
        elif status == "dropped":
            old = p["old"]
            print(f"<  {short_id(old['commit_id'])}  {sanitize_display(old['subject'])}")
        elif status == "added":
            new = p["new"]
            print(f">  {short_id(new['commit_id'])}  {sanitize_display(new['subject'])}")
