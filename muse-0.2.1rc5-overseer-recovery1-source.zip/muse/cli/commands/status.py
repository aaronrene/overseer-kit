"""muse status — show working-tree drift against HEAD.

Output modes
------------

Default (color when stdout is a TTY)::

    On branch main
    Your branch is up to date with 'origin/main'.

    Changes since last commit:
      (use "muse commit -m <msg>" to record changes)

        modified: tracks/drums.mid
        new file: tracks/lead.mp3
         deleted: tracks/scratch.mid
         renamed: tracks/old.mid → tracks/new.mid

--short (color letter prefix when stdout is a TTY)::

    M tracks/drums.mid
    A tracks/lead.mp3
    D tracks/scratch.mid
    R tracks/old.mid → tracks/new.mid

--json (agent-native, always stable)::

    {
      "branch":             "main",
      "head_commit":        "sha256:abc123…",
      "upstream":           null,
      "ahead":              null,
      "behind":             null,
      "clean":              true,
      "dirty":              false,
      "total_changes":      0,
      "untracked_count":    0,
      "added":              [],
      "modified":           [],
      "deleted":            [],
      "renamed":            {},
      "staged":             {"added": [], "modified": [], "deleted": []},
      "unstaged":           {"added": [], "modified": [], "deleted": []},
      "untracked":          [],
      "conflict_paths":     [],
      "merge_in_progress":  false,
      "merge_from":         null,
      "conflict_count":     0,
      "checkout_interrupted": false,
      "checkout_target":    null,
      "sparse_checkout":    null,
      "duration_ms":         1.2,
      "exit_code":          0
    }

``sparse_checkout`` is ``null`` when sparse-checkout is disabled.  When active::

    "sparse_checkout": {"enabled": true, "mode": "cone", "patterns": ["src/"]}

The schema is **always the same shape** regardless of domain or staging state.
``staged`` and ``unstaged`` are ``null`` for domains that have no staging concept
(e.g. non-code domains).  For code-domain repos they are always ``{added,
modified, deleted}`` sub-objects — even when all three lists are empty.

``added``, ``modified``, ``deleted`` are the flat union of staged + unstaged —
the primary interface for agents that only need "what changed".  ``staged`` and
``unstaged`` partition that union for agents that need staging detail.

--exit-code
    Exits 0 when the working tree is clean, 1 when dirty.  Combine with
    ``--json`` for structured output plus a testable exit code.

Color convention
----------------
  yellow  modified  — file exists in both old and new snapshot, content changed
  green   new file  — file is new, not present in last commit
  red     deleted   — file was removed since last commit
  cyan    renamed   — file was moved or renamed since last commit
"""

import argparse
import json
import logging
import pathlib
import sys
from typing import TypedDict

from muse.cli.commands.checkout import read_checkout_head
from muse.cli.config import get_remote_head, get_upstream
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.types import Manifest, Metadata, load_json_file
from muse.plugins.code.stage import EMPTY_DIR_OID as _DIR_SENTINEL
from muse.core.paths import repo_json_path as _repo_json_path, sparse_checkout_path as _sparse_checkout_path
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.hooks import install_notice
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import walk_commits_between
from muse.core.snapshots import get_head_snapshot_manifest
from muse.core.validation import sanitize_display
from muse.core.snapshot import directories_from_manifest
from muse.core.timing import start_timer
from muse.domain import SnapshotManifest, StagePlugin
from muse.plugins.registry import resolve_plugin

logger = logging.getLogger(__name__)

# Default domain when repo.json is absent or corrupt.  Must match
# the default used by ``muse init`` (currently "code").
_DEFAULT_DOMAIN = "code"

class _UpstreamInfo(TypedDict):
    """Computed ahead/behind counts for the current branch vs its upstream."""

    tracking_ref: str
    ahead: int | None
    behind: int | None
    line: str

class _BranchOnlyJson(EnvelopeJson):
    """JSON payload for ``--branch-only`` output.

    All keys are always present — agents must not need ``dict.get`` guards.
    """

    branch: str
    head_commit: str | None
    upstream: str | None
    ahead: int | None
    behind: int | None
    merge_in_progress: bool
    merge_from: str | None
    conflict_count: int

class _SparseCheckoutInfo(TypedDict):
    """Sparse-checkout config surfaced in ``muse status --json``.

    Agents can read the active sparse config in the same call as working-tree
    state — no second command needed.
    """

    enabled: bool
    mode: str | None
    patterns: list[str]

class _StagedBucket(TypedDict):
    """The added/modified/deleted/renamed breakdown for one staging layer."""

    added: list[str]
    modified: list[str]
    deleted: list[str]
    renamed: Manifest  # old → new; always {} for staged (renames are unstaged)

class _StatusJson(EnvelopeJson):
    """Canonical ``muse status --json`` payload — always the same shape.

    All keys are always present so agents can read them without ``dict.get``
    guards.  The schema is identical regardless of domain or whether a stage
    index is active.

    Schema
    ------
    branch          Current branch name.
    head_commit     sha256:-prefixed HEAD commit ID; null on an empty repo.
    upstream        Tracking remote name if configured, else null.
    clean           True when no staged changes, no unstaged changes, and no
                    untracked files.  Matches git: untracked files present = not clean.
    dirty           not clean — both always present for ergonomic CI checks.
    ahead           Commits ahead of remote; null when no upstream.
    behind          Commits behind remote; null when no upstream.
    total_changes   len(added) + len(modified) + len(deleted) + len(renamed).
                    Counts all tracked changes — files and directories.
                    Directory paths carry a trailing slash (e.g. "src/").
    untracked_count len(untracked).  Convenience field: total_changes == 0 with
                    untracked_count > 0 means only untracked files are present.
    added           Flat union — paths added since HEAD (staged ∪ unstaged).
                    Empty directories appear here with a trailing slash.
    modified        Flat union — paths modified since HEAD.
    deleted         Flat union — paths deleted since HEAD.
                    Deleted committed empty dirs appear here with a trailing slash.
    renamed         Mapping old → new for renamed paths.
    staged          {added, modified, deleted} for staged changes only.
                    Staged empty dirs appear in staged.added with trailing slash.
                    null when domain has no staging concept.
    unstaged        {added, modified, deleted} for unstaged changes only.
                    null when domain has no staging concept.
    untracked       Files on disk not tracked by Muse.  [] for non-code domains.
    conflict_paths           Paths with unresolved merge conflicts.
    resolved_conflict_paths  Paths already resolved (in original but cleared).
    merge_in_progress        True when a merge is in progress.
    merge_from               Branch being merged; null when no merge.
    conflict_count           len(conflict_paths).
    resolved_conflict_count  len(resolved_conflict_paths).
    checkout_interrupted  True when a checkout was interrupted mid-flight.
    checkout_target Branch or snapshot targeted by the interrupted checkout.
    """

    branch: str
    head_commit: str | None
    upstream: str | None
    clean: bool
    dirty: bool
    ahead: int | None
    behind: int | None
    total_changes: int
    untracked_count: int
    added: list[str]
    modified: list[str]
    deleted: list[str]
    renamed: Manifest
    staged: _StagedBucket | None
    unstaged: _StagedBucket | None
    untracked: list[str]
    conflict_paths: list[str]
    resolved_conflict_paths: list[str]
    merge_in_progress: bool
    merge_from: str | None
    conflict_count: int
    resolved_conflict_count: int
    checkout_interrupted: bool
    checkout_target: str | None
    sparse_checkout: _SparseCheckoutInfo | None

def _read_sparse_checkout(root: pathlib.Path) -> _SparseCheckoutInfo | None:
    """Read the sparse-checkout config and return a typed summary, or None.

    Returns ``None`` when sparse-checkout is disabled (config file absent).
    Silently returns ``None`` on any parse error — status must never crash due
    to a corrupt sparse config.

    Args:
        root: Repository root (directory that contains ``.muse/``).

    Returns:
        :class:`_SparseCheckoutInfo` when active, ``None`` otherwise.
    """
    cfg_path = _sparse_checkout_path(root)
    if not cfg_path.exists():
        return None
    data = load_json_file(cfg_path)
    if not isinstance(data, dict):
        return None
    try:
        return _SparseCheckoutInfo(
            enabled=True,
            mode=data.get("mode"),
            patterns=list(data.get("patterns", [])),
        )
    except Exception:
        return None

_YELLOW = "\033[33m"
_GREEN  = "\033[32m"
_RED    = "\033[31m"
_CYAN   = "\033[36m"
_BOLD   = "\033[1m"
_RESET  = "\033[0m"

def _color(text: str, ansi: str, is_tty: bool) -> str:
    """Wrap *text* in ANSI color codes only when writing to a TTY."""
    return f"{_BOLD}{ansi}{text}{_RESET}" if is_tty else text

def _compute_upstream_info(
    root: pathlib.Path,
    branch: str,
    upstream: str,
) -> _UpstreamInfo:
    """Compute ahead/behind counts and the human-readable tracking line once.

    Centralises all ``walk_commits_between`` calls so they are executed exactly
    once per ``muse status`` invocation regardless of output format.  Previously
    the text path called ``_tracking_line`` (two BFS walks) and the JSON path
    re-implemented the same logic inline (two more BFS walks) — four total BFS
    traversals per status call.  This helper performs at most two walks and
    returns a typed result consumed by both paths.

    Args:
        root:     Repository root.
        branch:   Current branch name.
        upstream: Upstream remote name (e.g. ``"origin"``).

    Returns:
        :class:`_UpstreamInfo` with ``tracking_ref``, ``ahead``, ``behind``,
        and a pre-formatted ``line`` for the text output.
    """
    tracking_ref = f"{upstream}/{branch}"
    remote_head = get_remote_head(upstream, branch, root)

    if not remote_head:
        return _UpstreamInfo(
            tracking_ref=tracking_ref,
            ahead=None,
            behind=None,
            line=f"Tracking: {tracking_ref} (not yet pushed)",
        )

    local_head = get_head_commit_id(root, branch)
    if not local_head:
        return _UpstreamInfo(
            tracking_ref=tracking_ref,
            ahead=None,
            behind=None,
            line=f"Tracking: {tracking_ref}",
        )

    if local_head == remote_head:
        return _UpstreamInfo(
            tracking_ref=tracking_ref,
            ahead=0,
            behind=0,
            line=f"Your branch is up to date with '{tracking_ref}'.",
        )

    # Both walks are necessary only for the diverged case; the common case
    # (up-to-date) returns early above without any BFS at all.
    ahead = len(walk_commits_between(root, local_head, remote_head))
    behind = len(walk_commits_between(root, remote_head, local_head))

    if ahead and behind:
        line = (
            f"Your branch and '{tracking_ref}' have diverged, "
            f"and have {ahead} and {behind} different commits each."
        )
    elif ahead:
        suffix = "commit" if ahead == 1 else "commits"
        line = f"Your branch is ahead of '{tracking_ref}' by {ahead} {suffix}."
    elif behind:
        suffix = "commit" if behind == 1 else "commits"
        line = f"Your branch is behind '{tracking_ref}' by {behind} {suffix}."
    else:
        line = f"Your branch is up to date with '{tracking_ref}'."

    return _UpstreamInfo(
        tracking_ref=tracking_ref,
        ahead=ahead,
        behind=behind,
        line=line,
    )

def _read_repo_meta(root: pathlib.Path) -> tuple[str, str]:
    """Read ``.muse/repo.json`` once and return ``(repo_id, domain)``.

    Returns sensible defaults on any read or parse failure rather than
    propagating an unhandled exception to the user.  Status degrades
    gracefully to an empty diff in the worst case.

    The domain default is ``"code"`` — matching ``muse init``'s default — so
    that a corrupt or absent ``repo.json`` produces sensible ignore rules rather
    than silently switching to the ``midi`` domain.
    """
    data = load_json_file(_repo_json_path(root))
    if data is None:
        return "", _DEFAULT_DOMAIN
    repo_id_raw = data.get("repo_id", "")
    repo_id = str(repo_id_raw) if isinstance(repo_id_raw, str) and repo_id_raw else ""
    domain_raw = data.get("domain", "")
    domain = str(domain_raw) if isinstance(domain_raw, str) and domain_raw else _DEFAULT_DOMAIN
    return repo_id, domain

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse status`` subcommand and its flags."""
    parser = subparsers.add_parser(
        "status",
        help="Show working-tree drift against HEAD.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--short", "-s", action="store_true",
        help="Condensed one-letter-per-file output.",
    )
    parser.add_argument(
        "--branch", "-b", action="store_true", dest="branch_only",
        help="Show branch/upstream info only — skip the file diff.",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit JSON output (default: human-readable text).",
    )
    parser.add_argument(
        "--exit-code", action="store_true", dest="exit_code",
        help=(
            "Exit 0 when the working tree is clean, 1 when dirty.  "
            "Combines with --json for structured output plus a testable exit code."
        ),
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Show working-tree drift against HEAD.

    Covers four scenarios: clean tree, dirty tree (added/modified/deleted/renamed
    files), merge in progress (conflict count and resolution steps), and staged
    index active (code plugin: three-bucket staged/unstaged/untracked view).
    Use ``--branch`` for a lightweight branch-info check without diffing files.

    Agent quickstart::

        muse status --json
        muse status --branch --json
        muse status --exit-code --json
        muse status --short --json

    JSON fields::

        branch             Current branch name.
        head_commit        SHA-256-prefixed HEAD commit ID; ``null`` on empty repo.
        upstream           Tracking remote name if configured, else ``null``.
        clean              ``true`` when working tree exactly matches HEAD.
        dirty              ``not clean``.
        ahead              Commits ahead of remote; ``null`` when no upstream.
        behind             Commits behind remote; ``null`` when no upstream.
        total_changes      ``len(added) + len(modified) + len(deleted) + len(renamed)``.
        added              Flat union of staged + unstaged new paths.
        modified           Flat union of staged + unstaged changed paths.
        deleted            Flat union of staged + unstaged removed paths.
        renamed            Mapping old → new for renamed paths.
        staged             ``{added, modified, deleted}`` staged changes; ``null`` for non-code.
        unstaged           ``{added, modified, deleted}`` unstaged changes; ``null`` for non-code.
        untracked          Files on disk not tracked by Muse; ``[]`` for non-code.
        conflict_paths     Paths with unresolved merge conflicts.
        merge_in_progress  ``true`` when a merge is in progress.
        merge_from         Branch being merged; ``null`` when no merge.
        conflict_count     ``len(conflict_paths)``.
        checkout_interrupted  ``true`` when a checkout was killed mid-flight.
        checkout_target    Branch or snapshot targeted by the interrupted checkout.
        sparse_checkout    Active sparse config ``{enabled, mode, patterns}``; ``null`` when disabled.
        muse_version       Muse release that produced this output.
        schema             Envelope schema version (int).
        exit_code          ``0`` normally; ``1`` when ``--exit-code`` and working tree is dirty.
        duration_ms        Wall-clock milliseconds for the command.
        timestamp          ISO-8601 UTC timestamp of command completion.
        warnings           List of non-fatal advisory messages.

    Exit codes::

        0  Success (or clean tree when ``--exit-code`` is set).
        1  Dirty working tree (only when ``--exit-code`` is given).
        2  Usage error (invalid ``--format`` value).
        3  Internal error (repository not found).
    """
    from muse.core.merge_engine import read_merge_state

    elapsed = start_timer()

    json_out: bool = args.json_out
    short: bool = args.short
    branch_only: bool = args.branch_only
    exit_code_flag: bool = args.exit_code

    root = require_repo()

    # musehub#192 Phase 4: nudge visibly (stderr, both text and --json modes)
    # when this repo declares pre-commit hooks that this clone hasn't
    # activated yet — covers clones that predate this feature or where
    # `muse hooks install` was skipped. Best-effort: a malformed
    # .musehooks.toml is surfaced by `muse hooks status`/`list`, not here.
    notice = install_notice(root)
    if notice:
        print(f"ℹ️  {notice}", file=sys.stderr)

    try:
        branch = read_current_branch(root)
    except ValueError as exc:
        print(f"fatal: {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    repo_id, domain = _read_repo_meta(root)
    upstream = get_upstream(branch, root)

    # ── Checkout-interrupted state ────────────────────────────────────────────
    # .muse/CHECKOUT_HEAD exists only when a previous checkout was killed
    # mid-flight.  The working tree may be partially mutated; warn loudly so
    # the user knows to retry the checkout rather than treating missing files
    # as uncommitted deletions.
    checkout_target: str | None = read_checkout_head(root)
    checkout_interrupted: bool = checkout_target is not None

    # ── Merge-in-progress state ───────────────────────────────────────────────
    merge_state = read_merge_state(root)
    merge_in_progress = merge_state is not None
    conflict_paths: list[str] = merge_state.conflict_paths if merge_state else []
    conflict_count = len(conflict_paths)
    merge_from: str | None = merge_state.other_branch if merge_state else None
    # resolved = in original_conflict_paths but cleared from conflict_paths
    if merge_state is not None:
        _current_set = set(merge_state.conflict_paths)
        resolved_conflict_paths: list[str] = [
            p for p in merge_state.original_conflict_paths if p not in _current_set
        ]
    else:
        resolved_conflict_paths = []

    # ── HEAD commit id ────────────────────────────────────────────────────────
    head_commit: str | None = get_head_commit_id(root, branch)

    # ── Upstream ahead/behind (computed once, shared by all output formats) ──
    upstream_info: _UpstreamInfo | None = None
    if upstream:
        upstream_info = _compute_upstream_info(root, branch, upstream)

    # ── Text: checkout-interrupted banner ─────────────────────────────────────
    if not json_out and checkout_interrupted:
        safe_target = sanitize_display(checkout_target) if checkout_target else ""
        print(
            f"\n🚨 CHECKOUT INTERRUPTED — the previous checkout to "
            f"'{safe_target}' did not complete.",
            file=sys.stderr,
        )
        print(
            "   The working tree may be partially mutated.\n"
            "   Files shown as 'deleted' below may be missing because of the\n"
            "   interrupted checkout, not because you deleted them.\n"
            "   Next steps:",
            file=sys.stderr,
        )
        print(
            f"     muse checkout {safe_target}   # retry the checkout\n"
            "     muse checkout <branch>          # switch to a different branch",
            file=sys.stderr,
        )

    # ── Text: merge banner and branch line ────────────────────────────────────
    if not json_out:
        if not short:
            print(f"On branch {sanitize_display(branch)}")
            if upstream_info:
                print(upstream_info["line"])

        if merge_in_progress:
            safe_merge_from = sanitize_display(merge_from) if merge_from else ""
            label = f" merging '{safe_merge_from}'" if safe_merge_from else ""
            n_resolved = len(resolved_conflict_paths)
            print(f"\n⚠️  You have an unresolved merge in progress{label}.")
            if conflict_count:
                progress = f" ({n_resolved} resolved)" if n_resolved else ""
                print(f"   {conflict_count} unresolved conflict(s){progress}.")
                print("   Next steps:")
                print("     muse conflicts              # see all conflicts")
                print("     muse resolve <path>         # after manual edit")
                print("     muse checkout --ours <path> # accept your version")
                print("     muse checkout --theirs <path> # accept their version")
                print("     muse checkout --ours --all  # resolve all — keep ours")
                print("     muse checkout --theirs --all # resolve all — keep theirs")
                print("     muse commit                 # once all resolved")
                print("     muse merge --abort          # cancel the merge")
            else:
                print("   All conflicts resolved — run `muse commit` to complete the merge.")

    # ── Branch-only mode ──────────────────────────────────────────────────────
    if branch_only:
        if json_out:
            out = _BranchOnlyJson(
                **make_envelope(elapsed),
                branch=sanitize_display(branch),
                head_commit=head_commit,
                upstream=upstream,
                ahead=upstream_info["ahead"] if upstream_info else None,
                behind=upstream_info["behind"] if upstream_info else None,
                merge_in_progress=merge_in_progress,
                merge_from=sanitize_display(merge_from) if merge_from else None,
                conflict_count=conflict_count,
            )
            print(json.dumps(out))
        return

    is_tty = sys.stdout.isatty() and not json_out

    plugin = resolve_plugin(root)

    # ── Staged-index path (any domain that supports staging) ─────────────────
    # Route here whenever the plugin supports StagePlugin, regardless of whether
    # the index file exists — so JSON output always includes staged/unstaged
    # buckets for code-domain repos, even when the index is empty/absent.
    sparse_checkout = _read_sparse_checkout(root)

    if isinstance(plugin, StagePlugin):
        _render_staged_status(
            root, plugin, branch, head_commit, json_out, short, is_tty,
            upstream_info=upstream_info,
            merge_in_progress=merge_in_progress,
            conflict_paths=conflict_paths,
            resolved_conflict_paths=resolved_conflict_paths,
            merge_from=merge_from,
            exit_code_flag=exit_code_flag,
            checkout_interrupted=checkout_interrupted,
            checkout_target=checkout_target,
            sparse_checkout=sparse_checkout,
            elapsed_fn=elapsed,
        )
        return

    # ── Drift computation ─────────────────────────────────────────────────────
    head_manifest = get_head_snapshot_manifest(root, branch) or {}
    committed_snap = SnapshotManifest(files=head_manifest, domain=domain, directories=directories_from_manifest(head_manifest))
    report = plugin.drift(committed_snap, root)
    delta = report.delta

    added: set[str] = set()
    modified: set[str] = set()
    deleted: set[str] = set()
    renamed: Manifest = {}

    for op in delta["ops"]:
        op_type = op["op"]
        addr = op["address"]
        if op_type == "insert":
            added.add(addr)
        elif op_type == "delete":
            deleted.add(addr)
        elif op_type == "replace":
            modified.add(addr)
        elif op_type == "patch":
            modified.add(addr)
        elif op_type == "rename":
            renamed[str(op["from_address"])] = addr

    clean = not (added or modified or deleted or renamed)
    dirty = not clean

    # ── JSON output ───────────────────────────────────────────────────────────
    if json_out:
        out_json = _StatusJson(
            **make_envelope(elapsed),
            branch=sanitize_display(branch),
            head_commit=head_commit,
            upstream=upstream,
            clean=clean,
            dirty=dirty,
            ahead=upstream_info["ahead"] if upstream_info else None,
            behind=upstream_info["behind"] if upstream_info else None,
            total_changes=len(added) + len(modified) + len(deleted) + len(renamed),
            untracked_count=0,
            added=sorted(added),
            modified=sorted(modified),
            deleted=sorted(deleted),
            renamed=renamed,
            # Non-stage domains have no staging concept — null signals this clearly.
            staged=None,
            unstaged=None,
            untracked=[],
            conflict_paths=conflict_paths,
            resolved_conflict_paths=resolved_conflict_paths,
            merge_in_progress=merge_in_progress,
            merge_from=sanitize_display(merge_from) if merge_from else None,
            conflict_count=conflict_count,
            resolved_conflict_count=len(resolved_conflict_paths),
            checkout_interrupted=checkout_interrupted,
            checkout_target=sanitize_display(checkout_target) if checkout_target else None,
            sparse_checkout=sparse_checkout,
        )
        print(json.dumps(out_json))
        if exit_code_flag and dirty:
            raise SystemExit(1)
        return

    # ── Short output ──────────────────────────────────────────────────────────
    if short:
        for p in sorted(modified):
            print(f" {_color('M', _YELLOW, is_tty)} {p}")
        for p in sorted(added):
            print(f" {_color('A', _GREEN, is_tty)} {p}")
        for p in sorted(deleted):
            print(f" {_color('D', _RED, is_tty)} {p}")
        for old, new in sorted(renamed.items()):
            print(f" {_color('R', _CYAN, is_tty)} {old} → {new}")
        if exit_code_flag and dirty:
            raise SystemExit(1)
        return

    # ── Long text output ──────────────────────────────────────────────────────
    if clean and not merge_in_progress:
        print("\nNothing to commit, working tree clean")
        if exit_code_flag:
            raise SystemExit(0)
        return

    if not clean:
        print("\nChanges since last commit:")
        print('  (use "muse commit -m <msg>" to record changes)\n')
        for p in sorted(modified):
            print(f"\t{_color('    modified:', _YELLOW, is_tty)} {sanitize_display(p)}")
        for p in sorted(added):
            print(f"\t{_color('    new file:', _GREEN, is_tty)} {sanitize_display(p)}")
        for p in sorted(deleted):
            print(f"\t{_color('     deleted:', _RED, is_tty)} {sanitize_display(p)}")
        for old, new in sorted(renamed.items()):
            print(
                f"\t{_color('     renamed:', _CYAN, is_tty)} "
                f"{sanitize_display(old)} → {sanitize_display(new)}"
            )

    if exit_code_flag and dirty:
        raise SystemExit(1)

def _render_staged_status(
    root: pathlib.Path,
    plugin: StagePlugin,
    branch: str,
    head_commit: str | None,
    json_out: bool,
    short: bool,
    is_tty: bool,
    *,
    upstream_info: "_UpstreamInfo | None" = None,
    merge_in_progress: bool = False,
    conflict_paths: list[str] | None = None,
    resolved_conflict_paths: list[str] | None = None,
    merge_from: str | None = None,
    exit_code_flag: bool = False,
    checkout_interrupted: bool = False,
    checkout_target: str | None = None,
    sparse_checkout: "_SparseCheckoutInfo | None" = None,
    elapsed_fn: "callable[[], float] | None" = None,
) -> None:
    """Render the three-bucket staged / unstaged / untracked view.

    Displayed when the active plugin implements :class:`~muse.domain.StagePlugin`
    and a stage index is present.  Mirrors ``git status`` long-form output.

    Args:
        root:             Repository root.
        plugin:           Active plugin (must implement :class:`StagePlugin`).
        branch:           Current branch name.
        head_commit:      SHA-256 of HEAD commit (null on empty repo).
        json_out:         True to emit JSON, False for human-readable text.
        short:            Render condensed one-letter-per-file output.
        is_tty:           True when stdout is a terminal (enables color).
        upstream_info:    Ahead/behind tracking info; ``None`` when no remote.
        merge_in_progress: True when a merge is in progress.
        conflict_paths:   Paths with unresolved merge conflicts.
        merge_from:       Branch being merged in.
        exit_code_flag:   Exit 1 when dirty.
        checkout_interrupted: True when a previous checkout was killed mid-flight.
        checkout_target:  Branch or snapshot targeted by the interrupted checkout.
        sparse_checkout:  Active sparse-checkout config; ``None`` when disabled.
        elapsed_fn:       Callable returning milliseconds since ``run()`` started.
    """
    status = plugin.stage_status(root)
    staged = status["staged"]
    unstaged = status["unstaged"]
    untracked = status["untracked"]
    wt_renamed: Manifest = status.get("renamed", {})  # type: ignore[assignment]
    _raw_dirs = status.get("directories", {"added": [], "deleted": [], "staged_added": [], "staged_deleted": [], "staged_renamed": {}})
    # Directory paths with trailing slash — folded into the same buckets as files.
    dir_added: list[str] = [p + "/" for p in _raw_dirs["added"]]
    dir_deleted: list[str] = [p + "/" for p in _raw_dirs["deleted"]]
    dir_staged_added: list[str] = [p + "/" for p in _raw_dirs["staged_added"]]
    dir_staged_deleted: list[str] = [p + "/" for p in _raw_dirs.get("staged_deleted", [])]
    # Explicit dir renames from muse mv — keys/values get trailing slash for display.
    _raw_dir_renames: dict[str, str] = _raw_dirs.get("staged_renamed", {})
    dir_staged_renamed: dict[str, str] = {k + "/": v + "/" for k, v in _raw_dir_renames.items()}

    # Exclude dir sentinels from the visible staged set — they are not real file changes.
    staged_visible = {p: e for p, e in staged.items() if e.get("object_id") != _DIR_SENTINEL}

    clean = (
        not staged_visible and not unstaged and not untracked
        and not wt_renamed and not dir_staged_renamed
        and not dir_added and not dir_deleted and not dir_staged_added and not dir_staged_deleted
    )
    dirty = not clean
    _conflict_paths: list[str] = conflict_paths or []
    _resolved_conflict_paths: list[str] = resolved_conflict_paths or []

    _MODE_LABEL: Metadata = {
        "A": "new file",
        "M": "modified",
        "D": "deleted",
    }

    if json_out:
        # Staged sub-bucket: exclude empty-dir entries (object_id == EMPTY_DIR_OID).
        staged_added = sorted(
            p for p, e in staged.items()
            if e["mode"] == "A" and e["object_id"] != _DIR_SENTINEL
        )
        staged_modified = sorted(p for p, e in staged.items() if e["mode"] == "M")
        staged_deleted = sorted(
            p for p, e in staged.items()
            if e["mode"] == "D" and e.get("object_id") != _DIR_SENTINEL
        )

        unstaged_modified = sorted(p for p, lbl in unstaged.items() if lbl == "modified")
        unstaged_deleted = sorted(p for p, lbl in unstaged.items() if lbl == "deleted")

        # Dirs are symmetric with files: trailing slash is the only distinguisher.
        # Untracked dirs   → untracked (same as untracked files).
        # Staged dirs A    → staged.added + flat_added.
        # Staged dirs D    → staged.deleted + flat_deleted.
        # Staged dir renames → staged.renamed + top-level renamed.
        # Unstaged dir del → flat_deleted (not yet staged).
        all_untracked = sorted(list(untracked) + dir_added)
        flat_added = sorted(set(staged_added) | set(dir_staged_added))
        flat_modified = sorted(set(staged_modified) | set(unstaged_modified))
        flat_deleted = sorted(set(staged_deleted) | set(unstaged_deleted) | set(dir_deleted) | set(dir_staged_deleted))
        # Merge working-tree file renames and staged dir renames into one map.
        all_renamed = dict(wt_renamed)
        all_renamed.update(dir_staged_renamed)
        total = len(flat_added) + len(flat_modified) + len(flat_deleted) + len(all_renamed)

        out = _StatusJson(
            **make_envelope(elapsed_fn),
            branch=sanitize_display(branch),
            head_commit=head_commit,
            upstream=upstream_info["tracking_ref"] if upstream_info else None,
            clean=clean,
            dirty=dirty,
            ahead=upstream_info["ahead"] if upstream_info else None,
            behind=upstream_info["behind"] if upstream_info else None,
            total_changes=total,
            untracked_count=len(all_untracked),
            added=flat_added,
            modified=flat_modified,
            deleted=flat_deleted,
            renamed=all_renamed,
            staged=_StagedBucket(
                added=sorted(staged_added + dir_staged_added),
                modified=staged_modified,
                deleted=sorted(staged_deleted + dir_staged_deleted),
                renamed=dir_staged_renamed,
            ),
            unstaged=_StagedBucket(
                added=[],
                modified=unstaged_modified,
                deleted=sorted(unstaged_deleted + dir_deleted),
                renamed=dict(wt_renamed),
            ),
            untracked=all_untracked,
            conflict_paths=_conflict_paths,
            resolved_conflict_paths=_resolved_conflict_paths,
            merge_in_progress=merge_in_progress,
            merge_from=sanitize_display(merge_from) if merge_from else None,
            conflict_count=len(_conflict_paths),
            resolved_conflict_count=len(_resolved_conflict_paths),
            checkout_interrupted=checkout_interrupted,
            checkout_target=sanitize_display(checkout_target) if checkout_target else None,
            sparse_checkout=sparse_checkout,
        )
        print(json.dumps(out))
        if exit_code_flag and dirty:
            raise SystemExit(1)
        return

    if short:
        for p, entry in sorted(staged_visible.items()):
            s_mode = entry["mode"]
            color = _GREEN if s_mode == "A" else _YELLOW if s_mode == "M" else _RED
            print(f"{_color(s_mode, color, is_tty)}  {p}")
        for p, label in sorted(unstaged.items()):
            u_letter = "M" if label == "modified" else "D"
            u_color = _YELLOW if label == "modified" else _RED
            print(f" {_color(u_letter, u_color, is_tty)} {p}")
        for old, new in sorted(wt_renamed.items()):
            print(f" {_color('R', _CYAN, is_tty)} {old} -> {new}")
        for p in untracked:
            print(f"?? {p}")
        if exit_code_flag and dirty:
            raise SystemExit(1)
        return

    # Long form — mirrors git status exactly.
    if staged_visible or dir_staged_added or dir_staged_deleted or dir_staged_renamed:
        print("\nChanges staged for commit:")
        print('  (use "muse code reset HEAD <file>" to unstage)\n')
        for p, entry in sorted(staged_visible.items()):
            mode = entry["mode"]
            is_sym = "::" in p
            if mode == "A":
                label = "new symbol" if is_sym else "new file"
                color = _GREEN
            elif mode == "M":
                label = "modified symbol" if is_sym else "modified"
                color = _YELLOW
            else:
                label = "deleted symbol" if is_sym else "deleted"
                color = _RED
            pad = max(0, 16 - len(label))
            print(f"\t{_color(label + ':', color, is_tty)}{' ' * pad} {p}")
        for p in sorted(dir_staged_added):
            pad = max(0, 16 - len("new directory"))
            print(f"\t{_color('new directory:', _GREEN, is_tty)}{' ' * pad} {p}")
        for p in sorted(dir_staged_deleted):
            pad = max(0, 16 - len("deleted directory"))
            print(f"\t{_color('deleted directory:', _RED, is_tty)}{' ' * pad} {p}")
        for old, new in sorted(dir_staged_renamed.items()):
            label = "renamed directory"
            pad = max(0, 16 - len(label))
            print(f"\t{_color(label + ':', _CYAN, is_tty)}{' ' * pad} {old} → {new}")

    if unstaged or dir_deleted:
        print("\nChanges not staged for commit:")
        print('  (use "muse code add <file>" to update what will be committed)\n')
        for p, label in sorted(unstaged.items()):
            color = _YELLOW if label == "modified" else _RED
            pad = max(0, 10 - len(label))
            print(f"\t{_color(label + ':', color, is_tty)}{' ' * pad} {p}")
        for p in sorted(dir_deleted):
            pad = max(0, 10 - len("deleted"))
            print(f"\t{_color('deleted:', _RED, is_tty)}{' ' * pad} {p}")

    if wt_renamed:
        print("\nRenamed in working tree (not staged):")
        print('  (use "muse code add <new> && muse rm <old>" to stage the rename)\n')
        for old, new in sorted(wt_renamed.items()):
            print(f"\t{_color('renamed:', _CYAN, is_tty)}   {old} → {new}")

    if untracked or dir_added:
        print("\nUntracked files:")
        print('  (use "muse code add <file>" to include in what will be committed)\n')
        for p in sorted(list(untracked) + dir_added):
            if p.endswith("/"):
                label = "untracked directory:"
            else:
                label = "untracked file:"
            pad = max(0, 20 - len(label))
            print(f"\t{_color(label, _RED, is_tty)}{' ' * pad} {p}")

    if clean and not merge_in_progress:
        print("\nNothing to commit, working tree clean")

    if staged_visible or dir_staged_added:
        print()  # trailing newline after last section

    if exit_code_flag and dirty:
        raise SystemExit(1)
