"""muse domain-info — inspect the active domain plugin.

Reports which domain is active for this repository, which plugin class
implements it, what optional capabilities it exposes, and the full structural
schema it declares (merge mode, top-level element shape, dimensions).

Output (JSON, default)::

    {
      "domain":             "midi",
      "plugin_class":       "MidiPlugin",
      "capabilities": {
        "addressed_merge": true,
        "crdt":            false,
        "harmony":         false
      },
      "schema": {
        "domain":         "midi",
        "description":    "...",
        "merge_mode":     "three_way",
        "schema_version": "0.x.y",
        "top_level":      { ... },
        "dimensions":     [ ... ]
      },
      "registered_domains": ["bitcoin", "code", "midi", "scaffold"],
      "duration_ms":    0.003421,
      "exit_code":          0
    }

Text output (``--format text``)::

    Domain:       midi
    Plugin:       MidiPlugin
    Merge mode:   three_way
    Capabilities: addressed_merge

Output contract
---------------

- Exit 0: domain resolved and schema emitted.
- Exit 1: no repository found; domain not registered; bad ``--format`` value.
- Exit 3: plugin raised an unexpected error when computing its schema.

Capabilities
------------

``addressed_merge``
    The plugin implements ``AddressedMergePlugin`` and can perform
    symbol-level address-keyed merges rather than falling back to text-level
    line diffs.  Agents should check this before attempting a semantic merge.

``crdt``
    The plugin implements ``CRDTPlugin`` and exposes CRDT-annotated fields
    (e.g. ``reviewed_by`` ORSet, ``test_runs`` GCounter).  Agents performing
    collaborative annotation should check this before writing CRDT fields.

``harmony``
    The plugin implements ``HarmonyPlugin`` and can record and replay
    conflict resolutions.  Agents resolving conflicts in a swarm should
    check this to avoid duplicate resolution work.

Agent use
---------

Inspect any domain without entering its repository::

    muse domain-info --domain midi
    muse domain-info --domain code --capabilities-only
    muse domain-info --all-domains
"""

import argparse
import json
import logging
import sys
from typing import TypedDict

from muse.core.types import JsonValue
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.validation import sanitize_display, validate_domain_name
from muse.core.timing import start_timer
from muse.domain import AddressedMergePlugin, CRDTPlugin, HarmonyPlugin
from muse.plugins.registry import (
    read_domain,
    registered_domains,
    resolve_plugin,
    resolve_plugin_by_domain,
)

logger = logging.getLogger(__name__)

type _DomainSchema = dict[str, JsonValue]

class _CapabilitiesDict(TypedDict):
    """Capability flags for a domain plugin — nested in domain-info JSON output.

    Fields
    ------
    addressed_merge   True when the plugin implements ``AddressedMergePlugin``
                      (Map CRDT address-keyed merge via ``merge_ops``).  Required
                      for ``muse merge`` to use domain-aware symbol-level resolution.
    crdt              True when the plugin exposes a CRDT data model (enables
                      real-time multi-writer collaboration without conflicts).
    harmony           True when the plugin registers harmony patterns for conflict
                      replay via the Harmony resolution engine.
    """

    addressed_merge: bool
    crdt: bool
    harmony: bool

class _DomainInfoAllJson(EnvelopeJson):
    """JSON output for ``muse domain-info --all-domains --json``.

    Inherits the 6 standard envelope fields from :class:`~muse.core.envelope.EnvelopeJson`.

    Fields
    ------
    registered_domains  Sorted list of every domain identifier registered in the
                        plugin registry (not necessarily active in any repo).
    """

    registered_domains: list[str]

class _DomainInfoCapabilitiesJson(EnvelopeJson):
    """JSON output for ``muse domain-info --capabilities-only --json``.

    Inherits the 6 standard envelope fields from :class:`~muse.core.envelope.EnvelopeJson`.

    Fields
    ------
    domain        The active domain identifier for this repository.
    capabilities  Capability flags for the domain plugin — see :class:`_CapabilitiesDict`.
    """

    domain: str
    capabilities: _CapabilitiesDict

class _DomainInfoFullJson(EnvelopeJson):
    """JSON output for ``muse domain-info --json`` (full schema view).

    Inherits the 6 standard envelope fields from :class:`~muse.core.envelope.EnvelopeJson`.

    Fields
    ------
    domain              The active domain identifier for this repository.
    plugin_class        Fully-qualified Python class name of the active plugin.
    capabilities        Capability flags — see :class:`_CapabilitiesDict`.
    domain_schema       Domain schema dict as returned by ``plugin.schema()``.
                        Contains merge mode, dimensions, version, and description.
    registered_domains  All domains registered in the plugin registry.
    """

    domain: str
    plugin_class: str
    capabilities: _CapabilitiesDict
    domain_schema: _DomainSchema
    registered_domains: list[str]

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the domain-info subcommand."""
    parser = subparsers.add_parser(
        "domain-info",
        help="Inspect active domain plugin capabilities and schema.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit machine-readable JSON instead of human text.",
    )
    parser.add_argument(
        "--all-domains", "-a",
        action="store_true",
        dest="all_domains",
        help="List every registered domain instead of querying the active repo.",
    )
    parser.add_argument(
        "--domain",
        default=None,
        dest="domain_name",
        metavar="DOMAIN",
        help=(
            "Inspect a specific domain by name without requiring an active repo. "
            "Example: --domain midi. "
            "Use --all-domains to list available names."
        ),
    )
    parser.add_argument(
        "--capabilities-only",
        action="store_true",
        dest="capabilities_only",
        help=(
            "Emit only the capabilities dict. "
            "Ideal for agents doing merge-strategy negotiation — "
            "avoids serialising the full schema."
        ),
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Inspect the domain plugin active for this repository.

    Reports the domain name, plugin class, optional protocol capabilities
    (``AddressedMergePlugin``, ``CRDTPlugin``, ``HarmonyPlugin``), and the
    full structural schema declared by the plugin.  Use ``--all-domains`` to
    enumerate every registered domain without entering a repo.

    Agent quickstart
    ----------------
    ::

        muse domain-info --json
        muse domain-info --all-domains --json
        muse domain-info --domain code --json
        muse domain-info --capabilities-only --json

    JSON fields
    -----------
    domain              Active domain name.
    plugin_class        Fully qualified plugin class name.
    capabilities        Map of capability flags (``addressed_merge``, etc.).
    schema              Full structural schema declared by the plugin.
    registered_domains  List of all registered domain names.

    Exit codes
    ----------
    0  Success.
    1  Unknown domain name or invalid arguments.
    2  Not inside a Muse repository (unless ``--all-domains`` is set).
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    all_domains: bool = args.all_domains
    domain_name: str | None = args.domain_name
    capabilities_only: bool = args.capabilities_only

    # --all-domains — no repo required.
    if all_domains:
        domains = registered_domains()
        if not json_out:
            for d in domains:
                print(d)
        else:
            print(json.dumps(_DomainInfoAllJson(
                **make_envelope(elapsed),
                registered_domains=domains,
            )))
        return

    # --domain <name> — inspect by name without entering a repo.
    if domain_name is not None:
        try:
            validate_domain_name(domain_name)
        except ValueError as exc:
            print(json.dumps({"error": f"Invalid domain name: {exc}"}), file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        try:
            plugin = resolve_plugin_by_domain(domain_name)
        except Exception as exc:
            print(json.dumps({"error": str(exc)}), file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        active_domain = domain_name
    else:
        root = require_repo()
        active_domain = read_domain(root)
        try:
            plugin = resolve_plugin(root)
        except Exception as exc:
            print(json.dumps({"error": str(exc)}), file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

    plugin_class = type(plugin).__name__

    capabilities: _CapabilitiesDict = {
        "addressed_merge": isinstance(plugin, AddressedMergePlugin),
        "crdt": isinstance(plugin, CRDTPlugin),
        "harmony": isinstance(plugin, HarmonyPlugin),
    }

    # --capabilities-only — skip schema serialisation.
    if capabilities_only:
        if not json_out:
            active_caps = [k for k, v in capabilities.items() if v]
            cap_str = ", ".join(active_caps) if active_caps else "none"
            print(f"Domain:       {sanitize_display(active_domain)}")
            print(f"Capabilities: {cap_str}")
        else:
            print(json.dumps(_DomainInfoCapabilitiesJson(
                **make_envelope(elapsed),
                domain=active_domain,
                capabilities=dict(capabilities),
            )))
        return

    try:
        schema = plugin.schema()
    except Exception as exc:
        logger.debug("domain-info: plugin.schema() failed: %s", exc)
        print(json.dumps({"error": f"Plugin schema error: {exc}"}), file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    all_domains_list = registered_domains()

    if not json_out:
        print(f"Domain:       {sanitize_display(active_domain)}")
        print(f"Plugin:       {sanitize_display(plugin_class)}")
        print(f"Merge mode:   {schema.get('merge_mode', 'unknown')}")
        active_caps = [k for k, v in capabilities.items() if v]
        cap_str = ", ".join(active_caps) if active_caps else "none"
        print(f"Capabilities: {cap_str}")
        print(f"Registered:   {', '.join(all_domains_list)}")
        return

    domain_schema = dict(schema)
    domain_schema["domain"] = active_domain

    print(json.dumps(_DomainInfoFullJson(
        **make_envelope(elapsed),
        domain=active_domain,
        plugin_class=plugin_class,
        capabilities=dict(capabilities),
        domain_schema=domain_schema,
        registered_domains=all_domains_list,
    )))
