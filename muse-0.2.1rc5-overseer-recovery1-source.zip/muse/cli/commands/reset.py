"""``muse reset`` — move HEAD to a prior commit.

Modes::

    --soft   Move the branch pointer only; working tree is untouched.
    --hard   Move the branch pointer AND restore the working tree from the
             target snapshot.  Requires a clean working tree unless ``--force``
             is also passed.

Usage::

    muse reset <ref>              — soft reset (branch pointer only)
    muse reset <ref> --hard       — hard reset (branch + working tree)
    muse reset <ref> --dry-run    — simulate without writing anything

JSON output (``--format json`` or ``--json``)::

    {
      "branch":        "<current-branch>",
      "ref":           "<ref-as-passed>",
      "old_commit_id": "<sha256> | null",
      "new_commit_id": "<sha256>",
      "snapshot_id":   "<sha256>",
      "mode":          "soft | hard",
      "dry_run":       false
    }

Exit codes::

    0 — success (or dry-run with no problems found)
    1 — ref not found, invalid branch name, invalid format
    3 — internal error (snapshot missing from object store)
"""

import argparse
import json
import logging
import sys
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
    write_branch_ref,
)
from muse.core.commits import resolve_commit_ref
from muse.core.snapshots import (
    get_commit_snapshot_manifest,
    read_snapshot,
)
from muse.core.reflog import append_reflog
from muse.core.timing import start_timer
from muse.core.validation import sanitize_display, validate_branch_name
from muse.core.workdir import apply_manifest
from muse.cli.guard import require_clean_workdir

logger = logging.getLogger(__name__)

class _ResetJson(EnvelopeJson):
    """JSON envelope emitted by ``muse reset --json``."""

    branch: str
    ref: str
    old_commit_id: str | None
    new_commit_id: str
    snapshot_id: str
    mode: str
    dry_run: bool

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse reset`` subcommand and all its flags.

    Arguments registered
    --------------------
    ref          Positional. Commit ID or ref to reset to (e.g. ``HEAD~1``, ``abc12345``).
    --hard       Reset branch pointer AND restore the working tree from the target snapshot.
    --soft       Reset branch pointer only, leaving the working tree unchanged (default).
    --force      With ``--hard``: proceed even if the working tree has uncommitted changes.
    --dry-run / -n  Simulate without writing. Still validates ref and returns full JSON.
    --format / -f   Output format: ``text`` (default) or ``json``.
    --json / -j  Shorthand for ``--format json``.
    """
    parser = subparsers.add_parser(
        "reset",
        help="Move HEAD to a prior commit.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("ref", help="Commit ID or ref to reset to (e.g. HEAD~1, a3f2c9).")
    parser.add_argument(
        "--hard", action="store_true",
        help="Reset branch pointer AND restore the working tree from the target snapshot.",
    )
    parser.add_argument(
        "--soft", action="store_true",
        help="Reset branch pointer only, leaving the working tree unchanged (default).",
    )
    parser.add_argument(
        "--force", action="store_true",
        help="With --hard: proceed even if the working tree has uncommitted changes.",
    )
    parser.add_argument(
        "--dry-run", "-n", action="store_true", dest="dry_run",
        help=(
            "Simulate the reset without writing anything. "
            "Reports what would change and validates the target ref."
        ),
    )
    parser.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit machine-readable JSON instead of human text.",
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Move HEAD to a prior commit.

    All error messages are written to **stderr**; stdout is reserved for
    structured output only.  Pass ``--dry-run`` (or ``-n``) to validate the
    target ref and preview without writing anything to disk.

    Agent quickstart::

        muse reset HEAD~1 --json
        muse reset HEAD~1 --hard --json
        muse reset abc123 --dry-run --json
        muse reset HEAD~3 --hard --force --json

    JSON fields::

        branch          str       Current branch name
        ref             str       Ref as passed by the caller
        old_commit_id   str|null  Commit ID before the reset; null if no prior commit
        new_commit_id   str       Commit ID after the reset (target)
        snapshot_id     str       Snapshot ID of the target commit
        mode            str       "soft" | "hard"
        dry_run         bool      True when no writes were made

    Exit codes::

        0  Success (or successful dry-run).
        1  Ref not found, invalid branch name, or invalid format.
        3  Internal error (target snapshot missing from object store).
    """
    elapsed = start_timer()
    ref: str = args.ref
    hard: bool = args.hard
    dry_run: bool = getattr(args, "dry_run", False)
    force: bool = args.force
    json_out: bool = args.json_out

    root = require_repo()
    # Only --hard modifies the working tree; --soft just moves the branch pointer.
    # Dry-run never touches the working tree.
    if hard and not dry_run:
        require_clean_workdir(root, "reset --hard", force=force, json_out=json_out)

    branch = read_current_branch(root)

    try:
        validate_branch_name(branch)
    except ValueError as exc:
        print(
            f"❌ Current branch name is invalid: {sanitize_display(str(exc))}",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    commit = resolve_commit_ref(root, branch, ref)
    if commit is None:
        if json_out:
            print(json.dumps({"error": "ref_not_found", "ref": ref, "message": f"'{ref}' not found"}))
        print(
            f"❌ '{sanitize_display(ref)}' not found.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    # For --hard, validate the snapshot exists BEFORE writing anything to disk.
    # This prevents the critical ordering bug where write_branch_ref() succeeds
    # but apply_manifest() fails, leaving the branch ref pointing at the new
    # commit while the working tree is only partially restored.
    snapshot_id = commit.snapshot_id
    if hard:
        snapshot = read_snapshot(root, snapshot_id)
        if snapshot is None:
            if json_out:
                print(json.dumps({"error": "snapshot_missing", "snapshot_id": snapshot_id, "message": f"snapshot {snapshot_id} not found in object store — aborting to prevent data loss"}))
            print(
                f"❌ Snapshot {snapshot_id} not found in object store "
                "— aborting to prevent data loss.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.INTERNAL_ERROR)
    else:
        snapshot = None

    mode = "hard" if hard else "soft"
    old_commit_id = get_head_commit_id(root, branch)

    # Dry-run: report what would happen without writing anything.
    if dry_run:
        if json_out:
            print(json.dumps(_ResetJson(
                **make_envelope(elapsed),
                branch=branch,
                ref=ref,
                old_commit_id=old_commit_id,
                new_commit_id=commit.commit_id,
                snapshot_id=snapshot_id,
                mode=mode,
                dry_run=True,
            )))
        else:
            label = f"[dry-run] Would reset '{sanitize_display(branch)}'"
            msg_snip = sanitize_display(commit.message.splitlines()[0][:60])
            print(f"{label} ({mode}) to {commit.commit_id} {msg_snip}")
        return

    # Write the branch ref first for --soft (no snapshot dependency).
    # For --hard: snapshot was already validated above — write ref then restore.
    write_branch_ref(root, branch, commit.commit_id)
    append_reflog(
        root, branch, old_id=old_commit_id, new_id=commit.commit_id,
        author="user",
        operation=f"reset ({mode}): moving to {commit.commit_id}",
    )

    if hard and snapshot is not None:
        old_manifest = get_commit_snapshot_manifest(root, old_commit_id) if old_commit_id else {}
        apply_manifest(root, old_manifest or {}, snapshot.manifest)

    if json_out:
        print(json.dumps(_ResetJson(
            **make_envelope(elapsed),
            branch=branch,
            ref=ref,
            old_commit_id=old_commit_id,
            new_commit_id=commit.commit_id,
            snapshot_id=snapshot_id,
            mode=mode,
            dry_run=False,
        )))
    elif hard:
        print(
            f"HEAD is now at {commit.commit_id} "
            f"{sanitize_display(commit.message.splitlines()[0])}"
        )
    else:
        print(f"Moved {sanitize_display(branch)} to {commit.commit_id}")
