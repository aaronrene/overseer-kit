"""``muse cherry-pick`` — apply a specific commit's changes on top of HEAD.

Cherry-pick computes the *delta* introduced by a commit (its snapshot vs its
parent's snapshot), then applies that delta on top of the current HEAD via a
three-way merge.  The result is a new commit that replays the same change in a
different context.

Usage::

    muse cherry-pick <ref>               — apply and commit immediately
    muse cherry-pick <ref> --no-commit   — apply to working tree only
    muse cherry-pick <ref> --dry-run     — simulate without writing anything

JSON output (``--format json`` or ``--json``)::

    {
      "status":           "picked | applied | conflict | dry_run",
      "commit_id":        "<sha256> | null",
      "branch":           "<current-branch>",
      "ref":              "<ref-as-passed>",
      "source_commit_id": "<sha256>",
      "snapshot_id":      "<sha256> | null",
      "message":          "<commit-message>",
      "no_commit":        false,
      "dry_run":          false,
      "conflicts":        [],
      "duration_ms":  0.000123,
      "exit_code":        0
    }

``duration_ms``
    Wall-clock time from argument parsing to output.
``exit_code``
    Mirrors the process exit code: ``0`` for success (picked, applied,
    dry_run) and ``1`` for conflicts.  Lets agents evaluate the result
    without inspecting the process exit code separately.

The schema is identical across all code paths (success, ``--no-commit``,
``--dry-run``, conflict).

Exit codes::

    0 — success (picked, applied to workdir, or dry-run)
    1 — ref not found, conflict, invalid format, invalid branch name
    3 — internal error (unreadable target snapshot)
"""

import argparse
import datetime
import json
import logging
import sys
import time

from muse.core.errors import ExitCode
from muse.core.merge_engine import write_merge_state
from muse.core.reflog import append_reflog
from muse.core.repo import require_repo
from muse.core.ids import hash_commit, hash_snapshot
from muse.core.snapshot import directories_from_manifest
from muse.core.refs import (
    RefConflictError,
    get_head_commit_id,
    read_current_branch,
    write_branch_ref,
)
from muse.core.commits import (
    CommitRecord,
    read_commit,
    resolve_commit_ref,
    write_commit,
)
from muse.core.snapshots import (
    SnapshotRecord,
    get_head_snapshot_manifest,
    read_snapshot,
    write_snapshot,
)
from muse.core.validation import sanitize_display, validate_branch_name
from muse.core.workdir import apply_manifest
from muse.cli.guard import require_clean_workdir
from muse.domain import SnapshotManifest
from muse.plugins.registry import read_domain, resolve_plugin
from muse.core.types import Manifest, short_id
from muse.core.timing import start_timer
from muse.core.envelope import EnvelopeJson, make_envelope
from typing import TypedDict

logger = logging.getLogger(__name__)

class _CherryPickErrorJson(EnvelopeJson):
    """JSON output for cherry-pick error paths."""

    error: str
    message: str

class _CherryPickJson(EnvelopeJson):
    """JSON output for ``muse cherry-pick --json`` success/conflict paths."""

    status: str           # "conflict" | "dry_run" | "applied" | "picked"
    commit_id: str | None
    branch: str
    ref: str
    source_commit_id: str
    snapshot_id: str | None
    message: str
    no_commit: bool
    dry_run: bool
    conflicts: list[str]

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse cherry-pick`` subcommand and all its flags."""
    parser = subparsers.add_parser(
        "cherry-pick",
        help="Apply a specific commit's changes on top of HEAD.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("ref", help="Commit ID (full or prefix) to apply.")
    parser.add_argument(
        "-m", "--message", default=None,
        help="Override the cherry-pick commit message (default: re-uses the source message).",
    )
    parser.add_argument(
        "--no-commit", action="store_true", dest="no_commit",
        help="Apply the changes to the working tree without creating a commit.",
    )
    parser.add_argument(
        "--force", action="store_true",
        help="Proceed even if the working tree has uncommitted changes.",
    )
    parser.add_argument(
        "--dry-run", action="store_true", dest="dry_run",
        help=(
            "Simulate the cherry-pick without writing anything. "
            "Reports what would be applied and whether conflicts would arise."
        ),
    )
    parser.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit machine-readable JSON instead of human text.",
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Apply a specific commit's changes on top of HEAD.

    Computes the delta between ``ref`` and its parent, applies that delta to
    the current HEAD snapshot via a three-way merge.  Use ``--dry-run`` to
    detect conflicts without modifying the working tree.  Use ``--no-commit``
    to stage the result for a subsequent ``muse commit``.

    Agent quickstart
    ----------------
    ::

        muse cherry-pick abc123 --json
        muse cherry-pick abc123 --dry-run --json
        muse cherry-pick abc123 --no-commit --json

    JSON fields
    -----------
    status           Outcome: ``"picked"``, ``"applied"`` (no-commit),
                     ``"conflict"``, or ``"dry_run"``.
    commit_id        New commit ID; ``null`` with ``--no-commit`` or conflicts.
    branch           Current branch name.
    ref              Ref as passed on the command line.
    source_commit_id The commit that was cherry-picked.
    snapshot_id      New snapshot ID; ``null`` on conflict or no-commit.
    message          Commit message used (may differ from source if ``-m`` given).
    no_commit        ``true`` when ``--no-commit`` was passed.
    dry_run          ``true`` when ``--dry-run`` was passed.
    conflicts        List of conflicting file paths (empty on success).

    Exit codes
    ----------
    0  Success (picked, applied to workdir, or dry-run clean).
    1  Ref not found, conflict, or invalid arguments.
    3  Internal error (unreadable target snapshot).
    """
    elapsed = start_timer()
    ref: str = args.ref
    message: str | None = args.message
    no_commit: bool = args.no_commit
    force: bool = args.force
    dry_run: bool = getattr(args, "dry_run", False)
    json_out: bool = args.json_out

    root = require_repo()
    # Dry-run never touches the working tree.
    if not dry_run:
        require_clean_workdir(root, "cherry-pick", force=force, json_out=json_out)
    branch = read_current_branch(root)

    try:
        validate_branch_name(branch)
    except ValueError as exc:
        print(
            f"❌ Current branch name is invalid: {sanitize_display(str(exc))}",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    domain = read_domain(root)
    plugin = resolve_plugin(root)

    target = resolve_commit_ref(root, branch, ref)
    if target is None:
        if json_out:
            print(json.dumps({"error": "commit_not_found", "ref": ref, "message": f"commit '{ref}' not found"}))
        print(
            f"❌ Commit '{sanitize_display(ref)}' not found.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    # Validate the target snapshot before touching the working tree.
    target_snap_rec = read_snapshot(root, target.snapshot_id)
    if target_snap_rec is None:
        if json_out:
            print(json.dumps({"error": "snapshot_missing", "snapshot_id": target.snapshot_id, "commit_id": target.commit_id, "message": f"snapshot {target.snapshot_id} for commit {target.commit_id} not found"}))
        print(
            f"❌ Snapshot {target.snapshot_id} for commit {target.commit_id} not found.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.INTERNAL_ERROR)
    target_manifest = target_snap_rec.manifest

    # Build the base manifest (the parent of the cherry-picked commit).
    # Fail fast if the parent commit is recorded but its data is missing —
    # that indicates object-store corruption, not a legitimate root commit.
    base_manifest: Manifest = {}
    if target.parent_commit_id:
        parent_commit = read_commit(root, target.parent_commit_id)
        if parent_commit is None:
            if json_out:
                print(json.dumps({"error": "corrupt_store", "commit_id": target.parent_commit_id, "message": f"parent commit {target.parent_commit_id} not found — object store may be corrupted"}))
            print(
                f"❌ Parent commit {target.parent_commit_id} not found — "
                "object store may be corrupted.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.INTERNAL_ERROR)
        parent_snap = read_snapshot(root, parent_commit.snapshot_id)
        if parent_snap is None:
            if json_out:
                print(json.dumps({"error": "corrupt_store", "snapshot_id": parent_commit.snapshot_id, "message": f"parent snapshot {parent_commit.snapshot_id} not found — object store may be corrupted"}))
            print(
                f"❌ Parent snapshot {parent_commit.snapshot_id} not found — "
                "object store may be corrupted.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.INTERNAL_ERROR)
        base_manifest = parent_snap.manifest

    ours_manifest = get_head_snapshot_manifest(root, branch) or {}

    base_snap = SnapshotManifest(files=base_manifest, domain=domain, directories=directories_from_manifest(base_manifest))
    ours_snap = SnapshotManifest(files=ours_manifest, domain=domain, directories=directories_from_manifest(ours_manifest))
    target_snap = SnapshotManifest(files=target_manifest, domain=domain, directories=directories_from_manifest(target_manifest))

    result = plugin.merge(base_snap, ours_snap, target_snap)

    # Sanitize the source commit message before embedding it in any stored commit.
    safe_message = sanitize_display(target.message.splitlines()[0])
    commit_message = message or safe_message

    if not result.is_clean:
        # Write merge state so `muse conflicts` and `muse checkout --ours/--theirs`
        # can inspect the conflict without re-running cherry-pick.
        write_merge_state(
            root,
            base_commit=target.parent_commit_id or "",
            ours_commit=get_head_commit_id(root, branch) or "",
            theirs_commit=target.commit_id,
            conflict_paths=result.conflicts,
        )
        if json_out:
            print(json.dumps(_CherryPickJson(
                **make_envelope(elapsed, exit_code=1),
                status="conflict",
                commit_id=None,
                branch=branch,
                ref=ref,
                source_commit_id=target.commit_id,
                snapshot_id=None,
                message=commit_message,
                no_commit=no_commit,
                dry_run=False,
                conflicts=sorted(result.conflicts),
            )))
        else:
            print(
                f"❌ Cherry-pick conflict in {len(result.conflicts)} file(s):",
                file=sys.stderr,
            )
            for p in sorted(result.conflicts):
                print(f"  CONFLICT (both modified): {sanitize_display(p)}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    merged_manifest = result.merged["files"]

    # Dry-run: all validation passed — report and exit without writes.
    if dry_run:
        snapshot_id = hash_snapshot(merged_manifest, directories_from_manifest(merged_manifest))
        if json_out:
            print(json.dumps(_CherryPickJson(
                **make_envelope(elapsed),
                status="dry_run",
                commit_id=None,
                branch=branch,
                ref=ref,
                source_commit_id=target.commit_id,
                snapshot_id=snapshot_id,
                message=commit_message,
                no_commit=no_commit,
                dry_run=True,
                conflicts=[],
            )))
        else:
            print(
                f"[dry-run] Would cherry-pick '{sanitize_display(ref)}' "
                f"({target.commit_id}) on '{sanitize_display(branch)}'"
            )
        return

    if no_commit:
        apply_manifest(root, ours_manifest, merged_manifest)
        if json_out:
            print(json.dumps(_CherryPickJson(
                **make_envelope(elapsed),
                status="applied",
                commit_id=None,
                branch=branch,
                ref=ref,
                source_commit_id=target.commit_id,
                snapshot_id=None,
                message=commit_message,
                no_commit=True,
                dry_run=False,
                conflicts=[],
            )))
        else:
            print(
                f"Applied {target.commit_id} to working tree. "
                f"Run 'muse commit' to record."
            )
        return

    # Correct write ordering for atomicity:
    # 1. Compute snapshot_id and commit_id (pure computation — no I/O).
    # 2. write_snapshot (idempotent — crash here leaves workdir unchanged).
    # 3. write_commit (idempotent — crash here leaves workdir unchanged).
    # 4. apply_manifest (workdir modified only after both objects are durable).
    # 5. write_branch_ref (branch pointer advances last — visible to others only when complete).
    # 6. append_reflog (non-critical audit trail — never blocks success).
    head_commit_id = get_head_commit_id(root, branch)
    manifest = merged_manifest
    manifest_dirs = directories_from_manifest(manifest)
    snapshot_id = hash_snapshot(manifest, manifest_dirs)
    committed_at = datetime.datetime.now(datetime.timezone.utc)
    cherry_author = target.author or ""
    commit_id = hash_commit(
        parent_ids=[head_commit_id] if head_commit_id else [],
        snapshot_id=snapshot_id,
        message=commit_message,
        committed_at_iso=committed_at.isoformat(),
        author=cherry_author,
    )

    write_snapshot(root, SnapshotRecord(snapshot_id=snapshot_id, manifest=manifest, directories=manifest_dirs))
    write_commit(root, CommitRecord(
        commit_id=commit_id,
        branch=branch,
        snapshot_id=snapshot_id,
        message=commit_message,
        committed_at=committed_at,
        parent_commit_id=head_commit_id,
        author=cherry_author,
    ))
    apply_manifest(root, ours_manifest, manifest)
    try:
        write_branch_ref(root, branch, commit_id, expected_id=head_commit_id)
    except RefConflictError as exc:
        print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    append_reflog(
        root, branch, old_id=head_commit_id, new_id=commit_id,
        author="user",
        operation=f"cherry-pick: {sanitize_display(ref)} -> {commit_id}",
    )

    if json_out:
        print(json.dumps(_CherryPickJson(
            **make_envelope(elapsed),
            status="picked",
            commit_id=commit_id,
            branch=branch,
            ref=ref,
            source_commit_id=target.commit_id,
            snapshot_id=snapshot_id,
            message=commit_message,
            no_commit=False,
            dry_run=False,
            conflicts=[],
        )))
    else:
        print(
            f"[{sanitize_display(branch)} {short_id(commit_id)}] "
            f"{sanitize_display(commit_message)}"
        )
