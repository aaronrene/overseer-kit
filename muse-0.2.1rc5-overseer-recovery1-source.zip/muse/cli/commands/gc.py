"""``muse gc`` — garbage-collect unreachable objects.

Content-addressed storage accumulates blobs that no live commit can reach.
These orphaned objects are safe to delete.  ``muse gc`` walks the full commit
graph from every live branch and tag, marks every referenced object as
reachable, then removes the rest.

A grace period (``--grace-period``, default 30 s) prevents deleting objects
written by a concurrent ``muse commit`` that has not yet created its commit
record.

Usage::

    muse gc                           # remove unreachable objects (30 s grace)
    muse gc --full                    # also prune orphaned commits + snapshots
    muse gc --clear-symbol-cache      # delete the symbol cache (forces re-parse)
    muse gc --dry-run                 # show what would be removed, touch nothing
    muse gc --verbose                 # print each removed object ID
    muse gc --grace-period 0          # no grace — useful in tests / CI
    muse gc --json                    # machine-readable output

Exit codes::

    0  — success (even if nothing was collected)
    1  — bad arguments or internal error
"""

import argparse
import json
import logging
import sys
from typing import TypedDict

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.paths import symbol_cache_path as _symbol_cache_path
from muse.core.errors import ExitCode
from muse.core.gc import _DEFAULT_GRACE_PERIOD_SECONDS, _DEFAULT_REFLOG_EXPIRE_DAYS, _DEFAULT_SYMLOG_EXPIRE_DAYS, run_gc, prune_stale_remote_refs
from muse.core.repo import require_repo
from muse.core.timing import start_timer
from muse.core.validation import sanitize_display

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Typed JSON schema
# ---------------------------------------------------------------------------

class _GcJson(EnvelopeJson):
    """JSON output for ``muse gc --json``.

    Inherits the 6 standard envelope fields from :class:`~muse.core.envelope.EnvelopeJson`.
    GC warnings (symlink-skip notices, corrupt snapshot alerts, etc.) are surfaced
    via the envelope ``warnings`` list rather than a separate field.

    Fields
    ------
    status                     "ok" on success; "error" on bad args or internal error.
    error                      Empty on success; error message on failure.
    mode                       "conservative" (default) or "tight" (--full).
    collected_count            Total objects collected.
    collected_bytes            Total bytes freed.
    reachable_count            Total objects still reachable after GC.
    commits_reachable          Reachable commits.
    commits_collected          Commits collected.
    commits_collected_bytes    Bytes freed from commit objects.
    snapshots_reachable        Reachable snapshots.
    snapshots_collected        Snapshots collected.
    snapshots_collected_bytes  Bytes freed from snapshot objects.
    grace_period_seconds       Grace period used (objects newer than this are kept).
    dry_run                    True when no objects were actually deleted.
    full                       True when --full (tight mode) was used.
    collected_ids              Sorted list of all collected object IDs.
    collected_commit_ids       Sorted list of collected commit IDs.
    collected_snapshot_ids     Sorted list of collected snapshot IDs.
    symbol_cache_cleared       True when the symbol cache was cleared.
    symbol_cache_bytes         Bytes freed from the symbol cache.
    """

    status: str
    error: str
    mode: str
    collected_count: int
    collected_bytes: int
    reachable_count: int
    commits_reachable: int
    commits_collected: int
    commits_collected_bytes: int
    snapshots_reachable: int
    snapshots_collected: int
    snapshots_collected_bytes: int
    grace_period_seconds: int
    dry_run: bool
    full: bool
    collected_ids: list[str]
    collected_commit_ids: list[str]
    collected_snapshot_ids: list[str]
    symbol_cache_cleared: bool
    symbol_cache_bytes: int
    stale_remote_refs_collected: int
    stale_remote_refs_bytes: int
    reflog_expired: int
    symlog_expired: int

class _GcErrorJson(EnvelopeJson):
    """JSON error output for ``muse gc --json`` on invalid arguments."""

    status: str
    error: str

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fmt_bytes(n: int) -> str:
    """Human-readable byte count (B / KiB / MiB)."""
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f} KiB"
    return f"{n / (1024 * 1024):.1f} MiB"

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``gc`` subcommand."""
    parser = subparsers.add_parser(
        "gc",
        help="Remove unreachable objects from the Muse object store.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--dry-run", "-n",
        action="store_true",
        help="Show what would be removed without deleting anything.",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Print each object ID that is (or would be) removed.",
    )
    parser.add_argument(
        "--grace-period",
        type=int,
        default=_DEFAULT_GRACE_PERIOD_SECONDS,
        dest="grace_period",
        metavar="SECONDS",
        help=(
            "Skip objects written within the last SECONDS seconds even if "
            "unreachable (protects concurrent commits).  Default: "
            f"{_DEFAULT_GRACE_PERIOD_SECONDS}."
        ),
    )
    parser.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit machine-readable JSON instead of human text.",
    )
    parser.add_argument(
        "--full",
        action="store_true",
        help=(
            "Also prune orphaned commit and snapshot objects from "
            ".muse/objects/sha256/, mirroring git prune.  Reachability "
            "is computed from live branch refs, not all files in the store."
        ),
    )
    parser.add_argument(
        "--clear-symbol-cache",
        action="store_true",
        dest="clear_symbol_cache",
        help=(
            "Delete the symbol cache (.muse/cache/symbols.json).  "
            "Forces a full re-parse on the next ``muse code`` invocation.  "
            "Use this when the cache is stale — e.g. after installing a new "
            "language grammar (tree-sitter-markdown, etc.)."
        ),
    )
    parser.set_defaults(func=run)

# ---------------------------------------------------------------------------
# Command implementation
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Remove unreachable objects from the Muse object store.

    Identifies and removes blobs no longer referenced by any commit, snapshot,
    branch, or tag.  The reachability walk always completes before any deletion
    occurs.  Use ``--full`` to also prune orphaned commits and snapshots;
    ``--dry-run`` to preview without writing.

    Agent quickstart
    ----------------
    ::

        muse gc --json
        muse gc --dry-run --json
        muse gc --full --json
        muse gc --grace-period 0 --json

    JSON fields
    -----------
    status                ``"ok"`` on success.
    mode                  ``"tight"`` (``--full``) or ``"conservative"``.
    collected_count       Number of blobs deleted.
    collected_bytes       Bytes reclaimed from blobs.
    reachable_count       Blobs retained as reachable.
    commits_collected     Commits pruned (``--full`` only).
    snapshots_collected   Snapshots pruned (``--full`` only).
    dry_run               ``true`` if no objects were actually deleted.

    Exit codes
    ----------
    0  Success.
    1  Invalid arguments.
    2  Not inside a Muse repository.
    3  I/O error reading or writing the object store.
    """
    elapsed = start_timer()
    dry_run: bool = args.dry_run
    verbose: bool = args.verbose
    json_out: bool = args.json_out
    grace_period: int = args.grace_period
    full: bool = args.full
    clear_symbol_cache: bool = args.clear_symbol_cache

    if grace_period < 0:
        if json_out:
            print(json.dumps(_GcErrorJson(
                **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                status="error",
                error=f"--grace-period must be \u2265 0 (got {grace_period})",
            )))
        else:
            print(
                f"❌ --grace-period must be ≥ 0 (got {grace_period}).",
                file=sys.stderr,
            )
        raise SystemExit(ExitCode.USER_ERROR)

    repo_root = require_repo()

    # --- Reflog TTL — read from config, fall back to 90 days -----------------
    from muse.cli.config import get_config_value as _get_config_value
    _ttl_raw = _get_config_value("reflog.expire-days", repo_root)
    try:
        reflog_expire_days: int = int(_ttl_raw) if _ttl_raw is not None else _DEFAULT_REFLOG_EXPIRE_DAYS
    except (ValueError, TypeError):
        reflog_expire_days = _DEFAULT_REFLOG_EXPIRE_DAYS

    # --- Symlog TTL — read from config, fall back to 90 days -----------------
    _sl_ttl_raw = _get_config_value("symlog.expire-days", repo_root)
    try:
        symlog_expire_days: int = int(_sl_ttl_raw) if _sl_ttl_raw is not None else _DEFAULT_SYMLOG_EXPIRE_DAYS
    except (ValueError, TypeError):
        symlog_expire_days = _DEFAULT_SYMLOG_EXPIRE_DAYS

    # --- Symbol cache clear --------------------------------------------------
    symbol_cache_cleared = False
    symbol_cache_bytes = 0
    if clear_symbol_cache:
        cache_path = _symbol_cache_path(repo_root)
        if cache_path.is_file():
            symbol_cache_bytes = cache_path.stat().st_size
            if not dry_run:
                cache_path.unlink()
            symbol_cache_cleared = True

    result = run_gc(
        repo_root,
        dry_run=dry_run,
        grace_period_seconds=grace_period,
        full=full,
        reflog_expire_days=reflog_expire_days,
        symlog_expire_days=symlog_expire_days,
    )

    # --- Stale remote tracking ref pruning (--full only) ---------------------
    if full:
        from muse.cli.config import list_remotes
        configured_names = {r["name"] for r in list_remotes(repo_root)}
        prune_stale_remote_refs(repo_root, configured_names, result, dry_run=dry_run)

    if json_out:
        print(json.dumps(_GcJson(
            **make_envelope(elapsed, warnings=result.warnings),
            status="ok",
            error="",
            mode="tight" if full else "conservative",
            collected_count=result.collected_count,
            collected_bytes=result.collected_bytes,
            reachable_count=result.reachable_count,
            commits_reachable=result.commits_reachable,
            commits_collected=result.commits_collected,
            commits_collected_bytes=result.commits_collected_bytes,
            snapshots_reachable=result.snapshots_reachable,
            snapshots_collected=result.snapshots_collected,
            snapshots_collected_bytes=result.snapshots_collected_bytes,
            grace_period_seconds=result.grace_period_seconds,
            dry_run=result.dry_run,
            full=result.full,
            collected_ids=sorted(result.collected_ids),
            collected_commit_ids=sorted(result.collected_commit_ids),
            collected_snapshot_ids=sorted(result.collected_snapshot_ids),
            symbol_cache_cleared=symbol_cache_cleared,
            symbol_cache_bytes=symbol_cache_bytes,
            stale_remote_refs_collected=result.stale_remote_refs_collected,
            stale_remote_refs_bytes=result.stale_remote_refs_bytes,
            reflog_expired=result.reflog_expired,
            symlog_expired=result.symlog_expired,
        )))
        return

    prefix = "[dry-run] " if dry_run else ""
    action = "Would remove" if dry_run else "Removed"

    if verbose and result.collected_ids:
        print(f"{prefix}Unreachable objects:")
        for oid in sorted(result.collected_ids):
            print(f"  {sanitize_display(oid)}")

    print(
        f"{prefix}{action} {result.collected_count} object(s) "
        f"({_fmt_bytes(result.collected_bytes)}) "
        f"in {result.duration_ms:.1f}ms  "
        f"[{result.reachable_count} reachable]"
    )

    if full:
        print(
            f"{prefix}{action} {result.commits_collected} commit(s) "
            f"({_fmt_bytes(result.commits_collected_bytes)})  "
            f"[{result.commits_reachable} reachable]"
        )
        print(
            f"{prefix}{action} {result.snapshots_collected} snapshot(s) "
            f"({_fmt_bytes(result.snapshots_collected_bytes)})  "
            f"[{result.snapshots_reachable} reachable]"
        )
        if result.stale_remote_refs_collected:
            print(
                f"{prefix}{action} {result.stale_remote_refs_collected} stale remote "
                f"tracking ref(s) ({_fmt_bytes(result.stale_remote_refs_bytes)})"
            )

    if symbol_cache_cleared:
        cache_action = "Would clear" if dry_run else "Cleared"
        print(f"{prefix}{cache_action} symbol cache ({_fmt_bytes(symbol_cache_bytes)})")

    if result.reflog_expired:
        reflog_action = "Would expire" if dry_run else "Expired"
        print(f"{prefix}{reflog_action} {result.reflog_expired} reflog entry/entries")

    if result.symlog_expired:
        symlog_action = "Would expire" if dry_run else "Expired"
        print(f"{prefix}{symlog_action} {result.symlog_expired} symlog entry/entries")
