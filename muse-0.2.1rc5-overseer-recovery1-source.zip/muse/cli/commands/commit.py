"""``muse commit`` — record the current workspace state as a new version.

Algorithm
---------
1. Resolve repo root (walk up for ``.muse/``).
2. Read the current branch from ``.muse/HEAD``.
3. Invoke ``plugin.snapshot(root)`` to collect the workspace manifest
   (domain-specific; the code plugin walks tracked source files).
4. If the computed ``snapshot_id`` matches HEAD → "nothing to commit".
5. Compute a deterministic ``commit_id`` = SHA-256 of (parents | snapshot |
   message | timestamp).
6. Write content-addressed blob objects to ``.muse/objects/sha256/``.
7. Write snapshot record to ``.muse/objects/sha256/`` (unified store).
8. Write commit record to ``.muse/objects/sha256/`` (unified store).
9. Advance ``.muse/refs/heads/<branch>`` to the new ``commit_id``.

``--dry-run``
    Perform steps 1–5 (compute snapshot and commit_id) without writing
    anything.  Exits 0 when changes are present, 1 when the tree is clean.
    Combine with ``--json`` for structured preflight output in agent pipelines.

Exit codes::

    0 — commit created, OR nothing to commit (clean tree)
    1 — validation error (no message, unresolved conflicts, clean tree with --dry-run)
    3 — I/O error
"""

import argparse
import datetime
import json
import logging
import os
import pathlib
import re
import sys

from muse.cli.config import get_config_value, get_protected_branches, is_branch_protected
from muse.core.types import long_id, short_id, split_id
from muse.core.errors import ExitCode
from muse.core.merge_engine import clear_merge_state, read_merge_state
from muse.core.object_store import has_object, write_object_from_path
from muse.core.provenance import (
    encode_public_key,
    make_agent_identity,
    provenance_payload,
    sign_commit_record,
)
from muse.core.reflog import append_reflog
from muse.core.symlog import _write_symlogs
from muse.core.repo import require_repo
from muse.core.harmony import record_resolutions as harmony_record_resolutions
from muse.core.ids import hash_commit, hash_snapshot
from muse.core.types import (
    Manifest,
    Metadata,
)
from muse.core.refs import (
    RefConflictError,
    get_head_commit_id,
    read_current_branch,
    write_branch_ref,
)
from muse.core.commits import (
    CommitRecord,
    MissingParentError,
    get_head_snapshot_id,
    read_commit,
    write_commit,
)
from muse.core.snapshots import (
    SnapshotRecord,
    read_snapshot,
    write_snapshot,
)
from muse.core.validation import sanitize_display, sanitize_provenance, validate_branch_name
from muse.core.semver_classifier import classify_delta
from muse.domain import SemVerBump, SnapshotManifest, StagePlugin, StructuredDelta
from muse.plugins.code.stage import read_stage
from muse.plugins.registry import read_domain, resolve_plugin
from muse.core.timing import start_timer
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.hooks import get_status, run_hook_point
from typing import TypedDict

logger = logging.getLogger(__name__)

class _CommitErrorJson(EnvelopeJson):
    """JSON output for commit error paths."""

    error: str
    message: str

class _CommitConflictErrorJson(_CommitErrorJson):
    """JSON output when there are unresolved merge conflicts."""

    conflict_paths: list[str]

class _CommitCleanJson(EnvelopeJson):
    """JSON output when working tree is clean (nothing to commit)."""

    dry_run: bool
    clean: bool
    message: str

class _CommitHookFailedJson(EnvelopeJson):
    """JSON output when an installed pre-commit hook command exits non-zero."""

    error: str
    failed_command: str
    output: str
    message: str

class _CommitFilesChangedJson(TypedDict):
    """File-change counts embedded in commit output."""

    added: int
    modified: int
    deleted: int
    total: int

class _CommitJson(EnvelopeJson):
    """JSON output for ``muse commit --json`` success and dry-run paths."""

    dry_run: bool
    clean: bool
    commit_id: str
    branch: str
    snapshot_id: str
    message: str
    parent_commit_id: str | None
    parent2_commit_id: str | None
    committed_at: str
    author: str
    agent_id: str
    model_id: str
    toolchain_id: str
    sem_ver_bump: str
    breaking_changes: list[str]
    signer_public_key: str
    files_changed: _CommitFilesChangedJson

# Maximum length for author and agent-provenance fields.
# Prevents DoS via arbitrarily long values and keeps commit records bounded.
_MAX_FIELD_LEN = 256
def _normalize_prompt_hash(value: str) -> str:
    """Canonicalize prompt_hash to sha256:<64-hex> or empty string.

    Accepts a bare 64-char hex digest or an already-prefixed sha256: value.
    Any other input is rejected and returns "" — the prompt_hash field must
    be self-describing or absent.
    """
    if not value:
        return ""
    try:
        _, hex_id = split_id(value)
        return long_id(hex_id)
    except ValueError:
        return ""

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse commit`` subcommand and its flags."""
    parser = subparsers.add_parser(
        "commit",
        help="Record the current state as a new version.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "-m", "--message", default=None,
        help="Commit message (required unless --allow-empty is set).",
    )
    parser.add_argument(
        "--allow-empty", action="store_true",
        help="Allow committing with no changes (empty-message commits still warn).",
    )
    parser.add_argument(
        "--dry-run", "-n", action="store_true", dest="dry_run",
        help=(
            "Compute snapshot and commit_id without writing anything.  "
            "Exits 0 when changes exist, 1 when the working tree is clean.  "
            "Combine with --json for structured preflight output in agent pipelines."
        ),
    )
    parser.add_argument(
        "--section", default=None,
        help="Tag this commit with a section label (verse, chorus, bridge…).",
    )
    parser.add_argument(
        "--track", default=None,
        help="Tag this commit with an instrument track (drums, bass, keys…).",
    )
    parser.add_argument(
        "--emotion", default=None,
        help="Attach an emotion label (joyful, melancholic, tense…).",
    )
    parser.add_argument(
        "--author", default=None,
        help="Override the commit author.",
    )
    parser.add_argument(
        "--agent-id", default=None, dest="agent_id",
        help="Agent identity string (overrides MUSE_AGENT_ID env var).",
    )
    parser.add_argument(
        "--model-id", default=None, dest="model_id",
        help="Model identifier for AI agents (overrides MUSE_MODEL_ID env var).",
    )
    parser.add_argument(
        "--toolchain-id", default=None, dest="toolchain_id",
        help="Toolchain string (overrides MUSE_TOOLCHAIN_ID env var).",
    )
    parser.add_argument(
        "--sign", action="store_true",
        help="Ed25519-sign the commit using the agent's stored key (requires --agent-id or MUSE_AGENT_ID).",
    )
    parser.add_argument(
        "--no-verify", action="store_true", dest="no_verify",
        help=(
            "Skip installed pre-commit hooks (musehub#192). Never silent — "
            "the skip is always noted in a 'warnings' entry (JSON) or a "
            "printed line (text mode)."
        ),
    )
    parser.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit machine-readable JSON.",
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Record the current staged state as a new version.

    Snapshots the stage, writes the commit record, and advances the branch
    pointer.  Agent commits must include ``--agent-id``, ``--model-id``, and
    ``--sign`` for full provenance.  Use ``--dry-run`` to preview without
    writing anything.

    Agent quickstart
    ----------------
    ::

        muse commit -m "feat: add X" --agent-id claude-code --model-id claude-sonnet-4-6 --sign --json
        muse commit -m "feat: add X" --dry-run --json

    JSON fields
    -----------
    commit_id          Full ``sha256:…`` commit ID (deterministic).
    branch             Branch the commit was written to.
    snapshot_id        Full ``sha256:…`` snapshot ID.
    message            Commit message.
    parent_commit_id   Parent commit ID; ``null`` for first commit.
    parent2_commit_id  Second parent; ``null`` for non-merge commits.
    committed_at       ISO-8601 timestamp.
    author             Author handle.
    agent_id           Agent identifier (empty string for human commits).
    sem_ver_bump       Inferred bump: ``"major"``, ``"minor"``, ``"patch"``,
                       or ``"none"``.
    breaking_changes   List of addresses of removed public symbols.
    files_changed      ``{added, modified, deleted}`` counts.
    dry_run            ``true`` when ``--dry-run`` was passed.

    Exit codes
    ----------
    0  Commit created; or nothing to commit (clean tree, no ``--dry-run``).
    1  Dry-run with clean tree; or validation error (missing message, conflicts).
    3  I/O error or repository not found.
    """
    elapsed = start_timer()
    message: str | None = args.message
    allow_empty: bool = args.allow_empty
    dry_run: bool = args.dry_run
    section: str | None = args.section
    track: str | None = args.track
    emotion: str | None = args.emotion
    raw_author: str | None = args.author
    agent_id: str | None = args.agent_id
    model_id: str | None = args.model_id
    toolchain_id: str | None = args.toolchain_id
    sign: bool = args.sign
    no_verify: bool = args.no_verify
    json_out: bool = args.json_out

    if message is None and not allow_empty:
        if json_out:
            print(json.dumps(_CommitErrorJson(
                **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                error="no_message",
                message="provide a commit message with -m MESSAGE",
            )))
        print("❌ Provide a commit message with -m MESSAGE.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    if message is None and allow_empty:
        logger.warning(
            "⚠️ --allow-empty used without -m: commit will have an empty message."
        )

    # Sanitize and cap the author field.  An explicit --author override is a
    # potential impersonation vector (an agent could supply a human's name).
    # We strip all C0/DEL/C1 control chars and cap at _MAX_FIELD_LEN.
    # A warning is emitted when the caller explicitly passes --author so the
    # act is always visible in logs.
    author: str | None = (
        sanitize_provenance(raw_author[:_MAX_FIELD_LEN]) if raw_author else None
    )
    if raw_author is not None:
        logger.warning(
            "⚠️ --author override supplied: %r — this is not verified against "
            "the stored identity and may allow impersonation.",
            author,
        )

    root = require_repo()

    # config-based auto-sign: commit.sign = true → behave as if --sign was passed
    if not sign and get_config_value("commit.sign", root) == "true":
        sign = True

    # When no explicit --author is provided, resolve user.handle from
    # identity.toml for the active hub (via get_config_value delegation).
    if author is None:
        identity_handle = get_config_value("user.handle", root)
        if identity_handle:
            author = sanitize_provenance(identity_handle[:_MAX_FIELD_LEN])

    # Read merge state before any writes — needed for conflict check and
    # harmony recording later.
    merge_state = read_merge_state(root)
    if merge_state is not None and merge_state.conflict_paths:
        conflict_paths = sorted(merge_state.conflict_paths)
        if json_out:
            print(json.dumps(_CommitConflictErrorJson(
                **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                error="unresolved_conflicts",
                conflict_paths=conflict_paths,
                message="you have unresolved merge conflicts — resolve them before committing",
            )))
        print(
            "❌ You have unresolved merge conflicts. Resolve them before committing.",
            file=sys.stderr,
        )
        for p in conflict_paths:
            print(f"  both modified: {sanitize_display(p)}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    branch = read_current_branch(root)

    protected = get_protected_branches(root)
    if is_branch_protected(branch, protected):
        msg = f"Branch '{branch}' is protected — commit directly to it is not allowed. Use a feature branch and merge."
        if json_out:
            print(json.dumps({
                **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                "error": "protected_branch",
                "message": msg,
            }))
        print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    parent_id = get_head_commit_id(root, branch)

    # ── Guard: refuse when only unstaged changes exist (no staged entries) ────
    # Matches git behaviour: unstaged tracked modifications are not committed.
    # Exception: no parent commit yet (first commit) — stage not required then.
    # Staging is a code-domain concept; non-code domains commit the full workdir.
    if parent_id and not allow_empty and read_domain(root) == "code":
        stage = read_stage(root)
        if not stage:
            from muse.core.snapshot import diff_workdir_vs_snapshot
            from muse.core.snapshots import get_head_snapshot_manifest
            head_manifest = get_head_snapshot_manifest(root, branch) or {}
            if head_manifest:
                added, modified, deleted, _, _, _ = diff_workdir_vs_snapshot(root, head_manifest)
                if added or modified or deleted:
                    msg = (
                        "No changes staged for commit.\n"
                        "  Use 'muse code add <file>' to stage changes before committing."
                    )
                    if json_out:
                        print(json.dumps(_CommitErrorJson(
                            **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                            error="nothing_staged",
                            message=msg,
                        )))
                    print(f"⚠️  {msg}", file=sys.stderr)
                    raise SystemExit(ExitCode.USER_ERROR)

    plugin = resolve_plugin(root)
    snap = plugin.snapshot(root)
    manifest = snap["files"]
    directories = list(snap.get("directories") or [])
    if not manifest and not allow_empty:
        # An empty snapshot is valid when staged deletions produced it —
        # e.g. `muse rm` removed the last tracked file(s).  Only reject if
        # there are no staged changes at all (truly virgin working tree).
        stage = read_stage(root)
        has_staged_deletions = any(e["mode"] == "D" for e in stage.values())
        if not has_staged_deletions:
            if json_out:
                print(json.dumps(_CommitErrorJson(
                    **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                    error="empty_workdir",
                    message="nothing tracked — working tree is empty",
                )))
            print("⚠️  Nothing tracked — working tree is empty.", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

    snapshot_id = hash_snapshot(manifest, directories)

    if not allow_empty:
        head_snapshot = get_head_snapshot_id(root, branch)
        if head_snapshot == snapshot_id:
            if dry_run:
                if json_out:
                    print(json.dumps(_CommitCleanJson(
                        **make_envelope(elapsed, exit_code=1),
                        dry_run=True,
                        clean=True,
                        message="Nothing to commit, working tree clean",
                    )))
                else:
                    print("Nothing to commit, working tree clean")
                raise SystemExit(1)
            if json_out:
                print(json.dumps(_CommitCleanJson(
                    **make_envelope(elapsed),
                    dry_run=False,
                    clean=True,
                    message="Nothing to commit, working tree clean",
                )))
            else:
                print("Nothing to commit, working tree clean")
            raise SystemExit(ExitCode.SUCCESS)

    committed_at = datetime.datetime.now(datetime.timezone.utc)
    parent_ids = [parent_id] if parent_id else []

    # When completing a conflicted merge, include the second parent so that
    # the merge is recorded as a true two-parent merge commit.  This ensures
    # subsequent merge --dry-run correctly computes the LCA as the resolved
    # merge commit rather than the pre-merge common ancestor, preventing the
    # same conflicts from re-appearing on the next merge attempt.
    merge_parent2: str | None = None
    if merge_state is not None and merge_state.theirs_commit:
        merge_parent2 = merge_state.theirs_commit
        if merge_parent2 not in parent_ids:
            parent_ids = parent_ids + [merge_parent2]

    # Resolve agent provenance: CLI flags take priority over environment vars.
    # 1. Truncate to _MAX_FIELD_LEN chars — prevents DoS via arbitrarily long values.
    # 2. Strip all C0/DEL/C1 control characters — prevents terminal injection
    #    when provenance fields are rendered in display paths (muse log, muse read,
    #    agent dashboards), log-line splitting, and visual spoofing.
    resolved_agent_id = sanitize_provenance(
        (agent_id or os.environ.get("MUSE_AGENT_ID", ""))[:_MAX_FIELD_LEN]
    )
    resolved_model_id = sanitize_provenance(
        (model_id or os.environ.get("MUSE_MODEL_ID", ""))[:_MAX_FIELD_LEN]
    )
    resolved_toolchain_id = sanitize_provenance(
        (toolchain_id or os.environ.get("MUSE_TOOLCHAIN_ID", ""))[:_MAX_FIELD_LEN]
    )
    _raw_prompt_hash = sanitize_provenance(
        os.environ.get("MUSE_PROMPT_HASH", "")[:_MAX_FIELD_LEN]
    )
    resolved_prompt_hash = _normalize_prompt_hash(_raw_prompt_hash)

    # Resolve signing identity early so signer_public_key is bound into the
    # commit ID (v2 formula).  The public key is deterministic from the private
    # key — no side effects from resolving it here.
    signing = None
    pre_signer_public_key = ""
    if sign and resolved_agent_id:
        from muse.cli.config import get_signing_identity
        signing = get_signing_identity(root, agent_id=resolved_agent_id)
        if signing is not None:
            _, pre_signer_public_key = encode_public_key(signing.private_key)
        else:
            logger.warning(
                "No signing identity found for agent %r — commit will be unsigned. "
                "Run `muse auth keygen && muse auth register` to set up a keypair.",
                resolved_agent_id,
            )

    commit_id = hash_commit(
        parent_ids=parent_ids,
        snapshot_id=snapshot_id,
        message=message or "",
        committed_at_iso=committed_at.isoformat(),
        author=author or "",
        signer_public_key=pre_signer_public_key,
    )

    metadata: Metadata = {}
    if section:
        metadata["section"] = section
    if track:
        metadata["track"] = track
    if emotion:
        metadata["emotion"] = emotion

    # Load the parent snapshot manifest once and reuse it for both
    # structured_delta computation and file-count output.  Previously the
    # manifest was loaded independently in each section — two separate
    # read_snapshot() calls per commit.
    parent_manifest: Manifest = {}
    parent_directories: list[str] = []
    if parent_id is not None:
        parent_commit_rec = read_commit(root, parent_id)
        if parent_commit_rec is not None:
            parent_snap_record = read_snapshot(root, parent_commit_rec.snapshot_id)
            if parent_snap_record is not None:
                parent_manifest = dict(parent_snap_record.manifest)
                parent_directories = list(parent_snap_record.directories)

    # Compute a structured delta against the parent snapshot so muse read
    # can display note-level changes without reloading blobs.
    # For the genesis commit (no parent) diff against an empty snapshot so
    # every tracked symbol appears as op=insert — indexers depend on this to
    # record symbol births as op=add rather than op=modify.
    structured_delta: StructuredDelta | None = None
    sem_ver_bump: SemVerBump = "none"
    breaking_changes: list[str] = []
    domain = read_domain(root)
    base_snap = SnapshotManifest(
        files=parent_manifest,
        domain=domain,
        directories=parent_directories,
    )
    try:
        structured_delta = plugin.diff(base_snap, snap, repo_root=root)
    except Exception as exc:
        # plugin.diff() is domain-specific and may fail on unsupported
        # file types.  The commit proceeds without a structured delta;
        # sem_ver_bump defaults to "none".
        logger.debug("plugin.diff() failed — structured delta omitted: %s", exc)
        structured_delta = None

    # Classify the structured delta into a semver bump and breaking-change list.
    if structured_delta is not None:
        classification = classify_delta(structured_delta, repo_root=root)
        sem_ver_bump = classification.bump
        breaking_changes = classification.breaking_addresses
        structured_delta["sem_ver_bump"] = sem_ver_bump
        structured_delta["breaking_changes"] = breaking_changes

    # Compute file-level change counts from the (now single-read) parent manifest.
    files_added    = len(set(manifest) - set(parent_manifest))
    files_deleted  = len(set(parent_manifest) - set(manifest))
    files_modified = sum(
        1 for p in set(manifest) & set(parent_manifest)
        if manifest[p] != parent_manifest[p]
    )

    # ── Pre-commit hooks (musehub#192) ────────────────────────────────────────
    # Never run during --dry-run: dry-run is a pure preview with no writes, and
    # hook commands are arbitrary shell commands that may themselves have side
    # effects — running them speculatively would surprise callers.
    commit_warnings: list[str] = []
    if not dry_run:
        if no_verify:
            commit_warnings.append(
                "Skipped pre-commit hooks (--no-verify)."
            )
        else:
            try:
                hooks_status = get_status(root)
            except ValueError as exc:
                if json_out:
                    print(json.dumps(_CommitErrorJson(
                        **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                        error="hooks_config_invalid",
                        message=str(exc),
                    )))
                print(f"❌ {exc}", file=sys.stderr)
                raise SystemExit(ExitCode.USER_ERROR) from exc

            if hooks_status.state == "defined_not_installed":
                commit_warnings.append(
                    "Hooks are defined in .musehooks.toml but not installed "
                    "for this clone. Run 'muse hooks install' to enable them."
                )
            elif hooks_status.state == "installed":
                hook_result = run_hook_point(root, "pre-commit")
                if not hook_result.passed:
                    msg = (
                        f"pre-commit hook failed: {hook_result.failed_command}"
                    )
                    if json_out:
                        print(json.dumps(_CommitHookFailedJson(
                            **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                            error="pre_commit_hook_failed",
                            failed_command=hook_result.failed_command or "",
                            output=hook_result.output,
                            message=msg,
                        )))
                    print(f"❌ {msg}", file=sys.stderr)
                    if hook_result.output:
                        print(hook_result.output, file=sys.stderr)
                    print(
                        "   Use --no-verify to skip hooks (always logged, never silent).",
                        file=sys.stderr,
                    )
                    raise SystemExit(ExitCode.USER_ERROR)

    # ── Dry-run path — no writes beyond this point ────────────────────────────
    if dry_run:
        if json_out:
            print(json.dumps(_CommitJson(
                **make_envelope(elapsed),
                dry_run=True,
                clean=False,
                commit_id=commit_id,
                branch=branch,
                snapshot_id=snapshot_id,
                message=message or "",
                parent_commit_id=parent_id,
                parent2_commit_id=merge_parent2,
                committed_at=committed_at.isoformat(),
                author=author or "",
                agent_id=resolved_agent_id,
                model_id=resolved_model_id,
                toolchain_id=resolved_toolchain_id,
                sem_ver_bump=sem_ver_bump,
                breaking_changes=breaking_changes,
                signer_public_key=pre_signer_public_key,
                files_changed=_CommitFilesChangedJson(
                    added=files_added,
                    modified=files_modified,
                    deleted=files_deleted,
                    total=files_added + files_modified + files_deleted,
                ),
            )))
        else:
            total = files_added + files_deleted + files_modified
            print(f"[dry-run] [{sanitize_display(branch)} {commit_id}] {sanitize_display(message or '')}")
            if total:
                parts: list[str] = []
                if files_modified:
                    parts.append(f"{files_modified} modified")
                if files_added:
                    parts.append(f"{files_added} added")
                if files_deleted:
                    parts.append(f"{files_deleted} removed")
                print(f" {total} file{'s' if total != 1 else ''} changed ({', '.join(parts)})")
            print(" (dry-run: nothing written)")
        return

    # ── Actual writes ─────────────────────────────────────────────────────────
    # Write objects for every file whose object is not yet in the store.
    # We skip only when the parent manifest has the same ID *and* the object
    # is actually present — parent objects may be absent after a clone without
    # blobs, a gc run, or a prior commit that failed to write them.
    for rel_path, object_id in manifest.items():
        if parent_manifest.get(rel_path) == object_id and has_object(root, object_id):
            continue
        write_object_from_path(root, object_id, root / rel_path)

    write_snapshot(root, SnapshotRecord(snapshot_id=snapshot_id, manifest=manifest, directories=directories))

    signature = ""
    signer_public_key = pre_signer_public_key
    signer_key_id = ""
    if signing is not None:
        result = sign_commit_record(
            commit_id,
            resolved_agent_id,
            signing.private_key,
            author=author or "",
            model_id=resolved_model_id,
            toolchain_id=resolved_toolchain_id,
            prompt_hash=resolved_prompt_hash,
            committed_at=committed_at.isoformat(),
        )
        if result is not None:
            signature, signer_public_key, signer_key_id = result

    _commit_record = CommitRecord(
        commit_id=commit_id,
        branch=branch,
        snapshot_id=snapshot_id,
        message=message or "",
        committed_at=committed_at,
        parent_commit_id=parent_id,
        parent2_commit_id=merge_parent2,
        author=author or "",
        metadata=metadata,
        structured_delta=structured_delta,
        sem_ver_bump=sem_ver_bump,
        breaking_changes=breaking_changes,
        agent_id=resolved_agent_id,
        model_id=resolved_model_id,
        toolchain_id=resolved_toolchain_id,
        prompt_hash=resolved_prompt_hash,
        signature=signature,
        signer_public_key=signer_public_key,
        signer_key_id=signer_key_id,
    )
    try:
        write_commit(root, _commit_record)
    except MissingParentError:
        write_commit(root, _commit_record, skip_parent_check=True)

    try:
        write_branch_ref(root, branch, commit_id, expected_id=parent_id)
    except RefConflictError as exc:
        msg = str(exc)
        if json_out:
            print(json.dumps(_CommitErrorJson(
                **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                error="branch_conflict",
                message=msg,
            )))
        print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    # Clear the stage after a successful commit so the next muse commit
    # returns to full-snapshot mode unless the user runs muse code add again.
    # Wrapped in try/except: clear_stage failure must not hide a successful
    # commit.  A failure here leaves staged index entries for already-committed
    # content — the next muse status would show them as staged, and a naive
    # re-commit would produce a duplicate commit with identical snapshot_id.
    # Logging the error is sufficient; the commit is already durable.
    if isinstance(plugin, StagePlugin):
        try:
            plugin.clear_stage(root)
        except Exception as _clear_exc:
            logger.warning(
                "⚠️ clear_stage failed after successful commit %s — "
                "stage index may still list committed files: %s",
                commit_id, _clear_exc,
            )

    append_reflog(
        root,
        branch,
        old_id=parent_id,
        new_id=commit_id,
        author=author or "unknown",
        operation=f"commit: {sanitize_display(message or '(no message)')}",
    )

    try:
        _write_symlogs(
            root,
            parent_commit_id=parent_id,
            new_snapshot_id=snapshot_id,
            new_commit_id=commit_id,
            author=author or "unknown",
            commit_message=message or "",
        )
    except Exception as _symlog_exc:
        logger.warning(
            "⚠️ symlog write failed for commit %s — symbol journal may be incomplete: %s",
            commit_id, _symlog_exc,
        )

    # If this commit completed a conflicted merge, record how each conflict
    # was resolved so harmony can replay it on future identical conflicts.
    # clear_merge_state is unconditional — harmony recording is optional
    # bookkeeping, but cleanup must always happen after a successful commit.
    if merge_state is not None:
        if merge_state.ours_commit and merge_state.theirs_commit:
            def _manifest_for(cid: str) -> Manifest:
                cr = read_commit(root, cid)
                if cr is None:
                    return {}
                snap_rec = read_snapshot(root, cr.snapshot_id)
                return snap_rec.manifest if snap_rec else {}

            ours_manifest = _manifest_for(merge_state.ours_commit)
            theirs_manifest = _manifest_for(merge_state.theirs_commit)
            domain = read_domain(root)
            # Use original_conflict_paths so harmony learns even when all conflicts
            # were resolved via `muse checkout --ours/--theirs` before commit
            # (which clears conflict_paths but preserves original_conflict_paths).
            all_conflict_paths = (
                merge_state.original_conflict_paths or merge_state.conflict_paths
            )
            harmony_record_resolutions(
                root,
                list(all_conflict_paths),
                ours_manifest,
                theirs_manifest,
                manifest,
                domain,
                plugin,
                manually_resolved=set(merge_state.manually_resolved) if merge_state.manually_resolved else None,
            )
        clear_merge_state(root)

    # ── Output ────────────────────────────────────────────────────────────────
    if json_out:
        print(json.dumps(_CommitJson(
            **make_envelope(elapsed, warnings=commit_warnings),
            dry_run=False,
            clean=False,
            commit_id=commit_id,
            branch=branch,
            snapshot_id=snapshot_id,
            message=message or "",
            parent_commit_id=parent_id,
            parent2_commit_id=merge_parent2,
            committed_at=committed_at.isoformat(),
            author=author or "",
            agent_id=resolved_agent_id,
            model_id=resolved_model_id,
            toolchain_id=resolved_toolchain_id,
            sem_ver_bump=sem_ver_bump,
            breaking_changes=breaking_changes,
            signer_public_key=signer_public_key,
            files_changed=_CommitFilesChangedJson(
                added=files_added,
                modified=files_modified,
                deleted=files_deleted,
                total=files_added + files_modified + files_deleted,
            ),
        )))
    else:
        print(f"[{sanitize_display(branch)} {commit_id}] {sanitize_display(message or '')}")
        total_files = files_added + files_deleted + files_modified
        if total_files:
            stat_parts: list[str] = []
            if files_modified:
                stat_parts.append(f"{files_modified} modified")
            if files_added:
                stat_parts.append(f"{files_added} added")
            if files_deleted:
                stat_parts.append(f"{files_deleted} removed")
            print(f" {total_files} file{'s' if total_files != 1 else ''} changed ({', '.join(stat_parts)})")
        for w in commit_warnings:
            print(f"⚠️  {w}", file=sys.stderr)
