"""muse path — HD derivation path tooling.

Subcommands::

    muse path annotate <path>   Decode a raw HD path to human-readable form.

Example (six-level, pre-Phase-2, or seven-level hub-scoped — musehub#221)::

    $ muse path annotate "m/1075233755'/1660078172'/0'/0'/0'/0'"
    purpose:      muse (1075233755)
    domain:       muse/identity (1660078172)
    entity_type:  human (0)
    entity_id:    0
    role:         sign (0)
    index:        0

    $ muse path annotate "m/1075233755'/1660078172'/0'/0'/0'/1449979433'/0'"
    purpose:      muse (1075233755)
    domain:       muse/identity (1660078172)
    entity_type:  human (0)
    entity_id:    0
    role:         sign (0)
    hub:          1449979433
    index:        0

JSON schema for ``muse path annotate --json``::

    {
      "raw_path":     "m/1075233755'/1660078172'/0'/0'/0'/1449979433'/0'",
      "purpose":      "muse",
      "purpose_idx":  1075233755,
      "domain":       "muse/identity",
      "domain_idx":   1660078172,
      "domain_registered": true,
      "entity_type":  "human",
      "entity_type_idx": 0,
      "entity_id":    0,
      "role":         "sign",
      "role_idx":     0,
      "hub_idx":      1449979433,
      "hub_scoped":   true,
      "index":        0
    }

``hub_idx`` is ``null`` and ``hub_scoped`` is ``false`` for six-level paths
that predate hub scoping. Unrecognised integers are rendered as their raw
value with a ``?`` suffix.
"""

import argparse
import json
import re
import sys
from typing import TypedDict

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.paths import user_domain_registry_path
from muse.core.slip010 import MUSE_PURPOSE
from muse.core.timing import start_timer
from muse.core.types import load_json_file

# Inline the lookup to avoid circular imports — domain_cmd is not a lib.
import hashlib
import os
import pathlib

class _DomainSeed(TypedDict):
    name: str
    index: int


# ---------------------------------------------------------------------------
# Known constant maps
# ---------------------------------------------------------------------------

_ENTITY_NAMES: dict[int, str] = {
    0: "human",
    1: "agent",
    2: "org",
}

_ROLE_NAMES: dict[int, str] = {
    0: "sign",
    1: "receive",
    2: "provision",
    3: "attest",
    4: "delegate",
}

_SEED_DOMAINS: list[_DomainSeed] = [
    {"name": "muse/identity",   "index": 1660078172},
    {"name": "muse/payments",   "index": 284229149},
    {"name": "muse/code",       "index": 678195575},
    {"name": "muse/music",      "index": 1755707987},
    {"name": "muse/midi",       "index": 1444628350},
    {"name": "muse/blockchain", "index": 1556829714},
    {"name": "muse/generic",    "index": 2023564266},
]

def _load_domain_map() -> dict[int, str]:
    """Return index → name map from the registry, falling back to the seed."""
    paths = [
        os.environ.get("MUSE_DOMAIN_REGISTRY", ""),
        str(user_domain_registry_path()),
    ]
    for p in paths:
        if p:
            data = load_json_file(pathlib.Path(p))
            if isinstance(data, dict):
                return {e["index"]: e["name"] for e in data.get("domains", [])}
    return {e["index"]: e["name"] for e in _SEED_DOMAINS}

# ---------------------------------------------------------------------------
# Path parser
# ---------------------------------------------------------------------------

_PATH_RE = re.compile(r"^m((?:/\d+'?)+)$")
_SEGMENT_RE = re.compile(r"/(\d+)'?")

class _PathAnnotation(TypedDict):
    raw_path: str
    purpose: str
    purpose_idx: int
    domain: str
    domain_idx: int
    domain_registered: bool
    entity_type: str
    entity_type_idx: int
    entity_id: int
    role: str
    role_idx: int
    hub_idx: int | None
    hub_scoped: bool
    index: int


def _annotate(raw: str) -> _PathAnnotation:
    m = _PATH_RE.match(raw.strip())
    segments = [int(s) for s in _SEGMENT_RE.findall(m.group(1))] if m else []
    # Six levels: purpose/domain/entity_type/entity_id/role/index (pre-Phase-2).
    # Seven levels: same, with a hub segment inserted before index (musehub#221).
    if len(segments) not in (6, 7):
        raise ValueError(
            f"Cannot parse path {raw!r}. "
            "Expected format: m/<purpose>'/<domain>'/<entity_type>'/<entity_id>'/<role>'/[<hub>'/]<index>'"
        )
    purpose_idx, domain_idx, et_idx, entity_id, role_idx = segments[:5]
    hub_idx: int | None = segments[5] if len(segments) == 7 else None
    index = segments[-1]

    domain_map = _load_domain_map()

    purpose_name = "muse" if purpose_idx == MUSE_PURPOSE else f"{purpose_idx}?"
    domain_name = domain_map.get(domain_idx, f"{domain_idx}?")
    domain_registered = domain_idx in domain_map
    entity_name = _ENTITY_NAMES.get(et_idx, f"{et_idx}?")
    role_name = _ROLE_NAMES.get(role_idx, f"{role_idx}?")

    return {
        "raw_path": raw.strip(),
        "purpose": purpose_name,
        "purpose_idx": purpose_idx,
        "domain": domain_name,
        "domain_idx": domain_idx,
        "domain_registered": domain_registered,
        "entity_type": entity_name,
        "entity_type_idx": et_idx,
        "entity_id": entity_id,
        "role": role_name,
        "role_idx": role_idx,
        "hub_idx": hub_idx,
        "hub_scoped": hub_idx is not None,
        "index": index,
    }

# ---------------------------------------------------------------------------
# Subcommand: annotate
# ---------------------------------------------------------------------------

def _run_annotate(args: argparse.Namespace) -> None:
    elapsed = start_timer()
    try:
        result = _annotate(args.path)
    except ValueError as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    if args.json_out:
        print(json.dumps({**make_envelope(elapsed), **result}))
    else:
        print(f"purpose:      {result['purpose']} ({result['purpose_idx']})")
        reg = "" if result["domain_registered"] else " [unregistered]"
        print(f"domain:       {result['domain']} ({result['domain_idx']}){reg}")
        print(f"entity_type:  {result['entity_type']} ({result['entity_type_idx']})")
        print(f"entity_id:    {result['entity_id']}")
        print(f"role:         {result['role']} ({result['role_idx']})")
        if result["hub_scoped"]:
            print(f"hub:          {result['hub_idx']}")
        print(f"index:        {result['index']}")

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse path`` namespace."""
    parser = subparsers.add_parser(
        "path",
        help="HD derivation path tooling — annotate raw paths to human-readable form.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    path_subs = parser.add_subparsers(dest="path_subcmd", metavar="SUBCMD")
    path_subs.required = True

    # ── annotate ───────────────────────────────────────────────────────
    p_annotate = path_subs.add_parser(
        "annotate",
        help="Decode a raw HD path to human-readable form.",
    )
    p_annotate.add_argument(
        "path",
        help="Raw HD path, e.g. \"m/1075233755'/1660078172'/0'/0'/0'/0'\".",
    )
    p_annotate.add_argument("--json", "-j", action="store_true", dest="json_out")
    p_annotate.set_defaults(func=_run_annotate)
