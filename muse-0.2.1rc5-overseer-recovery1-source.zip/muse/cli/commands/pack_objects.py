"""muse pack-objects — build a MPack and write to stdout.

Collects a set of commits (and all referenced snapshots and objects) into a
single msgpack MPack suitable for transport to a remote.  Efficient binary
encoding with raw bytes for object content (no base64 overhead).

Usage::

    muse pack-objects <want_id>... [--have <id>...]

The ``--have`` IDs are commits the receiver already has.  Objects reachable
exclusively from ``--have`` ancestors are pruned from the mpack.

Output: a MPack msgpack binary written to stdout (pipe to a file or HTTP
request body).

Output contract
---------------

- Exit 0: pack written to stdout.
- Exit 1: a wanted commit not found or HEAD has no commits.
- Exit 3: I/O error reading objects or snapshots from the local store.

Agent use — dry-run inspection
-------------------------------

Agents can inspect what *would* be packed without producing binary output::

    muse pack-objects HEAD --dry-run
    # → {
    #     "want": [...], "have": [...],
    #     "commits": 3, "snapshots": 3, "blobs": 12, "object_bytes": 40960,
    #     "duration_ms": 4.2, "exit_code": 0
    #   }

``object_bytes`` is the total uncompressed byte size of all object payloads in
the pack.  Agents use it to decide whether to buffer the full mpack in memory
or stream it directly to the remote.
"""

import argparse
import json
import logging
import sys
from typing import TypedDict

import msgpack

from muse.core.errors import ExitCode
from muse.core.mpack import build_mpack
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.repo import require_repo
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.validation import validate_object_id
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Wire-format TypedDicts
# ---------------------------------------------------------------------------

class _PackObjectsDryRunJson(EnvelopeJson):
    """Stable JSON envelope for ``pack-objects --dry-run`` output."""
    want: list[str]
    have: list[str]
    commits: int
    snapshots: int
    blobs: int
    object_bytes: int

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the pack-objects subcommand."""
    parser = subparsers.add_parser(
        "pack-objects",
        help="Build a MPack from wanted commits and write to stdout.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "want",
        nargs="+",
        help="Commit IDs to pack. May be full hex IDs or 'HEAD'.",
    )
    parser.add_argument(
        "--have",
        action="append",
        default=[],
        dest="have",
        metavar="COMMIT_ID",
        help="Commits the receiver already has (pruned from pack). Repeat for multiple.",
    )
    parser.add_argument(
        "--dry-run", "-n",
        action="store_true",
        dest="dry_run",
        help=(
            "Print pack summary as JSON instead of writing binary msgpack. "
            "Includes elapsed(), exit_code, and object_bytes for agent pipelines."
        ),
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON.",
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Build a MPack from wanted commits and write to stdout.

    Traverses the commit graph from each ``want`` ID, collecting all commits,
    snapshots, and objects not already reachable from ``--have`` ancestors.
    The resulting binary mpack can be piped to ``muse unpack-objects`` or sent
    to a MuseHub endpoint.  Use ``--dry-run`` for a JSON summary without binary
    output — shows ``object_bytes`` so agents can size the transfer first.

    Agent quickstart
    ----------------
    ::

        muse pack-objects HEAD --dry-run --json
        muse pack-objects sha256:<id> --dry-run --json
        muse pack-objects HEAD --have sha256:<base> --dry-run --json

    JSON fields (``--dry-run`` only — binary output otherwise)
    -----------------------------------------------------------
    want          Resolved want commit IDs.
    have          Have commit IDs excluded from the pack.
    commits       Number of commits included.
    snapshots     Number of snapshots included.
    objects       Number of content objects included.
    object_bytes  Total uncompressed payload bytes.

    Exit codes
    ----------
    0  Success.
    1  Invalid want/have IDs, or HEAD has no commits.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    want: list[str] = args.want
    have: list[str] = args.have
    dry_run: bool = args.dry_run

    root = require_repo()

    # Resolve "HEAD" → commit ID and validate all other IDs upfront so
    # we fail loudly instead of silently producing empty packs.
    resolved_wants: list[str] = []
    for w in want:
        if w.upper() == "HEAD":
            branch = read_current_branch(root)
            cid = get_head_commit_id(root, branch)
            if cid is None:
                print(json.dumps({"error": "HEAD has no commits"}), file=sys.stderr)
                raise SystemExit(ExitCode.USER_ERROR)
            resolved_wants.append(cid)
        else:
            try:
                validate_object_id(w)
            except ValueError as exc:
                print(json.dumps({"error": f"Invalid want ID: {exc}"}), file=sys.stderr)
                raise SystemExit(ExitCode.USER_ERROR)
            resolved_wants.append(w)

    for h in have:
        try:
            validate_object_id(h)
        except ValueError as exc:
            print(json.dumps({"error": f"Invalid --have ID: {exc}"}), file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

    mpack = build_mpack(root, commit_ids=resolved_wants, have=have)

    if dry_run:
        object_bytes = sum(
            len(obj["content"]) if isinstance(obj.get("content"), (bytes, bytearray)) else 0
            for obj in mpack["blobs"]
        )
        print(json.dumps(_PackObjectsDryRunJson(
            **make_envelope(elapsed),
            want=resolved_wants,
            have=have,
            commits=len(mpack["commits"]),
            snapshots=len(mpack["snapshots"]),
            blobs=len(mpack["blobs"]),
            object_bytes=object_bytes,
        )))
        return

    sys.stdout.buffer.write(msgpack.packb(mpack, use_bin_type=True))
