"""muse commit-tree — create a commit from an explicit snapshot ID.

Low-level commit creation: takes a snapshot ID (which must already exist in the
store), optional parent commit IDs, and a message, and writes a new
``CommitRecord`` to the store.  Does not touch ``HEAD`` or any branch ref.

Commands like ``muse commit`` call this internally after staging changes and
writing the snapshot.

Output (JSON, default)::

    {
      "commit_id":          "sha256:<64hex>",
      "snapshot_id":        "sha256:<64hex>",
      "branch":             "main",
      "message":            "feat: add melody",
      "committed_at":       "2026-03-18T12:00:00+00:00",
      "author":             "gabriel",
      "agent_id":           "counterpoint-bot",
      "model_id":           "claude-opus-4",
      "toolchain_id":       "cursor-agent-v2",
      "parent_commit_id":   "sha256:<64hex> | null",
      "parent2_commit_id":  null,
      "duration_ms":    0.003,
      "exit_code":          0
    }

Output (``--format text``)::

    sha256:<64hex>

Output contract
---------------

- Exit 0: commit written, commit record printed.
- Exit 1: snapshot not found, parent commit not found, or repo.json unreadable.
- Exit 3: write failure.

``agent_id`` / ``model_id`` / ``toolchain_id``
    Provenance fields embedded in the commit record.  Empty string when not
    supplied.  Agents should always set these so their identity is auditable.

``duration_ms``
    Wall-clock time from argument parsing to output.

``exit_code``
    Mirrors the process exit code (always ``0`` in the success path).

Agent use
---------

Agents must stamp their identity into every commit they create::

    muse commit-tree \\
        --snapshot <snap_id> \\
        --message "feat: add melody" \\
        --agent-id counterpoint-bot \\
        --model-id claude-opus-4 \\
        --toolchain-id cursor-agent-v2

Up to two parents are supported (for merge commits)::

    muse commit-tree --snapshot <id> --parent <p1> --parent <p2>
"""

import argparse
import datetime
import json
import logging
import sys
import time

from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.ids import hash_commit
from muse.core.refs import read_current_branch
from muse.core.commits import (
    CommitRecord,
    read_commit,
    write_commit,
)
from muse.core.snapshots import read_snapshot
from muse.core.validation import validate_object_id
from muse.core.timing import start_timer
from muse.core.envelope import EnvelopeJson, make_envelope
from typing import TypedDict

logger = logging.getLogger(__name__)

class _CommitTreeErrorJson(EnvelopeJson):
    """JSON output for ``muse commit-tree`` error paths."""

    error: str

class _CommitTreeJson(EnvelopeJson):
    """JSON output for ``muse commit-tree --json``."""

    commit_id: str
    snapshot_id: str
    branch: str
    message: str
    committed_at: str
    author: str
    agent_id: str
    model_id: str
    toolchain_id: str
    parent_commit_id: str | None
    parent2_commit_id: str | None

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the commit-tree subcommand."""
    parser = subparsers.add_parser(
        "commit-tree",
        help="Create a commit from an explicit snapshot ID.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--snapshot", "-s",
        required=True,
        dest="snapshot_id",
        metavar="SNAPSHOT_ID",
        help="SHA-256 snapshot ID.",
    )
    parser.add_argument(
        "--parent", "-p",
        action="append",
        default=[],
        dest="parent",
        metavar="COMMIT_ID",
        help=(
            "Parent commit ID. Repeat once for merge commits. "
            "At most two parents are supported."
        ),
    )
    parser.add_argument(
        "--message", "-m",
        default="",
        dest="message",
        metavar="MESSAGE",
        help="Commit message.",
    )
    parser.add_argument(
        "--author", "-a",
        default="",
        dest="author",
        metavar="AUTHOR",
        help="Author name.",
    )
    parser.add_argument(
        "--branch", "-b",
        default=None,
        dest="branch",
        metavar="BRANCH",
        help="Branch name to record (default: current branch).",
    )
    # Agent provenance — agents must set these so their identity is auditable.
    parser.add_argument(
        "--agent-id",
        default="",
        dest="agent_id",
        metavar="AGENT_ID",
        help="Stable agent identifier (e.g. 'counterpoint-bot').",
    )
    parser.add_argument(
        "--model-id",
        default="",
        dest="model_id",
        metavar="MODEL_ID",
        help="Model identifier (e.g. 'claude-opus-4'). Empty for human authors.",
    )
    parser.add_argument(
        "--toolchain-id",
        default="",
        dest="toolchain_id",
        metavar="TOOLCHAIN_ID",
        help="Toolchain that produced this commit (e.g. 'cursor-agent-v2').",
    )
    parser.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Shorthand for --format json.",
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Create a commit record from an explicit snapshot ID.

    The snapshot must already exist in the unified object store.  The commit is
    written to ``.muse/objects/sha256/`` but no branch ref is updated — use
    ``muse update-ref`` to advance a branch.  At most two parents (linear or
    merge).  Always pass ``--agent-id``, ``--model-id``, ``--toolchain-id`` for
    auditable agent provenance.

    Agent quickstart
    ----------------
    ::

        muse commit-tree sha256:<snap-id> -m "feat: X" --agent-id claude-code --model-id claude-sonnet-4-6 --json
        muse commit-tree sha256:<snap-id> -m "merge" --parent sha256:<a> --parent sha256:<b> --json

    JSON fields
    -----------
    commit_id          Full ``sha256:…`` commit ID written.
    snapshot_id        Snapshot ID used.
    branch             Branch context (not updated).
    message            Commit message.
    committed_at       ISO-8601 timestamp.
    author             Author handle.
    agent_id           Agent identifier.
    model_id           Model identifier.
    toolchain_id       Toolchain identifier.
    parent_commit_id   First parent; ``null`` for root commits.
    parent2_commit_id  Second parent; ``null`` for non-merge commits.

    Exit codes
    ----------
    0  Commit record created.
    1  Invalid snapshot ID, too many parents, or validation error.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    snapshot_id: str = args.snapshot_id
    parent: list[str] = args.parent
    message: str = args.message
    author: str = args.author
    branch: str | None = args.branch
    agent_id: str = args.agent_id
    model_id: str = args.model_id
    toolchain_id: str = args.toolchain_id
    # CommitRecord only supports two parents (regular and merge).
    if len(parent) > 2:
        print(
            json.dumps({"error": f"At most 2 parents supported; got {len(parent)}."}),
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()

    try:
        validate_object_id(snapshot_id)
    except ValueError as exc:
        print(json.dumps({"error": f"Invalid snapshot ID: {exc}"}), file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    for pid in parent:
        try:
            validate_object_id(pid)
        except ValueError as exc:
            print(json.dumps({"error": f"Invalid parent commit ID: {exc}"}), file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

    snap = read_snapshot(root, snapshot_id)
    if snap is None:
        print(json.dumps({"error": f"Snapshot not found: {snapshot_id}"}), file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    for pid in parent:
        if read_commit(root, pid) is None:
            print(json.dumps({"error": f"Parent commit not found: {pid}"}), file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

    branch_name = branch or read_current_branch(root)
    committed_at = datetime.datetime.now(datetime.timezone.utc)

    commit_id = hash_commit(
        parent_ids=parent,
        snapshot_id=snapshot_id,
        message=message,
        committed_at_iso=committed_at.isoformat(),
        author=author or "",
    )

    record = CommitRecord(
        commit_id=commit_id,
        branch=branch_name,
        snapshot_id=snapshot_id,
        message=message,
        committed_at=committed_at,
        author=author,
        parent_commit_id=parent[0] if len(parent) >= 1 else None,
        parent2_commit_id=parent[1] if len(parent) >= 2 else None,
        agent_id=agent_id,
        model_id=model_id,
        toolchain_id=toolchain_id,
    )
    write_commit(root, record)

    if not json_out:
        print(commit_id)
        return

    print(json.dumps(_CommitTreeJson(
        **make_envelope(elapsed),
        commit_id=commit_id,
        snapshot_id=snapshot_id,
        branch=branch_name,
        message=message,
        committed_at=committed_at.isoformat(),
        author=author,
        agent_id=agent_id,
        model_id=model_id,
        toolchain_id=toolchain_id,
        parent_commit_id=parent[0] if len(parent) >= 1 else None,
        parent2_commit_id=parent[1] if len(parent) >= 2 else None,
    )))
