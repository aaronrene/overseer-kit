"""``muse merge-tree <branch1> <branch2>`` — three-way merge without touching the working tree.

Computes the merged manifest of two branches entirely in memory and returns
the result as structured data.  Nothing is written to the working tree, HEAD,
any branch ref, or MERGE_STATE.json — this command is a pure computation.

Output (text, default)::

    Merge base:  <commit_id>
    branch1:     <commit_id>  (<branch1>)
    branch2:     <commit_id>  (<branch2>)

    Merged files: 14
    Conflicts:    0
    Result:       trivially merged

    CONFLICT  shared.py       (both modified)

JSON (``--json``)::

    {
      "base": "<commit_id>",
      "branch1": "<commit_id>",
      "branch2": "<commit_id>",
      "conflicts": ["shared.py"],
      "merged_manifest": {"src/foo.py": "<object_id>", "shared.py": null},
      "trivially_merged": false,
      "duration_ms": 1.2,
      "exit_code": 1
    }

With ``--write-objects`` the merged snapshot is also written to the object
store and its ID is included::

    {"snapshot_id": "<snapshot_id>", "duration_ms": 0.8, "exit_code": 0, ...}

Agent workflow::

    muse merge-tree feature dev --json
    # → check conflicts == [] and exit_code == 0
    muse commit-tree <snapshot_id> -m "merge feature into dev"

Flags
-----
``--base <ref>``
    Override the automatically computed merge base (LCA).  Useful when the
    caller already knows the common ancestor and wants to skip BFS.  Accepts
    branch names or sha256:-prefixed commit IDs.

``--write-objects``
    Write the merged snapshot to ``.muse/objects/sha256/`` so the caller can
    reference it in a subsequent ``muse commit-tree``.  Only the snapshot
    record is written; no commit, no branch update, no working-tree changes.

``--json``
    Emit a single JSON object on stdout.  In this mode all errors also go to
    stdout as JSON — stderr will be empty.  Agents should parse stdout and
    check ``exit_code``.

Output contract
---------------

- ``exit_code`` 0: clean merge (zero conflicts).
- ``exit_code`` 1: merge has conflicts or a ref cannot be resolved.
- ``exit_code`` 2: usage error (bad ref name, ANSI injection).
- ``elapsed()``: wall-clock milliseconds for the merge computation.

JSON error schema (--json mode)::

    {
      "status":    "error",
      "error":     "<human-readable message>",
      "exit_code": <int>
    }

Exit codes::

    0 — merge is clean (zero conflicts)
    1 — merge has conflicts or a ref cannot be resolved
    2 — usage error (bad ref name, ANSI injection)
"""

import argparse
import json as _json
import logging
import pathlib
import re
import sys
from typing import TypedDict

from muse.core.types import load_json_file
from muse.core.paths import ref_path as _ref_path, repo_json_path as _repo_json_path
from muse.core.errors import ExitCode
from muse.core.merge_engine import (
    apply_merge,
    detect_conflicts,
    diff_snapshots,
    find_merge_base,
)
from muse.core.repo import require_repo
from muse.core.refs import read_ref
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import read_commit
from muse.core.snapshots import read_snapshot
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.validation import sanitize_display, validate_object_id
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

# Allow alphanumeric, underscore, slash, dot, hyphen, plus full sha256:-prefixed commit IDs.
_SAFE_REF_RE = re.compile(r"^(sha256:[0-9a-f]{64}|[a-zA-Z0-9_/.\-]+)$")

# ---------------------------------------------------------------------------
# Wire-format TypedDicts
# ---------------------------------------------------------------------------

class _MergeTreeJsonBase(EnvelopeJson):
    """Stable JSON envelope for merge-tree results.

    Inherits the 6 standard envelope fields from :class:`~muse.core.envelope.EnvelopeJson`.
    """
    base: str
    branch1: str
    branch2: str
    conflicts: list[str]
    merged_manifest: dict[str, str | None]
    trivially_merged: bool

class _MergeTreeJson(_MergeTreeJsonBase, total=False):
    """Extended merge-tree JSON — adds optional ``snapshot_id`` when ``--write-objects`` is used."""
    snapshot_id: str

class _MergeTreeErrorJson(EnvelopeJson):
    """Error payload for usage/internal errors in --json mode."""
    status: str       # "error"
    error: str

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _emit_error(json_out: bool, msg: str, code: ExitCode, elapsed: float) -> None:
    """Print an error and raise SystemExit.  Never returns.

    In ``--json`` mode the error goes to stdout as a JSON payload so agents
    always get parseable output.  In text mode it goes to stderr.
    """
    if json_out:
        print(_json.dumps(_MergeTreeErrorJson(
            **make_envelope(elapsed, exit_code=int(code)),
            status="error",
            error=msg,
        )))
    else:
        print(f"❌ {msg}", file=sys.stderr)
    raise SystemExit(code)

# ---------------------------------------------------------------------------
# Ref resolution
# ---------------------------------------------------------------------------

def _resolve_ref(root: pathlib.Path, treeish: str) -> str | None:
    """Resolve HEAD, a branch name, or a sha256:-prefixed commit ID to a commit ID."""
    if treeish.upper() == "HEAD":
        try:
            branch = read_current_branch(root)
            return get_head_commit_id(root, branch)
        except Exception:
            return None

    # Accept sha256:-prefixed commit IDs directly.
    if treeish.startswith("sha256:"):
        try:
            validate_object_id(treeish)
            record = read_commit(root, treeish)
            return record.commit_id if record else None
        except ValueError:
            return None

    # Try as branch ref file.
    ref_file = _ref_path(root, treeish)
    return read_ref(ref_file)

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``muse merge-tree`` subcommand."""
    parser = subparsers.add_parser(
        "merge-tree",
        help="Three-way merge without modifying the working tree.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "branch1",
        metavar="BRANCH1",
        help="First branch (ours).",
    )
    parser.add_argument(
        "branch2",
        metavar="BRANCH2",
        help="Second branch (theirs).",
    )
    parser.add_argument(
        "--base",
        metavar="REF",
        default=None,
        help="Explicit merge base commit ID or branch name (overrides LCA).",
    )
    parser.add_argument(
        "--write-objects",
        action="store_true",
        dest="write_objects",
        help="Write the merged snapshot to the object store.",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit a single JSON object on stdout.",
    )
    parser.set_defaults(func=run)

# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Perform a three-way merge and report the result without touching the working tree.

    Computes a three-way merge between two branches (or explicit commit IDs)
    using their lowest common ancestor as the base.  Never modifies the working
    tree or any branch refs — useful for previewing conflicts before a real merge.

    Agent quickstart
    ----------------
    ::

        muse merge-tree dev feat/billing --json
        muse merge-tree feat/x main --base sha256:<base-id> --json
        muse merge-tree dev feat/audio --write-objects --json

    JSON fields
    -----------
    base              Resolved merge-base commit ID.
    branch1           Resolved commit ID for the first branch (ours).
    branch2           Resolved commit ID for the second branch (theirs).
    conflicts         List of paths with unresolved conflicts.
    merged_manifest   Map of ``path → object_id`` for the merged result.
    trivially_merged  ``true`` when there are zero conflicts.
    snapshot_id       Written snapshot ID (only present when ``--write-objects``).

    Exit codes
    ----------
    0  Clean merge — zero conflicts.
    1  Merge has conflicts, or a ref cannot be resolved.
    2  Usage error.
    """
    elapsed = start_timer()

    branch1_ref: str = args.branch1
    branch2_ref: str = args.branch2
    base_ref: str | None = args.base
    write_objects: bool = args.write_objects
    json_out: bool = args.json_out

    # Validate all ref names before doing any work.
    for ref in [branch1_ref, branch2_ref] + ([base_ref] if base_ref else []):
        if not _SAFE_REF_RE.match(ref):
            print(
                f"❌ Invalid ref: {sanitize_display(ref)}",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()

    repo_id = (load_json_file(_repo_json_path(root)) or {}).get("repo_id", "")

    # Resolve branch refs to commit IDs.
    branch1_id = _resolve_ref(root, branch1_ref)
    if branch1_id is None:
        _emit_error(json_out, f"Cannot resolve ref: {sanitize_display(branch1_ref)}", ExitCode.USER_ERROR, elapsed)

    branch2_id = _resolve_ref(root, branch2_ref)
    if branch2_id is None:
        _emit_error(json_out, f"Cannot resolve ref: {sanitize_display(branch2_ref)}", ExitCode.USER_ERROR, elapsed)

    # Resolve merge base.
    if base_ref is not None:
        base_id = _resolve_ref(root, base_ref)
        if base_id is None:
            _emit_error(json_out, f"Cannot resolve base ref: {sanitize_display(base_ref)}", ExitCode.USER_ERROR, elapsed)
        # Verify the base commit actually exists.
        if read_commit(root, base_id) is None:
            _emit_error(json_out, f"Base commit not found: {sanitize_display(base_id)}", ExitCode.USER_ERROR, elapsed)
    else:
        base_id = find_merge_base(root, branch1_id, branch2_id)
        if base_id is None:
            _emit_error(
                json_out,
                f"No common ancestor found between "
                f"{sanitize_display(branch1_ref)} and {sanitize_display(branch2_ref)}",
                ExitCode.USER_ERROR,
                elapsed,
            )

    # Load all three snapshots.
    branch1_commit = read_commit(root, branch1_id)
    branch2_commit = read_commit(root, branch2_id)
    base_commit = read_commit(root, base_id)

    base_snap = read_snapshot(root, base_commit.snapshot_id) if base_commit else None
    branch1_snap = read_snapshot(root, branch1_commit.snapshot_id) if branch1_commit else None
    branch2_snap = read_snapshot(root, branch2_commit.snapshot_id) if branch2_commit else None

    base_manifest = dict(base_snap.manifest) if base_snap else {}
    branch1_manifest = dict(branch1_snap.manifest) if branch1_snap else {}
    branch2_manifest = dict(branch2_snap.manifest) if branch2_snap else {}

    # Three-way merge (pure, no I/O).
    branch1_changed = diff_snapshots(base_manifest, branch1_manifest)
    branch2_changed = diff_snapshots(base_manifest, branch2_manifest)
    conflict_paths = detect_conflicts(
        branch1_changed, branch2_changed, branch1_manifest, branch2_manifest
    )
    merged_manifest = apply_merge(
        base_manifest, branch1_manifest, branch2_manifest,
        branch1_changed, branch2_changed, conflict_paths,
    )

    trivially_merged = len(conflict_paths) == 0

    # Build output manifest: conflict paths get null object_id.
    output_manifest: dict[str, str | None] = {k: v for k, v in merged_manifest.items()}
    for path in conflict_paths:
        output_manifest[path] = None
    exit_code = 0 if trivially_merged else int(ExitCode.USER_ERROR)

    result = _MergeTreeJson(
        **make_envelope(elapsed, exit_code=exit_code),
        base=base_id,
        branch1=branch1_id,
        branch2=branch2_id,
        conflicts=sorted(conflict_paths),
        merged_manifest=output_manifest,
        trivially_merged=trivially_merged,
    )

    # --write-objects: persist the conflict-free merged snapshot.
    if write_objects:
        from muse.core.ids import hash_snapshot
        from muse.core.snapshots import (
    SnapshotRecord,
    write_snapshot,
        )
        snapshot_id = hash_snapshot(merged_manifest)
        write_snapshot(root, SnapshotRecord(snapshot_id=snapshot_id, manifest=merged_manifest))
        result["snapshot_id"] = snapshot_id

    if json_out:
        print(_json.dumps(result))
    else:
        _print_text(result, branch1_ref, branch2_ref)

    if not trivially_merged:
        raise SystemExit(ExitCode.USER_ERROR)

def _print_text(result: _MergeTreeJsonBase, branch1_ref: str, branch2_ref: str) -> None:
    """Print a human-readable merge-tree summary."""
    base = result["base"]
    b1 = result["branch1"]
    b2 = result["branch2"]
    conflicts = result["conflicts"]
    n_merged = len(result["merged_manifest"])
    trivial = result["trivially_merged"]

    print(f"Merge base:  {base}")
    print(f"branch1:     {b1}  ({sanitize_display(branch1_ref)})")
    print(f"branch2:     {b2}  ({sanitize_display(branch2_ref)})")
    print()
    print(f"Merged files: {n_merged}")
    print(f"Conflicts:    {len(conflicts)}")
    result_label = "trivially merged" if trivial else f"{len(conflicts)} conflict(s)"
    print(f"Result:       {result_label}")

    if conflicts:
        print()
        for path in conflicts:
            print(f"CONFLICT  {sanitize_display(path)}  (both modified)")
