"""``muse shelf`` — first-class named working-tree checkpoints.

A shelf is a named, content-addressed snapshot of the working tree that has not
been promoted to a commit.  Shelves are a first-class design
built for a content-addressed, domain-agnostic, multi-dimensional VCS in an
agent-first era.

Design principles
-----------------
- **Named, not indexed.** Every shelf has a unique name. Integer indices are a
  lookup convenience, not the primary identity.
- **Full snapshots, not deltas.** The complete working-tree manifest is stored,
  so restoration is always unambiguous — even after intervening merges.
- **Already-current detection.** Applying a shelf reports files that were already
  at the shelf version (e.g. merged in since shelving) separately from files that
  were actually written.  Silent no-ops are replaced by explicit accounting.
- **Intent-typed.** Every shelf carries an ``intent_type`` that describes *why*
  it was created: ``interrupt``, ``checkpoint``, ``handoff``, ``experiment``,
  or ``draft``.
- **Agent-attributed.** ``created_by`` records which agent or human created the
  shelf.  ``resumable`` marks entries that another agent can continue.
- **GC-integrated.** All object IDs referenced by shelf entries are treated as
  reachable during garbage collection.

CLI
---
  muse shelf              — alias for ``muse shelf save`` (no subcommand needed)
  muse shelf save [NAME] [-m INTENT] [--intent-type TYPE] [--tag T] [--resumable]
  muse shelf list  [--json] [--branch B] [--resumable] [--by AGENT_ID]
  muse shelf read  [NAME|N] [--json]
  muse shelf apply [NAME|N] [--json]
  muse shelf pop   [NAME|N] [--json]
  muse shelf drop  [NAME|N] [--json]
  muse shelf diff  [NAME|N] [--json]

Name format
-----------
  Auto-generated: ``branch/NNN`` (e.g. ``dev/000``, ``main/000``).
  Custom name:    ``muse shelf save my-auth-refactor``
  Lookup by name or integer index — both always work.

Intent types
------------
  interrupt    — agent was interrupted mid-task
  checkpoint   — voluntary save before a risky operation
  handoff      — passing context to another agent or human
  experiment   — exploring a hypothesis; may be discarded
  draft        — work-in-progress, not ready for review

JSON output (save / apply / pop)
---------------------------------
::

    {
      "status":        "shelved | nothing_to_shelf | applied | popped | dropped",
      "id":            "sha256:...",
      "name":          "<name>",
      "snapshot_id":   "sha256:...",
      "parent_commit": "sha256:...",
      "branch":        "<branch>",
      "created_at":    "<iso8601>",
      "created_by":    {"handle": "<name>", "kind": "human | agent"},
      "intent_type":   "interrupt | checkpoint | handoff | experiment | draft",
      "intent":        "<free-text> | null",
      "resumable":     true | false,
      "tags":          ["..."],
      "files_count":   N,
      "shelf_size":    N
    }

Exit codes
----------
  0 — success
  1 — user error (empty shelf, name not found, duplicate name, invalid args)
  2 — not inside a Muse repository
  3 — object store integrity error (missing objects on apply/pop)
"""

import argparse
import json
import logging
import pathlib
import sys
from collections.abc import Mapping
from typing import TypedDict

from muse.cli.config import get_config_value
from muse.core.types import JsonValue, Manifest, content_hash, now_utc_iso
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.object_store import has_object, read_object, write_object_from_path
from muse.core.repo import require_repo
from muse.core.ignore import is_ignored
from muse.core.ids import hash_snapshot
from muse.core.snapshot import (
    directories_from_manifest,
    load_ignore_patterns,
)
from muse.core.reflog import append_reflog
from muse.core.refs import get_head_commit_id, read_current_branch
from muse.core.commits import read_commit
from muse.core.snapshots import (
    get_head_snapshot_manifest,
    read_snapshot,
)
from muse.core.shelf import (
    delete_shelf_entry as _delete_shelf_entry,
    list_shelf_entries as _list_shelf_entries,
    read_shelf_entry as _read_shelf_entry,
    write_shelf_entry as _write_shelf_entry,
)
from muse.core.timing import start_timer
from muse.core.validation import sanitize_display
from muse.core.workdir import apply_manifest
from muse.plugins.registry import resolve_plugin

type _DomainState = dict[str, JsonValue]
type _RestoreCountMap = dict[str, int]

_VALID_INTENT_TYPES = frozenset({"interrupt", "checkpoint", "handoff", "experiment", "draft"})

logger = logging.getLogger(__name__)

class _CreatedBy(TypedDict):
    """Identity of the entity that created a shelf entry."""

    handle: str   # username or agent ID
    kind: str     # "human" | "agent"

class _ShelfSaveJson(EnvelopeJson, total=False):
    """JSON envelope for ``muse shelf save --json``."""

    status: str
    id: str | None
    name: str | None
    snapshot_id: str | None
    parent_commit: str | None
    branch: str
    created_at: str | None
    created_by: _CreatedBy
    intent_type: str
    intent: str | None
    resumable: bool
    tags: list[str]
    files_count: int
    shelf_size: int

class _ShelfListEntryJson(TypedDict):
    """One shelf entry in the ``muse shelf list --json`` array."""

    index: int
    id: str
    name: str
    snapshot_id: str
    branch: str
    created_at: str
    created_by: _CreatedBy
    intent_type: str
    intent: str | None
    resumable: bool
    tags: list[str]
    files_count: int

class _ShelfListJson(EnvelopeJson):
    """JSON envelope for ``muse shelf list --json``."""

    entries: list[_ShelfListEntryJson]

class _ShelfReadJson(EnvelopeJson, total=False):
    """JSON envelope for ``muse shelf read --json``."""

    index: int
    id: str
    name: str
    snapshot_id: str
    parent_commit: str
    branch: str
    created_at: str
    created_by: _CreatedBy
    intent_type: str
    intent: str | None
    resumable: bool
    tags: list[str]
    files_count: int
    files: list[str]
    deleted: list[str]

class _ShelfApplyJson(EnvelopeJson):
    """JSON envelope for ``muse shelf apply --json``."""

    status: str
    name: str
    restored: int
    already_current: int
    deleted: int
    shelf_size: int

class _ShelfPopJson(EnvelopeJson):
    """JSON envelope for ``muse shelf pop --json``."""

    status: str
    name: str
    restored: int
    already_current: int
    deleted: int
    shelf_size_after: int

class _ShelfDropJson(EnvelopeJson):
    """JSON envelope for ``muse shelf drop --json``."""

    status: str
    name: str
    id: str
    shelf_size: int

class _ShelfDiffJson(EnvelopeJson):
    """JSON envelope for ``muse shelf diff --json``."""

    name: str
    branch: str
    would_restore: list[str]
    already_current: list[str]
    would_delete: list[str]

class ShelfEntry(TypedDict):
    """A single named checkpoint in the shelf registry.

    ``snapshot`` is the *complete* working-tree manifest (all tracked files and
    their object IDs) at the moment the shelf was created.  This is the key
    design improvement over the delta-based approach: full snapshots enable unambiguous
    restoration and explicit already-current detection after intervening merges.

    ``deleted`` lists paths that existed in HEAD at shelf time but were absent
    from the working tree — files the user had removed before shelving.

    ``id`` is the sha256 of the entry content (excluding ``id`` itself), making
    every shelf entry content-addressed.
    """

    id: str                  # sha256: of entry content (minus this field)
    name: str                # unique human-readable identifier within this repo
    snapshot: Manifest       # complete path → object_id for all tracked files
    deleted: list[str]       # paths in HEAD that were removed from working tree
    snapshot_id: str         # sha256: of snapshot (for GC and display)
    parent_commit: str       # HEAD commit ID at shelf time
    branch: str              # branch at shelf time
    created_at: str          # ISO 8601
    created_by: _CreatedBy   # {"handle": "<name>", "kind": "human|agent"}
    intent_type: str         # interrupt | checkpoint | handoff | experiment | draft
    intent: str | None       # free-text description of what was being done
    resumable: bool          # whether another agent can continue this work
    tags: list[str]          # arbitrary labels for filtering
    expires_at: str | None   # ISO 8601 expiry; null = no expiry
    domain_state: _DomainState  # per-domain plugin metadata (MIDI beat, etc.)

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _compute_shelf_id(entry_without_id: Mapping[str, object]) -> str:
    """Return the content-addressed sha256: ID for a shelf entry.

    The ID is derived from all fields *except* ``id`` itself, sorted for
    canonical JSON serialisation.  Two entries with identical content always
    produce the same ID.
    """
    return content_hash(entry_without_id)

def _load_shelf(root: pathlib.Path) -> list[ShelfEntry]:
    """Return all shelf entries sorted newest-first.

    Delegates to :func:`muse.core.store.list_shelf_entries`, which reads
    per-entry git-header+JSON files from ``.muse/shelf/<algo>/<hex>``.
    Corrupt or oversized files are silently skipped.
    """
    raw_entries = _list_shelf_entries(root)
    entries: list[ShelfEntry] = []
    for item in raw_entries:
        if not isinstance(item, dict):
            continue
        snapshot = item.get("snapshot")
        if not isinstance(snapshot, dict):
            continue
        safe_snapshot: Manifest = {
            k: v for k, v in snapshot.items()
            if isinstance(k, str) and isinstance(v, str)
        }
        raw_deleted = item.get("deleted", [])
        safe_deleted: list[str] = (
            [p for p in raw_deleted if isinstance(p, str)]
            if isinstance(raw_deleted, list) else []
        )
        # Normalize created_by: old entries stored a plain string; new entries
        # store {"handle": ..., "kind": ...}. Deserialize both gracefully.
        raw_cb = item.get("created_by", "human")
        if isinstance(raw_cb, dict):
            created_by_obj = _CreatedBy(
                handle=str(raw_cb.get("handle", "human")),
                kind=str(raw_cb.get("kind", "human")),
            )
        else:
            s = str(raw_cb)
            created_by_obj = _CreatedBy(
                handle=s,
                kind="human" if s == "human" else "agent",
            )
        entries.append(ShelfEntry(
            id=str(item.get("id", "")),
            name=str(item.get("name", "")),
            snapshot=safe_snapshot,
            deleted=safe_deleted,
            snapshot_id=str(item.get("snapshot_id", "")),
            parent_commit=str(item.get("parent_commit", "")),
            branch=str(item.get("branch", "")),
            created_at=str(item.get("created_at", "")),
            created_by=created_by_obj,
            intent_type=str(item.get("intent_type", "checkpoint")),
            intent=str(item["intent"]) if item.get("intent") else None,
            resumable=bool(item.get("resumable", False)),
            tags=[str(t) for t in item.get("tags", []) if isinstance(t, str)],
            expires_at=str(item["expires_at"]) if item.get("expires_at") else None,
            domain_state=item.get("domain_state") if isinstance(item.get("domain_state"), dict) else {},
        ))
    return entries

def _resolve_entry(
    entries: list[ShelfEntry],
    name_or_index: str | None,
    *,
    default: int = 0,
) -> tuple[int, ShelfEntry]:
    """Return ``(index, entry)`` for the given name or integer index.

    Resolution order:
    1. If *name_or_index* is ``None``: use *default* index.
    2. If *name_or_index* is a decimal integer string: treat as 0-based index.
    3. Otherwise: look up by exact name.

    Raises ``ValueError`` with a human-readable message on invalid input.
    """
    if not entries:
        raise ValueError("No shelf entries.")

    if name_or_index is None:
        idx = default
        if idx < 0 or idx >= len(entries):
            raise ValueError(
                f"Shelf index {idx} is out of range (0–{len(entries) - 1})."
            )
        return idx, entries[idx]

    # Integer index?
    try:
        idx = int(name_or_index)
        if idx < 0 or idx >= len(entries):
            raise ValueError(
                f"Shelf index {idx} is out of range (0–{len(entries) - 1})."
            )
        return idx, entries[idx]
    except ValueError as exc:
        if "out of range" in str(exc):
            raise
        # Not an integer — treat as name.
        pass

    for i, e in enumerate(entries):
        if e["name"] == name_or_index:
            return i, e

    raise ValueError(
        f"No shelf entry named {sanitize_display(name_or_index)!r}.\n"
        f"   Run 'muse shelf list' to see available entries."
    )

def _generate_name(branch: str, existing_names: set[str]) -> str:
    """Generate a unique shelf name from the branch name.

    Format: ``{branch}/{N:03d}`` where N is the lowest integer that doesn't
    already exist.  Branch characters outside ``[a-zA-Z0-9/_-]`` are replaced
    with ``-``.
    """
    safe = "".join(c if c.isalnum() or c in "/_-" else "-" for c in branch)
    safe = safe.strip("-").strip("/") or "shelf"
    n = 0
    while True:
        candidate = f"{safe}/{n:03d}"
        if candidate not in existing_names:
            return candidate
        n += 1

def _verify_snapshot_objects(root: pathlib.Path, snapshot: Manifest) -> list[str]:
    """Return paths in *snapshot* whose object IDs are absent from the object store."""
    return [p for p, oid in snapshot.items() if not has_object(root, oid)]

def _apply_shelf_snapshot(
    root: pathlib.Path,
    entry: ShelfEntry,
    head_manifest: Manifest,
) -> _RestoreCountMap:
    """Restore the shelf snapshot to the working tree.

    Only files that were **actually dirty** when the shelf was saved are
    restored.  "Dirty" means the working-tree hash at save time differed
    from the source-branch HEAD snapshot.  Files that were clean on the
    source branch — including those committed there but not yet merged into
    the current branch — are intentionally skipped so they do not bleed
    into the working tree as phantom modifications.

    Counts:
    - **restored**: files written from the object store.
    - **already_current**: disk already matches the shelf version.
    - **deleted**: paths removed (were in HEAD at save time, deleted by user).

    Returns a dict with keys ``restored``, ``already_current``, ``deleted``.
    """
    from muse.core.types import hash_file

    # Load the source-branch HEAD manifest so we can identify which files were
    # truly dirty (working-tree hash ≠ source HEAD hash) vs. merely committed
    # on the source branch but not yet present on the current branch.
    source_head_manifest: Manifest = {}
    parent_commit_id = entry.get("parent_commit", "")
    if parent_commit_id:
        src_commit = read_commit(root, parent_commit_id)
        if src_commit is not None:
            snap_id = src_commit.snapshot_id
            if snap_id:
                src_snap = read_snapshot(root, snap_id)
                if src_snap is not None:
                    source_head_manifest = dict(src_snap.manifest)

    restored = 0
    already_current = 0

    for rel_path, obj_id in entry["snapshot"].items():
        # Skip files that were clean on the source branch — their current
        # content is the merge's responsibility, not the shelf's.
        if source_head_manifest.get(rel_path) == obj_id:
            continue

        dest = root / rel_path
        if dest.exists():
            try:
                disk_id = hash_file(dest)
            except OSError:
                disk_id = None
            if disk_id == obj_id:
                # Disk already has the exact shelf bytes — no write needed.
                already_current += 1
                continue
        data = read_object(root, obj_id)
        if data is None:
            logger.warning("⚠️  shelf: object missing for %s — skipping", rel_path)
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        restored += 1

    deleted = 0
    for rel_path in entry["deleted"]:
        target = root / rel_path
        try:
            target.unlink()
            deleted += 1
        except FileNotFoundError:
            pass  # already gone — idempotent

    return {"restored": restored, "already_current": already_current, "deleted": deleted}

def _entry_files_count(entry: ShelfEntry, head_manifest: Manifest) -> int:
    """Count files that differ between the shelf and HEAD (the shelf's change set)."""
    changed = sum(
        1 for p, oid in entry["snapshot"].items()
        if head_manifest.get(p) != oid
    )
    return changed + len(entry["deleted"])

def _resolve_created_by(root: pathlib.Path, explicit_by: str) -> _CreatedBy:
    """Resolve the created_by identity for a new shelf entry.

    If *explicit_by* is not ``"human"`` (i.e. the caller passed ``--by`` with an
    explicit agent ID), return it as-is with ``kind="agent"``.  Otherwise read
    ``user.handle`` from the repo config (same source ``muse commit`` uses for
    ``author``) and return ``{"handle": <handle>, "kind": "human"}``.  Falls back
    to ``"human"`` when no handle is configured.
    """
    if explicit_by != "human":
        return _CreatedBy(handle=explicit_by, kind="agent")
    handle = get_config_value("user.handle", root) or "human"
    return _CreatedBy(handle=handle, kind="human")

# ---------------------------------------------------------------------------
# Programmatic API  (used by checkout / merge --autoshelf)
# ---------------------------------------------------------------------------

def _shelf_push_programmatic(
    root: pathlib.Path,
    name: str | None = None,
    *,
    intent_type: str = "interrupt",
    intent: str | None = None,
    created_by: str = "muse",
    resumable: bool = False,
    tags: list[str] | None = None,
    domain_state: _DomainState | None = None,
) -> ShelfEntry | None:
    """Save the current working-tree state to the shelf without CLI output.

    Returns the new :class:`ShelfEntry` if changes were shelved, or ``None``
    when the working tree is already clean (nothing to shelf).

    Args:
        root:        Repository root.
        name:        Shelf name.  Auto-generated if ``None``.
        intent_type: One of the :data:`_VALID_INTENT_TYPES`.
        intent:      Free-text description of the in-progress work.
        created_by:  Agent ID or ``"human"``.
        resumable:   Whether another agent can continue this shelf.
        tags:        Arbitrary string labels.
        domain_state: Per-domain plugin metadata.

    Returns:
        The :class:`ShelfEntry` that was saved, or ``None`` if the tree was
        already clean.

    Raises:
        ValueError: If *name* already exists in the shelf registry.
    """
    branch = read_current_branch(root)
    plugin = resolve_plugin(root)
    manifest = plugin.snapshot(root)["files"]

    head_manifest = get_head_snapshot_manifest(root, branch) or {}
    if manifest == head_manifest:
        return None

    # Compute deleted: in HEAD but genuinely absent from the working tree.
    _ignore_patterns = load_ignore_patterns(root)
    deleted: list[str] = [
        path for path in head_manifest
        if path not in manifest
        and not (is_ignored(path, _ignore_patterns) and (root / path).exists())
    ]

    # Write new/modified objects to the store.
    for rel_path, object_id in manifest.items():
        if head_manifest.get(rel_path) != object_id:
            write_object_from_path(root, object_id, root / rel_path)

    snapshot_id = hash_snapshot(manifest, directories_from_manifest(manifest))

    # Resolve parent commit.
    from muse.core.commits import resolve_commit_ref
    ref = resolve_commit_ref(root, branch, None)
    parent_commit = ref.commit_id if ref else ""

    # Determine name.
    entries = _load_shelf(root)
    existing_names = {e["name"] for e in entries}
    if name is None:
        name = _generate_name(branch, existing_names)
    elif name in existing_names:
        raise ValueError(
            f"A shelf entry named {name!r} already exists.  "
            "Use a different name or drop the existing entry first."
        )

    created_at = now_utc_iso()
    created_by_obj = _resolve_created_by(root, created_by)
    entry_without_id = {
        "name": name,
        "snapshot": manifest,
        "deleted": deleted,
        "snapshot_id": snapshot_id,
        "parent_commit": parent_commit,
        "branch": branch,
        "created_at": created_at,
        "created_by": created_by_obj,
        "intent_type": intent_type,
        "intent": intent,
        "resumable": resumable,
        "tags": tags or [],
        "expires_at": None,
        "domain_state": domain_state or {},
    }
    shelf_id = _compute_shelf_id(entry_without_id)
    entry = ShelfEntry(id=shelf_id, **entry_without_id)  # type: ignore[misc]

    _write_shelf_entry(root, entry)

    apply_manifest(root, manifest, head_manifest)
    logger.debug("shelf: saved %d file(s) as %r", len(manifest), name)
    return entry

def _shelf_pop_programmatic(
    root: pathlib.Path,
    name_or_index: str | int = 0,
) -> ShelfEntry:
    """Restore a shelf entry and remove it from the registry.

    Args:
        root:           Repository root.
        name_or_index:  Name string or integer index (0 = most recent).

    Returns:
        The :class:`ShelfEntry` that was applied and removed.

    Raises:
        ValueError:   If the shelf is empty or the entry is not found.
        RuntimeError: If objects are missing from the object store.
    """
    entries = _load_shelf(root)
    if not entries:
        raise ValueError("No shelf entries.")

    raw = str(name_or_index) if isinstance(name_or_index, int) else name_or_index
    idx, entry = _resolve_entry(entries, raw)

    missing = _verify_snapshot_objects(root, entry["snapshot"])
    if missing:
        raise RuntimeError(
            f"Shelf entry {entry['name']!r} is missing {len(missing)} object(s) "
            f"from the object store: {', '.join(sorted(missing))}"
        )

    branch = read_current_branch(root)
    head_manifest = get_head_snapshot_manifest(root, branch) or {}

    _delete_shelf_entry(root, entry["id"])
    _apply_shelf_snapshot(root, entry, head_manifest)
    logger.debug("shelf: restored %r", entry["name"])
    return entry

# ---------------------------------------------------------------------------
# CLI subcommand registration
# ---------------------------------------------------------------------------

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse shelf`` subcommand tree."""
    parser = subparsers.add_parser(
        "shelf",
        help="Save, inspect, and restore named working-tree checkpoints.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit machine-readable JSON.")
    subs = parser.add_subparsers(dest="subcommand", metavar="SUBCOMMAND")

    # ── save ──────────────────────────────────────────────────────────────────
    save_p = subs.add_parser(
        "save",
        help="Save the current working-tree state as a named shelf entry.",
        description=(
            "Snapshot the current working tree and save it as a named shelf entry.\n\n"
            "After saving, the working tree is restored to HEAD so you can\n"
            "switch context without committing half-done work.\n\n"
            "Name rules\n"
            "----------\n"
            "  Names must be unique within the repo.  If omitted, a name is\n"
            "  generated from the current branch: ``dev/000``, ``dev/001``, etc.\n\n"
            "Intent types\n"
            "------------\n"
            "  interrupt    agent was interrupted mid-task\n"
            "  checkpoint   voluntary save before a risky operation (default)\n"
            "  handoff      passing context to another agent or human\n"
            "  experiment   exploring a hypothesis; may be discarded\n"
            "  draft        work-in-progress, not ready for review\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse shelf save --json\n"
            "  muse shelf save auth-refactor --intent-type handoff \\\n"
            "      -m 'updating test assertions, 60% done'\n\n"
            "Aliases\n"
            "-------\n"
            "  ``muse shelf`` with no subcommand is identical to ``muse shelf save``.\n\n"
            "Name format\n"
            "-----------\n"
            "  Auto-generated names use ``branch/NNN`` (e.g. ``dev/000``, ``dev/001``).\n"
            "  Pass a custom name as the first positional argument to override.\n"
            "  Any name can be looked up by its exact string or by integer index.\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {\n'
            '    "status":        "shelved | nothing_to_shelf",\n'
            '    "id":            "sha256:...",\n'
            '    "name":          "<name>",\n'
            '    "snapshot_id":   "sha256:...",\n'
            '    "parent_commit": "sha256:...",\n'
            '    "branch":        "<branch>",\n'
            '    "created_at":    "<iso8601>",\n'
            '    "created_by":    {"handle": "<name>", "kind": "human | agent"},\n'
            '    "intent_type":   "<type>",\n'
            '    "intent":        "<text> | null",\n'
            '    "resumable":     true|false,\n'
            '    "tags":          [...],\n'
            '    "files_count":   N,\n'
            '    "shelf_size":    N\n'
            '  }\n'
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    save_p.add_argument("name", nargs="?", default=None,
                        help="Name for this shelf entry (auto-generated if omitted).")
    save_p.add_argument("-m", "--intent", default=None,
                        help="Free-text description of the work in progress.")
    save_p.add_argument("--intent-type", default="checkpoint", dest="intent_type",
                        choices=sorted(_VALID_INTENT_TYPES),
                        help="Why this shelf was created (default: checkpoint).")
    save_p.add_argument("--by", default="human", dest="created_by",
                        help="Agent ID or 'human' (default: human).")
    save_p.add_argument("--resumable", action="store_true", default=False,
                        help="Mark this shelf as resumable by another agent.")
    save_p.add_argument("--tag", action="append", default=[], dest="tags",
                        metavar="TAG",
                        help="Add a tag label (repeatable).")
    save_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit machine-readable JSON.")
    save_p.set_defaults(func=run_save)

    # ── list ──────────────────────────────────────────────────────────────────
    list_p = subs.add_parser(
        "list",
        help="List all shelf entries.",
        description=(
            "List all shelf entries, newest first.\n\n"
            "An empty shelf is a valid result — exit code is always 0.\n\n"
            "Filter flags\n"
            "------------\n"
            "  --branch B      only entries shelved from branch B\n"
            "  --resumable     only entries marked resumable\n"
            "  --by AGENT_ID   only entries created by this agent\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse shelf list --json\n"
            "  muse shelf list --resumable --json\n"
            "  muse shelf list --branch dev --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  [{\n'
            '    "index":       N,\n'
            '    "id":          "sha256:...",\n'
            '    "name":        "<name>",\n'
            '    "snapshot_id": "sha256:...",\n'
            '    "branch":      "<branch>",\n'
            '    "created_at":  "<iso8601>",\n'
            '    "created_by":  {"handle": "<name>", "kind": "human | agent"},\n'
            '    "intent_type": "<type>",\n'
            '    "intent":      "<text> | null",\n'
            '    "resumable":   true|false,\n'
            '    "tags":        [...],\n'
            '    "files_count": N\n'
            '  }, ...]\n'
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    list_p.add_argument("--branch", default=None,
                        help="Filter by branch.")
    list_p.add_argument("--resumable", action="store_true", default=False,
                        help="Only show resumable entries.")
    list_p.add_argument("--by", default=None, dest="created_by",
                        help="Filter by creator agent ID.")
    list_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit machine-readable JSON.")
    list_p.set_defaults(func=run_list)

    # ── read ──────────────────────────────────────────────────────────────────
    read_p = subs.add_parser(
        "read",
        help="Inspect a shelf entry without modifying the working tree.",
        description=(
            "Show the metadata and file list for a shelf entry.\n\n"
            "Does not modify the working tree.\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {\n'
            '    "index":         N,\n'
            '    "id":            "sha256:...",\n'
            '    "name":          "<name>",\n'
            '    "snapshot_id":   "sha256:...",\n'
            '    "parent_commit": "sha256:...",\n'
            '    "branch":        "<branch>",\n'
            '    "created_at":    "<iso8601>",\n'
            '    "created_by":    {"handle": "<name>", "kind": "human | agent"},\n'
            '    "intent_type":   "<type>",\n'
            '    "intent":        "<text> | null",\n'
            '    "resumable":     true|false,\n'
            '    "tags":          [...],\n'
            '    "files_count":   N,\n'
            '    "files":         ["path/to/changed.py", ...],\n'
            '    "deleted":       ["path/to/gone.py", ...]\n'
            '  }\n'
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    read_p.add_argument("entry", nargs="?", default=None,
                        help="Name or index of the entry to inspect (default: 0).")
    read_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit machine-readable JSON.")
    read_p.set_defaults(func=run_read)

    # ── apply ─────────────────────────────────────────────────────────────────
    apply_p = subs.add_parser(
        "apply",
        help="Restore a shelf entry to the working tree (keeps the entry).",
        description=(
            "Restore the shelf snapshot to the working tree without removing\n"
            "the entry from the shelf.  This is the default restore action.\n\n"
            "Already-current detection\n"
            "-------------------------\n"
            "Files already at the shelf version (e.g. merged in since shelving)\n"
            "are counted as 'already_current' rather than silently re-written.\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {\n'
            '    "status":          "applied",\n'
            '    "name":            "<name>",\n'
            '    "restored":        N,\n'
            '    "already_current": N,\n'
            '    "deleted":         N,\n'
            '    "shelf_size":      N\n'
            '  }\n'
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    apply_p.add_argument("entry", nargs="?", default=None,
                         help="Name or index to apply (default: 0).")
    apply_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit machine-readable JSON.")
    apply_p.set_defaults(func=run_apply)

    # ── pop ───────────────────────────────────────────────────────────────────
    pop_p = subs.add_parser(
        "pop",
        help="Restore a shelf entry and remove it from the shelf.",
        description=(
            "Restore the shelf snapshot to the working tree and remove the\n"
            "entry from the shelf registry.  Use this when you are done with\n"
            "the shelf and want to continue the work in place.\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {\n'
            '    "status":          "popped",\n'
            '    "name":            "<name>",\n'
            '    "restored":        N,\n'
            '    "already_current": N,\n'
            '    "deleted":         N,\n'
            '    "shelf_size_after": N\n'
            '  }\n'
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    pop_p.add_argument("entry", nargs="?", default=None,
                       help="Name or index to pop (default: 0).")
    pop_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit machine-readable JSON.")
    pop_p.set_defaults(func=run_pop)

    # ── drop ──────────────────────────────────────────────────────────────────
    drop_p = subs.add_parser(
        "drop",
        help="Discard a shelf entry without applying it.",
        description=(
            "Remove a shelf entry from the registry without touching the\n"
            "working tree.\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {\n'
            '    "status":     "dropped",\n'
            '    "name":       "<name>",\n'
            '    "id":         "sha256:...",\n'
            '    "shelf_size": N\n'
            '  }\n'
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    drop_p.add_argument("entry", nargs="?", default=None,
                        help="Name or index to drop (default: 0).")
    drop_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit machine-readable JSON.")
    drop_p.set_defaults(func=run_drop)

    # ── diff ──────────────────────────────────────────────────────────────────
    diff_p = subs.add_parser(
        "diff",
        help="Show what applying a shelf entry would change.",
        description=(
            "Compare the shelf snapshot against the current HEAD to show what\n"
            "would change if you ran 'muse shelf apply'.\n\n"
            "Does not modify the working tree.\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {\n'
            '    "name":            "<name>",\n'
            '    "branch":          "<branch>",\n'
            '    "would_restore":   ["path/to/file.py", ...],\n'
            '    "already_current": ["path/to/same.py", ...],\n'
            '    "would_delete":    ["path/to/gone.py", ...]\n'
            '  }\n'
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    diff_p.add_argument("entry", nargs="?", default=None,
                        help="Name or index to diff (default: 0).")
    diff_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit machine-readable JSON.")
    diff_p.set_defaults(func=run_diff)

    parser.set_defaults(func=run_save)

# ---------------------------------------------------------------------------
# Command implementations
# ---------------------------------------------------------------------------

def run_save(args: argparse.Namespace) -> None:
    """Save the current working-tree state as a named shelf entry.

    Writes all changed/added objects to the object store, records the full
    working-tree manifest as a snapshot, then restores HEAD to the working
    tree so you can switch context without a half-done commit.

    Agent quickstart::

        muse shelf save --json
        muse shelf save auth-refactor --intent-type handoff -m "updating tests, 60% done" --json
        muse shelf save --intent-type checkpoint --resumable --json

    JSON fields::

        status          str         "shelved" or "nothing_to_shelf"
        id              str|null    Content-addressed shelf entry ID
        name            str|null    Shelf entry name (auto-generated if omitted)
        snapshot_id     str|null    sha256 of the working-tree snapshot
        parent_commit   str|null    HEAD commit ID at shelf time
        branch          str         Branch at shelf time
        created_at      str|null    ISO 8601 creation timestamp
        created_by      dict        {"handle": "<name>", "kind": "human|agent"}
        intent_type     str         interrupt|checkpoint|handoff|experiment|draft
        intent          str|null    Free-text description of work in progress
        resumable       bool        True if another agent may continue this shelf
        tags            list[str]   Arbitrary labels
        files_count     int         Files differing from HEAD (0 when nothing_to_shelf)
        shelf_size      int         Total entries in the shelf after this operation

    Exit codes::

        0  Success.
        1  Name collision or invalid --format.
        2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    name: str | None = getattr(args, "name", None)
    intent: str | None = getattr(args, "intent", None)
    intent_type: str = getattr(args, "intent_type", "checkpoint")
    created_by: str = getattr(args, "created_by", "human")
    resumable: bool = getattr(args, "resumable", False)
    tags: list[str] = getattr(args, "tags", [])

    root = require_repo()
    created_by_obj = _resolve_created_by(root, created_by)
    branch = read_current_branch(root)
    plugin = resolve_plugin(root)
    manifest = plugin.snapshot(root)["files"]
    head_manifest = get_head_snapshot_manifest(root, branch) or {}

    if manifest == head_manifest:
        if json_out:
            print(json.dumps(_ShelfSaveJson(
                **make_envelope(elapsed),
                status="nothing_to_shelf",
                id=None,
                name=None,
                snapshot_id=None,
                parent_commit=None,
                branch=branch,
                created_at=None,
                created_by=created_by_obj,
                intent_type=intent_type,
                intent=intent,
                resumable=resumable,
                tags=tags,
                files_count=0,
                shelf_size=len(_load_shelf(root)),
            )))
        else:
            print("Nothing to shelf.")
        return

    # Check for name collision before doing any work.
    existing_entries = _load_shelf(root)
    existing_names = {e["name"] for e in existing_entries}
    if name is not None and name in existing_names:
        print(
            f"❌ A shelf entry named {sanitize_display(name)!r} already exists.\n"
            "   Use a different name, or drop the existing entry first with:\n"
            f"   muse shelf drop {sanitize_display(name)}",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    if name is None:
        name = _generate_name(branch, existing_names)

    _ignore_patterns = load_ignore_patterns(root)
    deleted: list[str] = [
        path for path in head_manifest
        if path not in manifest
        and not (is_ignored(path, _ignore_patterns) and (root / path).exists())
    ]

    for rel_path, object_id in manifest.items():
        if head_manifest.get(rel_path) != object_id:
            write_object_from_path(root, object_id, root / rel_path)

    snapshot_id = hash_snapshot(manifest, directories_from_manifest(manifest))

    from muse.core.commits import resolve_commit_ref
    ref = resolve_commit_ref(root, branch, None)
    parent_commit = ref.commit_id if ref else ""

    created_at = now_utc_iso()
    entry_without_id = {
        "name": name,
        "snapshot": manifest,
        "deleted": deleted,
        "snapshot_id": snapshot_id,
        "parent_commit": parent_commit,
        "branch": branch,
        "created_at": created_at,
        "created_by": created_by_obj,
        "intent_type": intent_type,
        "intent": intent,
        "resumable": resumable,
        "tags": tags,
        "expires_at": None,
        "domain_state": {},
    }
    shelf_id = _compute_shelf_id(entry_without_id)
    entry = ShelfEntry(id=shelf_id, **entry_without_id)  # type: ignore[misc]

    _write_shelf_entry(root, entry)
    apply_manifest(root, manifest, head_manifest)

    files_count = sum(
        1 for p, oid in manifest.items() if head_manifest.get(p) != oid
    ) + len(deleted)

    if json_out:
        print(json.dumps(_ShelfSaveJson(
            **make_envelope(elapsed),
            status="shelved",
            id=shelf_id,
            name=name,
            snapshot_id=snapshot_id,
            parent_commit=parent_commit,
            branch=branch,
            created_at=created_at,
            created_by=created_by_obj,
            intent_type=intent_type,
            intent=intent,
            resumable=resumable,
            tags=tags,
            files_count=files_count,
            shelf_size=len(existing_entries),
        )))
    else:
        label = f" — {intent}" if intent else ""
        print(f"Shelved {sanitize_display(name)!r} ({files_count} file(s)){label}")

def run_list(args: argparse.Namespace) -> None:
    """List shelf entries, newest first.

    Applies optional filters for branch, resumability, and creator.  An empty
    shelf is a valid result — exit code is always 0 unless the format is invalid.

    Agent quickstart::

        muse shelf list --json
        muse shelf list --resumable --json
        muse shelf list --branch dev --json

    JSON fields::

        entries         list        Array of shelf entry objects (may be empty)
        entries[].index int         0-based position in the shelf
        entries[].id    str         Content-addressed shelf entry ID
        entries[].name  str         Human-readable name
        entries[].snapshot_id str   sha256 of the snapshot
        entries[].branch str        Branch at shelf time
        entries[].created_at str    ISO 8601 creation timestamp
        entries[].created_by dict   {"handle": "<name>", "kind": "human|agent"}
        entries[].intent_type str   interrupt|checkpoint|handoff|experiment|draft
        entries[].intent str|null   Free-text description
        entries[].resumable bool    True if another agent may continue
        entries[].tags list[str]    Arbitrary labels
        entries[].files_count int   Files differing from HEAD

    Exit codes::

        0  Success (empty shelf is valid).
        1  Invalid --format.
        2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    filter_branch: str | None = getattr(args, "branch", None)
    filter_resumable: bool = getattr(args, "resumable", False)
    filter_by: str | None = getattr(args, "created_by", None)

    root = require_repo()
    branch = read_current_branch(root)
    head_manifest = get_head_snapshot_manifest(root, branch) or {}
    entries = _load_shelf(root)

    # Apply filters.
    filtered = [
        (i, e) for i, e in enumerate(entries)
        if (filter_branch is None or e["branch"] == filter_branch)
        and (not filter_resumable or e["resumable"])
        and (filter_by is None or e["created_by"]["handle"] == filter_by)
    ]

    if json_out:
        print(json.dumps(_ShelfListJson(
            **make_envelope(elapsed),
            entries=[_ShelfListEntryJson(
                index=i,
                id=e["id"],
                name=e["name"],
                snapshot_id=e["snapshot_id"],
                branch=e["branch"],
                created_at=e["created_at"],
                created_by=e["created_by"],
                intent_type=e["intent_type"],
                intent=e.get("intent"),
                resumable=e["resumable"],
                tags=e.get("tags", []),
                files_count=_entry_files_count(e, head_manifest),
            ) for i, e in filtered],
        )))
        return

    if not filtered:
        print("No shelf entries.")
        return
    for i, e in filtered:
        label = f": {sanitize_display(e['intent'] or '')}" if e.get("intent") else ""
        intent_tag = f"[{e['intent_type']}]" if e.get("intent_type") else ""
        print(
            f"shelf/{i}  {sanitize_display(e['name'])}  "
            f"({sanitize_display(e['branch'])})  "
            f"{intent_tag}{label}"
        )

def run_read(args: argparse.Namespace) -> None:
    """Inspect a shelf entry without modifying the working tree.

    Shows metadata and the full file list for a shelf entry.  Does not
    restore any files — use ``muse shelf apply`` or ``muse shelf pop`` for that.

    Agent quickstart::

        muse shelf read --json
        muse shelf read 0 --json
        muse shelf read auth-refactor --json

    JSON fields::

        index           int         0-based position in the shelf
        id              str         Content-addressed shelf entry ID
        name            str         Human-readable name
        snapshot_id     str         sha256 of the snapshot
        parent_commit   str         HEAD commit ID at shelf time
        branch          str         Branch at shelf time
        created_at      str         ISO 8601 creation timestamp
        created_by      dict        {"handle": "<name>", "kind": "human|agent"}
        intent_type     str         interrupt|checkpoint|handoff|experiment|draft
        intent          str|null    Free-text description
        resumable       bool        True if another agent may continue
        tags            list[str]   Arbitrary labels
        files_count     int         Files differing from HEAD
        files           list[str]   Tracked paths in the snapshot
        deleted         list[str]   Paths removed before shelving

    Exit codes::

        0  Success.
        1  Empty shelf or entry not found.
        2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    raw: str | None = getattr(args, "entry", None)

    root = require_repo()
    entries = _load_shelf(root)
    if not entries:
        print("❌ No shelf entries.", file=sys.stderr)
        if json_out:
            print(json.dumps({"error": "no_shelf_entries", "shelf_size": 0}))
        raise SystemExit(ExitCode.USER_ERROR)

    try:
        idx, entry = _resolve_entry(entries, raw)
    except ValueError as exc:
        print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    branch = read_current_branch(root)
    head_manifest = get_head_snapshot_manifest(root, branch) or {}
    # Only paths that actually differ from HEAD — same set files_count counts.
    changed_files = sorted(
        p for p, oid in entry["snapshot"].items()
        if head_manifest.get(p) != oid
    )
    deleted_files = sorted(entry["deleted"])
    files_count = len(changed_files) + len(deleted_files)

    if json_out:
        print(json.dumps(_ShelfReadJson(
            **make_envelope(elapsed),
            index=idx,
            id=entry["id"],
            name=entry["name"],
            snapshot_id=entry["snapshot_id"],
            parent_commit=entry["parent_commit"],
            branch=entry["branch"],
            created_at=entry["created_at"],
            created_by=entry["created_by"],
            intent_type=entry["intent_type"],
            intent=entry.get("intent"),
            resumable=entry["resumable"],
            tags=entry.get("tags", []),
            files_count=files_count,
            files=changed_files,
            deleted=deleted_files,
        )))
    else:
        label = f" — {sanitize_display(entry['intent'] or '')}" if entry.get("intent") else ""
        print(f"shelf/{idx}  {sanitize_display(entry['name'])}{label}")
        cb = entry["created_by"]
        print(f"  Branch:      {sanitize_display(entry['branch'])}")
        print(f"  Intent type: {entry['intent_type']}")
        print(f"  Created by:  {sanitize_display(cb['handle'])} ({cb['kind']})")
        print(f"  Created at:  {entry['created_at']}")
        print(f"  Resumable:   {entry['resumable']}")
        if entry.get("tags"):
            print(f"  Tags:        {', '.join(sanitize_display(t) for t in entry['tags'])}")
        print(f"  Files ({files_count}):")
        for f in changed_files:
            print(f"    M {sanitize_display(f)}")
        for f in deleted_files:
            print(f"    D {sanitize_display(f)}")

def run_apply(args: argparse.Namespace) -> None:
    """Restore a shelf entry to the working tree without removing it.

    Writes each file from the shelf snapshot that differs from HEAD.  Files
    already at the shelf version are counted as ``already_current`` and not
    re-written.  The entry remains in the shelf after this operation.

    Agent quickstart::

        muse shelf apply --json
        muse shelf apply auth-refactor --json
        muse shelf apply 0 --json

    JSON fields::

        status          str    Always "applied"
        name            str    Shelf entry name
        restored        int    Files written from the object store
        already_current int    Files already at the shelf version (not re-written)
        deleted         int    Files removed from the working tree
        shelf_size      int    Total entries remaining in the shelf

    Exit codes::

        0  Success.
        1  Empty shelf, entry not found, or invalid --format.
        2  Not inside a Muse repository.
        3  Object store integrity error (missing blobs).
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    raw: str | None = getattr(args, "entry", None)

    root = require_repo()
    entries = _load_shelf(root)
    if not entries:
        print("❌ No shelf entries.", file=sys.stderr)
        if json_out:
            print(json.dumps({"error": "no_shelf_entries", "shelf_size": 0}))
        raise SystemExit(ExitCode.USER_ERROR)

    try:
        idx, entry = _resolve_entry(entries, raw)
    except ValueError as exc:
        print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    missing = _verify_snapshot_objects(root, entry["snapshot"])
    if missing:
        print(
            f"❌ Shelf entry {sanitize_display(entry['name'])!r} is missing "
            f"{len(missing)} object(s) — aborting.",
            file=sys.stderr,
        )
        for p in sorted(missing):
            print(f"  missing: {sanitize_display(p)}", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    branch = read_current_branch(root)
    head_manifest = get_head_snapshot_manifest(root, branch) or {}
    counts = _apply_shelf_snapshot(root, entry, head_manifest)
    try:
        head_commit_id = get_head_commit_id(root, branch)
        if head_commit_id:
            append_reflog(
                root, branch,
                old_id=entry.get("parent_commit") or None,
                new_id=head_commit_id,
                author="user",
                operation=f"shelf-apply: restored {entry['name']!r}",
            )
    except Exception as _rl_exc:
        logger.warning("⚠️ reflog: failed to record shelf-apply: %s", _rl_exc)

    if json_out:
        print(json.dumps(_ShelfApplyJson(
            **make_envelope(elapsed),
            status="applied",
            name=entry["name"],
            restored=counts["restored"],
            already_current=counts["already_current"],
            deleted=counts["deleted"],
            shelf_size=len(entries),
        )))
    else:
        parts = [f"{counts['restored']} restored"]
        if counts["already_current"]:
            parts.append(f"{counts['already_current']} already current")
        if counts["deleted"]:
            parts.append(f"{counts['deleted']} deleted")
        print(f"Applied {sanitize_display(entry['name'])!r} ({', '.join(parts)})")

def run_pop(args: argparse.Namespace) -> None:
    """Restore a shelf entry and remove it from the shelf.

    Restores the snapshot to the working tree and removes the entry from
    the shelf registry.  Use this when you are ready to continue the shelved
    work in place and do not need to keep the checkpoint.

    Agent quickstart::

        muse shelf pop --json
        muse shelf pop auth-refactor --json
        muse shelf pop 0 --json

    JSON fields::

        status           str    Always "popped"
        name             str    Shelf entry name
        restored         int    Files written from the object store
        already_current  int    Files already at the shelf version (not re-written)
        deleted          int    Files removed from the working tree
        shelf_size_after int    Total entries remaining after the pop

    Exit codes::

        0  Success.
        1  Empty shelf, entry not found, or invalid --format.
        2  Not inside a Muse repository.
        3  Object store integrity error (missing blobs).
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    raw: str | None = getattr(args, "entry", None)

    root = require_repo()
    entries = _load_shelf(root)
    if not entries:
        print("❌ No shelf entries.", file=sys.stderr)
        if json_out:
            print(json.dumps({"error": "no_shelf_entries", "shelf_size": 0}))
        raise SystemExit(ExitCode.USER_ERROR)

    try:
        idx, entry = _resolve_entry(entries, raw)
    except ValueError as exc:
        print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    missing = _verify_snapshot_objects(root, entry["snapshot"])
    if missing:
        print(
            f"❌ Shelf entry {sanitize_display(entry['name'])!r} is missing "
            f"{len(missing)} object(s) — aborting to prevent data loss.",
            file=sys.stderr,
        )
        for p in sorted(missing):
            print(f"  missing: {sanitize_display(p)}", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    branch = read_current_branch(root)
    head_manifest = get_head_snapshot_manifest(root, branch) or {}

    _delete_shelf_entry(root, entry["id"])
    counts = _apply_shelf_snapshot(root, entry, head_manifest)
    try:
        head_commit_id = get_head_commit_id(root, branch)
        if head_commit_id:
            append_reflog(
                root, branch,
                old_id=entry.get("parent_commit") or None,
                new_id=head_commit_id,
                author="user",
                operation=f"shelf-pop: restored {entry['name']!r}",
            )
    except Exception as _rl_exc:
        logger.warning("⚠️ reflog: failed to record shelf-pop: %s", _rl_exc)
    remaining = _load_shelf(root)

    if json_out:
        print(json.dumps(_ShelfPopJson(
            **make_envelope(elapsed),
            status="popped",
            name=entry["name"],
            restored=counts["restored"],
            already_current=counts["already_current"],
            deleted=counts["deleted"],
            shelf_size_after=len(remaining),
        )))
    else:
        parts = [f"{counts['restored']} restored"]
        if counts["already_current"]:
            parts.append(f"{counts['already_current']} already current")
        if counts["deleted"]:
            parts.append(f"{counts['deleted']} deleted")
        print(f"Popped {sanitize_display(entry['name'])!r} ({', '.join(parts)})")

def run_drop(args: argparse.Namespace) -> None:
    """Discard a shelf entry without applying it.

    Removes the entry from the shelf registry without restoring any files.
    Use this to discard work-in-progress that is no longer needed.

    Agent quickstart::

        muse shelf drop --json
        muse shelf drop auth-refactor --json
        muse shelf drop 0 --json

    JSON fields::

        status      str    Always "dropped"
        name        str    Shelf entry name
        id          str    Content-addressed shelf entry ID
        shelf_size  int    Total entries remaining after the drop

    Exit codes::

        0  Success.
        1  Empty shelf, entry not found, or invalid --format.
        2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    raw: str | None = getattr(args, "entry", None)

    root = require_repo()
    entries = _load_shelf(root)
    if not entries:
        print("❌ No shelf entries.", file=sys.stderr)
        if json_out:
            print(json.dumps({"error": "no_shelf_entries", "shelf_size": 0}))
        raise SystemExit(ExitCode.USER_ERROR)

    try:
        idx, entry = _resolve_entry(entries, raw)
    except ValueError as exc:
        print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    _delete_shelf_entry(root, entry["id"])
    remaining = _load_shelf(root)

    if json_out:
        print(json.dumps(_ShelfDropJson(
            **make_envelope(elapsed),
            status="dropped",
            name=entry["name"],
            id=entry["id"],
            shelf_size=len(remaining),
        )))
    else:
        print(f"Dropped {sanitize_display(entry['name'])!r}")

def run_diff(args: argparse.Namespace) -> None:
    """Show what applying a shelf entry would change.

    Compares the shelf snapshot against the current HEAD.  Does not modify
    the working tree — purely informational, safe to call at any time.

    Agent quickstart::

        muse shelf diff --json
        muse shelf diff auth-refactor --json
        muse shelf diff 0 --json

    JSON fields::

        name            str         Shelf entry name
        branch          str         Branch at shelf time
        would_restore   list[str]   Paths that differ from HEAD (would be written)
        already_current list[str]   Paths already at the shelf version (no-op)
        would_delete    list[str]   Paths that would be removed from the working tree

    Exit codes::

        0  Success.
        1  Empty shelf, entry not found, or invalid --format.
        2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    raw: str | None = getattr(args, "entry", None)

    root = require_repo()
    entries = _load_shelf(root)
    if not entries:
        print("❌ No shelf entries.", file=sys.stderr)
        if json_out:
            print(json.dumps({"error": "no_shelf_entries", "shelf_size": 0}))
        raise SystemExit(ExitCode.USER_ERROR)

    try:
        idx, entry = _resolve_entry(entries, raw)
    except ValueError as exc:
        print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    branch = read_current_branch(root)
    head_manifest = get_head_snapshot_manifest(root, branch) or {}

    would_restore = sorted(
        p for p, oid in entry["snapshot"].items()
        if head_manifest.get(p) != oid
    )
    already_current = sorted(
        p for p, oid in entry["snapshot"].items()
        if head_manifest.get(p) == oid
    )
    would_delete = sorted(entry["deleted"])

    if json_out:
        print(json.dumps(_ShelfDiffJson(
            **make_envelope(elapsed),
            name=entry["name"],
            branch=entry["branch"],
            would_restore=would_restore,
            already_current=already_current,
            would_delete=would_delete,
        )))
    else:
        label = f" — {sanitize_display(entry['intent'] or '')}" if entry.get("intent") else ""
        print(f"shelf/{idx}  {sanitize_display(entry['name'])}{label}")
        for f in would_restore:
            print(f"  M {sanitize_display(f)}  (would restore)")
        for f in would_delete:
            print(f"  D {sanitize_display(f)}  (would delete)")
        for f in already_current:
            print(f"  = {sanitize_display(f)}  (already current)")
