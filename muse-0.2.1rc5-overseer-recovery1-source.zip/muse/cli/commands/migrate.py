"""``muse code migrate`` — unified object store migration + v2 commit ID replay.

Brings a repository fully up to date with the current on-disk format.
Safe to run on an already-migrated repo — all passes are idempotent.

Passes performed (in order)
----------------------------
1. **Blob relocation** — legacy blobs stored without an algo subdirectory
   are moved to the canonical ``.muse/objects/sha256/`` layout.

2. **Snapshot relocation** — msgpack files in ``.muse/snapshots/sha256/``
   are moved into the unified ``.muse/objects/sha256/`` store and the
   legacy ``.muse/snapshots/`` directory is removed.

3. **Commit relocation** — msgpack files in ``.muse/commits/sha256/`` are
   moved into the unified ``.muse/objects/sha256/`` store and the legacy
   ``.muse/commits/`` directory is removed.

4. **v2 commit ID rewrite** — rewrites commits whose IDs were produced by
   the v1 formula (which did not bind ``repo_id``, ``author``, or
   ``signer_public_key``).  All branch refs, remote tracking refs, and
   reflogs are updated to the new IDs.

5. **Signature normalisation** — bare base64 Ed25519 signatures are
   normalised to the ``ed25519:…`` prefix.

Dry-run mode (``--dry-run``) is the default-safe entry point — it prints the
full id_map and counts but makes zero writes.

Usage::

    muse code migrate --dry-run    # inspect, zero writes (safe)
    muse code migrate              # execute the full migration
    muse code migrate --sign       # also sign unsigned commits
    muse code migrate --json       # machine-readable output

Output::

    {
      "commits_rewritten":    <int>,
      "blobs_migrated":       <int>,
      "blobs_rewritten":      <int>,
      "snapshots_relocated":  <int>,
      "snapshots_rewritten":  <int>,
      "commits_relocated":    <int>,
      "commits_unified":      <int>,
      "legacy_dirs_removed":  <int>,
      "refs_updated":         <int>,
      "remote_refs_updated":  <int>,
      "signatures_normalised":<int>,
      "commits_signed":       <int>,
      "id_map":               {"sha256:<old>": "sha256:<new>", ...},
      "dry_run":              true | false
    }

Exit codes
----------
- 0: Migration completed (or dry-run completed) successfully.
- 1: Merge or rebase in progress — finish it first.
- 2: I/O error during migration.
"""

import argparse
import json
import logging
import sys
import time

from muse.core.errors import ExitCode
from muse.core.migrate import migrate
from muse.core.repo import require_repo

logger = logging.getLogger(__name__)

def register(subparsers: argparse._SubParsersAction) -> None:
    parser = subparsers.add_parser(
        "migrate",
        help="Rewrite the commit DAG with the v2 commit ID formula.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Print the id_map and counts but make no writes (default: False).",
    )
    parser.add_argument(
        "--sign",
        action="store_true",
        default=False,
        help="Sign unsigned commits (and re-sign invalidated ones) with the current identity.",
    )
    parser.add_argument(
        "--force-resign",
        dest="force_resign",
        action="store_true",
        default=False,
        help="Re-sign every commit with the current identity, even already-signed ones. "
             "Implies --sign. Use when the repo was signed with a different key.",
    )
    parser.add_argument(
        "--json", "-j",
        dest="json_out",
        action="store_true",
        default=False,
        help="Emit machine-readable JSON.",
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Execute the v2 commit ID migration (or dry-run)."""
    t0 = time.monotonic()
    json_out: bool = args.json_out
    dry_run: bool = args.dry_run

    root = require_repo()

    signing_identity = None
    if args.sign or args.force_resign:
        from muse.cli.config import get_signing_identity, list_remotes
        signing_identity = get_signing_identity(repo_root=root)
        if signing_identity is None:
            for remote in list_remotes(repo_root=root):
                signing_identity = get_signing_identity(repo_root=root, remote_url=remote["url"])
                if signing_identity is not None:
                    break

    try:
        result = migrate(root, dry_run=dry_run, signing_identity=signing_identity, force_resign=args.force_resign)
    except (RuntimeError, ValueError) as exc:
        msg = str(exc)
        if json_out:
            print(json.dumps({"error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    except OSError as exc:
        msg = f"I/O error during migration: {exc}"
        if json_out:
            print(json.dumps({"error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    elapsed_ms = round((time.monotonic() - t0) * 1000)

    if json_out:
        print(json.dumps({
            "commits_rewritten": result.commits_rewritten,
            "blobs_migrated": result.blobs_migrated,
            "legacy_dirs_removed": result.legacy_dirs_removed,
            "commits_relocated": result.commits_relocated,
            "snapshots_relocated": result.snapshots_relocated,
            "refs_updated": result.refs_updated,
            "remote_refs_updated": result.remote_refs_updated,
            "repo_id_updated": result.repo_id_updated,
            "branch_fields_renamed": result.branch_fields_renamed,
            "signatures_normalised": result.signatures_normalised,
            "format_versions_bumped": result.format_versions_bumped,
            "reflogs_updated": result.reflogs_updated,
            "commits_signed": result.commits_signed,
            "unsigned_commits_skipped": result.unsigned_commits_skipped,
            "blobs_rewritten": result.blobs_rewritten,
            "snapshots_rewritten": result.snapshots_rewritten,
            "commits_unified": result.commits_unified,
            "id_map": result.id_map,
            "dry_run": result.dry_run,
            "duration_ms": elapsed_ms,
        }))
        return

    prefix = "[dry-run] " if dry_run else ""
    print(f"{prefix}commits rewritten:   {result.commits_rewritten}")
    print(f"{prefix}blobs migrated:      {result.blobs_migrated}")
    print(f"{prefix}legacy dirs removed: {result.legacy_dirs_removed}")
    print(f"{prefix}blobs rewritten:     {result.blobs_rewritten}")
    print(f"{prefix}snapshots rewritten: {result.snapshots_rewritten}")
    print(f"{prefix}commits unified:     {result.commits_unified}")
    if result.id_map:
        print(f"\n{prefix}ID map ({len(result.id_map)} changed):")
        for old, new in result.id_map.items():
            print(f"  {old} → {new}")
    else:
        print(f"\n{prefix}No commits needed rewriting.")
