"""``muse bridge`` — Bidirectional Git interoperability.

Bridge makes Muse and Git speak to each other without losing identity in either
direction.  Three subcommands form the bridge namespace:

    git-import    Git → Muse   Replay a git repo's commits into a Muse repo.
    git-export    Muse → Git   Sync a Muse snapshot into a git working tree.
    git-status    Both         Show bridge state, drift, and last sync points.

Bridge state is persisted in ``.muse/git-bridge.toml`` — a TOML file that
records the last imported git SHA and the last exported Muse commit ID.  Add
``.muse/git-bridge.toml`` to ``.museignore`` to keep per-developer state out
of the object store.

All Muse commit IDs stored in bridge state are **canonically prefixed**:
``sha256:<64-hex>``.  Bare hex strings are never stored or returned.

Canonical prefix rules
-----------------------
- ``muse_commit_id`` — always ``sha256:<64-hex>``; :func:`write_bridge_state`
  raises :class:`ValueError` if the value lacks the prefix.
- ``git_sha`` — bare 40-char SHA-1 hex; no prefix (Git native format).

CI authentication
-----------------
Both git-import and git-export read signing identity from:

1. ``MUSE_AGENT_KEY`` environment variable (PEM-encoded Ed25519 private key)
2. ``MUSE_AGENT_HANDLE`` environment variable (registered agent handle)
3. ``~/.muse/identity.toml`` — fallback for interactive use

Usage examples::

    muse bridge git-import /path/to/git-repo --incremental --json
    muse bridge git-export --git-dir /path/to/git-mirror --no-push
    muse bridge git-status --json

Domain logic lives in ``muse.core.bridge``:
    state           BridgeState TypedDicts, read/write_bridge_state
    hooks           BridgeHook, BridgeHooks, load/run_bridge_hooks
    git_primitives  AttributionMapper, _CatFile, subprocess wrappers
    importer        Git → Muse import engine
    harmony_shelf   Harmony ↔ rerere, Shelf ↔ Stash migration
    exporter        Muse → Git export engine + watch loop
    status          drift computation and status display
"""

import argparse

from muse.core.bridge.exporter import _register_git_export_parser
from muse.core.bridge.importer import _register_git_import_parser
from muse.core.bridge.status import _register_git_status_parser


def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register ``muse bridge`` and its three subcommands.

    Subcommands:
        git-import   Git → Muse incremental import with attribution mapping.
        git-export   Muse → Git snapshot sync with CI push support.
        git-status   Bridge state and drift report.
    """
    parser = subparsers.add_parser(
        "bridge",
        help="Bidirectional Git interoperability (git-import / git-export).",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subs = parser.add_subparsers(dest="bridge_subcommand", metavar="SUBCOMMAND")
    subs.required = True

    _register_git_import_parser(subs)
    _register_git_export_parser(subs)
    _register_git_status_parser(subs)
