"""``muse rebase`` — replay commits from one branch onto another.

Muse rebase is cherry-pick of a range: it takes the commits unique to the
current branch (those not reachable from the upstream) and replays them
one-by-one on top of the upstream.  Because commits are content-addressed,
each replayed commit gets a new ID — the originals are untouched in the store.

Usage::

    muse rebase <upstream>                       # replay HEAD's unique commits onto upstream
    muse rebase --onto <newbase> <upstream>      # replay onto a different base
    muse rebase --squash [<upstream>]            # collapse all commits into one
    muse rebase --squash -m "msg" [<upstream>]   # squash with explicit commit message
    muse rebase --dry-run <upstream>             # preview which commits would be replayed
    muse rebase --status                         # show progress of an in-progress rebase
    muse rebase --abort                          # restore original HEAD
    muse rebase --continue                       # resume after resolving a conflict
    muse rebase --max-commits N <upstream>       # cap the number of commits replayed

All subcommands accept ``--json`` for machine-readable output::

    muse rebase --json main
    muse rebase --abort --json
    muse rebase --status --json

All JSON outputs include standard envelope fields (``duration_ms``,
``exit_code``, ``muse_version``, ``timestamp``, ``schema``, ``warnings``).
Result payloads also include ``replayed_commit_ids``
(list of sha256:-prefixed commit IDs produced during replay).

Exit codes::

    0 — success (completed, aborted, dry-run, status, up_to_date)
    1 — conflict encountered, bad arguments, or user error
    3 — internal error
"""

import argparse
import datetime
import json
import logging
import pathlib
import sys
import time
from typing import TypedDict

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.merge_engine import find_merge_base, write_merge_state
from muse.core.rebase import (
    RebaseState,
    _write_branch_ref,
    clear_rebase_state,
    collect_commits_to_replay,
    get_rebase_progress,
    load_rebase_state,
    replay_one,
    save_rebase_state,
)
from muse.core.reflog import append_reflog
from muse.core.repo import require_repo
from muse.core.ids import hash_commit, hash_snapshot
from muse.core.snapshot import directories_from_manifest
from muse.core.refs import read_ref
from muse.core.types import Manifest
from muse.core.refs import (
    RefConflictError,
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import (
    CommitRecord,
    read_commit,
    resolve_commit_ref,
    write_commit,
)
from muse.core.snapshots import (
    SnapshotRecord,
    read_snapshot,
    write_snapshot,
)
from muse.core.validation import sanitize_display, validate_branch_name
from muse.core.types import long_id, short_id, split_id
from muse.core.paths import ref_path as _ref_path
from muse.core.workdir import apply_manifest
from muse.core.timing import start_timer
from muse.domain import MuseDomainPlugin, SnapshotManifest
from muse.plugins.registry import read_domain, resolve_plugin

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# JSON wire formats
# ---------------------------------------------------------------------------

class _RebaseResultJson(EnvelopeJson):
    """JSON output for a completed rebase (normal or squash).

    ``replayed_commit_ids`` contains the new (rebased) commit IDs produced
    during replay — sha256:-prefixed, in replay order.  Empty for aborted,
    conflict, and up_to_date outcomes.
    """

    status: str          # "completed" | "conflict" | "aborted" | "up_to_date"
    branch: str
    new_head: str | None
    onto: str
    squash: bool
    replayed: int
    replayed_commit_ids: list[str]
    conflicts: list[str]

class _RebaseStatusJson(EnvelopeJson):
    """JSON output for ``muse rebase --status``."""

    active: bool
    original_branch: str
    original_head: str
    onto: str
    total: int
    done: int
    remaining: int
    squash: bool

class _RebaseDryRunCommitJson(TypedDict):
    """One entry in the ``--dry-run`` commits list."""

    commit_id: str
    message: str

class _RebaseDryRunJson(EnvelopeJson):
    """JSON output for ``muse rebase --dry-run``."""

    branch: str
    onto: str
    commits: list[_RebaseDryRunCommitJson]
    count: int
    squash: bool

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _resolve_ref_to_id(
    root: pathlib.Path,
    branch: str,
    ref: str,
) -> str | None:
    """Resolve a ref string (branch name, commit SHA, or HEAD) to a commit ID.

    Branch names are validated with ``validate_branch_name`` before being used
    as path components to prevent directory traversal attacks.
    """
    if ref.upper() == "HEAD":
        return get_head_commit_id(root, branch)

    # Try as a branch ref — validate before using as a path component.
    is_valid_branch = True
    try:
        validate_branch_name(ref)
    except ValueError:
        is_valid_branch = False

    if is_valid_branch:
        ref_path = _ref_path(root, ref)
        raw = read_ref(ref_path)
        if raw is not None and raw.startswith("sha256:"):
            _, hex_part = split_id(raw)
            if len(hex_part) == 64 and all(c in "0123456789abcdef" for c in hex_part):
                return raw

    # Fall back to commit SHA prefix resolution.
    rec = resolve_commit_ref(root, branch, ref)
    return rec.commit_id if rec else None

def _run_replay_loop(
    root: pathlib.Path,
    state: RebaseState,
    branch: str,
    plugin: MuseDomainPlugin,
    domain: str,
    json_out: bool,
    t0: float,
) -> bool:
    """Run the replay loop.

    Emits progress text (or NDJSON per commit when *json_out* is True)
    to stdout and writes ``MERGE_STATE.json`` on conflict.

    Args:
        t0: ``time.monotonic()`` value captured at the start of ``run()``
            — used to compute ``elapsed()`` in conflict JSON.

    Returns:
        ``True`` if all commits were replayed cleanly; ``False`` on conflict.
    """
    current_parent = state["completed"][-1] if state["completed"] else state["onto"]

    while state["remaining"]:
        orig_commit_id = state["remaining"][0]
        commit = read_commit(root, orig_commit_id)
        if commit is None:
            logger.warning("⚠️ Commit %s not found — skipping.", orig_commit_id)
            state["remaining"].pop(0)
            save_rebase_state(root, state)
            continue

        if not json_out:
            total = len(state["completed"]) + len(state["remaining"])
            done = len(state["completed"]) + 1
            print(
                f"  [{done}/{total}] Replaying {orig_commit_id}: "
                f"{sanitize_display(commit.message)}"
            )

        result = replay_one(
            root, commit, current_parent, plugin, domain, branch
        )

        if isinstance(result, list):
            # Conflict — write state and pause.
            state["remaining"].insert(0, orig_commit_id)
            save_rebase_state(root, state)

            write_merge_state(
                root,
                base_commit=commit.parent_commit_id or "",
                ours_commit=current_parent,
                theirs_commit=orig_commit_id,
                conflict_paths=result,
            )
            if json_out:
                result_payload = _RebaseResultJson(
                    **make_envelope(elapsed, exit_code=1),
                    status="conflict",
                    branch=branch,
                    new_head=None,
                    onto=state["onto"],
                    squash=False,
                    replayed=len(state["completed"]),
                    replayed_commit_ids=list(state["completed"]),
                    conflicts=sorted(result),
                )
                print(json.dumps(result_payload))
            else:
                print(
                    f"\n❌ Rebase stopped at {orig_commit_id} due to conflict(s):",
                    file=sys.stderr,
                )
                for p in sorted(result):
                    print(f"  CONFLICT: {p}", file=sys.stderr)
                print(
                    "\nResolve conflicts then run:\n"
                    "  muse rebase --continue    to resume\n"
                    "  muse rebase --abort       to restore original HEAD",
                    file=sys.stderr,
                )
            return False

        # Clean replay — advance.
        current_parent = result.commit_id
        state["remaining"].pop(0)
        state["completed"].append(result.commit_id)
        save_rebase_state(root, state)

        old_id = (
            state["completed"][-2]
            if len(state["completed"]) >= 2
            else state["onto"]
        )
        append_reflog(
            root, branch,
            old_id=old_id,
            new_id=result.commit_id,
            author="user",
            operation=f"rebase: replayed {orig_commit_id} onto {state['onto']}",
        )

    return True

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse rebase`` subcommand and all its flags."""
    parser = subparsers.add_parser(
        "rebase",
        help="Replay commits from the current branch onto a new base.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "upstream",
        nargs="?",
        default=None,
        metavar="UPSTREAM",
        help="Branch or commit to rebase onto.",
    )
    parser.add_argument(
        "--onto",
        default=None,
        metavar="NEWBASE",
        help="Replay commits onto this base instead of upstream.",
    )
    parser.add_argument(
        "--squash",
        action="store_true",
        help="Collapse all replayed commits into one.",
    )
    parser.add_argument(
        "--message", "-m",
        dest="squash_message",
        default=None,
        metavar="MSG",
        help="Commit message for the squashed commit (only with --squash).",
    )
    parser.add_argument(
        "--abort",
        action="store_true",
        help="Abort an in-progress rebase and restore original HEAD.",
    )
    parser.add_argument(
        "--continue",
        dest="continue_",
        action="store_true",
        help="Resume a paused rebase after resolving conflicts.",
    )
    parser.add_argument(
        "-n", "--dry-run",
        dest="dry_run",
        action="store_true",
        help="Show which commits would be replayed without actually replaying them.",
    )
    parser.add_argument(
        "--status",
        action="store_true",
        help="Show progress of an in-progress rebase.",
    )
    parser.add_argument(
        "--max-commits",
        type=int,
        default=10_000,
        dest="max_commits",
        metavar="N",
        help="Maximum number of commits to replay (default: 10 000).",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON on stdout.",
    )
    parser.set_defaults(func=run)

# ---------------------------------------------------------------------------
# Main handler
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Replay commits from the current branch onto a new base.

    The most common invocation replays all commits unique to the current
    branch on top of *upstream*'s HEAD::

        muse rebase main           # rebase current branch onto main
        muse rebase --json main    # same, machine-readable

    Use ``--onto`` when you need to replay onto a commit that is not the
    tip of *upstream*::

        muse rebase --onto newbase upstream

    Use ``--squash`` to collapse all replayed commits into one::

        muse rebase --squash main
        muse rebase --squash -m "feat: combined" main

    Use ``--dry-run`` to preview which commits would be replayed::

        muse rebase --dry-run main
        muse rebase --dry-run --json main

    Use ``--status`` to inspect an in-progress rebase::

        muse rebase --status
        muse rebase --status --json

    When a conflict is encountered, the rebase pauses.  Resolve the conflict,
    stage the resolved files, then::

        muse rebase --continue

    Or discard the entire rebase::

        muse rebase --abort

    JSON output
    -----------
    All outcomes emit a consistent payload when ``--json`` is supplied:

    All JSON payloads include standard envelope fields (``duration_ms``,
    ``exit_code``, ``muse_version``, ``timestamp``, ``schema``, ``warnings``).

    Completed rebase::

        {"status":"completed","branch":"feat/x","new_head":"sha256:<hex>",
         "onto":"sha256:<hex>","squash":false,"replayed":3,
         "replayed_commit_ids":["sha256:<hex>",...],
         "conflicts":[],"duration_ms":12.3,"exit_code":0}

    Conflict::

        {"status":"conflict","branch":"feat/x","new_head":null,"onto":"sha256:<hex>",
         "squash":false,"replayed":1,"replayed_commit_ids":["sha256:<hex>"],
         "conflicts":["path/to/file"],"duration_ms":5.1,"exit_code":1}

    Aborted::

        {"status":"aborted","branch":"feat/x","new_head":"sha256:<hex>",
         "onto":"sha256:<hex>","squash":false,"replayed":0,
         "replayed_commit_ids":[],"conflicts":[],"duration_ms":2.0,"exit_code":0}

    Already up to date::

        {"status":"up_to_date","branch":"feat/x","new_head":"sha256:<hex>",
         "onto":"sha256:<hex>","squash":false,"replayed":0,
         "replayed_commit_ids":[],"conflicts":[],"duration_ms":1.5,"exit_code":0}

    Dry-run::

        {"branch":"feat/x","onto":"sha256:<hex>","commits":[...],"count":3,
         "squash":false,"duration_ms":3.2,"exit_code":0}

    Status::

        {"active":true,"original_branch":"feat/x","original_head":"sha256:<hex>",
         "onto":"sha256:<hex>","total":5,"done":2,"remaining":3,"squash":false,
         "duration_ms":0.5,"exit_code":0}
    """
    import time as _time
    t0 = _time.monotonic()
    elapsed = start_timer()

    upstream: str | None = args.upstream
    onto: str | None = getattr(args, "onto", None)
    squash: bool = args.squash
    squash_message: str | None = args.squash_message
    abort: bool = args.abort
    continue_: bool = args.continue_
    dry_run: bool = args.dry_run
    show_status: bool = args.status
    max_commits: int = args.max_commits
    json_out: bool = args.json_out

    root = require_repo()
    branch = read_current_branch(root)

    # --status — does not need plugin/domain
    if show_status:
        progress = get_rebase_progress(root)
        if json_out:
            status_payload = _RebaseStatusJson(
                **make_envelope(elapsed),
                active=progress["active"],
                original_branch=progress["original_branch"],
                original_head=progress["original_head"],
                onto=progress["onto"],
                total=progress["total"],
                done=progress["done"],
                remaining=progress["remaining"],
                squash=progress["squash"],
            )
            print(json.dumps(status_payload))
        else:
            if not progress["active"]:
                print("No rebase in progress.")
            else:
                print(
                    f"Rebase in progress on '{sanitize_display(progress['original_branch'])}'\n"
                    f"  onto:      {progress['onto']}\n"
                    f"  progress:  {progress['done']}/{progress['total']} commits done "
                    f"({progress['remaining']} remaining)\n"
                    f"  squash:    {progress['squash']}"
                )
        return

    plugin = resolve_plugin(root)
    domain = read_domain(root)
    active_state = load_rebase_state(root)

    # --abort
    if abort:
        if active_state is None:
            print("❌ No rebase in progress.", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

        original_head = active_state["original_head"]
        original_branch = active_state["original_branch"]
        _write_branch_ref(root, original_branch, original_head)

        orig_commit = read_commit(root, original_head)
        if orig_commit:
            snap = read_snapshot(root, orig_commit.snapshot_id)
            if snap:
                apply_manifest(root, {}, snap.manifest)

        append_reflog(
            root, original_branch,
            old_id=active_state["completed"][-1] if active_state["completed"] else active_state["onto"],
            new_id=original_head,
            author="user",
            operation="rebase: abort",
        )
        clear_rebase_state(root)

        if json_out:
            result_payload = _RebaseResultJson(
                **make_envelope(elapsed),
                status="aborted",
                branch=original_branch,
                new_head=original_head,
                onto=active_state["onto"],
                squash=active_state["squash"],
                replayed=len(active_state["completed"]),
                replayed_commit_ids=[],
                conflicts=[],
            )
            print(json.dumps(result_payload))
        else:
            print(f"✅ Rebase aborted. HEAD restored to {original_head}.")
        return

    # --continue
    if continue_:
        if active_state is None:
            print("❌ No rebase in progress. Nothing to continue.", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

        current_parent = (
            active_state["completed"][-1]
            if active_state["completed"]
            else active_state["onto"]
        )
        orig_commit_id = active_state["remaining"][0] if active_state["remaining"] else ""
        orig_commit = read_commit(root, orig_commit_id) if orig_commit_id else None

        snap_result = plugin.snapshot(root)
        manifest: Manifest = snap_result["files"]
        manifest_dirs = directories_from_manifest(manifest)
        snapshot_id = hash_snapshot(manifest, manifest_dirs)
        committed_at = datetime.datetime.now(datetime.timezone.utc)
        message = orig_commit.message if orig_commit else "rebase: continued"
        _author = orig_commit.author if orig_commit else ""
        new_commit_id = hash_commit(
            parent_ids=[current_parent] if current_parent else [],
            snapshot_id=snapshot_id,
            message=message,
            committed_at_iso=committed_at.isoformat(),
            author=_author,
        )
        write_snapshot(root, SnapshotRecord(snapshot_id=snapshot_id, manifest=manifest, directories=manifest_dirs))
        new_commit = CommitRecord(
            commit_id=new_commit_id,
            branch=branch,
            snapshot_id=snapshot_id,
            message=message,
            committed_at=committed_at,
            parent_commit_id=current_parent if current_parent else None,
            author=orig_commit.author if orig_commit else "",
        )
        write_commit(root, new_commit)
        active_state["completed"].append(new_commit_id)
        if active_state["remaining"]:
            active_state["remaining"].pop(0)
        save_rebase_state(root, active_state)

        append_reflog(
            root, branch,
            old_id=current_parent,
            new_id=new_commit_id,
            author="user",
            operation=f"rebase: continue — replayed {orig_commit_id if orig_commit_id else '?'}",
        )

        if not active_state["remaining"]:
            try:
                _write_branch_ref(root, branch, new_commit_id, expected_id=active_state["original_head"])
            except RefConflictError as exc:
                print(f"❌ {exc}", file=sys.stderr)
                raise SystemExit(ExitCode.USER_ERROR)
            clear_rebase_state(root)
            if json_out:
                result_payload = _RebaseResultJson(
                    **make_envelope(elapsed),
                    status="completed",
                    branch=branch,
                    new_head=new_commit_id,
                    onto=active_state["onto"],
                    squash=False,
                    replayed=len(active_state["completed"]),
                    replayed_commit_ids=list(active_state["completed"]),
                    conflicts=[],
                )
                print(json.dumps(result_payload))
            else:
                print(f"✅ Rebase complete. HEAD is now {new_commit_id}.")
            return

        clean = _run_replay_loop(
            root, active_state, branch, plugin, domain, json_out, t0
        )
        if clean:
            final_id = active_state["completed"][-1]
            try:
                _write_branch_ref(root, branch, final_id, expected_id=active_state["original_head"])
            except RefConflictError as exc:
                print(f"❌ {exc}", file=sys.stderr)
                raise SystemExit(ExitCode.USER_ERROR)
            clear_rebase_state(root)
            if json_out:
                result_payload = _RebaseResultJson(
                    **make_envelope(elapsed),
                    status="completed",
                    branch=branch,
                    new_head=final_id,
                    onto=active_state["onto"],
                    squash=False,
                    replayed=len(active_state["completed"]),
                    replayed_commit_ids=list(active_state["completed"]),
                    conflicts=[],
                )
                print(json.dumps(result_payload))
            else:
                print(f"✅ Rebase complete. HEAD is now {final_id}.")
        return

    # New rebase
    if active_state is not None:
        print("❌ Rebase in progress. Use --continue or --abort.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    if upstream is None:
        print("❌ Provide an upstream branch or commit to rebase onto.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    head_commit_id = get_head_commit_id(root, branch)
    if head_commit_id is None:
        print("❌ Current branch has no commits.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    upstream_id = _resolve_ref_to_id(root, branch, upstream)
    if upstream_id is None:
        print(
            f"❌ Upstream '{sanitize_display(upstream)}' not found.", file=sys.stderr
        )
        raise SystemExit(ExitCode.USER_ERROR)

    if onto is not None:
        onto_id = _resolve_ref_to_id(root, branch, onto)
        if onto_id is None:
            print(
                f"❌ --onto '{sanitize_display(onto)}' not found.", file=sys.stderr
            )
            raise SystemExit(ExitCode.USER_ERROR)
    else:
        onto_id = upstream_id

    merge_base_id = find_merge_base(root, head_commit_id, upstream_id)
    stop_at = merge_base_id or ""

    if head_commit_id == upstream_id or head_commit_id == onto_id:
        if json_out:
            result_payload = _RebaseResultJson(
                **make_envelope(elapsed),
                status="up_to_date",
                branch=branch,
                new_head=head_commit_id,
                onto=onto_id,
                squash=squash,
                replayed=0,
                replayed_commit_ids=[],
                conflicts=[],
            )
            print(json.dumps(result_payload))
        else:
            print("Already up to date.")
        return

    commits_to_replay = collect_commits_to_replay(
        root, stop_at, head_commit_id, max_commits=max_commits
    )
    if not commits_to_replay:
        if json_out:
            result_payload = _RebaseResultJson(
                **make_envelope(elapsed),
                status="up_to_date",
                branch=branch,
                new_head=head_commit_id,
                onto=onto_id,
                squash=squash,
                replayed=0,
                replayed_commit_ids=[],
                conflicts=[],
            )
            print(json.dumps(result_payload))
        else:
            print("Already up to date.")
        return

    # --dry-run — show plan and exit
    if dry_run:
        if json_out:
            commit_entries = [
                _RebaseDryRunCommitJson(
                    commit_id=c.commit_id,
                    message=sanitize_display(c.message),
                )
                for c in commits_to_replay
            ]
            dry_payload = _RebaseDryRunJson(
                **make_envelope(elapsed),
                branch=branch,
                onto=onto_id,
                commits=commit_entries,
                count=len(commits_to_replay),
                squash=squash,
            )
            print(json.dumps(dry_payload))
        else:
            print(
                f"Would rebase {len(commits_to_replay)} commit(s) "
                f"onto {onto_id} (from {branch})"
            )
            for c in commits_to_replay:
                print(f"  {short_id(c.commit_id)}  {sanitize_display(c.message)}")
        return

    if not json_out:
        print(
            f"Rebasing {len(commits_to_replay)} commit(s) "
            f"onto {onto_id} (from {branch})"
        )

    # Squash mode
    if squash:
        current_parent = onto_id
        squash_manifest: Manifest = {}

        onto_commit = read_commit(root, onto_id)
        if onto_commit:
            onto_snap = read_snapshot(root, onto_commit.snapshot_id)
            if onto_snap:
                squash_manifest = dict(onto_snap.manifest)

        conflict_occurred = False
        conflict_paths: list[str] = []
        for commit in commits_to_replay:
            base_manifest: Manifest = {}
            if commit.parent_commit_id:
                pc = read_commit(root, commit.parent_commit_id)
                if pc:
                    ps = read_snapshot(root, pc.snapshot_id)
                    if ps:
                        base_manifest = ps.manifest

            theirs_snap = read_snapshot(root, commit.snapshot_id)
            if theirs_snap is None:
                print(
                    f"❌ Rebase aborted: snapshot {commit.snapshot_id} for "
                    f"commit {commit.commit_id} ({commit.message!r}) is missing "
                    "or corrupt. A squash with a missing snapshot would silently "
                    "delete all files from that commit. "
                    "Run `muse verify-pack` to audit the store.",
                    file=sys.stderr,
                )
                raise SystemExit(ExitCode.INTERNAL_ERROR)
            theirs_manifest = theirs_snap.manifest

            result = plugin.merge(
                SnapshotManifest(files=base_manifest, domain=domain, directories=directories_from_manifest(base_manifest)),
                SnapshotManifest(files=squash_manifest, domain=domain, directories=directories_from_manifest(squash_manifest)),
                SnapshotManifest(files=theirs_manifest, domain=domain, directories=directories_from_manifest(theirs_manifest)),
                repo_root=root,
            )
            if not result.is_clean:
                conflict_paths = sorted(result.conflicts)
                if json_out:
                    result_payload = _RebaseResultJson(
                        **make_envelope(elapsed, exit_code=1),
                        status="conflict",
                        branch=branch,
                        new_head=None,
                        onto=onto_id,
                        squash=True,
                        replayed=0,
                        replayed_commit_ids=[],
                        conflicts=conflict_paths,
                    )
                    print(json.dumps(result_payload))
                else:
                    print(
                        f"❌ Conflict during squash at {commit.commit_id}:",
                        file=sys.stderr,
                    )
                    for p in conflict_paths:
                        print(f"  CONFLICT: {p}", file=sys.stderr)
                    print(
                        "Resolve conflicts and try again. "
                        "Squash does not support --continue.",
                        file=sys.stderr,
                    )
                conflict_occurred = True
                break
            squash_manifest = result.merged["files"]

        if conflict_occurred:
            raise SystemExit(ExitCode.USER_ERROR)

        apply_manifest(root, {}, squash_manifest)
        squash_dirs = directories_from_manifest(squash_manifest)
        snapshot_id = hash_snapshot(squash_manifest, squash_dirs)
        committed_at = datetime.datetime.now(datetime.timezone.utc)
        final_message = squash_message or commits_to_replay[-1].message
        squash_author = commits_to_replay[0].author if commits_to_replay else ""
        new_commit_id = hash_commit(
            parent_ids=[onto_id],
            snapshot_id=snapshot_id,
            message=final_message,
            committed_at_iso=committed_at.isoformat(),
            author=squash_author,
        )
        write_snapshot(
            root, SnapshotRecord(snapshot_id=snapshot_id, manifest=squash_manifest, directories=squash_dirs)
        )
        write_commit(
            root,
            CommitRecord(
                commit_id=new_commit_id,
                branch=branch,
                snapshot_id=snapshot_id,
                message=final_message,
                committed_at=committed_at,
                parent_commit_id=onto_id,
                author=squash_author,
            ),
        )
        try:
            _write_branch_ref(root, branch, new_commit_id, expected_id=head_commit_id)
        except RefConflictError as exc:
            print(f"❌ {exc}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        append_reflog(
            root, branch,
            old_id=head_commit_id,
            new_id=new_commit_id,
            author="user",
            operation=f"rebase --squash onto {onto_id}",
        )
        if json_out:
            result_payload = _RebaseResultJson(
                **make_envelope(elapsed),
                status="completed",
                branch=branch,
                new_head=new_commit_id,
                onto=onto_id,
                squash=True,
                replayed=len(commits_to_replay),
                replayed_commit_ids=[new_commit_id],
                conflicts=[],
            )
            print(json.dumps(result_payload))
        else:
            print(f"✅ Squash-rebase complete. HEAD is now {new_commit_id}.")
        return

    # Normal replay loop
    state = RebaseState(
        original_branch=branch,
        original_head=head_commit_id,
        onto=onto_id,
        remaining=[c.commit_id for c in commits_to_replay],
        completed=[],
        squash=False,
    )
    save_rebase_state(root, state)

    clean = _run_replay_loop(root, state, branch, plugin, domain, json_out, t0)

    if clean:
        final_id = state["completed"][-1] if state["completed"] else onto_id
        try:
            _write_branch_ref(root, branch, final_id, expected_id=head_commit_id)
        except RefConflictError as exc:
            print(f"❌ {exc}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        clear_rebase_state(root)
        append_reflog(
            root, branch,
            old_id=head_commit_id,
            new_id=final_id,
            author="user",
            operation=f"rebase: finished onto {onto_id}",
        )
        if json_out:
            result_payload = _RebaseResultJson(
                **make_envelope(elapsed),
                status="completed",
                branch=branch,
                new_head=final_id,
                onto=onto_id,
                squash=False,
                replayed=len(state["completed"]),
                replayed_commit_ids=list(state["completed"]),
                conflicts=[],
            )
            print(json.dumps(result_payload))
        else:
            print(f"✅ Rebase complete. HEAD is now {final_id}.")
