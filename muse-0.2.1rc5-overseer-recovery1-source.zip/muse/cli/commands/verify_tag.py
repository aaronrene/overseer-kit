"""``muse verify-tag <tag>...`` — verify Ed25519 signatures on annotated tags.

Reads the ``signature``, ``signer_public_key``, and ``signer_key_id`` fields
from one or more tag records, reconstructs the canonical tag provenance payload,
and verifies the Ed25519 signature.

Output (per tag)
----------------
Text (default)::

    OK  <tag_name>  key=<key_id>
    BAD <tag_name>  (no signature)
    BAD <tag_name>  (invalid signature)
    ERR <tag_name>  (tag not found)

JSON (``--json``)::

    {
      "results": [
        {"tag": "v1.0", "commit_id": "sha256:...", "valid": true,
         "signer": "<key_id>", "key_id": "<key_id>", "message": "...",
         "key_status": "active|revoked|unknown"}
      ],
      "exit_code": 0,
      "duration_ms": 4.2
    }

JSON envelope fields
--------------------
``exit_code``
    Integer exit code: 0 on success, 1 on any failure.  Mirrors the process
    exit code so callers can act without inspecting ``results``.

``duration_ms``
    Wall-clock time spent verifying all tags, in milliseconds (float).
    Useful for agents monitoring verification latency at scale.

``results``
    List of per-tag verification dicts, one entry per tag in input order.

Flags
-----
``--strict``
    Exit non-zero if any tag is unsigned (no signature present).
    Without ``--strict``, unsigned tags are reported as ``valid=false``
    but do not affect the exit code unless the signature is *invalid*.

``--check-key-status``
    Query MuseHub to check whether the signing key is still active.
    Fails closed: returns ``"unknown"`` on timeout, network error, or when
    no hub is configured.

``--json``
    Emit a single JSON envelope (see above).

Exit codes::

    0 — all tags valid (or unsigned without --strict)
    1 — at least one invalid signature, or unsigned with --strict
    2 — usage error (bad tag name, ANSI injection)

Examples::

    muse verify-tag v1.0
    muse verify-tag v1.0 --json
    muse verify-tag v1.0 --strict
    muse verify-tag v1.0 v2.0 v3.0 --json
    muse verify-tag v1.0 --check-key-status
"""

import argparse
import hashlib
import json as _json
import logging
import pathlib
import re
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TypedDict

from muse.core.types import DEFAULT_SIGN_ALGO, decode_pubkey, sig_algo
from muse.core.paths import repo_json_path as _repo_json_path
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.provenance import verify_commit_ed25519
from muse.core.repo import require_repo
from muse.core.tags import (
    get_all_tags,
    get_tag_by_name,
)
from muse.core.timing import start_timer
from muse.core.validation import sanitize_display

logger = logging.getLogger(__name__)

# Timeout for hub key-status network calls.
_KEY_STATUS_TIMEOUT = 5.0

# Allow alphanumeric, underscore, slash, dot, hyphen — same as verify-commit.
_SAFE_TAG_RE = re.compile(r"^[a-zA-Z0-9_/.\-]+$")

# Null-byte field separator — prevents injection attacks.
_TAG_PROV_SEP = "\x00"

# Version prefix for the tag provenance payload format.
_TAG_PROV_PREFIX = "muse-tag-v1\n"

# ---------------------------------------------------------------------------
# TypedDicts
# ---------------------------------------------------------------------------

class _TagResult(TypedDict):
    """Per-tag verification result in the JSON envelope ``results`` list."""

    tag: str
    commit_id: str
    valid: bool
    signer: str
    key_id: str
    message: str
    key_status: str

class _TagVerifyJson(EnvelopeJson):
    """Top-level JSON envelope emitted by ``muse verify-tag --json``."""

    results: list[_TagResult]

# ---------------------------------------------------------------------------
# Payload
# ---------------------------------------------------------------------------

def tag_payload(
    tag_name: str,
    commit_id: str,
    message: str,
    key_id: str,
    created_at: str,
) -> str:
    """Compute the SHA-256 hex digest of the canonical tag signing payload.

    Binds the tag name, the commit it points at, the annotation message,
    the signing key fingerprint, and the creation timestamp.  Any mutation
    to these fields after signing will invalidate the signature.

    Canonical payload format::

        muse-tag-v1\\n
        <tag_name>\\x00<commit_id>\\x00<message>\\x00<key_id>\\x00<created_at>

    Args:
        tag_name:   The tag label string (e.g. ``"v1.0"``).
        commit_id:  Full 64-char hex commit ID the tag points at.
        message:    Optional annotation message (empty string if absent).
        key_id:     Canonical ``sha256:<64-hex>`` fingerprint of the signer's public key.
        created_at: ISO-8601 timestamp of tag creation.

    Returns:
        64-character lowercase hex SHA-256 digest.
    """
    fields = [tag_name, commit_id, message, key_id, created_at]
    raw = (_TAG_PROV_PREFIX + _TAG_PROV_SEP.join(fields)).encode()
    return hashlib.sha256(raw).hexdigest()

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _fetch_key_status(hub_url: str, key_id: str) -> str:
    """Query MuseHub for the status of *key_id*.

    Returns ``"active"``, ``"revoked"``, or ``"unknown"`` (on any error).
    """
    try:
        import urllib.request
        url = f"{hub_url.rstrip('/')}/api/keys/{key_id}/status"
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=_KEY_STATUS_TIMEOUT) as resp:
            body = _json.loads(resp.read().decode("utf-8"))
            status = body.get("status", "unknown")
            if status in ("active", "revoked"):
                return status
            return "unknown"
    except Exception:
        return "unknown"

def _verify_tag_one(
    root: pathlib.Path,
    repo_id: str,
    tag_name: str,
    *,
    check_key_status: bool = False,
    hub_url: str | None = None,
    key_status_cache: dict[str, str] | None = None,
) -> _TagResult:
    """Verify the Ed25519 signature on a single tag.

    Args:
        root:              Repository root path.
        repo_id:           Repository ID string.
        tag_name:          Tag label to look up and verify.
        check_key_status:  When True, query MuseHub for key revocation status.
        hub_url:           Hub URL for key-status queries. None → "unknown".
        key_status_cache:  Shared cache dict to deduplicate key-status lookups
                           within a batch invocation.

    Returns:
        Dict with keys: tag, commit_id, valid, signer, key_id, message, key_status, error.
        ``valid`` is False for unsigned tags, missing public keys, or failed
        signature verification.
    """
    result: _TagResult = {
        "tag": tag_name,
        "commit_id": "",
        "valid": False,
        "signer": "",
        "key_id": "",
        "message": "",
        "key_status": "unknown",
        "error": None,
    }

    tag = get_tag_by_name(root, repo_id, tag_name)
    if tag is None:
        result["error"] = "tag not found"
        return result

    result["commit_id"] = tag.commit_id
    result["message"] = tag.message
    result["signer"] = tag.signer_key_id
    result["key_id"] = tag.signer_key_id

    # Unsigned tag — not an error unless --strict is applied by the caller.
    if not tag.signature:
        return result

    # Dispatch on algorithm prefix — the prefix is the sole discriminator.
    sig = tag.signature
    pub_raw = tag.signer_public_key

    if sig_algo(sig) != DEFAULT_SIGN_ALGO:
        result["error"] = f"unrecognised signature algorithm {sig_algo(sig)!r} — re-sign to fix"
        return result

    if sig_algo(pub_raw) != DEFAULT_SIGN_ALGO:
        result["error"] = f"unrecognised public key algorithm {sig_algo(pub_raw)!r} — re-sign to fix"
        return result

    try:
        _, pub_bytes = decode_pubkey(pub_raw)
    except ValueError:
        return result

    if not pub_bytes:
        return result

    # Reconstruct canonical payload and verify.
    payload = tag_payload(
        tag_name,
        tag.commit_id,
        tag.message,
        tag.signer_key_id,
        tag.created_at.isoformat(),
    )

    result["valid"] = verify_commit_ed25519(payload, sig, pub_bytes)

    # Key status enrichment.
    if check_key_status and tag.signer_key_id:
        if hub_url is None:
            result["key_status"] = "unknown"
        else:
            if key_status_cache is not None and tag.signer_key_id in key_status_cache:
                result["key_status"] = key_status_cache[tag.signer_key_id]
            else:
                status = _fetch_key_status(hub_url, tag.signer_key_id)
                result["key_status"] = status
                if key_status_cache is not None:
                    key_status_cache[tag.signer_key_id] = status

    return result

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``muse verify-tag`` subcommand."""
    parser = subparsers.add_parser(
        "verify-tag",
        help="Verify Ed25519 signatures on annotated tags.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "tags",
        metavar="TAG",
        nargs="+",
        help="Tag name(s) to verify.",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Exit non-zero if any tag is unsigned.",
    )
    parser.add_argument(
        "--check-key-status",
        action="store_true",
        dest="check_key_status",
        help="Query MuseHub to check key revocation status.",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit one JSON object per tag, one per line.",
    )
    parser.set_defaults(func=run, json_out=False)

# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Verify Ed25519 signatures on one or more annotated tags.

    Looks up each tag by name, reconstructs the canonical signing payload
    (tag name + commit ID + message + key ID + timestamp), and verifies the
    embedded Ed25519 signature.  Results are collected and emitted as a single
    JSON envelope so batch callers can parse one object instead of one per line.

    Agent quickstart::

        muse verify-tag v1.0 --json
        muse verify-tag v1.0 v2.0 --json
        muse verify-tag v1.0 --strict --json
        muse verify-tag v1.0 --check-key-status --json

    JSON fields::

        results      List of {tag, commit_id, valid, signer, key_id, message, key_status}.
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    0 all ok, 1 any failure.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  All tags valid (or unsigned without --strict).
        1  At least one invalid signature, or unsigned with --strict.
        2  Usage error (bad tag name, ANSI injection attempt).
    """
    raw_tags: list[str] = args.tags
    strict: bool = args.strict
    check_key_status: bool = args.check_key_status
    json_out: bool = args.json_out

    # Validate all tag names before doing any work.
    for tag_name in raw_tags:
        if not _SAFE_TAG_RE.match(tag_name):
            print(
                f"❌ Invalid tag name: {sanitize_display(tag_name)}",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    root = require_repo()

    import json as _json_mod
    repo_id_str = _json_mod.loads(_repo_json_path(root).read_text())["repo_id"]

    # Resolve hub URL for key-status queries.
    hub_url: str | None = None
    if check_key_status:
        try:
            from muse.core.repo import read_hub_url
            hub_url = read_hub_url(root)
        except Exception:
            hub_url = None

    key_status_cache: dict[str, str] = {}
    any_failure = False

    # Verify tags (parallel for large batches).
    results: list[dict] = [{}] * len(raw_tags)

    def _verify_indexed(idx_name: tuple[int, str]) -> tuple[int, _TagResult]:
        idx, name = idx_name
        return idx, _verify_tag_one(
            root, repo_id_str, name,
            check_key_status=check_key_status,
            hub_url=hub_url,
            key_status_cache=key_status_cache,
        )

    with ThreadPoolExecutor(max_workers=min(8, len(raw_tags))) as pool:
        futures = {pool.submit(_verify_indexed, (i, n)): i for i, n in enumerate(raw_tags)}
        for future in as_completed(futures):
            idx, r = future.result()
            results[idx] = r

    for r in results:
        valid = r.get("valid", False)
        error = r.get("error")

        # "tag not found" is always a hard failure.
        if error:
            any_failure = True
        elif not valid:
            is_signed = bool(r.get("key_id") or r.get("signer"))
            # Invalid signature on a signed tag → always fail.
            # Unsigned tag → only fail with --strict.
            if is_signed or strict:
                any_failure = True

        if not json_out:
            tag_name = r["tag"]
            if error:
                print(f"ERR  {sanitize_display(tag_name)}  ({error})")
            else:
                status = "OK " if valid else "BAD"
                key = r["key_id"] or ""
                key_part = f"  key={key}" if key else ""
                print(f"{status}  {sanitize_display(tag_name)}{key_part}")

    exit_code = int(ExitCode.USER_ERROR) if any_failure else 0

    if json_out:
        clean_results = [{k: v for k, v in r.items() if k != "error"} for r in results]
        print(_json.dumps(_TagVerifyJson(
            **make_envelope(elapsed, exit_code=exit_code),
            results=clean_results,
        )))

    if any_failure:
        raise SystemExit(ExitCode.USER_ERROR)
