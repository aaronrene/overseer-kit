"""muse read-commit — emit full commit metadata as JSON.

Reads a commit record by its SHA-256 ID and emits the complete JSON
representation including provenance fields, CRDT annotations, and the
structured delta.  Equivalent to ``git cat-file commit`` but producing
the Muse JSON schema directly.

Output::

    {
      "commit_id": "<sha256>",
      "branch": "main",
      "snapshot_id": "<sha256>",
      "message": "Add verse melody",
      "committed_at": "2026-03-18T12:00:00+00:00",
      "parent_commit_id": "<sha256> | null",
      "parent2_commit_id": null,
      "author": "gabriel",
      "agent_id": "",
      "model_id": "",
      "sem_ver_bump": "none",
      "breaking_changes": [],
      "reviewed_by": [],
      "test_runs": 0,
      ...
    }

Output contract
---------------

- Exit 0: commit found and printed.
- Exit 1: commit not found, ambiguous prefix, or invalid commit ID format.

Agent use
---------

Fetch only the fields you need to keep agent context small::

    muse read-commit <id> --fields commit_id,branch,message,committed_at
    muse read-commit <id> --fields agent_id,model_id
"""

import argparse
import json
import logging
import re
import sys
from typing import TypedDict
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.refs import (
    get_head_commit_id,
    read_head,
)
from muse.core.commits import (
    CommitDict,
    find_commits_by_prefix,
    read_commit,
    resolve_commit_ref,
)
from muse.domain import StructuredDelta
from muse.core.validation import sanitize_display
from muse.core.types import long_id, Metadata
from muse.core.timing import start_timer

_SHA256_FULL_RE = re.compile(r"^sha256:[0-9a-f]{64}$")
_SHA256_PREFIX_RE = re.compile(r"^sha256:[0-9a-f]{1,63}$")
_BARE_HEX_RE = re.compile(r"^[0-9a-f]+$", re.IGNORECASE)

logger = logging.getLogger(__name__)

class _ReadCommitJson(EnvelopeJson, total=False):
    """JSON envelope for ``muse read-commit --json`` output.

    All CommitRecord fields are present; ``total=False`` reflects
    dynamic field selection via ``--fields``.
    """
    commit_id: str
    branch: str
    snapshot_id: str
    message: str
    committed_at: str
    parent_commit_id: str | None
    parent2_commit_id: str | None
    author: str
    agent_id: str
    model_id: str
    sem_ver_bump: str
    breaking_changes: list[str]
    metadata: Metadata
    structured_delta: StructuredDelta | None

# All fields exposed by CommitRecord.to_dict() — used to validate --fields input.
_ALL_FIELDS: frozenset[str] = frozenset(CommitDict.__annotations__.keys())

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the read-commit subcommand."""
    parser = subparsers.add_parser(
        "read-commit",
        help="Emit full commit metadata as JSON.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "commit_id",
        help="Full or abbreviated SHA-256 commit ID.",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON.",
    )
    parser.add_argument(
        "--fields",
        default=None,
        metavar="FIELD,…",
        dest="fields",
        help=(
            "Comma-separated list of CommitDict fields to include in JSON output. "
            "Reduces response size for agent pipelines. "
            "Example: --fields commit_id,branch,message,committed_at"
        ),
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Emit full commit metadata as JSON (default) or a compact text summary.

    Accepts a full 64-character commit ID or a unique prefix.  The JSON output
    schema matches ``CommitRecord.to_dict()`` and is stable across Muse
    versions.

    Use ``--fields`` to request only the fields you need — essential for
    agents that must keep their context window small.

    Text format (``--format text``)::

        <commit_id[:12]>  <branch>  <author>  <committed_at>  <message>
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    commit_id: str = args.commit_id
    fields_raw: str | None = args.fields

    # Parse and validate --fields before touching the store.
    requested_fields: frozenset[str] | None = None
    if fields_raw is not None:
        if not json_out:
            print(
                json.dumps({"error": "--fields is only valid with --json"}),
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)
        parts = {f.strip() for f in fields_raw.split(",") if f.strip()}
        unknown = parts - _ALL_FIELDS
        if unknown:
            print(
                json.dumps({
                    "error": f"Unknown field(s): {', '.join(sorted(unknown))}. "
                             f"Valid fields: {', '.join(sorted(_ALL_FIELDS))}",
                }),
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)
        requested_fields = frozenset(parts)

    root = require_repo()

    record = None

    if _SHA256_FULL_RE.match(commit_id):
        # Exact canonical content address — look up directly.
        record = read_commit(root, commit_id)

    elif _SHA256_PREFIX_RE.match(commit_id):
        # Canonical prefix form: sha256:<partial-hex> — strip algo tag for filesystem glob.
        bare_prefix = long_id(commit_id, strip=True)
        matches = find_commits_by_prefix(root, bare_prefix)
        if len(matches) == 1:
            record = matches[0]
        elif len(matches) > 1:
            print(
                json.dumps({
                    "error": "ambiguous prefix",
                    "candidates": [m.commit_id for m in matches],
                }),
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)

    elif _BARE_HEX_RE.match(commit_id):
        # Bare hex without the algo tag — always an error.
        print(
            json.dumps({
                "error": (
                    f"Invalid commit reference {commit_id!r}: "
                    "use the canonical 'sha256:<hex>' form. "
                    "Bare hex IDs are not accepted."
                ),
            }),
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    else:
        # Symbolic ref: HEAD, HEAD~N, branch name, <sha256:...>~N.
        try:
            head_state = read_head(root)
            branch = head_state["branch"] if head_state["kind"] == "branch" else ""
        except ValueError:
            branch = ""
        if commit_id.upper() == "HEAD":
            record = resolve_commit_ref(root, branch, None)
        else:
            try:
                is_branch = get_head_commit_id(root, commit_id) is not None
            except (ValueError, Exception):
                is_branch = False
            if is_branch:
                # Input is a branch name — resolve its tip.
                record = resolve_commit_ref(root, commit_id, None)
            else:
                # Tilde notation (HEAD~N, sha256:...~N) or other ref forms.
                record = resolve_commit_ref(root, branch, commit_id)

    if record is None:
        print(json.dumps({"error": f"Commit not found: {commit_id}"}), file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    if not json_out:
        msg = sanitize_display((record.message or "").replace("\n", " "))
        print(
            f"{record.commit_id}  {sanitize_display(record.branch)}  "
            f"{sanitize_display(record.author or '')}  "
            f"{record.committed_at.isoformat()}  {msg}"
        )
        return

    record_data = record.to_dict()
    if requested_fields is not None:
        record_data = {k: v for k, v in record_data.items() if k in requested_fields}
    print(json.dumps(_ReadCommitJson(**make_envelope(elapsed), **record_data), default=str))
