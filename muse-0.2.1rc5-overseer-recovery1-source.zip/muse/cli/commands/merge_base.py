"""muse merge-base — find the lowest common ancestor of two commits.

Walks the commit DAG from two starting points and returns the nearest shared
ancestor (the Lowest Common Ancestor, or LCA).  Used by merge engines, CI
systems, and agent pipelines to compute the divergence point between branches.

Output (JSON, default)::

    {
      "commit_a":   "<sha256>",
      "commit_b":   "<sha256>",
      "merge_base": "<sha256>",
      "duration_ms": 1.2,
      "exit_code":  0
    }

When no common ancestor exists::

    {
      "commit_a":   "<sha256>",
      "commit_b":   "<sha256>",
      "merge_base": null,
      "error":      "no common ancestor",
      "duration_ms": 0.8,
      "exit_code":  0
    }

JSON error schema (usage / internal errors)::

    {
      "status":    "error",
      "error":     "<human-readable message>",
      "exit_code": <int>
    }

When ``--json`` is active all errors go to stdout as JSON — no prose on
stderr.  Agents should parse stdout and check ``exit_code``.

Output contract
---------------

- Exit 0: operation completed (check ``merge_base`` field for null vs. found).
- Exit 1: a commit ID or ref cannot be resolved; bad ``--format`` value.
- Exit 3: DAG walk failed (I/O error or malformed graph).
"""

import argparse
import json
import logging
import pathlib
import sys
from typing import TypedDict

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.merge_engine import find_merge_base
from muse.core.repo import require_repo
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import read_commit
from muse.core.validation import validate_object_id
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Wire-format TypedDicts
# ---------------------------------------------------------------------------

class _MergeBaseFoundJson(EnvelopeJson):
    """Stable JSON envelope when a merge base is found."""
    commit_a: str
    commit_b: str
    merge_base: str       # sha256:… commit ID

class _MergeBaseNotFoundJson(EnvelopeJson):
    """Stable JSON envelope when no common ancestor exists."""
    commit_a: str
    commit_b: str
    merge_base: None
    error: str            # "no common ancestor"

class _MergeBaseErrorJson(EnvelopeJson):
    """Error payload for usage/internal errors in --json mode."""
    status: str           # "error"
    error: str

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _emit_error(json_out: bool, msg: str, code: ExitCode, elapsed: float) -> None:
    """Print an error and raise SystemExit.  Never returns.

    In ``--json`` mode the error goes to stdout as a JSON payload so agents
    always get parseable output.  In text mode it goes to stderr.
    """
    if json_out:
        print(json.dumps(_MergeBaseErrorJson(
            **make_envelope(elapsed, exit_code=int(code)),
            status="error",
            error=msg,
        )))
    else:
        print(f"❌ {msg}", file=sys.stderr)
    raise SystemExit(code)

def _resolve_ref(root: pathlib.Path, ref: str) -> str | None:
    """Resolve a branch name, HEAD, or sha256-prefixed commit ID.

    Returns ``None`` when the ref cannot be resolved to a known commit.
    """
    if ref.upper() == "HEAD":
        branch = read_current_branch(root)
        return get_head_commit_id(root, branch)

    # Try as branch name first.  Guard against refs that are not valid branch
    # names (e.g. sha256:-prefixed commit IDs) — get_head_commit_id calls
    # validate_branch_name which raises ValueError for colons and slashes.
    try:
        cid = get_head_commit_id(root, ref)
        if cid is not None:
            return cid
    except (ValueError, OSError):
        pass  # not a valid branch name; fall through to commit-ID lookup

    # Try as full sha256-prefixed commit ID.
    try:
        validate_object_id(ref)
        record = read_commit(root, ref)
        return record.commit_id if record else None
    except ValueError:
        return None

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the merge-base subcommand."""
    parser = subparsers.add_parser(
        "merge-base",
        help="Find the lowest common ancestor of two commits.",
        description=__doc__,
    )
    parser.add_argument(
        "commit_a",
        help="First commit ID, branch name, or HEAD.",
    )
    parser.add_argument(
        "commit_b",
        help="Second commit ID, branch name, or HEAD.",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON.",
    )
    parser.set_defaults(func=run)

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Find the lowest common ancestor of two commits.

    Accepts sha256-prefixed commit IDs, branch names, or ``HEAD``.  The result
    is the commit reachable from both inputs closest to both tips — the
    divergence point between two histories.  ``merge_base`` is ``null`` when
    no common ancestor exists (disconnected histories).

    Agent quickstart
    ----------------
    ::

        muse merge-base dev feat/billing --json
        muse merge-base HEAD feat/x --json
        muse merge-base sha256:<a> sha256:<b> --json

    JSON fields
    -----------
    commit_a     Resolved commit ID of the first input.
    commit_b     Resolved commit ID of the second input.
    merge_base   Common ancestor commit ID, or ``null`` if none exists.

    Exit codes
    ----------
    0  Success (check ``merge_base`` — ``null`` means no common ancestor).
    1  Cannot resolve one of the refs, or invalid ``--format``.
    3  Internal error during DAG walk.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    commit_a: str = args.commit_a
    commit_b: str = args.commit_b

    root = require_repo()

    resolved_a = _resolve_ref(root, commit_a)
    if resolved_a is None:
        _emit_error(json_out, f"Cannot resolve ref: {commit_a!r}", ExitCode.USER_ERROR, elapsed)

    resolved_b = _resolve_ref(root, commit_b)
    if resolved_b is None:
        _emit_error(json_out, f"Cannot resolve ref: {commit_b!r}", ExitCode.USER_ERROR, elapsed)

    try:
        base = find_merge_base(root, resolved_a, resolved_b)
    except Exception as exc:
        logger.debug("merge-base DAG walk failed: %s", exc)
        _emit_error(json_out, str(exc), ExitCode.INTERNAL_ERROR, elapsed)

    if not json_out:
        if base is None:
            print("(no common ancestor)")
        else:
            print(base)
        return

    if base is None:
        print(json.dumps(_MergeBaseNotFoundJson(
            **make_envelope(elapsed),
            commit_a=resolved_a,
            commit_b=resolved_b,
            merge_base=None,
            error="no common ancestor",
        )))
        return

    print(json.dumps(_MergeBaseFoundJson(
        **make_envelope(elapsed),
        commit_a=resolved_a,
        commit_b=resolved_b,
        merge_base=base,
    )))
