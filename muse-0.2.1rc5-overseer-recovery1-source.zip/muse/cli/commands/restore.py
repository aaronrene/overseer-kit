"""``muse restore`` — restore working-tree files and/or stage entries.

The focused, explicit alternative to ``muse checkout -- <file>`` for file
restoration.  It never moves HEAD or switches branches.

Targets
-------
- **Working tree** (default): overwrite the on-disk file with the content
  from the stage (if staged) or HEAD (if clean).  The stage is untouched.
- **Stage only** (``--staged``): reset the stage entry back to HEAD state —
  i.e. remove any staged modification, deletion, or addition — without
  touching the on-disk file.
- **Both** (``--staged --worktree``): clear the stage entry *and* restore the
  on-disk file from HEAD (or ``--source``).
- **Arbitrary source** (``--source <ref>``): use a commit ID or branch name
  instead of HEAD as the restoration source.

Behaviour per flag combination
--------------------------------
``muse restore file.py``
    Restore the working-tree file from the staged version (if staged) or
    from HEAD.  Stage is not modified.

``muse restore --staged file.py``
    Remove *file.py*'s entry from the stage so it matches HEAD:
    - Staged as ``"M"`` → remove entry (HEAD version is back in effect)
    - Staged as ``"D"`` → remove entry (undelete)
    - Staged as ``"A"`` → remove entry (un-track new file; disk untouched)
    - Not staged → no-op

``muse restore --staged --worktree file.py``
    Do both: clear the stage entry (as above) and restore the disk file from
    HEAD (or ``--source``).

``muse restore --source <ref> file.py``
    Use *ref*'s snapshot manifest as the source instead of HEAD.  Works with
    ``--staged`` and ``--staged --worktree`` too.

JSON schema (``--json``)::

    {
      "restored":    ["file1.py", ...],
      "not_found":   ["missing.py", ...],
      "dry_run":     true | false,
      "staged":      true | false,
      "worktree":    true | false,
      "duration_ms":  12.3,
      "exit_code":   0
    }

Exit codes::

    0 — success (all paths restored, or nothing to do)
    1 — user error: file not in source, ref not found, path traversal
    2 — not a Muse repository
    3 — I/O error or object missing from store

Examples::

    muse restore a.py                         # discard working-tree changes
    muse restore --staged a.py                # unstage a.py
    muse restore --staged --worktree a.py     # full reset: stage + disk
    muse restore --source feat a.py           # restore from branch 'feat'
    muse restore --source abc123 a.py b.py    # restore two files from commit
    muse restore --dry-run --json a.py        # preview in JSON
"""

import argparse
import json as _json
import logging
import pathlib
import sys
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.object_store import restore_object
from muse.core.repo import require_repo
from muse.core.types import Manifest
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import (
    read_commit,
    resolve_commit_ref,
)
from muse.core.snapshots import read_snapshot
from muse.core.validation import contain_path, sanitize_display
from muse.core.timing import start_timer
from muse.plugins.code.stage import StagedFileMap, read_stage, write_stage

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# JSON output type
# ---------------------------------------------------------------------------

class _RestoreResult(EnvelopeJson):
    """Machine-readable output for ``muse restore --json``."""

    restored: list[str]
    not_found: list[str]
    dry_run: bool
    staged: bool
    worktree: bool

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _resolve_source_manifest(
    root: pathlib.Path,
    source_ref: str | None,
) -> Manifest:
    """Return the manifest for *source_ref*, or HEAD if ``None``.

    Returns an empty dict when the repository has no commits yet, when
    *source_ref* is ``None`` and HEAD is empty, or when *source_ref* cannot
    be resolved to a known commit.  Never raises.

    Args:
        root:       Absolute repo root.
        source_ref: A branch name, commit ID, or ``None`` for HEAD.

    Returns:
        Dict mapping repo-relative POSIX paths to object IDs, or ``{}`` when
        no source is available.
    """
    try:
        branch = read_current_branch(root)

        if source_ref is None:
            commit_id = get_head_commit_id(root, branch)
            if not commit_id:
                logger.debug("_resolve_source_manifest: repo has no commits")
                return {}
            commit = read_commit(root, commit_id)
        else:
            commit = resolve_commit_ref(root, branch, source_ref)

        if commit is None:
            logger.debug("_resolve_source_manifest: ref %r resolved to None", source_ref)
            return {}
        snap = read_snapshot(root, commit.snapshot_id)
        return dict(snap.manifest) if snap else {}
    except Exception:
        logger.debug("_resolve_source_manifest: exception resolving ref %r", source_ref, exc_info=True)
        return {}

def _resolve_file_path(root: pathlib.Path, raw: str) -> str:
    """Resolve *raw* to a repo-relative POSIX path, rejecting path traversal.

    Handles both relative paths (resolved against CWD first, then repo root)
    and absolute paths.  Rejects any path that resolves outside *root*.

    Args:
        root: Absolute repo root.
        raw:  Raw path as given by the user.

    Returns:
        POSIX-style path relative to *root* (e.g. ``"src/auth.py"``).

    Raises:
        SystemExit(USER_ERROR): path escapes the repository root.
    """
    p = pathlib.Path(raw)
    if not p.is_absolute():
        cwd_candidate = (pathlib.Path.cwd() / p).resolve()
        try:
            cwd_candidate.relative_to(root.resolve())
            abs_target = cwd_candidate
        except ValueError:
            abs_target = (root / p).resolve()
    else:
        abs_target = p.resolve()

    try:
        rel = abs_target.relative_to(root.resolve())
    except ValueError:
        print(
            f"❌ fatal: '{sanitize_display(raw)}' is outside the repository root.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    return rel.as_posix()

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``muse restore`` subcommand."""
    parser = subparsers.add_parser(
        "restore",
        help="Restore working-tree files and/or stage entries from HEAD or a ref.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "paths",
        nargs="+",
        metavar="PATH",
        help="File(s) to restore.",
    )
    parser.add_argument(
        "--staged", "-S",
        action="store_true",
        dest="staged",
        help=(
            "Restore the stage entry from HEAD (or --source), without touching "
            "the working-tree file.  Removes staged modifications, deletions, "
            "and new-file additions."
        ),
    )
    parser.add_argument(
        "--worktree", "-W",
        action="store_true",
        dest="worktree",
        help=(
            "Restore the working-tree file.  This is the default when "
            "--staged is not given.  Use together with --staged to reset both."
        ),
    )
    parser.add_argument(
        "--source", "-s",
        metavar="REF",
        default=None,
        dest="source",
        help=(
            "Use this commit ID or branch name as the restore source instead "
            "of HEAD.  Works with --staged and --worktree."
        ),
    )
    parser.add_argument(
        "-n", "--dry-run",
        action="store_true",
        dest="dry_run",
        help="Preview what would be restored without writing anything.",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON on stdout.",
    )
    parser.set_defaults(func=run)

# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Restore files in the working tree and/or stage.

    For each path:

    1. Resolve and validate the path (path-traversal guard).
    2. If ``--staged``: remove the stage entry (so it matches HEAD/source).
    3. If ``--worktree`` (or default): overwrite the disk file from the
       stage entry (if present) or source manifest.

    The two actions are independent: ``--staged --worktree`` does both.
    When neither flag is given, ``--worktree`` is the implicit default.

    Agent quickstart::

        muse restore a.py --json
        muse restore --staged a.py --json
        muse restore --staged --worktree a.py --json
        muse restore --source HEAD~3 a.py b.py --json

    JSON fields::

        restored    list[str]  Repo-relative paths successfully restored
        not_found   list[str]  Paths absent from the source or object store
        dry_run     bool       True when no writes were made
        staged      bool       True when --staged was in effect
        worktree    bool       True when working-tree restore was in effect

    Exit codes::

        0  All paths restored (or would be in dry-run).
        1  User error: file not in source, ref not found, or path traversal.
        2  Not inside a Muse repository.
        3  Object missing from store (I/O or data-integrity failure).
    """
    elapsed = start_timer()

    raw_paths: list[str] = args.paths
    do_staged: bool = args.staged
    do_worktree: bool = args.worktree
    source_ref: str | None = args.source
    dry_run: bool = args.dry_run
    json_out: bool = args.json_out

    # Default: restore worktree when neither flag is given.
    if not do_staged and not do_worktree:
        do_worktree = True

    logger.debug(
        "restore: paths=%r staged=%s worktree=%s source=%r dry_run=%s",
        raw_paths, do_staged, do_worktree, source_ref, dry_run,
    )

    root = require_repo()

    # ── Validate source ref first ─────────────────────────────────────────────
    if source_ref is not None:
        # Attempt to resolve; surface a clean error for bad refs.
        try:
            branch = read_current_branch(root)
            commit = resolve_commit_ref(root, branch, source_ref)
        except Exception:
            commit = None
        if commit is None:
            print(
                f"❌ '{sanitize_display(source_ref)}' is not a known branch or commit ID.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)

    # ── Load source manifest ──────────────────────────────────────────────────
    source_manifest = _resolve_source_manifest(root, source_ref)
    logger.debug("restore: source manifest has %d entries", len(source_manifest))

    # ── Load current stage ────────────────────────────────────────────────────
    current_stage = read_stage(root)
    new_stage = dict(current_stage)

    # ── Process paths ─────────────────────────────────────────────────────────
    restored: list[str] = []
    not_found: list[str] = []
    any_user_error = False   # user mistake: file absent from source, path traversal
    any_io_error = False     # infrastructure failure: blob missing from store

    for raw in raw_paths:
        # Path validation — rejects traversal.
        try:
            rel = _resolve_file_path(root, raw)
        except SystemExit:
            # _resolve_file_path already printed to stderr; in JSON mode we
            # rely on the not_found list + exit_code instead.
            any_user_error = True
            not_found.append(raw)
            continue

        # ── --staged: reset stage entry to match source ───────────────────
        if do_staged:
            staged_entry = current_stage.get(rel)
            if staged_entry is not None:
                # Remove the stage entry regardless of mode (M, D, or A).
                # After removal the stage agrees with the source (HEAD by default).
                if not dry_run:
                    new_stage.pop(rel, None)
                    logger.debug("restore: cleared stage entry for %r", rel)
            # If not staged: no-op (already matches HEAD).

        # ── --worktree: restore the disk file ────────────────────────────
        if do_worktree:
            # Determine the object_id to restore from.
            # Priority: stage entry (if present and not being cleared by --staged)
            # then source manifest.
            object_id: str | None = None

            if do_staged:
                # We just cleared the stage — restore from source manifest.
                object_id = source_manifest.get(rel)
            else:
                staged_entry = current_stage.get(rel)
                if staged_entry is not None and staged_entry["mode"] not in ("D",):
                    object_id = staged_entry["object_id"]
                else:
                    object_id = source_manifest.get(rel)

            if object_id is None:
                if not json_out:
                    print(
                        f"❌ '{sanitize_display(rel)}' is not in the source "
                        f"({'HEAD' if source_ref is None else sanitize_display(source_ref)}) "
                        f"manifest.",
                        file=sys.stderr,
                    )
                logger.debug("restore: %r not in source manifest", rel)
                any_user_error = True
                not_found.append(rel)
                continue

            if not dry_run:
                try:
                    dest = contain_path(root, rel)
                except ValueError as exc:
                    if not json_out:
                        print(f"❌ Unsafe path '{sanitize_display(rel)}': {exc}", file=sys.stderr)
                    any_user_error = True
                    not_found.append(rel)
                    continue

                ok = restore_object(root, object_id, dest)
                if not ok:
                    if not json_out:
                        print(
                            f"❌ Object for '{sanitize_display(rel)}' is missing from the "
                            f"object store — repository may be corrupt.",
                            file=sys.stderr,
                        )
                    logger.error(
                        "restore: object %r for %r not found in store", object_id, rel
                    )
                    any_io_error = True
                    not_found.append(rel)
                    continue

                logger.debug("restore: wrote %r from object %r", rel, object_id)

        restored.append(rel)

    # ── Check file-not-in-source for staged-only (no worktree check) ─────────
    # For paths that only use --staged, we already handled them above (removing
    # from stage or no-op).  Non-existent source paths are not an error for
    # --staged-only mode (removing a new-file staging is valid even when HEAD
    # doesn't have it).

    # ── Commit stage changes ──────────────────────────────────────────────────
    if do_staged and not dry_run and new_stage != current_stage:
        write_stage(root, new_stage)
        logger.debug("restore: wrote updated stage")

    # ── Determine final exit code ─────────────────────────────────────────────
    if any_io_error:
        final_exit_code: int = ExitCode.INTERNAL_ERROR
    elif any_user_error:
        final_exit_code = ExitCode.USER_ERROR
    else:
        final_exit_code = ExitCode.SUCCESS

    duration_ms = elapsed()
    logger.debug(
        "restore: done in %.1f ms — restored=%d not_found=%d exit_code=%d",
        duration_ms, len(restored), len(not_found), final_exit_code,
    )

    # ── Output ───────────────────────────────────────────────────────────────
    if json_out:
        result = _RestoreResult(
            **make_envelope(elapsed, exit_code=final_exit_code),
            restored=restored,
            not_found=not_found,
            dry_run=dry_run,
            staged=do_staged,
            worktree=do_worktree,
        )
        print(_json.dumps(result))
    else:
        for rel in restored:
            verb = "[dry-run] Would restore" if dry_run else "Restored"
            targets = []
            if do_staged:
                targets.append("stage")
            if do_worktree:
                targets.append("worktree")
            print(f"{verb}: {sanitize_display(rel)} ({', '.join(targets)})")
        # Summary line
        n_restored = len(restored)
        if dry_run:
            print(f"Would restore {n_restored} file(s).")
        else:
            print(f"Restored {n_restored} file(s).")
        if not_found:
            print(f"{len(not_found)} error(s).", file=sys.stderr)
        for rel in not_found:
            print(f"  not found: {sanitize_display(rel)}", file=sys.stderr)

    if final_exit_code != ExitCode.SUCCESS:
        raise SystemExit(final_exit_code)
