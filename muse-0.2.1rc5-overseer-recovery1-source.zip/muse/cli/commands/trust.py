"""muse trust — manage trusted repository paths and pinned hub fingerprints.

Security model
--------------
Muse performs an ownership check on every discovered ``.muse/`` directory
(CVE-2022-24765 equivalent).  If the ``.muse/`` directory is owned by a
different UID, Muse refuses to operate on it and raises
:class:`~muse.core.errors.UntrustedRepositoryError`.

For shared-filesystem environments (Docker bind-mounts, CI agents, multi-user
workstations), specific paths can be added to the trust list so Muse operates
normally without re-checking ownership.

Trust sources (in evaluation order)
------------------------------------
1. ``MUSE_SAFE_DIRS`` environment variable — colon-separated absolute paths.
   Useful for ephemeral CI containers.
2. ``~/.muse/config.toml`` ``[security] safe_dirs`` — persistent trust list.
   Managed by ``muse trust add`` / ``muse trust remove``.

Hub fingerprint pinning (TOFU)
-------------------------------
``muse trust hub-list`` and ``muse trust hub-reset`` manage the TOFU
(Trust On First Use) fingerprint store at ``~/.muse/hub_trust.toml``.

JSON output contract
--------------------
Every ``--json`` response includes ``duration_ms`` (float, milliseconds) and
``exit_code`` (int).  Errors are emitted to **stdout** (not stderr) in JSON
mode so agents can always parse a structured response::

    {"error": "<key>", "message": "<description>", "duration_ms": 0.3, "exit_code": 3}

Exit codes::

    0 — success
    3 — I/O error reading or writing the trust store
"""

import argparse
import json as _json
import sys
from typing import TYPE_CHECKING, TypedDict

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.timing import start_timer

if TYPE_CHECKING:
    from muse.core.hub_trust import HubTrustStore

class _TrustAddJson(EnvelopeJson):
    added: bool
    path: str

class _TrustRemoveJson(EnvelopeJson):
    removed: bool
    path: str

class _TrustListJson(EnvelopeJson):
    trusted_dirs: list[str]
    count: int

class _TrustHubListJson(EnvelopeJson):
    fingerprints: HubTrustStore
    count: int

class _TrustHubResetJson(EnvelopeJson):
    reset: bool
    hostname: str

def _add_json_flag(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        default=False,
        dest="json_out",
        help="Emit machine-readable JSON instead of human-readable text.",
    )
    parser.set_defaults(json_out=False)

def register(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Register the ``muse trust`` namespace and its subcommands."""
    trust_parser = subparsers.add_parser(
        "trust",
        help="Manage trusted repository paths and pinned hub fingerprints.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    trust_subs = trust_parser.add_subparsers(dest="trust_command", metavar="TRUST_COMMAND")
    trust_subs.required = True

    # muse trust add <path>
    add_p = trust_subs.add_parser(
        "add",
        help="Add a path to the trusted directory list (~/.muse/config.toml).",
        description=(
            "Add PATH to the [security] safe_dirs list in ~/.muse/config.toml.\n"
            "Muse will skip the ownership check for this repository.\n\n"
            "Example:\n"
            "  muse trust add /shared/workspaces/myrepo"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    add_p.add_argument("path", help="Repository path to trust (absolute or relative).")
    _add_json_flag(add_p)
    add_p.set_defaults(func=_run_add)

    # muse trust remove <path>
    remove_p = trust_subs.add_parser(
        "remove",
        help="Remove a path from the trusted directory list.",
        description=(
            "Remove PATH from the [security] safe_dirs list in ~/.muse/config.toml."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    remove_p.add_argument("path", help="Repository path to remove from the trust list.")
    _add_json_flag(remove_p)
    remove_p.set_defaults(func=_run_remove)

    # muse trust list
    list_p = trust_subs.add_parser(
        "list",
        help="Print all currently trusted paths.",
        description="Print all paths in the [security] safe_dirs list.",
    )
    _add_json_flag(list_p)
    list_p.set_defaults(func=_run_list)

    # muse trust hub-list
    hub_list_p = trust_subs.add_parser(
        "hub-list",
        help="List all pinned hub fingerprints (TOFU store).",
        description=(
            "Print all hub fingerprints stored in ~/.muse/hub_trust.toml.\n"
            "Each entry shows: hostname, SHA-256 fingerprint, first seen, verified count."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_json_flag(hub_list_p)
    hub_list_p.set_defaults(func=_run_hub_list)

    # muse trust hub-reset <hostname>
    hub_reset_p = trust_subs.add_parser(
        "hub-reset",
        help="Remove a pinned hub fingerprint so the next connection re-pins (TOFU reset).",
        description=(
            "Remove the stored fingerprint for HOSTNAME from ~/.muse/hub_trust.toml.\n"
            "The next connection to this hub will re-pin with TOFU.\n\n"
            "Use this after a legitimate certificate rotation to acknowledge the change."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    hub_reset_p.add_argument("hostname", help="Hub hostname (e.g. 'musehub.ai' or 'localhost:1337').")
    _add_json_flag(hub_reset_p)
    hub_reset_p.set_defaults(func=_run_hub_reset)

    trust_parser.set_defaults(func=lambda args: trust_parser.print_help() or sys.exit(0))

def _run_add(args: argparse.Namespace) -> None:
    """Add a path to the global trusted-directory list.

    Normalises *path* to an absolute path before storing.  Adding the same
    path twice is idempotent — no duplicate entry is created.

    Agent quickstart::

        muse trust add /shared/workspaces/myrepo --json
        muse trust add . --json

    JSON fields::

        added        true if the path was newly added (false if already trusted).
        path         Absolute path that was added.
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    0 on success, 3 on I/O error.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  Path added (or already trusted).
        3  I/O error reading or writing ~/.muse/config.toml.
    """
    elapsed = start_timer()
    from muse.cli.config import add_global_safe_dir
    import os
    abs_path = os.path.abspath(args.path)
    json_out: bool = getattr(args, "json_out", False)

    def _emit_error(msg: str, code: int, error_key: str = "error") -> None:
        if json_out:
            print(_json.dumps({**make_envelope(elapsed, exit_code=code), "error": error_key, "message": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(code)

    try:
        add_global_safe_dir(abs_path)
    except OSError as exc:
        _emit_error(str(exc), 3, "io_error")

    if json_out:
        print(_json.dumps(_TrustAddJson(**make_envelope(elapsed), added=True, path=abs_path)))
    else:
        print(f"Trusted path added: {abs_path}")
        print(f"Muse will skip the ownership check for: {abs_path}")

def _run_remove(args: argparse.Namespace) -> None:
    """Remove a path from the global trusted-directory list.

    Normalises *path* to an absolute path before matching.  Removal is
    idempotent — removing a path that is not trusted exits 0 with ``removed=false``.

    Agent quickstart::

        muse trust remove /shared/workspaces/myrepo --json

    JSON fields::

        removed      true if the path was found and removed; false if not trusted.
        path         Absolute path that was targeted.
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    0 on success, 3 on I/O error.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  Completed (whether or not the path was in the list).
        3  I/O error reading or writing ~/.muse/config.toml.
    """
    elapsed = start_timer()
    from muse.cli.config import remove_global_safe_dir, get_global_safe_dirs
    import os
    abs_path = os.path.abspath(args.path)
    json_out: bool = getattr(args, "json_out", False)

    def _emit_error(msg: str, code: int, error_key: str = "error") -> None:
        if json_out:
            print(_json.dumps({**make_envelope(elapsed, exit_code=code), "error": error_key, "message": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(code)

    try:
        before = get_global_safe_dirs()
        remove_global_safe_dir(abs_path)
        after = get_global_safe_dirs()
    except OSError as exc:
        _emit_error(str(exc), 3, "io_error")

    removed = abs_path in before and abs_path not in after
    if json_out:
        print(_json.dumps(_TrustRemoveJson(**make_envelope(elapsed), removed=removed, path=abs_path)))
    elif removed:
        print(f"Trusted path removed: {abs_path}")
    else:
        print(f"Path not in trust list: {abs_path}")

def _run_list(args: argparse.Namespace) -> None:
    """List all trusted paths from ``~/.muse/config.toml``.

    An empty list is a valid result — exits 0 with ``count=0``.

    Agent quickstart::

        muse trust list --json

    JSON fields::

        trusted_dirs List of absolute trusted-directory paths.
        count        Number of trusted paths.
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    Always 0.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  Success (empty list is still success).
    """
    elapsed = start_timer()
    from muse.cli.config import get_global_safe_dirs
    dirs = get_global_safe_dirs()
    if getattr(args, "json_out", False):
        print(_json.dumps(_TrustListJson(**make_envelope(elapsed), trusted_dirs=dirs, count=len(dirs))))
        return
    if not dirs:
        print("No trusted directories configured.")
        print("Add paths with: muse trust add <path>")
        return
    print("Trusted directories (~/.muse/config.toml):")
    for d in dirs:
        print(f"  {d}")

def _run_hub_list(args: argparse.Namespace) -> None:
    """List all pinned hub TLS fingerprints from ``~/.muse/hub_trust.toml``.

    Each entry is keyed by hostname and includes the full ``HubTrustRecord``
    (``hub_url``, ``fingerprint``, ``first_seen``, ``verified_count``).

    Agent quickstart::

        muse trust hub-list --json

    JSON fields::

        fingerprints Map of hostname → HubTrustRecord (hub_url, fingerprint, first_seen, verified_count).
        count        Number of pinned fingerprints.
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    Always 0.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  Success (empty map is still success).
    """
    elapsed = start_timer()
    from muse.core.hub_trust import load_hub_trust_store
    store = load_hub_trust_store()
    if getattr(args, "json_out", False):
        print(_json.dumps(_TrustHubListJson(**make_envelope(elapsed), fingerprints=dict(store), count=len(store))))
        return
    if not store:
        print("No hub fingerprints pinned.")
        print("Fingerprints are pinned automatically on first connection.")
        return
    print("Pinned hub fingerprints (~/.muse/hub_trust.toml):")
    for hostname, record in sorted(store.items()):
        print(
            f"  {hostname}\n"
            f"    fingerprint:    {record['fingerprint']}\n"
            f"    first_seen:     {record['first_seen']}\n"
            f"    verified_count: {record['verified_count']}"
        )

def _run_hub_reset(args: argparse.Namespace) -> None:
    """Remove a hub fingerprint so the next connection re-pins (TOFU reset).

    Idempotent — resetting an unknown hostname exits 0 with ``reset=false``.
    Use after a legitimate TLS certificate rotation to acknowledge the change.

    Agent quickstart::

        muse trust hub-reset musehub.ai --json
        muse trust hub-reset localhost:1337 --json

    JSON fields::

        reset        true if a fingerprint was found and removed; false if unknown hostname.
        hostname     Hub hostname that was targeted.
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    Always 0.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  Success (whether or not a fingerprint existed for the hostname).
    """
    elapsed = start_timer()
    from muse.core.hub_trust import remove_hub_record
    hostname = args.hostname
    removed = remove_hub_record(hostname)
    if getattr(args, "json_out", False):
        print(_json.dumps(_TrustHubResetJson(**make_envelope(elapsed), reset=removed, hostname=hostname)))
    elif removed:
        print(f"Hub fingerprint reset for: {hostname}")
        print("The next connection will re-pin with TOFU.")
    else:
        print(f"No pinned fingerprint found for: {hostname}")
