"""``muse workspace`` — compose multiple Muse repositories.

A workspace links several independent Muse repos together under a single
manifest, giving you a unified status view, one-shot sync, and a clear model
for multi-repo projects.

Subcommands::

    muse workspace add <name> <url> [--path repos/<name>] [--branch main]
    muse workspace update <name> [--url URL] [--path PATH] [--branch BRANCH]
    muse workspace list [--json]
    muse workspace remove <name>
    muse workspace status [<name>] [--json]
    muse workspace sync [<name>] [--dry-run] [--workers N] [--json]

Agent workflow::

    # Register members (no network I/O)
    muse workspace add core   https://musehub.ai/acme/core
    muse workspace add sounds https://musehub.ai/acme/sounds --branch v2

    # Clone / pull everything, 8 parallel workers, structured output
    muse workspace sync --workers 8 --json

    # Inspect state
    muse workspace status --json

JSON envelope fields (all subcommands)
---------------------------------------
``exit_code``
    Integer exit code: 0 on success, 1 on any failure.  Mirrors the process
    exit code so callers can act without inspecting inner fields.

``duration_ms``
    Wall-clock time for the operation in milliseconds (float).

``members`` (list and status only)
    Array of member status objects.  Each object has ``branch_mismatch: bool``
    which is ``true`` when the checked-out branch differs from the configured
    tracking branch.
"""

import argparse
import json
import pathlib
import sys
import logging
from typing import TypedDict

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.timing import start_timer
from muse.core.validation import sanitize_display
from muse.core.workspace import (
    WorkspaceMemberStatus,
    WorkspaceSyncResult,
    add_workspace_member,
    find_workspace_root,
    get_workspace_member,
    list_workspace_members,
    remove_workspace_member,
    require_workspace_root,
    sync_workspace,
    update_workspace_member,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# JSON wire formats
# ---------------------------------------------------------------------------

class _WorkspaceAddJson(EnvelopeJson):
    name: str
    url: str
    path: str
    branch: str

class _WorkspaceUpdateJson(EnvelopeJson):
    name: str
    url: str
    path: str
    branch: str

class _WorkspaceMemberJson(TypedDict):
    name: str
    url: str
    path: str
    branch: str              # configured tracking branch from workspace.toml
    present: bool
    head_commit: str | None  # actual HEAD commit (what HEAD resolves to)
    dirty: bool
    actual_branch: str | None  # currently checked-out branch
    shelf_count: int           # number of shelved changesets
    feature_branches: list[str]  # local branches other than main / dev
    branch_mismatch: bool      # True when actual_branch != configured branch

class _WorkspaceListJson(EnvelopeJson):
    members: list[_WorkspaceMemberJson]

class _WorkspaceStatusJson(EnvelopeJson):
    members: list[_WorkspaceMemberJson]

class _WorkspaceRemoveJson(EnvelopeJson):
    name: str
    removed: bool

class _WorkspaceSyncResultJson(TypedDict):
    name: str
    status: str
    ok: bool

class _WorkspaceSyncJson(EnvelopeJson):
    dry_run: bool
    workers: int
    results: list[_WorkspaceSyncResultJson]
    total: int
    ok_count: int
    error_count: int

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _member_to_json(m: WorkspaceMemberStatus) -> _WorkspaceMemberJson:
    return _WorkspaceMemberJson(
        name=sanitize_display(m.name),
        url=sanitize_display(m.url),
        path=sanitize_display(str(m.path)),
        branch=sanitize_display(m.branch),
        present=m.present,
        head_commit=m.head_commit,
        dirty=m.dirty,
        actual_branch=sanitize_display(m.actual_branch) if m.actual_branch else None,
        shelf_count=m.shelf_count,
        feature_branches=[sanitize_display(b) for b in m.feature_branches],
        branch_mismatch=bool(m.actual_branch and m.actual_branch != m.branch),
    )

def _sync_result_to_json(r: WorkspaceSyncResult) -> _WorkspaceSyncResultJson:
    return _WorkspaceSyncResultJson(
        name=r["name"],
        status=r["status"],
        ok=not r["status"].startswith("error"),
    )

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse workspace`` subcommand tree."""
    parser = subparsers.add_parser(
        "workspace",
        help="Compose multiple Muse repositories.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subs = parser.add_subparsers(dest="subcommand", metavar="SUBCOMMAND")
    subs.required = True

    # workspace add
    add_p = subs.add_parser(
        "add",
        help="Add a member repository to the workspace manifest.",
        description=(
            "Register a member repository in .muse/workspace.toml.\n"
            "No network I/O — run 'muse workspace sync' to clone it.\n\n"
            "NAME must be 1–64 alphanumeric characters, hyphens, underscores,\n"
            "or dots.  URL must be https://, http://, or a bare filesystem\n"
            "path.  PATH must not escape the workspace root.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse workspace add core https://musehub.ai/acme/core --json\n"
            "  muse workspace add data /local/dataset --branch v2 --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"name": "<name>", "url": "<url>",\n'
            '   "path": "<relative-path>", "branch": "<branch>"}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — success\n"
            "  1 — invalid name/URL/path, duplicate member, or invalid branch\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    add_p.add_argument("name", metavar="NAME", help="Member name (alphanumeric, hyphens, underscores, dots).")
    add_p.add_argument("url", metavar="URL", help="Remote URL (https/http) or local path of the member repository.")
    add_p.add_argument("--path", default="", metavar="PATH", help="Relative checkout path (default: repos/<name>).")
    add_p.add_argument("--branch", "-b", default="main", metavar="BRANCH", help="Branch to track (default: main).")
    add_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON on stdout.")
    add_p.set_defaults(func=run_workspace_add, json_out=False)

    # workspace list
    list_p = subs.add_parser(
        "list",
        help="List all workspace members from the manifest.",
        description=(
            "List every registered workspace member with its checkout status.\n\n"
            "Each entry shows whether the directory is present, whether the\n"
            "working tree is dirty, and the current HEAD commit.  All output\n"
            "fields are sanitized — ANSI control sequences are stripped.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse workspace list --json\n\n"
            "JSON output schema (array element)\n"
            "----------------------------------\n"
            '  {"name": "<name>", "url": "<url>", "path": "<absolute-path>",\n'
            '   "branch": "<branch>", "present": true|false,\n'
            '   "head_commit": "<sha256> | null", "dirty": true|false}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — success (empty list when no members registered)\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    list_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON on stdout.")
    list_p.set_defaults(func=run_workspace_list, json_out=False)

    # workspace remove
    remove_p = subs.add_parser(
        "remove",
        help="Remove a member from the workspace manifest (does not delete its directory).",
        description=(
            "Unregister a member from .muse/workspace.toml.\n"
            "The member's checked-out directory is left untouched — only\n"
            "the manifest entry is deleted.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse workspace remove sounds --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"name": "<name>", "removed": true}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — member removed successfully\n"
            "  1 — member not found, or no workspace manifest exists\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    remove_p.add_argument("name", metavar="NAME", help="Member name to remove.")
    remove_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON on stdout.")
    remove_p.set_defaults(func=run_workspace_remove, json_out=False)

    # workspace status
    status_p = subs.add_parser(
        "status",
        help="Show status of all (or one named) workspace member.",
        description=(
            "Report checkout status for every registered workspace member,\n"
            "or for a single named member.  Shows whether the directory is\n"
            "present, the current HEAD commit, and whether the working tree\n"
            "is dirty.  All output fields are sanitized — ANSI control\n"
            "sequences are stripped.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse workspace status --json\n"
            "  muse workspace status core --json\n\n"
            "JSON output schema (array element)\n"
            "----------------------------------\n"
            '  {"name": "<name>", "url": "<url>", "path": "<absolute-path>",\n'
            '   "branch": "<branch>", "present": true|false,\n'
            '   "head_commit": "<sha256> | null", "dirty": true|false}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — success (empty array when no members registered)\n"
            "  1 — named member not found, or no workspace manifest\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    status_p.add_argument("name", nargs="?", default=None, metavar="NAME", help="Show only this member.")
    status_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON on stdout.")
    status_p.set_defaults(func=run_workspace_status, json_out=False)

    # workspace sync
    sync_p = subs.add_parser(
        "sync",
        help="Clone or pull the latest state for workspace members.",
        description=(
            "Clone members that do not exist locally; pull members that do.\n"
            "Use --workers to parallelise across members."
        ),
    )
    sync_p.add_argument("name", nargs="?", default=None, metavar="NAME", help="Sync only this member (default: all).")
    sync_p.add_argument("-n", "--dry-run", action="store_true", dest="dry_run", help="Show what would happen without doing it.")
    sync_p.add_argument("--workers", type=int, default=1, metavar="N", help="Parallel sync workers (default: 1).")
    sync_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON on stdout.")
    sync_p.set_defaults(func=run_workspace_sync, json_out=False)

    # workspace update
    update_p = subs.add_parser(
        "update",
        help="Update the URL, path, or branch for an existing member.",
        description=(
            "Modify a registered workspace member without re-adding it.\n"
            "Only the supplied flags are changed; omitted fields keep their\n"
            "current values.  At least one of --url, --path, or --branch\n"
            "must be supplied.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse workspace update core --branch dev --json\n"
            "  muse workspace update data --url https://musehub.ai/acme/data2 --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"name": "<name>", "url": "<url>",\n'
            '   "path": "<relative-path>", "branch": "<branch>"}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — success\n"
            "  1 — member not found, no flags supplied, or invalid URL/path/branch\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    update_p.add_argument("name", metavar="NAME", help="Member name to update.")
    update_p.add_argument("--url", default=None, metavar="URL", help="New remote URL.")
    update_p.add_argument("--path", default=None, metavar="PATH", help="New relative checkout path.")
    update_p.add_argument("--branch", "-b", default=None, metavar="BRANCH", help="New branch to track.")
    update_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON on stdout.")
    update_p.set_defaults(func=run_workspace_update, json_out=False)

# ---------------------------------------------------------------------------
# Subcommand handlers
# ---------------------------------------------------------------------------

def run_workspace_add(args: argparse.Namespace) -> None:
    """Register a member repository in the workspace manifest.

    Writes to ``.muse/workspace.toml`` without any network I/O — run
    ``muse workspace sync`` afterward to clone the member.  Rejects invalid
    names, disallowed URL schemes, and paths that escape the workspace root.

    Agent quickstart::

        muse workspace add core https://musehub.ai/acme/core --json
        muse workspace add sounds https://musehub.ai/acme/sounds --branch v2 --json

    JSON fields::

        name         Registered member name.
        url          Remote URL.
        path         Relative checkout path (default: repos/<name>).
        branch       Tracking branch (default: main).
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    0 success, 1 validation error.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  Success.
        1  Invalid name/URL/path, duplicate member, or invalid branch.
    """
    name: str = args.name
    url: str = args.url
    path: str = args.path
    branch: str = args.branch
    json_out: bool = args.json_out

    elapsed = start_timer()
    # Use CWD as workspace root when no workspace.toml exists yet, enabling
    # workspace add as a bootstrap operation without a pre-existing workspace.
    root = find_workspace_root() or pathlib.Path.cwd()
    try:
        add_workspace_member(root, name, url, path=path, branch=branch)
    except ValueError as exc:
        if json_out:
            print(json.dumps({**make_envelope(elapsed, exit_code=int(ExitCode.USER_ERROR)),
                               "error": "add_failed", "name": name, "message": str(exc)}))
        print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    effective_path = path or f"repos/{name}"
    if json_out:
        payload = _WorkspaceAddJson(
            **make_envelope(elapsed),
            name=sanitize_display(name),
            url=sanitize_display(url),
            path=sanitize_display(effective_path),
            branch=sanitize_display(branch),
        )
        print(json.dumps(payload))
    else:
        print(f"✅ Added workspace member '{sanitize_display(name)}'  ({sanitize_display(url)})")
        print("   Run 'muse workspace sync' to clone it.")

def run_workspace_update(args: argparse.Namespace) -> None:
    """Update the URL, path, or branch for an existing workspace member.

    Only the supplied flags are changed; omitted fields keep their current
    values.  At least one of ``--url``, ``--path``, or ``--branch`` must be
    given.  All string fields are sanitized before JSON serialisation.

    Agent quickstart::

        muse workspace update core --branch dev --json
        muse workspace update data --url https://musehub.ai/acme/data2 --json

    JSON fields::

        name         Updated member name.
        url          Current remote URL.
        path         Current relative checkout path.
        branch       Current tracking branch.
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    0 success, 1 error.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  Success.
        1  Member not found, no flags supplied, or invalid URL/path/branch.
    """
    name: str = args.name
    url: str | None = args.url
    path: str | None = args.path
    branch: str | None = args.branch
    json_out: bool = args.json_out

    elapsed = start_timer()
    if url is None and path is None and branch is None:
        if json_out:
            print(json.dumps({**make_envelope(elapsed, exit_code=int(ExitCode.USER_ERROR)),
                               "error": "no_flags", "name": name,
                               "message": "specify at least one of --url, --path, or --branch"}))
        print("❌ Specify at least one of --url, --path, or --branch.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    root = find_workspace_root()
    if root is None:
        if json_out:
            print(json.dumps({**make_envelope(elapsed, exit_code=int(ExitCode.USER_ERROR)),
                               "error": "not_found", "name": name,
                               "message": f"workspace member '{name}' not found"}))
        print(f"❌ Workspace member '{name}' not found.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    try:
        update_workspace_member(root, name, url=url, path=path, branch=branch)
    except ValueError as exc:
        if json_out:
            print(json.dumps({**make_envelope(elapsed, exit_code=int(ExitCode.USER_ERROR)),
                               "error": "update_failed", "name": name, "message": str(exc)}))
        print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    member = get_workspace_member(root, name)
    if json_out:
        payload = _WorkspaceUpdateJson(
            **make_envelope(elapsed),
            name=sanitize_display(member.name),
            url=sanitize_display(member.url),
            path=sanitize_display(str(member.path)),
            branch=sanitize_display(member.branch),
        )
        print(json.dumps(payload))
    else:
        print(f"✅ Updated workspace member '{sanitize_display(name)}'.")

def run_workspace_remove(args: argparse.Namespace) -> None:
    """Remove a member from the workspace manifest (does not delete files).

    Only its registration in ``.muse/workspace.toml`` is removed.  The
    checkout directory on disk is left untouched.

    Agent quickstart::

        muse workspace remove sounds --json

    JSON fields::

        name         Member name that was removed.
        removed      Always true on success.
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    0 success, 1 error.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  Member removed successfully.
        1  Member not found, or no workspace manifest exists.

    Examples::

        muse workspace remove sounds
        muse workspace remove sounds --json
    """
    name: str = args.name
    json_out: bool = args.json_out

    elapsed = start_timer()
    root = find_workspace_root()
    if root is None:
        if json_out:
            print(json.dumps({**make_envelope(elapsed, exit_code=int(ExitCode.USER_ERROR)),
                               "error": "not_found", "name": name,
                               "message": f"workspace member '{name}' not found"}))
        print(f"❌ Workspace member '{name}' not found.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    try:
        remove_workspace_member(root, name)
    except ValueError as exc:
        if json_out:
            print(json.dumps({**make_envelope(elapsed, exit_code=int(ExitCode.USER_ERROR)),
                               "error": "remove_failed", "name": name, "message": str(exc)}))
        print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    if json_out:
        payload = _WorkspaceRemoveJson(**make_envelope(elapsed), name=sanitize_display(name), removed=True)
        print(json.dumps(payload))
    else:
        print(f"✅ Removed workspace member '{sanitize_display(name)}'.")

def run_workspace_list(args: argparse.Namespace) -> None:
    """List all workspace members and their current status.

    Returns status for every registered member: presence, actual branch,
    HEAD commit, dirty state, shelf count, and feature branches.  An empty
    member list exits 0 — no workspace manifest is silently treated as
    an empty workspace.

    Agent quickstart::

        muse workspace list --json

    JSON fields::

        members      List of member status objects (name, url, path, branch,
                     present, head_commit, dirty, actual_branch, shelf_count,
                     feature_branches, branch_mismatch).
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    Always 0.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  Success (empty list when no members registered).
    """
    json_out: bool = args.json_out
    elapsed = start_timer()
    root = find_workspace_root()
    members = list_workspace_members(root) if root is not None else []

    if json_out:
        payload = _WorkspaceListJson(
            **make_envelope(elapsed),
            members=[_member_to_json(m) for m in members],
        )
        print(json.dumps(payload))
        return

    if not members:
        print("No workspace members.  Add one with 'muse workspace add'.")
        return
    header = f"{'name':<20} {'on branch':<18} {'tracking':<14} {'HEAD':<12}  flags"
    print(header)
    print("-" * 80)
    for m in members:
        if not m.present:
            print(
                f"{'❌ ' + sanitize_display(m.name):<20} "
                f"{'(not cloned)':<18} "
                f"{sanitize_display(m.branch):<14} "
                f"{'—':<12}  run: muse workspace sync {sanitize_display(m.name)}"
            )
            continue
        actual = sanitize_display(m.actual_branch or "unknown")
        tracking = sanitize_display(m.branch)
        branch_mismatch = m.actual_branch and m.actual_branch != m.branch
        head_str = m.head_commit if m.head_commit else "unknown"
        flags: list[str] = []
        if m.dirty:
            flags.append("dirty")
        if m.shelf_count:
            flags.append(f"{m.shelf_count} shelf")
        if m.feature_branches:
            flags.append(f"branches:{','.join(sanitize_display(b) for b in m.feature_branches)}")
        if branch_mismatch:
            flags.append("⚠️ branch-mismatch")
        flags_str = "  ".join(flags) if flags else "clean"
        print(
            f"{sanitize_display(m.name):<20} "
            f"{actual:<18} "
            f"{tracking:<14} "
            f"{head_str:<12}  {flags_str}"
        )

def run_workspace_status(args: argparse.Namespace) -> None:
    """Show status of all (or one named) workspace members.

    Without NAME, reports every registered member.  With NAME, reports only
    that member.  ``branch_mismatch`` is true when ``actual_branch`` (currently
    checked out) differs from the configured tracking branch.

    Agent quickstart::

        muse workspace status --json
        muse workspace status core --json

    JSON fields::

        members      List of member status objects (name, url, path, branch,
                     present, head_commit, dirty, actual_branch, shelf_count,
                     feature_branches, branch_mismatch).
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    0 success, 1 named member not found.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  Success (empty array when no members registered).
        1  Named member not found, or no workspace manifest.
    """
    json_out: bool = args.json_out
    name: str | None = args.name
    elapsed = start_timer()
    root = find_workspace_root()

    if name is not None:
        if root is None:
            if json_out:
                print(json.dumps({**make_envelope(elapsed, exit_code=int(ExitCode.USER_ERROR)),
                                   "error": "no_workspace", "message": "no workspace manifest found"}))
            print("❌ No workspace manifest found.", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        try:
            members = [get_workspace_member(root, name)]
        except ValueError as exc:
            if json_out:
                print(json.dumps({**make_envelope(elapsed, exit_code=int(ExitCode.USER_ERROR)),
                                   "error": "not_found", "name": name, "message": str(exc)}))
            print(f"❌ {exc}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
    else:
        members = list_workspace_members(root) if root is not None else []

    if json_out:
        payload = _WorkspaceStatusJson(
            **make_envelope(elapsed),
            members=[_member_to_json(m) for m in members],
        )
        print(json.dumps(payload))
        return

    if not members:
        print("No workspace members.  Add one with 'muse workspace add'.")
        return
    print(f"Workspace: {root}\n")
    for m in members:
        if not m.present:
            print(
                f"❌  {sanitize_display(m.name):<20}  "
                f"NOT CHECKED OUT  branch={sanitize_display(m.branch)}"
            )
            print(f"     url:  {sanitize_display(m.url)}")
            print(f"     hint: muse workspace sync {sanitize_display(m.name)}")
            continue
        head = m.head_commit if m.head_commit else "unknown"
        actual = m.actual_branch or "unknown"
        tracking = m.branch
        branch_mismatch = m.actual_branch and m.actual_branch != m.branch
        if branch_mismatch:
            branch_display = (
                f"{sanitize_display(actual)}  "
                f"⚠️ (tracking: {sanitize_display(tracking)})"
            )
        else:
            branch_display = sanitize_display(actual)
        dirty_tag = "  ⚠️ dirty" if m.dirty else ""
        print(
            f"✅  {sanitize_display(m.name):<20}  "
            f"branch={branch_display}  head={head}{dirty_tag}"
        )
        print(f"     path: {sanitize_display(str(m.path))}")
        print(f"     url:  {sanitize_display(m.url)}")
        if m.shelf_count:
            print(f"     ⚠️ shelved: {m.shelf_count} — run 'muse shelf list' to review")
        if m.feature_branches:
            fb = ", ".join(sanitize_display(b) for b in m.feature_branches)
            print(f"     ⚠️ feature branches: {fb}")

def run_workspace_sync(args: argparse.Namespace) -> None:
    """Clone or pull the latest state for workspace members.

    Without NAME, syncs all members.  With NAME, syncs only that one.
    Parallel workers default to 1; use ``--workers N`` to clone members
    concurrently.  ``--dry-run`` shows what would happen without touching disk.

    Agent quickstart::

        muse workspace sync --json
        muse workspace sync --workers 8 --json
        muse workspace sync core --json
        muse workspace sync --dry-run --json

    JSON fields::

        dry_run      true when --dry-run was passed.
        workers      Number of parallel workers used.
        results      List of {name, status, ok} per member.
        total        Total member count.
        ok_count     Members that succeeded.
        error_count  Members that failed.
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    0 all ok, 3 any member failed.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  All members synced successfully.
        3  One or more members failed to sync.
    """
    name: str | None = args.name
    dry_run: bool = args.dry_run
    workers: int = args.workers
    json_out: bool = args.json_out

    elapsed = start_timer()
    root = find_workspace_root()
    results = sync_workspace(root, member_name=name, dry_run=dry_run, workers=workers) if root is not None else []

    if not results:
        if json_out:
            payload = _WorkspaceSyncJson(
                **make_envelope(elapsed),
                dry_run=dry_run,
                workers=workers,
                results=[],
                total=0,
                ok_count=0,
                error_count=0,
            )
            print(json.dumps(payload))
        else:
            print("No members to sync.  Add one with 'muse workspace add'.")
        return

    json_results = [_sync_result_to_json(r) for r in results]
    ok_count = sum(1 for r in json_results if r["ok"])
    error_count = len(json_results) - ok_count
    exit_code = int(ExitCode.INTERNAL_ERROR) if error_count else 0

    if json_out:
        payload = _WorkspaceSyncJson(
            **make_envelope(elapsed, exit_code=exit_code),
            dry_run=dry_run,
            workers=workers,
            results=json_results,
            total=len(json_results),
            ok_count=ok_count,
            error_count=error_count,
        )
        print(json.dumps(payload))
        return

    for r in results:
        icon = "✅" if not r["status"].startswith("error") else "❌"
        print(f"{icon}  {sanitize_display(r['name'])}: {sanitize_display(r['status'])}")
    if error_count:
        print(f"\n⚠️  {error_count} member(s) failed to sync.", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR)
