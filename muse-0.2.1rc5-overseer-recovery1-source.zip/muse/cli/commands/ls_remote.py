"""muse ls-remote — list references on a remote repository.

Contacts the remote and prints every branch and its current commit ID without
modifying any local state.  Useful for scripting, agent coordination, and
pre-flight checks before push/pull.

Output (text, default) — one line per branch, ``*`` marks the default branch::

    sha256:<commit_id>\\t<branch>
    sha256:<commit_id>\\t<branch> *

Output (``--json``/``-j``)::

    {
      "status":         "ok",
      "error":          "",
      "repo_id":        "<sha256:...>",
      "domain":         "midi",
      "default_branch": "main",
      "branches":       {"main": "sha256:<commit_id>", "feat/x": "sha256:<commit_id>"},
      "remote":         "origin",
      "url":            "https://musehub.ai/org/repo",
      "duration_ms":    4.1,
      "exit_code":      0
    }

All keys are always present so agents can read them without ``dict.get``
guards.  ``"status"`` is always ``"ok"`` on success.

``"remote"`` is the configured remote name used to resolve the URL (e.g.
``"origin"``).  It is ``null`` when the caller passed a full URL directly
instead of a remote name — no config lookup was performed.

``"url"`` is the resolved URL that was actually contacted.  Always present.

Branch OIDs are always ``sha256:``-prefixed regardless of what the remote
returns — bare hex is normalized to the canonical form.

JSON error schema (exit non-zero)::

    {
      "status":    "error",
      "error":     "<human-readable message>",
      "exit_code": 1
    }

When ``--json`` is active all errors go to stdout as JSON — no prose on
stderr.  Agents should parse stdout and check ``status``.

Agent use
---------

Pass a remote name (configured via ``muse remote add``) or a full URL::

    muse ls-remote origin --json
    muse ls-remote https://musehub.ai/org/repo --json

Output contract
---------------

- Exit 0: remote contacted, refs printed.
- Exit 1: remote not configured and argument does not look like a URL.
- Exit 3: transport error (network unreachable, HTTP error).
"""

import argparse
import json
import logging
import pathlib
import sys
from typing import TypedDict

from muse.cli.config import get_signing_identity, get_remote
from muse.core.types import long_id
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.repo import find_repo_root
from muse.core.transport import HttpTransport, TransportError
from muse.core.validation import sanitize_display
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

_HEX_CHARS = frozenset("0123456789abcdef")

type _BranchHeads = dict[str, str]

class _LsRemoteJson(EnvelopeJson):
    """Stable JSON envelope for ``muse ls-remote --json``.

    Inherits the 6 standard envelope fields from :class:`~muse.core.envelope.EnvelopeJson`.

    All keys are always present so agents can read them without ``dict.get``
    guards.  ``status`` is ``"ok"`` on success.
    """
    status: str            # "ok"
    error: str             # always "" on success
    repo_id: str
    domain: str
    default_branch: str
    branches: _BranchHeads
    remote: str | None     # remote name used; null when URL passed directly
    url: str               # resolved URL that was contacted

class _LsRemoteErrorJson(EnvelopeJson):
    """Error payload for ``muse ls-remote --json`` on usage or transport errors."""
    status: str            # "error"
    error: str

def _normalize_oid(oid: str) -> str:
    """Ensure an OID carries the canonical ``sha256:`` prefix.

    Defense in depth: remotes *should* return prefixed OIDs but may not.
    Bare 64-character hex strings are normalized.  Anything else is returned
    as-is — the caller is responsible for validating the result further.
    """
    if oid.startswith("sha256:"):
        return oid
    if len(oid) == 64 and all(c in _HEX_CHARS for c in oid.lower()):
        return long_id(oid.lower())
    return oid

def _emit_error(json_out: bool, msg: str, code: ExitCode, elapsed: float) -> None:
    """Print an error and raise SystemExit.  Never returns.

    In ``--json`` mode the error goes to stdout as a JSON payload so machine
    consumers always get parseable output.  In text mode it goes to stderr.
    """
    if json_out:
        print(json.dumps(_LsRemoteErrorJson(
            **make_envelope(elapsed, exit_code=int(code)),
            status="error",
            error=msg,
        )))
    else:
        print(f"❌ {sanitize_display(msg)}", file=sys.stderr)
    raise SystemExit(code)

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ls-remote subcommand."""
    parser = subparsers.add_parser(
        "ls-remote",
        help="List branch heads on a remote without modifying local state.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "remote_or_url",
        nargs="?",
        default="origin",
        help="Remote name (e.g. 'origin') or a full URL. Defaults to 'origin'.",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON.",
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """List branches and commit IDs on a remote.

    Contacts the remote and prints each branch HEAD without altering any local
    state.  Pass a remote name (configured via ``muse remote add``) or a full
    URL.  ``remote`` in the JSON output is ``null`` when a full URL was passed
    directly — no config lookup occurred.

    Agent quickstart
    ----------------
    ::

        muse ls-remote --json
        muse ls-remote origin --json
        muse ls-remote local --json
        muse ls-remote https://musehub.ai/gabriel/muse --json

    JSON fields
    -----------
    status          ``"ok"`` on success.
    repo_id         Remote repository identifier.
    domain          Domain of the remote repo (``"code"``, ``"audio"``, …).
    default_branch  The remote's default branch name.
    branches        Map of ``branch_name → sha256:<commit_id>``.
    remote          Remote name used, or ``null`` when a full URL was passed.
    url             Resolved URL that was contacted.

    Exit codes
    ----------
    0  Success.
    1  Remote not configured and argument is not a URL.
    3  Transport error — network unreachable or HTTP error.
    """
    elapsed = start_timer()

    json_out: bool = args.json_out
    remote_or_url: str = args.remote_or_url

    root = find_repo_root(pathlib.Path.cwd())

    # Track whether we resolved a named remote (remote_name) vs a raw URL.
    remote_name: str | None = None
    url: str | None = None

    if root is not None:
        resolved = get_remote(remote_or_url, root)
        if resolved is not None:
            remote_name = remote_or_url
            url = resolved

    if url is None:
        if remote_or_url.startswith("http://") or remote_or_url.startswith("https://"):
            url = remote_or_url
            # remote_name stays None — caller passed URL directly
        else:
            _emit_error(
                json_out,
                f"'{remote_or_url}' is not a configured remote and does not look like a URL. "
                f"Configure it with: muse remote add <name> <url>",
                ExitCode.USER_ERROR,
                elapsed,
            )

    # Resolve signing identity against the actual target URL so that named
    # remotes pointing to staging (or any host other than the repo's default
    # hub) use the correct registered key rather than falling back to the
    # local-hub key.
    token = get_signing_identity(root, remote_url=url)

    transport = HttpTransport()
    try:
        info = transport.fetch_remote_info(url, token)
    except TransportError as exc:
        _emit_error(json_out, f"Cannot reach remote: {exc}", ExitCode.INTERNAL_ERROR, elapsed)

    # Normalize all branch OIDs to sha256: prefix — defense in depth.
    branches = {
        branch: _normalize_oid(oid)
        for branch, oid in info["branch_heads"].items()
    }

    if json_out:
        print(json.dumps(_LsRemoteJson(
            **make_envelope(elapsed),
            status="ok",
            error="",
            repo_id=info["repo_id"],
            domain=info["domain"],
            default_branch=info["default_branch"],
            branches=branches,
            remote=remote_name,
            url=url,
        )))
        return

    if not branches:
        print("(no branches)")
        return

    for branch, commit_id in sorted(branches.items()):
        marker = " *" if branch == info["default_branch"] else ""
        print(f"{sanitize_display(commit_id)}\t{sanitize_display(branch)}{marker}")
