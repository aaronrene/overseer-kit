"""muse ls-files — list tracked files in a snapshot.

Lists every file tracked in a commit's snapshot, along with the SHA-256
object ID of its content.  Defaults to the HEAD commit of the current branch.

Output (JSON, default)::

    {
      "status":      "ok",
      "error":       "",
      "commit_id":   "sha256:…",
      "snapshot_id": "sha256:…",
      "branch":      "main",
      "path_prefix": null,
      "file_count":  3,
      "files": [
        {"path": "tracks/drums.mid", "object_id": "sha256:…"},
        ...
      ],
      "duration_ms": 1.2,
      "exit_code":   0
    }

All keys are always present so agents can read them without ``dict.get``
guards.  ``"status"`` is always ``"ok"`` on success.  ``"branch"`` is
``null`` when ``--commit`` is given explicitly (no branch resolution occurs).
``"path_prefix"`` is ``null`` when no ``--path-prefix`` filter was applied.

JSON error schema (exit non-zero)::

    {
      "status":    "error",
      "error":     "<human-readable message>",
      "exit_code": 1
    }

When ``--json`` is active all errors go to stdout as JSON — no prose on
stderr.  Agents should parse stdout and check ``status``.

Output (--format text)::

    <sha256:object_id>\\t<path>
    ...

Output contract
---------------

- Exit 0: manifest listed successfully.
- Exit 1: commit or snapshot not found, invalid argument, or unknown --format.

Agent use
---------

Filter to a subdirectory to avoid pulling the full manifest::

    muse ls-files --path-prefix src/
    muse ls-files --path-prefix src/ --commit <sha256:…>
"""

import argparse
import json
import logging
import sys
from typing import TypedDict

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import read_commit
from muse.core.snapshots import get_commit_snapshot_manifest
from muse.core.validation import sanitize_display, validate_object_id, validate_path_prefix
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

class _LsFileEntry(TypedDict):
    path: str
    object_id: str

class _LsFilesJson(EnvelopeJson):
    """Stable JSON envelope for ``muse ls-files --json``.

    Inherits the 6 standard envelope fields from :class:`~muse.core.envelope.EnvelopeJson`.

    All keys are always present so agents can read them without ``dict.get``
    guards.  ``status`` is ``"ok"`` on success.
    """
    status: str           # "ok"
    error: str            # always "" on success
    commit_id: str
    snapshot_id: str | None
    branch: str | None    # null when --commit was supplied explicitly
    path_prefix: str | None  # null when no --path-prefix filter applied
    file_count: int
    files: list[_LsFileEntry]

class _LsFilesErrorJson(EnvelopeJson):
    """Error payload for ``muse ls-files --json`` on usage or internal errors."""
    status: str           # "error"
    error: str

def _emit_error(json_out: bool, msg: str, code: ExitCode, elapsed: float) -> None:
    """Print an error and raise SystemExit.  Never returns.

    In ``--json`` mode the error goes to stdout as a JSON payload so machine
    consumers always get parseable output.  In text mode it goes to stderr.
    """
    if json_out:
        print(json.dumps(_LsFilesErrorJson(
            **make_envelope(elapsed, exit_code=int(code)),
            status="error",
            error=msg,
        )))
    else:
        print(f"❌ {sanitize_display(msg)}", file=sys.stderr)
    raise SystemExit(code)

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ls-files subcommand."""
    parser = subparsers.add_parser(
        "ls-files",
        help="List all tracked files and their object IDs in a snapshot.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--commit", "-c",
        default=None,
        dest="commit",
        metavar="COMMIT_ID",
        help="Commit ID to read (default: HEAD).",
    )
    parser.add_argument(
        "--path-prefix", "-p",
        default=None,
        dest="path_prefix",
        metavar="PREFIX",
        help="Only list files whose path starts with PREFIX.",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON.",
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """List all tracked files and their object IDs in a snapshot.

    Reads the snapshot manifest of the given commit (or HEAD) and emits each
    tracked file path together with its content-addressed object ID.  Use
    ``--path-prefix`` to scope the listing to a subdirectory — always prefer
    this over pulling the full manifest and filtering client-side.

    Agent quickstart
    ----------------
    ::

        muse ls-files --json
        muse ls-files --path-prefix src/ --json
        muse ls-files --commit sha256:<id> --json
        muse ls-files --path-prefix muse/core/ --commit HEAD --json

    JSON fields
    -----------
    status       ``"ok"`` on success.
    commit_id    Commit ID whose snapshot was read.
    snapshot_id  Content-addressed snapshot object ID.
    branch       Branch name, or ``null`` when ``--commit`` was given explicitly.
    path_prefix  The ``--path-prefix`` filter applied, or ``null``.
    file_count   Number of files returned.
    files        List of ``{"path": str, "object_id": str}`` entries.

    Exit codes
    ----------
    0  Success.
    1  Commit or snapshot not found, invalid argument, or unknown ``--format``.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()

    json_out: bool = args.json_out
    commit: str | None = args.commit
    path_prefix: str | None = args.path_prefix

    root = require_repo()

    branch: str | None = None

    if commit is None:
        branch = read_current_branch(root)
        commit_id = get_head_commit_id(root, branch)
        if commit_id is None:
            _emit_error(json_out, "No commits on current branch.", ExitCode.USER_ERROR, elapsed)
    else:
        try:
            validate_object_id(commit)
        except ValueError as exc:
            _emit_error(json_out, f"Invalid commit ID: {exc}", ExitCode.USER_ERROR, elapsed)
        commit_id = commit

    commit_record = read_commit(root, commit_id)
    if commit_record is None:
        _emit_error(json_out, f"Commit not found: {commit_id}", ExitCode.USER_ERROR, elapsed)

    manifest = get_commit_snapshot_manifest(root, commit_id)
    if manifest is None:
        _emit_error(json_out, f"Snapshot not found for commit: {commit_id}", ExitCode.USER_ERROR, elapsed)

    if path_prefix is not None:
        try:
            validate_path_prefix(path_prefix)
        except ValueError as exc:
            _emit_error(json_out, f"Invalid --path-prefix: {exc}", ExitCode.USER_ERROR, elapsed)

    items = sorted(manifest.items())
    if path_prefix is not None:
        items = [(p, oid) for p, oid in items if p.startswith(path_prefix)]

    files = [{"path": p, "object_id": oid} for p, oid in items]

    if not json_out:
        for entry in files:
            # sanitize_display guards against ANSI sequences in file paths —
            # valid on most filesystems but dangerous when echoed to a terminal.
            print(f"{entry['object_id']}\t{sanitize_display(entry['path'])}")
        return
    print(json.dumps(_LsFilesJson(
        **make_envelope(elapsed),
        status="ok",
        error="",
        commit_id=commit_id,
        snapshot_id=commit_record.snapshot_id,
        branch=branch,
        path_prefix=path_prefix,
        file_count=len(files),
        files=files,
    )))
