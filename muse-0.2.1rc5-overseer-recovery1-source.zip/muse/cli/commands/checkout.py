"""``muse checkout`` — switch branches or restore working tree from a commit.

Usage::

    muse checkout <branch>              — switch to existing branch
    muse checkout -b <branch>           — create and switch to new branch
    muse checkout <commit-id>           — detach HEAD at a specific commit
    muse checkout --ours <file>         — resolve conflict by accepting our version
    muse checkout --theirs <file>       — resolve conflict by accepting their version
    muse checkout --dry-run <branch>    — show what would happen without switching

Conflict resolution
-------------------
After a ``muse merge`` that leaves conflicts, use ``--ours`` or ``--theirs``
to accept one side of each conflicted file.  The file is restored from the
appropriate commit in MERGE_STATE.json and removed from the unresolved conflict
list.  Once all conflicts are cleared, run ``muse commit`` to complete the merge.

    # Accept our version of AGENTS.md (feature branch wins)
    muse checkout --ours AGENTS.md

    # Accept their version of pyproject.toml (main branch wins)
    muse checkout --theirs pyproject.toml

    # Bulk-resolve every conflict to one side
    muse checkout --ours   --all
    muse checkout --theirs --all

    # Check remaining conflicts
    muse status

    # Complete the merge
    muse commit -m "merge: resolve conflicts"

JSON output (``--format json`` or ``--json``)::

    {
      "action":          "created|switched|detached|already_on|restored",
      "branch":          "<name> | null",
      "commit_id":       "<sha256>",
      "from_branch":     "<previous-branch>",
      "dry_run":         false,
      "duration_ms": 0.000123,
      "exit_code":       0
    }

``duration_ms``
    Wall-clock time from argument parsing to output.
``exit_code``
    Always ``0`` on success.  Lets agents parse one payload instead of
    inspecting the process exit code separately.

Exit codes::

    0 — success
    1 — invalid branch name, branch not found, dirty working tree (without --force)
    3 — internal error (missing snapshot or object)
"""

import argparse
import json
import logging
import pathlib
import re
import sys

from muse.core.errors import ExitCode
from muse.core.merge_engine import read_merge_state, write_merge_state
from muse.core.object_store import has_object, read_object, restore_object
from muse.core.repo import require_repo
from muse.core.snapshot import diff_workdir_vs_snapshot
from muse.core.refs import read_ref
from muse.core.io import write_text_atomic
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
    read_head,
    write_branch_ref,
    write_head_branch,
    write_head_commit,
)
from muse.core.commits import (
    get_head_snapshot_id,
    read_commit,
    resolve_commit_ref,
)
from muse.core.snapshots import (
    get_head_snapshot_manifest,
    read_snapshot,
)
from muse.core.reflog import append_reflog
from muse.core.validation import contain_path, sanitize_display, validate_branch_name
from muse.cli.config import write_branch_meta
from muse.cli.guard import require_clean_workdir
from muse.cli.commands.shelf import _shelf_push_programmatic, _shelf_pop_programmatic
from muse.core.snapshot import directories_from_manifest
from muse.core.cohen_transform import three_way_merge_lines
from muse.domain import SnapshotManifest
from muse.plugins.registry import read_domain, resolve_plugin
from muse.core.types import NULL_COMMIT_ID, Manifest
from muse.core.paths import checkout_head_path as _checkout_head_path, muse_dir as _muse_dir, ref_path as _ref_path
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.timing import start_timer
from typing import TypedDict

logger = logging.getLogger(__name__)

class _CheckoutJson(EnvelopeJson, total=False):
    """Wire shape for muse checkout --json.

    All domain fields are optional because different checkout modes populate
    different subsets (branch switch vs conflict resolution vs --merge).
    EnvelopeJson fields remain required via the base class.
    """

    action: str           # created|switched|detached|already_on|restored|conflict_resolved|conflict_resolved_all
    branch: str | None    # branch name; None for detached HEAD
    commit_id: str
    from_branch: str
    dry_run: bool
    # conflict-resolution fields
    side: str             # "ours" | "theirs"
    resolved_count: int
    remaining_conflicts: int
    file: str             # single-path conflict resolution
    # --merge mode fields
    clean_merges: list[str]
    conflicts: list[str]
    dirty_paths: list[str]

class _MergeCheckoutResult(TypedDict, total=False):
    dry_run: bool
    action: str
    branch: str
    from_branch: str
    commit_id: str
    dirty_paths: list[str]
    clean_merges: list[str]
    conflicts: list[str]

_CHECKOUT_HEAD_FILENAME = "CHECKOUT_HEAD"

def _apply_autoshelf(root: pathlib.Path, json_out: bool) -> None:
    """Pop the autoshelf and emit a status line.

    Called unconditionally from the ``finally`` block in :func:`run` when an
    autoshelf was created.  On conflict the shelf entry is left intact so
    the user can resolve and ``muse shelf pop`` manually.

    Args:
        root:     Repository root containing ``.muse/``.
        json_out: When ``True`` autoshelf messages go to stderr so stdout
                  stays machine-readable.
    """
    try:
        entry = _shelf_pop_programmatic(root)
        files_n = len(entry["snapshot"]) + len(entry["deleted"])
        if not json_out:
            print(f"Applied autoshelf ({files_n} file(s) restored).")
        else:
            print(f"autoshelf: applied ({files_n} file(s) restored)", file=sys.stderr)
    except ValueError as exc:
        msg = f"⚠️  autoshelf pop failed — shelf may be empty: {exc}"
        print(msg, file=sys.stderr)
    except RuntimeError as exc:
        print(
            f"⚠️  autoshelf: could not restore changes — object store error: {exc}\n"
            f"   Your changes are safe on the shelf — run 'muse shelf pop' to restore them.",
            file=sys.stderr,
        )

def checkout_head_path(root: pathlib.Path) -> pathlib.Path:
    """Return the path to ``.muse/CHECKOUT_HEAD``.

    This file exists only while a checkout is in progress.  Its presence
    after a crash means the working tree may be partially mutated and
    ``muse status`` should warn the user.
    """
    return _checkout_head_path(root)

def read_checkout_head(root: pathlib.Path) -> str | None:
    """Return the target branch recorded in ``.muse/CHECKOUT_HEAD``, or ``None``.

    ``None`` means no checkout is in progress (normal state).
    A non-``None`` value means a previous checkout was interrupted and the
    working tree may be partially mutated.
    """
    path = checkout_head_path(root)
    try:
        val = path.read_text(encoding="utf-8").strip()
        return val if val else None
    except (FileNotFoundError, PermissionError, OSError):
        return None

def _checkout_snapshot(
    root: pathlib.Path,
    target_snapshot_id: str,
    current_snapshot_id: str | None,
    *,
    target_branch: str | None = None,
    clear_marker: bool = True,
) -> None:
    """Incrementally update the working tree from the current to the target snapshot.

    Uses the domain plugin to compute the delta between the two snapshots and
    only touches files that actually changed — removing deleted paths and
    restoring added/modified ones from the object store.  Calls
    ``plugin.apply()`` as the domain-level post-checkout hook.

    Pre-flight integrity guarantee
        Before mutating any file on disk, every object that must be restored
        is verified to exist in the local store via :func:`has_object`.  If
        any object is missing the function prints a diagnostic and raises
        ``SystemExit`` **without touching the working tree**.

    CHECKOUT_HEAD marker
        ``.muse/CHECKOUT_HEAD`` is written with *target_branch* (or the
        snapshot ID when no branch name is available) before the first file
        mutation.  When *clear_marker* is ``True`` (the default) the marker
        is unlinked at the end of this function.  Pass ``clear_marker=False``
        when the caller will follow with ``write_head_branch`` or
        ``write_head_commit``: the marker must survive through that write so
        that a kill between the working-tree update and the HEAD-pointer write
        is detectable by ``muse status``.  The caller is then responsible for
        calling ``checkout_head_path(root).unlink(missing_ok=True)`` after the
        HEAD write completes.

    Raises ``SystemExit(ExitCode.INTERNAL_ERROR)`` if the target snapshot or
    any required object is missing from the local store.
    """
    plugin = resolve_plugin(root)
    domain = read_domain(root)

    target_snap_rec = read_snapshot(root, target_snapshot_id)
    if target_snap_rec is None:
        print(
            f"❌ Snapshot {target_snapshot_id} not found in object store.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    target_snap = SnapshotManifest(
        files=target_snap_rec.manifest,
        domain=domain,
        directories=list(target_snap_rec.directories),
    )

    cur_rec = None
    if current_snapshot_id is not None:
        cur_rec = read_snapshot(root, current_snapshot_id)
        current_snap = (
            SnapshotManifest(
                files=cur_rec.manifest,
                domain=domain,
                directories=list(cur_rec.directories),
            )
            if cur_rec
            else SnapshotManifest(files={}, domain=domain, directories=[])
        )
    else:
        current_snap = SnapshotManifest(files={}, domain=domain, directories=[])

    delta = plugin.diff(current_snap, target_snap)
    cur_manifest: Manifest = cur_rec.manifest if cur_rec else {}

    # ── Gap 1: Pre-flight object existence check ──────────────────────────────
    # Build the list of file paths that need to be restored (insert / replace /
    # patch ops whose address is a real file in the target manifest, not a
    # directory entry).  Then verify every required object exists in the local
    # store BEFORE touching a single file on disk.  If anything is missing we
    # abort here — zero mutations to the working tree.
    to_restore = [
        op["address"] for op in delta["ops"]
        if op["op"] in ("insert", "replace", "patch")
        and op["address"] in target_snap_rec.manifest
    ]
    preflight_missing = [
        rel_path for rel_path in to_restore
        if not has_object(root, target_snap_rec.manifest[rel_path])
    ]
    if preflight_missing:
        for rel_path in preflight_missing:
            object_id = target_snap_rec.manifest[rel_path]
            print(
                f"❌ Object {object_id} for '{sanitize_display(rel_path)}' "
                "is missing from the local object store.",
                file=sys.stderr,
            )
        print(
            f"❌ Checkout aborted: {len(preflight_missing)} object(s) not in local "
            "store.  Fetch missing objects from the remote before retrying.\n"
            "   Working tree was NOT modified.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    # ── Gap 2: Write CHECKOUT_HEAD before first mutation ─────────────────────
    # Record the intended target so `muse status` can detect an interrupted
    # checkout and warn the user rather than silently reporting missing files
    # as uncommitted deletions.
    marker_path = checkout_head_path(root)
    marker_label = target_branch or target_snapshot_id
    write_text_atomic(marker_path, f"{marker_label}\n")

    # ── Remove files that no longer exist in the target snapshot ─────────────
    # Skip directory-level delete ops — only actual files (addresses present in
    # the current manifest) are unlinked here.
    removed = [
        op["address"] for op in delta["ops"]
        if op["op"] == "delete" and op["address"] in cur_manifest
    ]
    for rel_path in removed:
        fp = root / rel_path
        if fp.exists() and fp.is_file():
            fp.unlink()

    # ── Restore added and modified files from the content-addressed store ─────
    # All objects were verified present above; restore_object should not return
    # False here.  A second-layer check is kept as a defensive catch for races
    # (e.g. another process pruning the store mid-checkout).
    restore_failures: list[str] = []
    for rel_path in to_restore:
        object_id = target_snap_rec.manifest[rel_path]
        try:
            safe_dest = contain_path(root, rel_path)
        except ValueError as exc:
            logger.warning("⚠️ Skipping unsafe manifest path %r: %s", rel_path, exc)
            continue
        if not restore_object(root, object_id, safe_dest):
            restore_failures.append(rel_path)

    if restore_failures:
        for rel_path in restore_failures:
            object_id = target_snap_rec.manifest[rel_path]
            print(
                f"❌ Object {object_id} for '{sanitize_display(rel_path)}' "
                "disappeared from the store mid-checkout (store was modified "
                "concurrently?).",
                file=sys.stderr,
            )
        print(
            f"❌ Checkout incomplete: {len(restore_failures)} object(s) could not "
            "be restored.  Run `muse checkout <branch>` to retry.",
            file=sys.stderr,
        )
        # CHECKOUT_HEAD remains on disk — muse status will detect the
        # interrupted state and guide the user.
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    # ── Domain-level post-checkout hook ───────────────────────────────────────
    plugin.apply(delta, root)

    # ── Clear CHECKOUT_HEAD on success ────────────────────────────────────────
    # When clear_marker=False the caller is responsible for clearing after it
    # updates the branch HEAD ref — keeping the marker alive through that write
    # window so an interrupt there is still detectable by muse status.
    if clear_marker:
        marker_path.unlink(missing_ok=True)

def _checkout_with_merge(
    root: pathlib.Path,
    target: str,
    current_branch: str,
    *,
    json_out: bool,
    dry_run: bool,
) -> _MergeCheckoutResult:
    """Perform a branch switch carrying uncommitted changes via three-way merge.

    Implements ``muse checkout -m`` (the Cohen Transform checkout):

    1. Snapshot the dirty working-tree files (modified + deleted tracked files).
    2. Apply the target-branch snapshot to the working tree normally.
    3. For each dirty file, three-way merge:
         base   = HEAD version (what we last committed)
         ours   = working-tree version (your uncommitted edit)
         theirs = target-branch version
    4. Clean merges: write merged content silently.
    5. Conflicts: write diff3 + Manyana-labeled markers inline; record in
       MERGE_STATE.json (same format as ``muse merge`` conflicts so
       ``muse checkout --ours/--theirs`` works identically).

    Binary files with conflicts are left at the target-branch version and
    listed as conflicts; the user must resolve them manually.

    Args:
        root:           Repository root.
        target:         Target branch name.
        current_branch: Current branch name.
        json_out:       Emit JSON output instead of human text.
        dry_run:        When ``True``, report what would happen without writing.

    Returns:
        A result dict suitable for JSON serialisation with keys:
        ``action``, ``branch``, ``from_branch``, ``commit_id``,
        ``clean_merges``, ``conflicts``, ``dry_run``.
    """
    # ── Capture current dirty state ───────────────────────────────────────────
    current_snapshot_id = get_head_snapshot_id(root, current_branch)
    head_manifest: dict[str, str] = {}
    if current_snapshot_id:
        snap_rec = read_snapshot(root, current_snapshot_id)
        if snap_rec:
            head_manifest = dict(snap_rec.manifest)

    _added, modified, deleted, _untracked, _ad, _dd = diff_workdir_vs_snapshot(
        root, head_manifest
    )
    dirty_paths = modified | deleted

    # Read the working-tree content for every modified file BEFORE the
    # checkout overwrites the working tree.
    workdir_content: dict[str, bytes] = {}
    for rel_path in dirty_paths:
        fp = root / rel_path
        if fp.is_file():
            workdir_content[rel_path] = fp.read_bytes()
        else:
            workdir_content[rel_path] = b""  # deleted

    if dry_run:
        target_commit_id = get_head_commit_id(root, target) or ""
        return {
            "dry_run": True,
            "action": "switched",
            "branch": target,
            "from_branch": current_branch,
            "commit_id": target_commit_id,
            "dirty_paths": sorted(dirty_paths),
            "clean_merges": [],
            "conflicts": [],
        }

    # ── Apply the target snapshot (switches the branch normally) ─────────────
    target_snapshot_id = get_head_snapshot_id(root, target)
    if target_snapshot_id:
        # clear_marker=False: CHECKOUT_HEAD survives until write_head_branch
        # completes.  A crash between here and write_head_branch would leave
        # the working tree at target but HEAD at old branch — muse status needs
        # the marker to detect that interrupted state.
        _checkout_snapshot(root, target_snapshot_id, current_snapshot_id, target_branch=target, clear_marker=False)

    target_commit_id = get_head_commit_id(root, target) or ""

    write_head_branch(root, target)
    checkout_head_path(root).unlink(missing_ok=True)
    append_reflog(
        root, target,
        old_id=get_head_commit_id(root, current_branch) or None,
        new_id=target_commit_id or NULL_COMMIT_ID,
        author="user",
        operation=(
            f"checkout -m: carrying changes from {sanitize_display(current_branch)} "
            f"to {sanitize_display(target)}"
        ),
    )

    if not dirty_paths:
        return {
            "dry_run": False,
            "action": "switched",
            "branch": target,
            "from_branch": current_branch,
            "commit_id": target_commit_id,
            "clean_merges": [],
            "conflicts": [],
        }

    # ── Three-way merge each dirty file (the Cohen Transform) ─────────────────
    # Read the target snapshot manifest so we know theirs content.
    target_manifest: dict[str, str] = {}
    if target_snapshot_id:
        target_snap_rec = read_snapshot(root, target_snapshot_id)
        if target_snap_rec:
            target_manifest = dict(target_snap_rec.manifest)

    clean_merges: list[str] = []
    conflicts: list[str] = []

    ours_label = sanitize_display(current_branch)
    theirs_label = sanitize_display(target)

    for rel_path in sorted(dirty_paths):
        # base  = HEAD version (from the object store)
        base_oid = head_manifest.get(rel_path)
        base_bytes = read_object(root, base_oid) if base_oid else b""
        base_bytes = base_bytes or b""

        # ours  = working-tree content captured before checkout
        ours_bytes = workdir_content.get(rel_path, b"")

        # theirs = target-branch version (now on disk after checkout)
        theirs_oid = target_manifest.get(rel_path)
        theirs_bytes = read_object(root, theirs_oid) if theirs_oid else b""
        theirs_bytes = theirs_bytes or b""

        # Detect binary files: skip line-merge, treat as conflict.
        def _is_binary(b: bytes) -> bool:
            return b"\x00" in b[:8000]

        if _is_binary(base_bytes) or _is_binary(ours_bytes) or _is_binary(theirs_bytes):
            # Binary conflict: leave theirs (already on disk), record conflict.
            conflicts.append(rel_path)
            continue

        # Line-level three-way merge via the Cohen Transform.
        base_lines = base_bytes.decode("utf-8", errors="replace").splitlines(keepends=True)
        ours_lines = ours_bytes.decode("utf-8", errors="replace").splitlines(keepends=True)
        theirs_lines = theirs_bytes.decode("utf-8", errors="replace").splitlines(keepends=True)

        merged_lines, has_conflict = three_way_merge_lines(
            base_lines, ours_lines, theirs_lines,
            label_ours=f"{ours_label} (uncommitted)",
            label_base="base (HEAD)",
            label_theirs=f"{theirs_label}",
        )

        dest = root / rel_path
        dest.parent.mkdir(parents=True, exist_ok=True)
        write_text_atomic(dest, "".join(merged_lines))

        if has_conflict:
            conflicts.append(rel_path)
        else:
            clean_merges.append(rel_path)

    # ── Record MERGE_STATE when conflicts remain ───────────────────────────────
    if conflicts:
        ours_commit_id = get_head_commit_id(root, current_branch) or ""
        write_merge_state(
            root,
            base_commit=ours_commit_id,
            ours_commit=ours_commit_id,
            theirs_commit=target_commit_id,
            conflict_paths=conflicts,
            other_branch=target,
        )

    return {
        "dry_run": False,
        "action": "switched",
        "branch": target,
        "from_branch": current_branch,
        "commit_id": target_commit_id,
        "clean_merges": clean_merges,
        "conflicts": conflicts,
    }

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse checkout`` subcommand and all its flags."""
    parser = subparsers.add_parser(
        "checkout",
        help="Switch branches or restore working tree from a commit.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "target", nargs="?",
        help="Branch name, commit ID, or (with --ours/--theirs) file path to resolve.",
    )
    parser.add_argument(
        "-b", "--create", action="store_true",
        help="Create a new branch at HEAD and switch to it.",
    )
    parser.add_argument(
        "--force", "-f", action="store_true",
        help="Discard uncommitted changes and force the switch.",
    )
    parser.add_argument(
        "--dry-run", "-n", action="store_true", dest="dry_run",
        help=(
            "Show what would happen without making any changes.  "
            "Exits 0 if the switch would succeed, 1 if it would be blocked."
        ),
    )
    parser.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit machine-readable JSON.",
    )
    parser.add_argument(
        "--ours",
        dest="resolve_ours",
        action="store_true",
        help=(
            "Resolve conflict(s) by restoring from our branch (HEAD at merge time). "
            "Use with a file path to resolve one path, or --all to resolve every conflict."
        ),
    )
    parser.add_argument(
        "--theirs",
        dest="resolve_theirs",
        action="store_true",
        help=(
            "Resolve conflict(s) by restoring from the branch being merged in. "
            "Use with a file path to resolve one path, or --all to resolve every conflict."
        ),
    )
    parser.add_argument(
        "--all",
        dest="resolve_all",
        action="store_true",
        help=(
            "Resolve ALL unresolved conflicts at once using --ours or --theirs. "
            "Requires exactly one of --ours or --theirs."
        ),
    )
    parser.add_argument(
        "--merge", "-m",
        dest="merge",
        action="store_true",
        help=(
            "Carry uncommitted working-tree changes into the target branch using "
            "a three-way merge (the Cohen Transform).  "
            "Files that merge cleanly are updated in-place; files that conflict "
            "receive diff3-style markers with Manyana action labels "
            "(e.g. ``<<<<<<< ours [deleted]``) and the merge is recorded in "
            "MERGE_STATE.json for resolution with "
            "``muse checkout --ours/--theirs``.  "
            "Inspired by ``git checkout -m`` and Bram Cohen's Manyana project."
        ),
    )
    parser.add_argument(
        "--autoshelf",
        dest="autoshelf",
        action="store_true",
        help=(
            "Automatically shelf uncommitted changes before switching branches "
            "and pop them back onto the working tree after the switch succeeds.  "
            "Equivalent to running ``muse shelf save`` before checkout and "
            "``muse shelf pop`` after.  "
            "Mutually exclusive with --force and --merge."
        ),
    )
    parser.add_argument(
        "--intent", default=None, metavar="TEXT",
        help=(
            "Short description of what this branch is for (stored in config). "
            "Only valid with -b/--create."
        ),
    )
    parser.add_argument(
        "--resumable", action="store_true", default=False,
        help=(
            "Mark the new branch as a resumable agent checkpoint (discoverable "
            "via ``muse branch --resumable``). Only valid with -b/--create."
        ),
    )
    parser.set_defaults(func=run, merge=False, autoshelf=False)

def run(args: argparse.Namespace) -> None:
    """Switch branches or restore working tree from a commit.

    Without ``-b`` switches to an existing branch; with ``-b`` creates and
    switches atomically.  Use ``--intent`` and ``--resumable`` to annotate the
    new branch for agent handoff discovery.  Use ``--ours`` / ``--theirs`` to
    resolve merge conflicts.  ``--dry-run`` exits 0 if the switch would succeed.

    Agent quickstart
    ----------------
    ::

        muse checkout dev --json
        muse checkout -b task/my-thing --intent "implement X" --resumable --json
        muse checkout --ours src/billing.py --json

    JSON fields
    -----------
    action       What happened: ``"created"``, ``"switched"``, ``"detached"``,
                 ``"already_on"``, or ``"restored"``.
    branch       Branch name switched to; ``null`` for detached HEAD.
    commit_id    Full ``sha256:…`` commit ID at the tip of the target branch.
    from_branch  Branch name before the switch.
    dry_run      ``true`` when ``--dry-run`` was passed.

    Exit codes
    ----------
    0  Success (or ``--dry-run`` would succeed).
    1  Invalid branch name, branch not found, or dirty working tree.
    3  Internal error (missing snapshot or object).
    """
    elapsed = start_timer()
    target: str | None = args.target
    create: bool = args.create
    force: bool = args.force
    dry_run: bool = args.dry_run
    merge: bool = getattr(args, "merge", False)
    autoshelf: bool = getattr(args, "autoshelf", False)
    json_out: bool = args.json_out
    resolve_ours: bool = args.resolve_ours
    resolve_theirs: bool = args.resolve_theirs
    resolve_all: bool = args.resolve_all
    intent: str | None = args.intent
    resumable: bool = args.resumable

    if autoshelf and force:
        print("❌ --autoshelf and --force are mutually exclusive.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    if autoshelf and merge:
        print("❌ --autoshelf and --merge are mutually exclusive.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    if (intent is not None or resumable) and not create:
        print(
            "❌ --intent and --resumable are only valid with -b/--create.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    # ── Conflict resolution mode ──────────────────────────────────────────────
    if resolve_ours or resolve_theirs:
        if resolve_ours and resolve_theirs:
            print("❌ Cannot specify both --ours and --theirs.", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

        if not resolve_all and not target:
            print(
                "❌ Specify a file path, or use --all to resolve every conflict.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)

        root = require_repo()
        merge_state = read_merge_state(root)
        if merge_state is None:
            print(
                "❌ No merge in progress. --ours/--theirs only work during a conflicted merge.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)

        side_label = "ours" if resolve_ours else "theirs"
        source_commit_id = merge_state.ours_commit if resolve_ours else merge_state.theirs_commit
        if not source_commit_id:
            print(f"❌ MERGE_STATE has no {side_label} commit recorded.", file=sys.stderr)
            raise SystemExit(ExitCode.INTERNAL_ERROR)

        source_commit = read_commit(root, source_commit_id)
        if source_commit is None:
            print(
                f"❌ Source commit {source_commit_id} not found in object store.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.INTERNAL_ERROR)

        snap = read_snapshot(root, source_commit.snapshot_id)
        if snap is None:
            print(
                f"❌ Snapshot for commit {source_commit_id} not found.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.INTERNAL_ERROR)

        # ── Determine which conflict paths to resolve ─────────────────────
        if resolve_all:
            paths_to_resolve = list(merge_state.conflict_paths)
            if not paths_to_resolve:
                if json_out:
                    print(json.dumps(_CheckoutJson(**make_envelope(elapsed), action="conflict_resolved_all", side=side_label, resolved_count=0, remaining_conflicts=0)))
                else:
                    print("✅ No conflicts to resolve — working tree is already clean.")
                return
        else:
            file_path = (target or "").replace("\\", "/")
            matching = [
                p for p in merge_state.conflict_paths
                if p == file_path or p.startswith(f"{file_path}::")
            ]
            if not matching:
                print(
                    f"ℹ️  '{sanitize_display(file_path)}' is not in the conflict list "
                    f"— may already be resolved."
                )
                return
            paths_to_resolve = matching

        # ── Apply resolutions ─────────────────────────────────────────────
        resolved: list[str] = []
        for conflict_path in paths_to_resolve:
            # Extract the bare file path (strip symbol qualifier if present).
            bare_file = conflict_path.split("::")[0] if "::" in conflict_path else conflict_path

            if bare_file in snap.manifest:
                object_id = snap.manifest[bare_file]
                try:
                    safe_dest = contain_path(root, bare_file)
                except ValueError as exc:
                    print(
                        f"❌ Unsafe path '{sanitize_display(bare_file)}': {exc}",
                        file=sys.stderr,
                    )
                    continue
                if not restore_object(root, object_id, safe_dest):
                    print(
                        f"❌ Object {object_id} for '{sanitize_display(bare_file)}' "
                        f"not in local store.",
                        file=sys.stderr,
                    )
                    continue
            else:
                # File doesn't exist on the chosen side — delete it.
                target_path = root / bare_file
                if target_path.exists():
                    target_path.unlink()

            resolved.append(conflict_path)

        # ── Update MERGE_STATE ────────────────────────────────────────────
        remaining = [p for p in merge_state.conflict_paths if p not in resolved]
        write_merge_state(
            root,
            base_commit=merge_state.base_commit or "",
            ours_commit=merge_state.ours_commit or "",
            theirs_commit=merge_state.theirs_commit or "",
            conflict_paths=remaining,
            other_branch=merge_state.other_branch,
        )

        if resolve_all:
            if json_out:
                print(json.dumps(_CheckoutJson(**make_envelope(elapsed), action="conflict_resolved_all", side=side_label, resolved_count=len(resolved), remaining_conflicts=len(remaining))))
            else:
                print(f"✅ Resolved {len(resolved)} conflict(s) using {side_label}.")
                if remaining:
                    print(
                        f"   {len(remaining)} could not be resolved automatically "
                        f"— run 'muse conflicts' to inspect."
                    )
                else:
                    print("   All conflicts resolved. Run 'muse commit' to complete the merge.")
        else:
            file_path = (target or "").replace("\\", "/")
            if json_out:
                print(json.dumps(_CheckoutJson(**make_envelope(elapsed), action="conflict_resolved", file=file_path, side=side_label, remaining_conflicts=len(remaining))))
            else:
                print(f"✅ Resolved '{sanitize_display(file_path)}' using {side_label}.")
                if remaining:
                    print(
                        f"   {len(remaining)} conflict(s) remaining — "
                        f"run 'muse conflicts' to see them."
                    )
                else:
                    print("   All conflicts resolved. Run 'muse commit' to complete the merge.")
        return
    # ── End conflict resolution mode ─────────────────────────────────────────

    if target is None:
        print(
            "❌ Specify a branch, commit ID, or use --ours/--theirs with a file path.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()
    _head_state = read_head(root)
    current_branch: str | None = (
        _head_state["branch"] if _head_state["kind"] == "branch" else None
    )
    muse_dir = _muse_dir(root)

    # ── --merge: carry uncommitted changes via the Cohen Transform ────────────
    # Bypass the clean-workdir guard and instead three-way merge each dirty
    # file into the target branch context.  Only valid for branch switches
    # (not -b/--create, not detached-HEAD checkouts).
    if merge and not create and target is not None:
        if current_branch is None:
            print(
                "❌ --merge requires an active branch. "
                "Run 'muse checkout <branch>' to leave detached HEAD first.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)

        try:
            validate_branch_name(target)
        except ValueError as exc:
            print(
                f"❌ Invalid branch name: {sanitize_display(str(exc))}",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)

        ref_file = _ref_path(root, target)
        if not ref_file.exists():
            print(
                f"❌ Branch '{sanitize_display(target)}' not found. "
                f"--merge only works with existing branches.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)

        if target == current_branch:
            print(f"Already on '{sanitize_display(target)}'")
            return

        result = _checkout_with_merge(
            root, target, current_branch,
            json_out=json_out, dry_run=dry_run,
        )

        conflicts: list[str] = result.get("conflicts", [])  # type: ignore[assignment]
        clean_merges: list[str] = result.get("clean_merges", [])  # type: ignore[assignment]

        if json_out:
            print(json.dumps(_CheckoutJson(**make_envelope(elapsed), **result)))
        else:
            if dry_run:
                print(f"Would switch to branch '{sanitize_display(target)}' carrying changes")
            else:
                print(f"Switched to branch '{sanitize_display(target)}'")
            if clean_merges:
                print(f"  Merged cleanly: {len(clean_merges)} file(s)")
                for p in clean_merges:
                    print(f"    ✔ {sanitize_display(p)}")
            if conflicts:
                print(f"  Conflicts: {len(conflicts)} file(s)", file=sys.stderr)
                for p in conflicts:
                    print(f"    CONFLICT (both modified): {sanitize_display(p)}", file=sys.stderr)
                print(
                    "\nFix conflicts then run 'muse commit' to complete.\n"
                    "Run 'muse diff --conflict' to see what each side changed.",
                    file=sys.stderr,
                )
                raise SystemExit(ExitCode.USER_ERROR)
        return
    # ── End --merge mode ──────────────────────────────────────────────────────

    # ── Main checkout flow ────────────────────────────────────────────────────
    # try/finally ensures the autoshelf is always popped — whether the switch
    # succeeds, fails validation, or raises SystemExit — so the user's work is
    # never stranded on the shelf.
    autoshelf_entry = None
    try:
        # Detect commit-ID targets early so we can skip branch-specific logic.
        # A commit ref has a sha256: prefix or is 7–64 lowercase hex chars.
        # These targets reach resolve_commit_ref (detach path) and must not
        # be passed to get_head_snapshot_id / validate_branch_name as a branch.
        _is_commit_ref = target is not None and bool(
            target.startswith("sha256:")
            or re.fullmatch(r"[0-9a-f]{7,64}", target)
        )

        # Creating a new branch starts at the current HEAD — no files change,
        # so dirty tracked files cannot be overwritten.  The guard only fires
        # when switching to an *existing* branch whose snapshot differs.
        if not create:
            if autoshelf and not dry_run:
                # The push makes the tree clean so the switch proceeds;
                # the finally block pops unconditionally after.
                autoshelf_entry = _shelf_push_programmatic(
                    root,
                    name=f"_auto/{sanitize_display(current_branch or 'HEAD')}",
                    intent_type="interrupt",
                    intent=f"autoshelf before checkout to {sanitize_display(target or '')}",
                    created_by="muse",
                )
                if autoshelf_entry is not None and not json_out:
                    print("Shelving local changes before checkout…")
            elif not autoshelf and not dry_run:
                # Normal path: block only on files the target would actually
                # overwrite.  If target is an existing branch, load its manifest
                # so the guard can carry non-conflicting changes through.
                # Skip the snapshot lookup when target is a commit ref — detach
                # checkouts don't have a branch manifest to compare against.
                _target_manifest: dict[str, str] | None = None
                if target and not merge and not _is_commit_ref:
                    _target_snap_id = get_head_snapshot_id(root, target)
                    if _target_snap_id:
                        _target_snap = read_snapshot(root, _target_snap_id)
                        if _target_snap:
                            _target_manifest = dict(_target_snap.manifest)
                require_clean_workdir(
                    root, "checkout", force=force, target_manifest=_target_manifest, json_out=json_out
                )
            # autoshelf + dry_run, or plain dry_run: skip dirty check — a
            # dry-run is read-only and assumes the switch would succeed.

        if current_branch is None:
            _det_commit = read_commit(root, _head_state["commit_id"])
            current_snapshot_id = _det_commit.snapshot_id if _det_commit else None
        else:
            current_snapshot_id = get_head_snapshot_id(root, current_branch)

        if create:
            try:
                validate_branch_name(target)
            except ValueError as exc:
                print(
                    f"❌ Invalid branch name: {sanitize_display(str(exc))}",
                    file=sys.stderr,
                )
                raise SystemExit(ExitCode.USER_ERROR)
            ref_file = _ref_path(root, target)

            if ref_file.exists():
                print(
                    f"❌ Branch '{sanitize_display(target)}' already exists. "
                    f"Use 'muse checkout {sanitize_display(target)}' to switch to it.",
                    file=sys.stderr,
                )
                raise SystemExit(ExitCode.USER_ERROR)

            _cur_commit_for_create = (
                get_head_commit_id(root, current_branch)
                if current_branch is not None
                else _head_state["commit_id"]
            ) or ""
            if dry_run:
                if json_out:
                    print(json.dumps(_CheckoutJson(**make_envelope(elapsed), dry_run=True, action="created", branch=target, from_branch=current_branch, commit_id=_cur_commit_for_create)))
                else:
                    print(f"Would create and switch to branch '{sanitize_display(target)}'")
                return

            current_commit = _cur_commit_for_create
            if current_commit:
                write_branch_ref(root, target, current_commit)
            else:
                write_text_atomic(ref_file, "")
            write_head_branch(root, target)
            append_reflog(
                root, target, old_id=None, new_id=current_commit or NULL_COMMIT_ID,
                author="user",
                operation=f"branch: created from {sanitize_display(current_branch or 'HEAD')}",
            )
            if intent is not None or resumable:
                write_branch_meta(
                    root, target,
                    intent=intent,
                    resumable=resumable if resumable else None,
                )
            if json_out:
                print(json.dumps(_CheckoutJson(**make_envelope(elapsed), dry_run=False, action="created", branch=target, from_branch=current_branch, commit_id=current_commit)))
            else:
                print(f"Switched to a new branch '{sanitize_display(target)}'")
            return

        if not _is_commit_ref:
            try:
                validate_branch_name(target)
            except ValueError as exc:
                print(
                    f"❌ Invalid branch name: {sanitize_display(str(exc))}",
                    file=sys.stderr,
                )
                raise SystemExit(ExitCode.USER_ERROR)

        ref_file = _ref_path(root, target)
        if ref_file.exists():
            if target == current_branch:
                if force and current_snapshot_id:
                    # --force on the current branch restores the working tree
                    # to HEAD, overwriting modified/deleted tracked files.
                    # Pass None as current_snapshot_id so _checkout_snapshot
                    # diffs empty→HEAD, producing insert ops for every tracked
                    # file.  restore_object skips files already correct.
                    if not dry_run:
                        _checkout_snapshot(root, current_snapshot_id, None, target_branch=target)
                    if json_out:
                        print(json.dumps(_CheckoutJson(**make_envelope(elapsed), dry_run=dry_run, action="restored", branch=target, from_branch=current_branch, commit_id=current_snapshot_id)))
                    else:
                        if dry_run:
                            print(f"Would restore working tree to HEAD of '{sanitize_display(target)}'")
                        else:
                            print(f"HEAD of '{sanitize_display(target)}' restored to working tree")
                    return
                if json_out:
                    print(json.dumps(_CheckoutJson(**make_envelope(elapsed), dry_run=dry_run, action="already_on", branch=target, from_branch=current_branch, commit_id=get_head_commit_id(root, target) or "")))
                else:
                    print(f"Already on '{sanitize_display(target)}'")
                return

            target_commit_id = get_head_commit_id(root, target) or ""
            current_commit_id = (
                get_head_commit_id(root, current_branch)
                if current_branch is not None
                else _head_state["commit_id"]
            ) or ""

            if dry_run:
                if json_out:
                    print(json.dumps(_CheckoutJson(**make_envelope(elapsed), dry_run=True, action="switched", branch=target, from_branch=current_branch, commit_id=target_commit_id)))
                else:
                    print(f"Would switch to branch '{sanitize_display(target)}'")
                return

            target_snapshot_id = get_head_snapshot_id(root, target)
            if target_snapshot_id:
                # --force: restore ALL target files (diff from empty → target),
                # discarding any local modifications to tracked files.
                # Normal switch: incremental delta from current → target.
                from_snapshot_id = None if force else current_snapshot_id
                _checkout_snapshot(
                    root, target_snapshot_id, from_snapshot_id,
                    target_branch=target,
                    clear_marker=False,
                )

            write_head_branch(root, target)
            checkout_head_path(root).unlink(missing_ok=True)
            append_reflog(
                root, target, old_id=current_commit_id or None, new_id=target_commit_id or NULL_COMMIT_ID,
                author="user",
                operation=(
                    f"checkout: moving from {sanitize_display(current_branch or 'HEAD')} "
                    f"to {sanitize_display(target)}"
                ),
            )
            if json_out:
                print(json.dumps(_CheckoutJson(**make_envelope(elapsed), dry_run=False, action="switched", branch=target, from_branch=current_branch, commit_id=target_commit_id)))
            else:
                print(f"Switched to branch '{sanitize_display(target)}'")
            return

        # For commit refs, resolve_commit_ref only uses `branch` when resolving
        # HEAD or HEAD~N — for sha256:/hex targets, the branch param is unused.
        commit = resolve_commit_ref(root, current_branch or "", target)
        if commit is None:
            print(
                f"❌ '{sanitize_display(target)}' is not a branch or commit ID.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)

        current_commit_id = (
            get_head_commit_id(root, current_branch)
            if current_branch is not None
            else _head_state["commit_id"]
        ) or ""

        if dry_run:
            if json_out:
                print(json.dumps(_CheckoutJson(**make_envelope(elapsed), dry_run=True, action="detached", branch=None, from_branch=current_branch, commit_id=commit.commit_id)))
            else:
                print(
                    f"Would detach HEAD at {commit.commit_id} "
                    f"{sanitize_display(commit.message or '')}"
                )
            return

        _checkout_snapshot(root, commit.snapshot_id, current_snapshot_id, clear_marker=False)
        write_head_commit(root, commit.commit_id)
        checkout_head_path(root).unlink(missing_ok=True)
        if current_branch is not None:
            append_reflog(
                root, current_branch, old_id=current_commit_id or None, new_id=commit.commit_id,
                author="user",
                operation=f"checkout: detaching HEAD at {commit.commit_id}",
            )
        if json_out:
            print(json.dumps(_CheckoutJson(**make_envelope(elapsed), dry_run=False, action="detached", branch=None, from_branch=current_branch, commit_id=commit.commit_id)))
        else:
            print(f"HEAD is now at {commit.commit_id} {sanitize_display(commit.message or '')}")

    finally:
        # ── Autoshelf pop ─────────────────────────────────────────────────────
        # Runs on every exit path — success, validation error, SystemExit —
        # so the user's work is never stranded on the shelf.
        if autoshelf_entry is not None:
            _apply_autoshelf(root, json_out)
