"""``muse pull`` — fetch from a remote and merge into the current branch.

Combines ``muse fetch`` and ``muse merge`` in a single command:

1. Downloads commits, snapshots, and blobs from the remote.
2. Updates the remote-tracking pointer.
3. Performs a three-way merge of the remote branch HEAD into the current branch.

If the remote branch is already an ancestor of the local HEAD (fast-forward),
the local branch ref and working tree are advanced without a merge commit.

Pass ``--no-merge`` to stop after the fetch step (equivalent to ``muse fetch``).
Pass ``--ff-only`` to refuse the pull if a fast-forward is not possible.
Pass ``--dry-run`` / ``-n`` to preview what would change without touching the
working tree or writing any commits.

JSON output (``--format json`` / ``--json``) schema::

    {
      "status":           "up_to_date | fast_forward | merged | conflict | fetched | dry_run",
      "remote":           "<name>",
      "branch":           "<remote_branch>",
      "local_branch":     "<local_branch>",
      "commits_received": <N>,
      "blobs_written":    <N>,
      "head":             "<sha256> | null",
      "conflict_paths":   ["<path>", ...],
      "dry_run":          false
    }

Exit codes::

    0 — success (up_to_date, fast_forward, merged, fetched, or dry_run)
    1 — remote not configured, branch not found, fetch failed, ff-only refused,
        authentication failure, format error
    2 — merge conflict (requires manual resolution)
"""

import argparse
import datetime
import json
import logging
import pathlib
import sys
import time
from typing import TypedDict

from muse.cli.config import get_signing_identity, get_remote, get_remote_head, get_upstream, set_remote_head
from muse.core.version_tags import (
    VersionTagRecord,
    write_version_tag,
    read_version_tag,
)
from muse.core.semver import parse_semver
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.merge_engine import find_merge_base, write_merge_state
from muse.core.types import Manifest
from muse.core.mpack import apply_mpack
from muse.core.repo import require_repo
from muse.core.timing import start_timer
from muse.core.ids import hash_commit, hash_snapshot
from muse.core.snapshot import directories_from_manifest
from muse.core.reflog import append_reflog
from muse.core.refs import (
    RefConflictError,
    get_head_commit_id,
    read_current_branch,
    write_branch_ref,
)
from muse.core.commits import (
    CommitRecord,
    get_all_commits,
    read_commit,
    write_commit,
)
from muse.core.snapshots import (
    SnapshotRecord,
    get_commit_snapshot_manifest,
    get_head_snapshot_manifest,
    read_snapshot,
    write_snapshot,
)
from muse.core.transport import (
    TransportError,
    make_transport,
)
from muse.core.workdir import apply_manifest
from muse.domain import AddressedMergePlugin, SnapshotManifest
from muse.plugins.registry import read_domain, resolve_plugin
from muse.core.validation import sanitize_display
from muse.core.merge_debug import merge_debug_log, merge_debug_manifest_summary

logger = logging.getLogger(__name__)


class _PullJson(EnvelopeJson):
    """Stable JSON schema emitted by ``muse pull --json``."""

    status: str            # up_to_date | fast_forward | merged | conflict | fetched | dry_run
    remote: str
    branch: str            # remote branch pulled from
    local_branch: str
    commits_received: int
    blobs_written: int
    head: str | None       # new local HEAD after the pull, null on conflict/dry_run
    conflict_paths: list[str]
    dry_run: bool


class _PullErrorJson(EnvelopeJson):
    """JSON output for pull fetch-failed error paths."""

    error: str       # "fetch_failed"
    remote: str
    message: str
    retryable: bool  # True when error is a 503 that exhausted the retry budget

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse pull`` subcommand and all its flags."""
    parser = subparsers.add_parser(
        "pull",
        help="Fetch from a remote and merge into the current branch.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "remote", nargs="?", default="origin",
        help="Remote name to pull from (default: origin).",
    )
    parser.add_argument(
        "branch_pos", nargs="?", default=None, metavar="BRANCH",
        help="Remote branch to pull (default: tracked branch or current branch). Same as --branch.",
    )
    parser.add_argument(
        "--branch", "-b", default=None, dest="branch_flag",
        help="Remote branch to pull (default: tracked branch or current branch).",
    )
    parser.add_argument(
        "--no-merge", action="store_true", dest="no_merge",
        help="Only fetch; do not merge into the current branch.",
    )
    parser.add_argument(
        "--ff-only", action="store_true", dest="ff_only",
        help="Refuse to pull if a fast-forward merge is not possible.",
    )
    parser.add_argument(
        "-n", "--dry-run", action="store_true",
        help="Preview what would change without modifying the working tree or writing commits.",
    )
    parser.add_argument(
        "-m", "--message", default=None,
        help="Override the merge commit message.",
    )
    parser.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit machine-readable JSON instead of human text.",
    )
    parser.add_argument(
        "--retry-timeout",
        type=float,
        default=None,
        dest="retry_budget_s",
        metavar="SECONDS",
        help=(
            "Maximum seconds to wait for the remote to finish preparing fetch data "
            "(503 Retry-After loop). Default: 120 s or MUSE_FETCH_RETRY_BUDGET_S env."
        ),
    )
    parser.add_argument(
        "--no-retry",
        action="store_const",
        const=0.0,
        dest="retry_budget_s",
        help=(
            "Disable the 503 retry loop — fail immediately on the first 503 response. "
            "Useful for deterministic CI. Overrides --retry-timeout."
        ),
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Fetch from a remote and merge into the current branch.

    All progress and error messages go to **stderr**.  ``--format json``
    (or ``--json``) emits a single JSON object on stdout for agent pipelines.

    ``--dry-run`` contacts the remote to discover the current HEAD but does
    not fetch objects, apply manifests, or write any commits.  The JSON output
    shows exactly what *would* happen (``status``, ``commits_received``
    estimate, ``conflict_paths`` if a three-way merge would be needed).

    ``--ff-only`` exits with code 1 if the remote HEAD is not a descendant of
    the local HEAD, preventing silent three-way merge commits.

    JSON schema::

        {
          "status":           "up_to_date | fast_forward | merged | conflict | fetched | dry_run",
          "remote":           "<remote_name>",
          "branch":           "<remote_branch>",
          "local_branch":     "<local_branch>",
          "commits_received": <N>,
          "blobs_written":    <N>,
          "head":             "<sha256> | null",
          "conflict_paths":   ["<path>", ...],
          "dry_run":          false
        }

    Exit codes::

        0 — success
        1 — configuration, network, or ff-only refusal error
        2 — merge conflict (resolve, then ``muse commit``)
    """
    elapsed = start_timer()
    remote: str = args.remote
    branch: str | None = (
        getattr(args, "branch_flag", None) or getattr(args, "branch_pos", None)
    )
    no_merge: bool = args.no_merge
    ff_only: bool = getattr(args, "ff_only", False)
    dry_run: bool = getattr(args, "dry_run", False)
    message: str | None = args.message
    json_out: bool = args.json_out
    retry_budget_s: float | None = getattr(args, "retry_budget_s", None)

    root = require_repo()

    url = get_remote(remote, root)
    if url is None:
        if json_out:
            print(json.dumps({
                "error": "remote_not_configured",
                "remote": remote,
                "message": f"remote '{remote}' is not configured",
                "hint": f"muse remote add {remote} <url>",
            }))
        print(
            f"❌ Remote '{sanitize_display(remote)}' is not configured.\n"
            f"  Add it with: muse remote add {sanitize_display(remote)} <url>",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    signing = get_signing_identity(root, remote_url=url)
    current_branch = read_current_branch(root)
    target_branch = branch or get_upstream(current_branch, root) or current_branch

    transport = make_transport(url)

    # ── Phase 0: discover remote HEAD ────────────────────────────────────────
    try:
        info = transport.fetch_remote_info(url, signing)
    except TransportError as exc:
        if json_out:
            print(json.dumps({
                "error": "remote_unreachable",
                "remote": remote,
                "message": str(exc),
            }))
        print(
            f"❌ Cannot reach remote '{sanitize_display(remote)}': "
            f"{sanitize_display(str(exc))}",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    remote_commit_id = info["branch_heads"].get(target_branch)
    if remote_commit_id is None:
        if json_out:
            print(json.dumps({
                "error": "branch_not_found",
                "remote": remote,
                "branch": target_branch,
                "available": sorted(info["branch_heads"]),
                "message": f"branch '{target_branch}' does not exist on remote '{remote}'",
            }))
        print(
            f"❌ Branch '{sanitize_display(target_branch)}' does not exist "
            f"on remote '{sanitize_display(remote)}'.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    # ── Phase 1: fetch ────────────────────────────────────────────────────────
    commits_received: int = 0
    blobs_written: int = 0

    already_known = get_remote_head(remote, target_branch, root)
    if already_known == remote_commit_id:
        # We have everything for this commit — skip network fetch entirely.
        if not json_out:
            print(
                f"✅ Fetched 0 commit(s), 0 new blob(s) from "
                f"{sanitize_display(remote)}/{sanitize_display(target_branch)} "
                f"({remote_commit_id})"
            )
    else:
        print(
            f"Fetching {sanitize_display(remote)}/{sanitize_display(target_branch)} …",
            file=sys.stderr,
        )

        if dry_run:
            if json_out:
                print(json.dumps(_PullJson(
                    **make_envelope(elapsed),
                    status="dry_run",
                    remote=remote,
                    branch=target_branch,
                    local_branch=current_branch,
                    commits_received=0,
                    blobs_written=0,
                    head=None,
                    conflict_paths=[],
                    dry_run=True,
                )))
            else:
                print(
                    f"Would fetch {sanitize_display(remote)}/{sanitize_display(target_branch)} "
                    f"→ {remote_commit_id} (dry run)"
                )
            return

        # Build have-list from full local history.
        have_for_fetch = [c.commit_id for c in get_all_commits(root)]

        t0_fetch = time.perf_counter()
        try:
            fetch_result = transport.fetch_mpack(
                url, signing,
                want=[remote_commit_id],
                have=have_for_fetch,
                retry_budget_s=retry_budget_s,
            )
        except TransportError as exc:
            _is_503 = exc.status_code == 503
            if _is_503:
                from muse.core.transport import _resolve_retry_budget
                _budget = _resolve_retry_budget(retry_budget_s)
                _msg = f"Remote still preparing fetch data after {int(_budget)}s — try again shortly."
            else:
                _msg = str(exc)
            if json_out:
                print(json.dumps(_PullErrorJson(
                    **make_envelope(elapsed, exit_code=ExitCode.INTERNAL_ERROR),
                    error="fetch_failed",
                    remote=remote,
                    message=_msg,
                    retryable=_is_503,
                )))
            print(f"❌ {sanitize_display(_msg)}", file=sys.stderr)
            raise SystemExit(ExitCode.INTERNAL_ERROR)
        t_fetch = time.perf_counter() - t0_fetch

        apply_result = apply_mpack(root, {
            "commits":   fetch_result["commits"],
            "snapshots": fetch_result["snapshots"],
            "blobs":     fetch_result.get("blobs") or [],
        })
        commits_received = apply_result["commits_written"]
        blobs_written = apply_result["blobs_written"]

        if not (apply_result.get("failed_blobs") or []):
            set_remote_head(remote, target_branch, remote_commit_id, root)

        print(
            f"[mpack] fetch/mpack: {t_fetch:.2f}s  "
            f"blobs: {fetch_result['blobs_received']}  "
            f"commits: {commits_received}",
            file=sys.stderr,
        )

        # Fetch version tags from remote and store locally (best-effort).
        try:
            vtag_result = transport.fetch_version_tags(url, signing)
            for tag_dict in (vtag_result.get("tags") or []):
                tag_name = tag_dict.get("tag", "")
                tag_id = tag_dict.get("tag_id", "")
                repo_id_val = tag_dict.get("repo_id", "")
                commit_id_val = tag_dict.get("commit_id", "")
                created_at_str = tag_dict.get("created_at", "")
                author_val = tag_dict.get("author", "")
                message_val = tag_dict.get("message", "")
                semver_raw = tag_dict.get("semver") or {}
                if not tag_name:
                    continue
                try:
                    semver = parse_semver(tag_name)
                except Exception:
                    try:
                        semver = {
                            "major": int(semver_raw.get("major", 0)),
                            "minor": int(semver_raw.get("minor", 0)),
                            "patch": int(semver_raw.get("patch", 0)),
                            "pre": str(semver_raw.get("pre", "")),
                            "build": str(semver_raw.get("build", "")),
                        }
                    except Exception:
                        continue
                try:
                    created_at = datetime.datetime.fromisoformat(created_at_str)
                except Exception:
                    created_at = datetime.datetime.now(datetime.timezone.utc)
                record = VersionTagRecord(
                    tag_id=tag_id,
                    repo_id=repo_id_val,
                    tag=tag_name,
                    semver=semver,
                    commit_id=commit_id_val,
                    created_at=created_at,
                    author=author_val,
                    message=message_val,
                )
                write_version_tag(root, record)
        except Exception as _vtag_exc:
            logger.debug("version-tag fetch failed (non-fatal): %s", _vtag_exc)

        if not json_out:
            print(
                f"✅ Fetched {commits_received} commit(s), {blobs_written} new blob(s) "
                f"from {sanitize_display(remote)}/{sanitize_display(target_branch)} "
                f"({remote_commit_id})"
            )

    if no_merge:
        if json_out:
            print(json.dumps(_PullJson(
                **make_envelope(elapsed),
                status="fetched",
                remote=remote,
                branch=target_branch,
                local_branch=current_branch,
                commits_received=commits_received,
                blobs_written=blobs_written,
                head=remote_commit_id,
                conflict_paths=[],
                dry_run=dry_run,
            )))
        return

    # ── Phase 3: merge ────────────────────────────────────────────────────────
    ours_commit_id = get_head_commit_id(root, current_branch)
    theirs_commit_id = remote_commit_id

    if ours_commit_id is None:
        # No local commits yet — bootstrap: advance HEAD to the remote commit.
        # Apply the manifest BEFORE writing the branch ref so a crash between
        # the two leaves the ref consistent with the working tree.
        if not dry_run:
            theirs_commit = read_commit(root, theirs_commit_id)
            if not theirs_commit:
                print(
                    f"❌ Pull aborted: commit {theirs_commit_id} was fetched but "
                    "is not readable from the local store (corrupt or hash mismatch). "
                    "Run `muse verify-pack` to audit the store.",
                    file=sys.stderr,
                )
                raise SystemExit(ExitCode.INTERNAL_ERROR)
            snap = read_snapshot(root, theirs_commit.snapshot_id)
            if snap is None:
                print(
                    f"❌ Pull aborted: snapshot {theirs_commit.snapshot_id} "
                    f"referenced by commit {theirs_commit_id} is missing or corrupt. "
                    "Run `muse verify-pack` to audit the store.",
                    file=sys.stderr,
                )
                raise SystemExit(ExitCode.INTERNAL_ERROR)
            
            apply_manifest(root, {}, snap.manifest)
            try:
                write_branch_ref(root, current_branch, theirs_commit_id, expected_id=ours_commit_id)
            except RefConflictError as exc:
                print(f"❌ {exc}", file=sys.stderr)
                raise SystemExit(ExitCode.USER_ERROR)
            try:
                append_reflog(
                    root, current_branch,
                    old_id=ours_commit_id,
                    new_id=theirs_commit_id,
                    author="user",
                    operation=f"pull: fetched {remote}/{target_branch}",
                )
            except Exception as _rl_exc:
                logger.warning("⚠️ reflog: failed to record pull: %s", _rl_exc)
        if json_out:
            print(json.dumps(_PullJson(
                **make_envelope(elapsed),
                status="fast_forward",
                remote=remote,
                branch=target_branch,
                local_branch=current_branch,
                commits_received=commits_received,
                blobs_written=blobs_written,
                head=None if dry_run else theirs_commit_id,
                conflict_paths=[],
                dry_run=dry_run,
            )))
        else:
            suffix = " (dry run)" if dry_run else ""
            print(
                f"✅ Initialised {sanitize_display(current_branch)} "
                f"at {theirs_commit_id}{suffix}"
            )
        return

    if ours_commit_id == theirs_commit_id:
        if json_out:
            print(json.dumps(_PullJson(
                **make_envelope(elapsed),
                status="up_to_date",
                remote=remote,
                branch=target_branch,
                local_branch=current_branch,
                commits_received=commits_received,
                blobs_written=blobs_written,
                head=ours_commit_id,
                conflict_paths=[],
                dry_run=dry_run,
            )))
        else:
            print("Already up to date.", file=sys.stderr)
        return

    base_commit_id = find_merge_base(root, ours_commit_id, theirs_commit_id)

    if base_commit_id == theirs_commit_id:
        # Local is already ahead of remote — nothing to pull.
        if json_out:
            print(json.dumps(_PullJson(
                **make_envelope(elapsed),
                status="up_to_date",
                remote=remote,
                branch=target_branch,
                local_branch=current_branch,
                commits_received=commits_received,
                blobs_written=blobs_written,
                head=ours_commit_id,
                conflict_paths=[],
                dry_run=dry_run,
            )))
        else:
            print("Already up to date.", file=sys.stderr)
        return

    # Fast-forward: remote is a direct descendant of local HEAD.
    if base_commit_id == ours_commit_id:
        if not dry_run:
            theirs_commit = read_commit(root, theirs_commit_id)
            if not theirs_commit:
                print(
                    f"❌ Pull aborted: commit {theirs_commit_id} was fetched but "
                    "is not readable from the local store (corrupt or hash mismatch). "
                    "Run `muse verify-pack` to audit the store.",
                    file=sys.stderr,
                )
                raise SystemExit(ExitCode.INTERNAL_ERROR)
            snap = read_snapshot(root, theirs_commit.snapshot_id)
            if snap is None:
                print(
                    f"❌ Pull aborted: snapshot {theirs_commit.snapshot_id} "
                    f"referenced by commit {theirs_commit_id} is missing or corrupt. "
                    "Run `muse verify-pack` to audit the store.",
                    file=sys.stderr,
                )
                raise SystemExit(ExitCode.INTERNAL_ERROR)
            # Apply manifest BEFORE advancing the branch pointer so a
            # crash between the two leaves the ref consistent with the tree.
            
            ours_ff_manifest = get_commit_snapshot_manifest(root, ours_commit_id) or {}
            apply_manifest(root, ours_ff_manifest, snap.manifest)
            try:
                write_branch_ref(root, current_branch, theirs_commit_id, expected_id=ours_commit_id)
            except RefConflictError as exc:
                print(f"❌ {exc}", file=sys.stderr)
                raise SystemExit(ExitCode.USER_ERROR)
            try:
                append_reflog(
                    root, current_branch,
                    old_id=ours_commit_id,
                    new_id=theirs_commit_id,
                    author="user",
                    operation=f"pull: fetched {remote}/{target_branch}",
                )
            except Exception as _rl_exc:
                logger.warning("⚠️ reflog: failed to record pull: %s", _rl_exc)
        if json_out:
            print(json.dumps(_PullJson(
                **make_envelope(elapsed),
                status="fast_forward",
                remote=remote,
                branch=target_branch,
                local_branch=current_branch,
                commits_received=commits_received,
                blobs_written=blobs_written,
                head=None if dry_run else theirs_commit_id,
                conflict_paths=[],
                dry_run=dry_run,
            )))
        else:
            suffix = " (dry run)" if dry_run else ""
            print(
                f"Fast-forward {sanitize_display(current_branch)} to "
                f"{theirs_commit_id} "
                f"({sanitize_display(remote)}/{sanitize_display(target_branch)}){suffix}"
            )
        return

    # Branches have diverged — three-way merge required.
    if ff_only:
        if json_out:
            print(json.dumps({
                "error": "ff_only_refused",
                "remote": remote,
                "branch": target_branch,
                "local_branch": current_branch,
                "message": f"{remote}/{target_branch} has diverged from {current_branch} — fast-forward not possible",
                "hint": "remove --ff-only to allow a merge commit",
            }))
        print(
            f"❌ Pull aborted: {sanitize_display(remote)}/{sanitize_display(target_branch)} "
            f"has diverged from {sanitize_display(current_branch)}.\n"
            f"   Fast-forward not possible. Remove --ff-only to allow a merge commit.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    domain = read_domain(root)
    plugin = resolve_plugin(root)

    ours_manifest = get_head_snapshot_manifest(root, current_branch) or {}
    theirs_commit = read_commit(root, theirs_commit_id)
    if not theirs_commit:
        print(
            f"❌ Pull aborted: commit {theirs_commit_id} is not readable from "
            "the local store (corrupt or hash mismatch). "
            "Run `muse verify-pack` to audit the store.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.INTERNAL_ERROR)
    theirs_snap = read_snapshot(root, theirs_commit.snapshot_id)
    if theirs_snap is None:
        print(
            f"❌ Pull aborted: snapshot {theirs_commit.snapshot_id} "
            f"referenced by commit {theirs_commit_id} is missing or corrupt. "
            "A merge with a missing remote snapshot would treat all remote files "
            "as deleted. Run `muse verify-pack` to audit the store.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.INTERNAL_ERROR)
    theirs_manifest = dict(theirs_snap.manifest)

    base_manifest: Manifest = {}
    if base_commit_id:
        base_commit = read_commit(root, base_commit_id)
        if base_commit:
            base_snap = read_snapshot(root, base_commit.snapshot_id)
            if base_snap:
                base_manifest = dict(base_snap.manifest)

    base_snap_obj = SnapshotManifest(files=base_manifest, domain=domain, directories=directories_from_manifest(base_manifest))
    ours_snap_obj = SnapshotManifest(files=ours_manifest, domain=domain, directories=directories_from_manifest(ours_manifest))
    theirs_snap_obj = SnapshotManifest(files=theirs_manifest, domain=domain, directories=directories_from_manifest(theirs_manifest))

    merge_debug_log("pull.merge.enter", {
        "caller": "muse_pull",
        "current_branch": current_branch,
        "remote": remote,
        "remote_branch": target_branch,
        "base_commit_id": base_commit_id,
        "ours_commit_id": ours_commit_id,
        "theirs_commit_id": theirs_commit_id,
        "base_manifest": merge_debug_manifest_summary(base_manifest),
        "ours_manifest": merge_debug_manifest_summary(ours_manifest),
        "theirs_manifest": merge_debug_manifest_summary(theirs_manifest),
    })

    if isinstance(plugin, AddressedMergePlugin):
        ours_delta = plugin.diff(base_snap_obj, ours_snap_obj, repo_root=root)
        theirs_delta = plugin.diff(base_snap_obj, theirs_snap_obj, repo_root=root)
        merge_debug_log("pull.merge.ops", {
            "caller": "muse_pull",
            "ours_ops": ours_delta["ops"],
            "theirs_ops": theirs_delta["ops"],
        })
        result = plugin.merge_ops(
            base_snap_obj,
            ours_snap_obj,
            theirs_snap_obj,
            ours_delta["ops"],
            theirs_delta["ops"],
            repo_root=root,
        )
    else:
        result = plugin.merge(base_snap_obj, ours_snap_obj, theirs_snap_obj, repo_root=root)

    merge_debug_log("pull.merge.result", {
        "caller": "muse_pull",
        "is_clean": result.is_clean,
        "conflicts": result.conflicts,
        "applied_strategies": result.applied_strategies,
        "merged_file_count": len(result.merged["files"]),
    })

    if not json_out and result.applied_strategies:
        for p, strategy in sorted(result.applied_strategies.items()):
            if strategy != "manual":
                print(f"  ✔ [{strategy}] {p}", file=sys.stderr)

    if not result.is_clean:
        if not dry_run:
            write_merge_state(
                root,
                base_commit=base_commit_id or "",
                ours_commit=ours_commit_id,
                theirs_commit=theirs_commit_id,
                conflict_paths=result.conflicts,
                other_branch=f"{remote}/{target_branch}",
            )
        conflict_paths = sorted(result.conflicts)
        if json_out:
            print(json.dumps(_PullJson(
                **make_envelope(elapsed, exit_code=int(ExitCode.USER_ERROR)),
                status="conflict",
                remote=remote,
                branch=target_branch,
                local_branch=current_branch,
                commits_received=commits_received,
                blobs_written=blobs_written,
                head=None,
                conflict_paths=conflict_paths,
                dry_run=dry_run,
            )))
        else:
            suffix = " (dry run — no state written)" if dry_run else ""
            print(f"❌ Merge conflict in {len(conflict_paths)} file(s){suffix}:", file=sys.stderr)
            for p in conflict_paths:
                print(f"  CONFLICT (both modified): {sanitize_display(p)}", file=sys.stderr)
            if not dry_run:
                print('\nFix conflicts and run "muse commit" to complete the merge.', file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    merged_manifest = result.merged["files"]

    if dry_run:
        if json_out:
            print(json.dumps(_PullJson(
                **make_envelope(elapsed),
                status="dry_run",
                remote=remote,
                branch=target_branch,
                local_branch=current_branch,
                commits_received=commits_received,
                blobs_written=blobs_written,
                head=None,
                conflict_paths=[],
                dry_run=True,
            )))
        else:
            print(
                f"Would merge {sanitize_display(remote)}/{sanitize_display(target_branch)} "
                f"into {sanitize_display(current_branch)} (dry run)"
            )
        return

    
    apply_manifest(root, {**ours_manifest, **theirs_manifest}, merged_manifest)

    merged_dirs = directories_from_manifest(merged_manifest)
    snapshot_id = hash_snapshot(merged_manifest, merged_dirs)
    committed_at = datetime.datetime.now(datetime.timezone.utc)
    merge_message = (
        message
        or f"Merge {remote}/{target_branch} into {current_branch}"
    )
    commit_id = hash_commit(
        parent_ids=[ours_commit_id, theirs_commit_id],
        snapshot_id=snapshot_id,
        message=merge_message,
        committed_at_iso=committed_at.isoformat(),
    )
    write_snapshot(root, SnapshotRecord(snapshot_id=snapshot_id, manifest=merged_manifest, directories=merged_dirs))
    write_commit(
        root,
        CommitRecord(
            commit_id=commit_id,
            branch=current_branch,
            snapshot_id=snapshot_id,
            message=merge_message,
            committed_at=committed_at,
            parent_commit_id=ours_commit_id,
            parent2_commit_id=theirs_commit_id,
        ),
    )
    try:
        write_branch_ref(root, current_branch, commit_id, expected_id=ours_commit_id)
    except RefConflictError as exc:
        print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    try:
        append_reflog(
            root, current_branch,
            old_id=ours_commit_id,
            new_id=commit_id,
            author="user",
            operation=f"pull: merged {remote}/{target_branch}",
        )
    except Exception as _rl_exc:
        logger.warning("⚠️ reflog: failed to record pull: %s", _rl_exc)

    if json_out:
        print(json.dumps(_PullJson(
            **make_envelope(elapsed),
            status="merged",
            remote=remote,
            branch=target_branch,
            local_branch=current_branch,
            commits_received=commits_received,
            blobs_written=blobs_written,
            head=commit_id,
            conflict_paths=[],
            dry_run=False,
        )))
    else:
        print(
            f"✅ Merged {sanitize_display(remote)}/{sanitize_display(target_branch)} "
            f"into {sanitize_display(current_branch)} ({commit_id})"
        )
