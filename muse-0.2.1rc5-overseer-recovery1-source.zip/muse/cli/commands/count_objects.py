"""``muse count-objects`` — object store diagnostics.

Reports the number of loose objects in the local store, their total
on-disk size, and optional per-shard breakdown.  A fast, read-only
diagnostic that uses ``os.scandir`` (stat only — no content reads) so
it stays sub-100 ms even for stores with 100k+ objects.

Concepts
--------
**Loose objects**: individual files stored under ``.muse/objects/<shard>/<id>``.
Muse does not yet have a pack-file format, so every object is loose.

**Reachable objects**: objects referenced (directly or transitively) by
any branch tip.  For each branch, the walk follows: commit → snapshot
manifest → blob object IDs.

**Unreachable objects** (``--unreachable``): objects present in the store
but not reachable from any branch tip — candidates for ``muse prune``.

JSON schema (``--json``)::

    {
      "loose_objects":       1240,
      "loose_size_kb":       4820.0,
      "total_objects":       1240,
      "total_size_kb":       4820.0,
      "object_store_path":   ".muse/objects",
      "unreachable_objects": 0,          # only when --unreachable is given
      "shards": [                        # only when --verbose is given
        {"prefix": "ab", "count": 12, "size_kb": 48.0},
        ...
      ],
      "duration_ms": 0.003,
      "exit_code": 0
    }

``duration_ms``
    Wall-clock time from argument parsing to output.
``exit_code``
    Mirrors the process exit code: always ``0`` on success.

Exit codes::

    0 — success
    2 — not a Muse repository
    3 — I/O error

Examples::

    muse count-objects
    muse count-objects --json
    muse count-objects --verbose
    muse count-objects --unreachable
    muse count-objects --unreachable --verbose --json
"""

import argparse
import json as _json
import logging
import os
import pathlib
import sys
import time
from typing import TypedDict

from muse.core.types import long_id, split_id
from muse.core.paths import objects_dir as _objects_dir
from muse.core.errors import ExitCode
from muse.core.graph import iter_ancestors
from muse.core.object_store import iter_stored_objects, objects_dir
from muse.core.refs import iter_branch_refs
from muse.core.repo import require_repo
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.timing import start_timer
from muse.core.refs import get_head_commit_id
from muse.core.commits import read_commit
from muse.core.snapshots import read_snapshot

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# TypedDicts for structured output
# ---------------------------------------------------------------------------

class _ShardInfo(TypedDict):
    prefix: str
    count: int
    size_kb: float

class _CountObjectsJson(EnvelopeJson, total=False):
    loose_objects: int
    loose_size_kb: float
    total_objects: int
    total_size_kb: float
    object_store_path: str
    unreachable_objects: int       # only present when --unreachable is given
    shards: list[_ShardInfo]       # only present when --verbose is given

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _count_loose_objects(root: pathlib.Path) -> tuple[int, int]:
    """Count loose objects and their total on-disk size (in bytes).

    Uses ``os.scandir`` to stat each object file without reading content.
    Traverses one level of shard directories under ``.muse/objects/``.

    Args:
        root: Absolute repo root.

    Returns:
        ``(count, total_bytes)`` tuple.
    """
    total_count = 0
    total_bytes = 0

    for _, obj_file in iter_stored_objects(root):
        try:
            total_bytes += obj_file.stat().st_size
            total_count += 1
        except OSError:
            pass

    return total_count, total_bytes

def _count_by_shard(root: pathlib.Path) -> list[dict]:
    """Return per-shard breakdown of object counts and sizes.

    Args:
        root: Absolute repo root.

    Returns:
        List of ``{"prefix": str, "count": int, "size_kb": float}`` dicts,
        sorted by prefix.
    """
    shard_stats: dict[str, dict] = {}

    for oid, obj_file in iter_stored_objects(root):
        prefix = split_id(oid)[1][:2]
        entry = shard_stats.setdefault(prefix, {"count": 0, "size_b": 0})
        try:
            entry["size_b"] += obj_file.stat().st_size
            entry["count"] += 1
        except OSError:
            pass

    return [
        {"prefix": p, "count": v["count"], "size_kb": round(v["size_b"] / 1024, 2)}
        for p, v in sorted(shard_stats.items())
        if v["count"]
    ]

def _collect_reachable_ids(root: pathlib.Path) -> set[str]:
    """BFS walk from all branch tips to collect every referenced object ID.

    For each branch tip, walks:
    - commit record → commit is not stored as a blob, so not counted
    - snapshot manifest → each ``object_id`` value is a reachable blob

    Args:
        root: Absolute repo root.

    Returns:
        Set of object ID strings (SHA-256 hex) that are reachable from
        any branch tip.
    """
    reachable: set[str] = set()

    # Collect all branch tips.
    tips: list[str] = [cid for _, cid in iter_branch_refs(root)]
    if not tips:
        return reachable

    # BFS from all tips; collect commit, snapshot, and blob IDs.
    for commit in iter_ancestors(root, tips, first_parent_only=True):
        reachable.add(commit.commit_id)
        reachable.add(commit.snapshot_id)
        snap = read_snapshot(root, commit.snapshot_id)
        if snap is not None:
            reachable.update(snap.manifest.values())

    return reachable

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``muse count-objects`` subcommand."""
    parser = subparsers.add_parser(
        "count-objects",
        help="Count objects in the local store and report store size.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        dest="verbose",
        help="Show per-shard object counts and sizes.",
    )
    parser.add_argument(
        "--unreachable",
        action="store_true",
        dest="unreachable",
        help=(
            "Also count objects not reachable from any branch tip — "
            "these are candidates for 'muse prune'."
        ),
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON on stdout.",
    )
    parser.set_defaults(func=run)

# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Count objects in the local store.

    Uses stat-only traversal of the object store — no object content is read.
    Use ``--verbose`` to see a per-shard breakdown; ``--unreachable`` to count
    objects not referenced by any commit.

    Agent quickstart
    ----------------
    ::

        muse count-objects --json
        muse count-objects --verbose --json
        muse count-objects --unreachable --json

    JSON fields
    -----------
    loose_objects       Number of loose object files.
    loose_size_kb       Total size of loose objects in KiB.
    total_objects       Total object count.
    total_size_kb       Total size in KiB.
    object_store_path   Absolute path to the object store.
    unreachable_objects Count of unreachable objects (with ``--unreachable``).
    shards              Per-shard breakdown list (with ``--verbose``).

    Exit codes
    ----------
    0  Success.
    2  Not inside a Muse repository.
    3  I/O error.
    """
    elapsed = start_timer()
    verbose: bool = args.verbose
    check_unreachable: bool = args.unreachable
    json_out: bool = args.json_out

    root = require_repo()

    try:
        loose_count, loose_bytes = _count_loose_objects(root)
    except OSError as exc:
        print(f"❌ I/O error reading object store: {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.IO_ERROR)

    loose_kb = round(loose_bytes / 1024, 2)
    store_path = str(_objects_dir(root).relative_to(root))

    unreachable_count: int | None = None
    if check_unreachable:
        reachable = _collect_reachable_ids(root)
        unreachable_count = sum(
            1 for oid, _ in iter_stored_objects(root) if oid not in reachable
        )

    shards: list[_ShardInfo] | None = None
    if verbose:
        shards = _count_by_shard(root)

    if json_out:
        out = _CountObjectsJson(
            **make_envelope(elapsed),
            loose_objects=loose_count,
            loose_size_kb=loose_kb,
            total_objects=loose_count,
            total_size_kb=loose_kb,
            object_store_path=store_path,
        )
        if unreachable_count is not None:
            out["unreachable_objects"] = unreachable_count
        if shards is not None:
            out["shards"] = shards
        print(_json.dumps(out))
        return

    # ── Text output ────────────────────────────────────────────────────────
    print(f"loose objects: {loose_count}")
    print(f"loose size:    {loose_kb:.1f} KiB")
    if unreachable_count is not None:
        print(f"unreachable:   {unreachable_count}")
    if shards is not None:
        for shard in shards:
            print(f"  shard {shard['prefix']}: {shard['count']} objects, {shard['size_kb']:.1f} KiB")
