import argparse
import base64
from ._core import *

def run_proposal_list(args: argparse.Namespace) -> None:
    """List proposals on MuseHub.

    Filters by state (default: ``open``) and respects ``--limit`` (default: 20).
    Use ``--state all`` to list every proposal regardless of state.
    Use ``--verbose`` / ``-v`` to show author and creation date per proposal.

    JSON output goes to stdout; human-readable text goes to stderr.
    With ``--json`` the response is a JSON **object** with envelope fields plus
    ``proposals`` (array), ``total`` (int), and ``next_cursor`` (str|null).
    ``--verbose`` has no effect when ``--json`` is set — callers receive the
    full API response and can select any field with ``jq``.

    Agent quickstart
    ----------------
    ::

        muse hub proposal list --state open --json
        muse hub proposal list --state all -n 100 --json | jq '.proposals[].proposalId'
        muse hub proposal list --verbose

    Exit codes
    ----------
    0  Success (including empty list).
    1  Not authenticated or no hub configured.
    2  Not inside a Muse repository.
    3  API / network error.
    """
    state: str = args.state
    limit: int = clamp_int(args.limit, 1, 10000, "limit")
    json_output: bool = args.json_output
    verbose: bool = getattr(args, "verbose", False)

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=args.hub)
    repo_id = _resolve_repo_id(hub_url, identity)

    params = f"?limit={limit}"
    if state != "all":
        params += f"&state={state}"
    data = _hub_api(hub_url, identity, "GET", f"/api/repos/{repo_id}/proposals{params}")
    proposals_val = data.get("proposals", [])
    proposals: list[_ProposalEntry] = (
        [r for r in proposals_val if isinstance(r, dict)]
        if isinstance(proposals_val, list) else []
    )
    prop_total: int = int(data.get("total", len(proposals)))
    prop_next_cursor: str | None = data.get("nextCursor") or data.get("next_cursor")  # type: ignore[assignment]

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **{
            "proposals": proposals,
            "total": prop_total,
            "next_cursor": prop_next_cursor,
        }}))
        return

    if not proposals:
        print(f"  No proposals found (state={state}).", file=sys.stderr)
        return

    print(
        f"\n  Proposals — {sanitize_display(hub_url)}  ({len(proposals)} shown)",
        file=sys.stderr,
    )
    print(f"  {'─' * 60}", file=sys.stderr)
    for proposal in proposals:
        print(_format_proposal(proposal, verbose=verbose), file=sys.stderr)
    print("", file=sys.stderr)

def run_proposal_read(args: argparse.Namespace) -> None:
    """Read a single proposal by ID.

    Accepts the full ID or an 8-character prefix.  Prefix resolution fetches
    the most recent :data:`_PROPOSAL_PREFIX_RESOLVE_LIMIT` proposals — use the full ID
    on large repositories to avoid ambiguity.

    Text output (stderr) shows: state icon, title, ID, branches, author,
    creation date, and the first :data:`_MAX_PROPOSAL_BODY_LINES` lines of the body.
    When the body is truncated a hint is printed; pass ``--json`` to retrieve
    the full body.

    JSON output is the raw API response merged with the standard envelope.
    API field names follow MuseHub's camelCase convention (``proposalId``,
    ``fromBranch``, etc.).

    Agent quickstart
    ----------------
    ::

        muse hub proposal read af54753d --json | jq '.state'
        muse hub proposal read af54753d --json | jq '{state,title,author}'

    Exit codes
    ----------
    0  Proposal found and printed.
    1  Prefix not found, ambiguous, or not authenticated.
    2  Not inside a Muse repository.
    3  API / network error.
    """
    proposal_id: str = args.proposal_id
    json_output: bool = args.json_output

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=args.hub)
    repo_id = _resolve_repo_id(hub_url, identity)
    proposal_id = _resolve_proposal_id(hub_url, identity, repo_id, proposal_id)

    data = _hub_api(hub_url, identity, "GET", f"/api/repos/{repo_id}/proposals/{proposal_id}")

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    title = sanitize_display(str(data.get("title", "(no title)")))
    state = str(data.get("state", "?"))
    from_b = sanitize_display(str(data.get("fromBranch", "?")))
    to_b = sanitize_display(str(data.get("toBranch", "?")))
    full_id = sanitize_display(str(data.get("proposalId", proposal_id)))
    author = sanitize_display(str(data.get("author", "")))
    created = sanitize_display(str(data.get("createdAt", ""))[:10])
    body = str(data.get("body", ""))
    # state_icon lookup uses the raw state string as a dict key — safe; the
    # fallback "❓" handles any unexpected value.  The display string is
    # sanitized separately so ANSI-injected state values don't reach the terminal.
    state_icon = {"open": "🟢", "merged": "🟣", "closed": "⛔"}.get(state, "❓")
    state_display = sanitize_display(state)

    print(f"\n  {state_icon} [{state_display.upper()}] {title}", file=sys.stderr)
    print(f"  ID:     {full_id}", file=sys.stderr)
    print(f"  Branch: {from_b} → {to_b}", file=sys.stderr)
    if author:
        print(f"  By:     {author}  {created}", file=sys.stderr)
    if body:
        body_lines = body.strip().splitlines()
        print("  Body:", file=sys.stderr)
        for line in body_lines[:_MAX_PROPOSAL_BODY_LINES]:
            print(f"    {sanitize_display(line)}", file=sys.stderr)
        if len(body_lines) > _MAX_PROPOSAL_BODY_LINES:
            remaining = len(body_lines) - _MAX_PROPOSAL_BODY_LINES
            print(
                f"    ... ({remaining} more line{'s' if remaining != 1 else ''}"
                " — use --json to see full body)",
                file=sys.stderr,
            )
    print("", file=sys.stderr)

def run_proposal_create(args: argparse.Namespace) -> None:
    """Open a new proposal on MuseHub.

    Uses the current branch as the source if ``--from-branch`` is not given.
    Both Muse-native (``--from-branch`` / ``--to-branch``) and git-familiar
    aliases (``--head`` / ``--base``) are accepted.

    All local validation (title length, branch detection) runs before any
    network I/O, so errors are reported immediately without contacting the hub.

    Branch detection falls back to the current branch in ``.muse/HEAD``.
    When the repository is in detached HEAD state and ``--from-branch`` is
    not given, a clear error is printed and the command exits with code 1.

    Title is validated client-side: must be non-empty and no longer than
    :data:`_MAX_PROPOSAL_TITLE_LEN` characters.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub proposal create --title "feat: x" --from-branch feat/x --json
        # → {"muse_version": "...", ..., "proposalId": "...", "state": "open"}

        # Full idiomatic flow:
        PROPOSAL=$(muse hub proposal create --title "feat: x" --json)
        echo "$PROPOSAL" | jq '.proposalId'

    Exit codes
    ----------
    0  Proposal created.
    1  Title empty/too long, branch cannot be determined, or not authenticated.
    2  Not inside a Muse repository.
    3  API / network error.
    """
    title: str = args.title
    body: str = _resolve_body(args)
    to_branch: str = args.to_branch
    json_output: bool = args.json_output

    # ── Local validation first — fail fast before any network I/O ────────────

    # Client-side title validation — better UX than a raw API 400.
    if not title.strip():
        print("❌ Proposal title must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    if len(title) > _MAX_PROPOSAL_TITLE_LEN:
        print(
            f"❌ Proposal title is too long ({len(title)} chars); "
            f"maximum is {_MAX_PROPOSAL_TITLE_LEN}.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    # Resolve source branch before making any network calls so that a
    # detached-HEAD error or missing branch is caught locally and quickly.
    from_branch: str = args.from_branch or ""
    if not from_branch:
        ctx = find_repo_root()
        if ctx is not None:
            try:
                from_branch = read_current_branch(ctx)
            except ValueError as exc:
                # Detached HEAD — read_current_branch raises ValueError.
                print(f"❌ {exc}", file=sys.stderr)
                print(
                    "   Use --from-branch to specify the source branch explicitly.",
                    file=sys.stderr,
                )
                raise SystemExit(ExitCode.USER_ERROR) from exc
    if not from_branch:
        print(
            "❌ Could not determine current branch. Use --from-branch.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    # ── Network calls ─────────────────────────────────────────────────────────

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=args.hub)
    repo_id = _resolve_repo_id(hub_url, identity)

    payload: _HubPayload = {
        "title": title,
        "body": body,
        "fromBranch": from_branch,
        "toBranch": to_branch,
    }
    data = _hub_api(
        hub_url, identity, "POST",
        f"/api/repos/{repo_id}/proposals",
        body=payload,
    )

    raw_proposal_id = str(data.get("proposalId", ""))
    if raw_proposal_id.startswith("sha256:"):
        proposal_id_b64 = base64.urlsafe_b64encode(bytes.fromhex(raw_proposal_id[7:])).rstrip(b"=").decode()
    else:
        proposal_id_b64 = ""
    parsed = urllib.parse.urlparse(hub_url)
    parts = parsed.path.strip("/").split("/")
    if len(parts) >= 2:
        owner, slug = parts[0], parts[1]
        server_root = f"{parsed.scheme}://{parsed.netloc}"
        proposal_url = f"{server_root}/{owner}/{slug}/proposals/{raw_proposal_id}"
    else:
        proposal_url = data.get("url") or raw_proposal_id

    if json_output:
        extras = {"url": data.get("url") or proposal_url, "proposalIdB64": proposal_id_b64}
        print(json.dumps({**make_envelope(elapsed), **data, **extras}))
        return

    if len(parts) >= 2:
        print(f"✅ Proposal created: {sanitize_display(proposal_url)}", file=sys.stderr)
    else:
        print(f"✅ Proposal created: {sanitize_display(raw_proposal_id)}", file=sys.stderr)
    print(
        f"   {sanitize_display(from_branch)} → {sanitize_display(to_branch)}: "
        f"{sanitize_display(title)}",
        file=sys.stderr,
    )

def run_proposal_merge(args: argparse.Namespace) -> None:
    """Merge a proposal.

    Merges immediately — no confirmation dialog.  The source branch is deleted
    by default; pass ``--no-delete-branch`` to keep it.

    Merge strategies: ``overlay`` (default), ``weave``, ``replay``, ``selective``.
    Commit history styles: ``merge`` (default), ``squash``, ``rebase``.

    The hub may return HTTP 200 with ``{"merged": false}`` when it refuses the
    merge (e.g. conflict, branch-protection rule).  This command treats that
    as a failure in **both** text and JSON modes — exit code 3 is returned so
    that agent pipelines can reliably use the exit code to detect success::

        muse hub proposal merge af54753d --json && echo "merged" || echo "conflict"

    JSON output is the raw API response merged with the standard envelope;
    human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub proposal merge af54753d --strategy squash --json
        # → {"muse_version": "...", ..., "merged": true, "mergeCommitId": "..."}

        # Safe pipeline — exit code 3 on merge failure, even with --json:
        PROPOSAL_RESULT=$(muse hub proposal merge af54753d --json) || exit 1
        echo "$PROPOSAL_RESULT" | jq '.mergeCommitId'

    Exit codes
    ----------
    0  Merged successfully.
    1  Prefix not found, ambiguous, or not authenticated.
    2  Not inside a Muse repository.
    3  Merge rejected by hub (conflict, branch protection, etc.) or API error.
    """
    proposal_id: str = args.proposal_id
    strategy: str = args.strategy
    delete_branch: bool = args.delete_branch
    json_output: bool = args.json_output

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=args.hub)
    repo_id = _resolve_repo_id(hub_url, identity)
    proposal_id = _resolve_proposal_id(hub_url, identity, repo_id, proposal_id)

    payload: _HubPayload = {
        "mergeStrategy": strategy,
        "deleteBranch": delete_branch,
    }
    data = _hub_api(
        hub_url, identity, "POST",
        f"/api/repos/{repo_id}/proposals/{proposal_id}/merge",
        body=payload,
    )

    merged: bool = bool(data.get("merged", False))

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        # Exit nonzero even in JSON mode so agent pipelines can rely on the
        # exit code — a hub-side merge rejection must never silently exit 0.
        if not merged:
            raise SystemExit(ExitCode.INTERNAL_ERROR)
        return

    commit_id: str = str(data.get("mergeCommitId", "")) or ""
    if merged:
        sha = sanitize_display(commit_id) if commit_id else "(no SHA)"
        print(
            f"✅ Proposal {sanitize_display(proposal_id)} merged → {sha}",
            file=sys.stderr,
        )
        if delete_branch:
            print("   Source branch deleted.", file=sys.stderr)
    else:
        msg = str(data.get("message", "unknown error"))
        print(f"❌ Merge failed: {sanitize_display(msg)}", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR)

def run_proposal_comment_list(args: argparse.Namespace) -> None:
    """List all comments on a proposal, threaded by parent.

    Each top-level comment includes its direct replies nested under it.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub proposal comment list af54753d --json
        muse hub proposal comment list af54753d --json | jq '.comments[].author'

    Exit codes
    ----------
    0  Success.
    1  Auth error or proposal not found.
    2  Not inside a Muse repository.
    3  API error.
    """
    proposal_id_or_prefix: str = args.proposal_id
    json_output: bool = args.json_output
    include_deleted: bool = getattr(args, "include_deleted", False)

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=args.hub)
    repo_id = _resolve_repo_id(hub_url, identity)
    proposal_id = _resolve_proposal_id(hub_url, identity, repo_id, proposal_id_or_prefix)

    path = f"/api/repos/{repo_id}/proposals/{proposal_id}/comments"
    if include_deleted:
        path += "?include_deleted=true"
    data = _hub_api(hub_url, identity, "GET", path)

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    comments = data.get("comments", [])
    total = data.get("total", len(comments))
    if not comments:
        print(f"No comments on proposal {sanitize_display(proposal_id)}.", file=sys.stderr)
        return
    print(f"Comments ({total}):", file=sys.stderr)
    for c in comments:
        author = sanitize_display(str(c.get("author", "")))
        body = sanitize_display(str(c.get("body", "")))[:80]
        print(f"  [{author}] {body}")
        for r in c.get("replies", []):
            r_author = sanitize_display(str(r.get("author", "")))
            r_body = sanitize_display(str(r.get("body", "")))[:70]
            print(f"    ↳ [{r_author}] {r_body}")

def run_proposal_reviewer_request(args: argparse.Namespace) -> None:
    """Request one or more reviewers on a proposal.

    Reviewer handles are passed as positional arguments.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub proposal reviewer request af54753d alice bob --json
        muse hub proposal reviewer request af54753d alice --json | jq '.reviews[].state'

    Exit codes
    ----------
    0  Success.
    1  Auth error or not authorized.
    2  Not inside a Muse repository.
    3  API error.
    """
    proposal_id_or_prefix: str = args.proposal_id
    reviewers: list[str] = args.reviewers
    json_output: bool = args.json_output

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=args.hub)
    repo_id = _resolve_repo_id(hub_url, identity)
    proposal_id = _resolve_proposal_id(hub_url, identity, repo_id, proposal_id_or_prefix)

    data = _hub_api(
        hub_url, identity, "POST",
        f"/api/repos/{repo_id}/proposals/{proposal_id}/reviewers",
        body={"reviewers": reviewers},
    )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    reviews = data.get("reviews", [])
    print(f"✅ Reviewers requested ({len(reviews)} total):", file=sys.stderr)
    for rv in reviews:
        handle = sanitize_display(str(rv.get("reviewerUsername", rv.get("reviewer", ""))))
        state = sanitize_display(str(rv.get("state", "")))
        print(f"  {handle:<32}  {state}")

def run_proposal_reviewer_remove(args: argparse.Namespace) -> None:
    """Remove a pending reviewer from a proposal.

    Only pending review requests can be removed — submitted reviews are immutable.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub proposal reviewer remove af54753d alice --json
        muse hub proposal reviewer remove af54753d alice --json | jq '.reviews | length'

    Exit codes
    ----------
    0  Success.
    1  Auth error, reviewer not found, or review already submitted.
    2  Not inside a Muse repository.
    3  API error.
    """
    proposal_id_or_prefix: str = args.proposal_id
    reviewer: str = args.reviewer
    json_output: bool = args.json_output

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=args.hub)
    repo_id = _resolve_repo_id(hub_url, identity)
    proposal_id = _resolve_proposal_id(hub_url, identity, repo_id, proposal_id_or_prefix)

    data = _hub_api(
        hub_url, identity, "DELETE",
        f"/api/repos/{repo_id}/proposals/{proposal_id}/reviewers/{reviewer}",
    )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    reviews = data.get("reviews", [])
    print(
        f"✅ Reviewer {sanitize_display(reviewer)} removed "
        f"({len(reviews)} reviewers remaining).",
        file=sys.stderr,
    )

def run_proposal_review_list(args: argparse.Namespace) -> None:
    """List all reviews for a proposal.

    Includes pending assignments and submitted reviews (``approved``,
    ``changes_requested``, ``dismissed``).  Pass ``--state`` to filter.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub proposal review list af54753d --json
        muse hub proposal review list af54753d --state approved --json | jq '.reviews[].reviewerUsername'

    Exit codes
    ----------
    0  Success.
    1  Auth error or proposal not found.
    2  Not inside a Muse repository.
    3  API error.
    """
    proposal_id_or_prefix: str = args.proposal_id
    state: str | None = getattr(args, "state", None) or None
    json_output: bool = args.json_output

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=args.hub)
    repo_id = _resolve_repo_id(hub_url, identity)
    proposal_id = _resolve_proposal_id(hub_url, identity, repo_id, proposal_id_or_prefix)

    path = f"/api/repos/{repo_id}/proposals/{proposal_id}/reviews"
    if state:
        path += f"?state={state}"
    data = _hub_api(hub_url, identity, "GET", path)

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    reviews = data.get("reviews", [])
    total = data.get("total", len(reviews))
    if not reviews:
        print(f"No reviews on proposal {sanitize_display(proposal_id)}.", file=sys.stderr)
        return
    print(f"Reviews ({total}):", file=sys.stderr)
    for rv in reviews:
        handle = sanitize_display(str(rv.get("reviewerUsername", rv.get("reviewer", ""))))
        s = sanitize_display(str(rv.get("state", "")))
        print(f"  {handle:<32}  {s}")

def run_proposal_comment_create(args: argparse.Namespace) -> None:
    """Post a comment on a merge proposal on MuseHub.

    The comment body is supplied via ``--body`` (inline) or ``--body-file``
    (path to a file whose contents become the body).  At least one is required.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub proposal comment create af54753d --body 'LGTM' --json
        # → {"muse_version": "...", ..., "commentId": "...", "author": "...", ...}

    JSON output keys (from hub): ``commentId``, ``proposalId``, ``author``,
    ``body``, ``createdAt``.

    Exit codes
    ----------
    0  Comment posted.
    1  Validation or auth error.
    2  Not inside a Muse repository.
    3  API error.
    """
    body: str = _resolve_body(args)
    if not body.strip():
        print("❌ --body or --body-file must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    payload = {"body": body}
    data = _hub_api(hub_url, identity, "POST",
                    f"/api/repos/{repo_id}/proposals/{args.proposal_id}/comments",
                    body=payload)

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"✅ Comment posted on proposal {args.proposal_id}.", file=sys.stderr)

def run_proposal_comment_delete(args: argparse.Namespace) -> None:
    """Delete a comment from a merge proposal on MuseHub.

    Soft-deletes by default (hidden from ``comment list`` but preserved in
    the audit log) -- requires write/admin access or repo ownership. Pass
    ``--hard`` to actually remove the row instead; this requires the repo
    owner or an *admin* collaborator specifically, matching the
    framework-wide "--hard gated to owner/admin" convention (musehub#141).

    JSON output includes envelope fields plus ``deleted`` (bool),
    ``comment_id`` (str), and ``hard`` (bool).

    Agent quickstart
    ----------------
    ::

        muse hub proposal comment delete af54753d --comment-id <id> --json
        muse hub proposal comment delete af54753d --comment-id <id> --hard --json
        # → {"muse_version": "...", ..., "deleted": true, "comment_id": "...", "hard": false}

    Exit codes
    ----------
    0  Comment deleted successfully.
    1  Validation or auth error.
    2  Not inside a Muse repository.
    3  API error (includes 404 if the comment does not exist).
    """
    proposal_id_or_prefix: str = args.proposal_id
    comment_id: str = args.comment_id
    hard: bool = args.hard
    json_output: bool = args.json_output

    if not comment_id.strip():
        print("❌ --comment-id must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=args.hub)
    repo_id = _resolve_repo_id(hub_url, identity)
    proposal_id = _resolve_proposal_id(hub_url, identity, repo_id, proposal_id_or_prefix)

    path = f"/api/repos/{repo_id}/proposals/{proposal_id}/comments/{comment_id}"
    if hard:
        path += "?hard=true"
    _hub_api(hub_url, identity, "DELETE", path)

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **{
            "deleted": True, "comment_id": comment_id, "hard": hard,
        }}))
        return

    kind = "hard-deleted" if hard else "deleted"
    print(f"✅ Comment {comment_id} {kind} from proposal {sanitize_display(proposal_id)}.", file=sys.stderr)

def run_proposal_update(args: argparse.Namespace) -> None:
    """Partially update a proposal (title, body, type, or strategy).

    At least one of ``--title``, ``--body`` / ``--body-file``, ``--type``, or
    ``--strategy`` must be supplied.  Only the fields you pass are changed;
    the rest are left untouched.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable confirmation goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub proposal update af54753d --title "New title" --json
        muse hub proposal update af54753d --type canonical_release --json
        muse hub proposal update af54753d --body-file notes.md --json

    Exit codes
    ----------
    0  Proposal updated.
    1  Validation error (no fields supplied, unknown type/strategy).
    2  Not inside a Muse repository.
    3  API / network error.
    """
    title: str | None = getattr(args, "title", None)
    body_inline: str | None = getattr(args, "body", None)
    body_file: str | None = getattr(args, "body_file", None)
    proposal_type: str | None = getattr(args, "proposal_type", None)
    merge_strategy: str | None = getattr(args, "merge_strategy", None)
    json_output: bool = args.json_output

    body: str | None = None
    if body_file is not None:
        import sys as _sys
        if body_file == "-":
            body = _sys.stdin.read()
        else:
            try:
                body = open(body_file).read()
            except OSError as exc:
                print(f"❌ Cannot read --body-file: {exc}", file=sys.stderr)
                raise SystemExit(ExitCode.USER_ERROR) from exc
    elif body_inline is not None:
        body = body_inline

    payload: dict[str, str] = {}
    if title is not None:
        payload["title"] = title
    if body is not None:
        payload["body"] = body
    if proposal_type is not None:
        payload["proposal_type"] = proposal_type
    if merge_strategy is not None:
        payload["merge_strategy"] = merge_strategy

    if not payload:
        print(
            "❌ At least one of --title, --body, --body-file, --type, or --strategy is required.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    try:
        hub_url, identity = _get_hub_and_identity(hub_url_override=getattr(args, "hub", None))
        repo_id = _resolve_repo_id(hub_url, identity)
        proposal_id = _resolve_proposal_id(hub_url, identity, repo_id, args.proposal_id)
        data = _hub_api(
            hub_url, identity, "PATCH",
            f"/api/repos/{repo_id}/proposals/{proposal_id}",
            body=payload,
        )
    except Exception as exc:
        print(f"❌ API error: {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR) from exc

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    proposal_id_out = str(data.get("proposalId", args.proposal_id))
    print(f"✅ Proposal {proposal_id_out} updated.", file=sys.stderr)


def run_proposal_close(args: argparse.Namespace) -> None:
    """Close an open proposal without merging.

    Issues ``POST .../proposals/{id}/close`` on MuseHub.
    Returns 409 if the proposal is already closed or merged.

    Agent quickstart
    ----------------
    ::

        muse hub proposal close af54753d --json
        # → {"muse_version": "...", ..., "state": "closed", ...}

    Exit codes
    ----------
    0  Closed successfully.
    1  Prefix not found, ambiguous, or not authenticated.
    2  Not inside a Muse repository.
    3  Proposal already closed/merged, or API error.
    """
    proposal_id: str = args.proposal_id
    json_output: bool = args.json_output

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=args.hub)
    repo_id = _resolve_repo_id(hub_url, identity)
    proposal_id = _resolve_proposal_id(hub_url, identity, repo_id, proposal_id)

    data = _hub_api(
        hub_url, identity, "POST",
        f"/api/repos/{repo_id}/proposals/{proposal_id}/close",
    )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"✅ Proposal {sanitize_display(proposal_id)} closed.", file=sys.stderr)


def run_proposal_review_submit(args: argparse.Namespace) -> None:
    """Submit an approve, request-changes, or comment review on a proposal.

    Verdicts: ``approve``, ``request_changes``, ``comment``.
    A ``--body`` is optional for ``approve`` and required for ``request_changes``.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub proposal review submit af54753d --verdict approve --json
        muse hub proposal review submit af54753d --verdict request_changes --body 'Fix X' --json
        # → {"muse_version": "...", ..., "reviewId": "...", "verdict": "..."}

    JSON output keys (from hub): ``reviewId``, ``proposalId``, ``author``,
    ``verdict``, ``body``, ``createdAt``.

    Exit codes
    ----------
    0  Review submitted.
    1  Auth error.
    2  Not inside a Muse repository.
    3  API error.
    """
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    payload = {"verdict": args.verdict, "body": _resolve_body(args)}
    data = _hub_api(hub_url, identity, "POST",
                    f"/api/repos/{repo_id}/proposals/{args.proposal_id}/reviews",
                    body=payload)

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"✅ Review ({args.verdict}) submitted on proposal {args.proposal_id}.", file=sys.stderr)

def register(subs: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register proposals subcommands."""
    # ── proposal ──────────────────────────────────────────────────────────────
    proposal_p = subs.add_parser(
        "proposal",
        help="Manage proposals on MuseHub.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    proposal_subs = proposal_p.add_subparsers(dest="proposal_subcommand", metavar="PROPOSAL_COMMAND")
    proposal_subs.required = True

    proposal_create_p = proposal_subs.add_parser(
        "create",
        help="Open a new proposal.",
        description=(
            "Open a new proposal on MuseHub.\n\n"
            "Uses the current branch as the source if --from-branch is omitted.\n"
            "Both Muse-native flags (--from-branch / --to-branch) and familiar\n"
            "aliases (--head / --base) are accepted.\n\n"
            f"Title must be non-empty and ≤ {_MAX_PROPOSAL_TITLE_LEN} characters.\n"
            "Detached HEAD is rejected — pass --from-branch explicitly.\n\n"
            "Agent quickstart:\n"
            "  muse hub proposal create --title 'feat: x' --from-branch feat/x --json\n"
            "  PROPOSAL=$(muse hub proposal create --title 'feat: x' --json)\n"
            "  echo \"$PROPOSAL\" | jq '.proposalId'\n\n"
            "Exit codes: 0 created, 1 validation/branch error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    proposal_create_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    proposal_create_p.add_argument("--title", "-t", required=True, help="Proposal title.")
    proposal_create_p.add_argument("--body", "-b", default="", help="Proposal body / description (inline text).")
    proposal_create_p.add_argument(
        "--body-file", default=None, metavar="PATH", dest="body_file",
        help="Read proposal body from PATH. Pass '-' for stdin. Takes precedence over --body.",
    )
    proposal_create_p.add_argument(
        "--from-branch", "--head", "-f", dest="from_branch", default=None,
        help=(
            "Source branch (default: current branch). "
            "--head is accepted as a git-familiar alias."
        ),
    )
    proposal_create_p.add_argument(
        "--to-branch", "--base", dest="to_branch", default="dev",
        help="Target branch (default: dev). --base is accepted as a git-familiar alias.",
    )
    proposal_create_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the created proposal.",
    )
    proposal_create_p.set_defaults(func=run_proposal_create)

    proposal_list_p = proposal_subs.add_parser(
        "list",
        help="List proposals.",
        description=(
            "List proposals on the configured MuseHub.\n\n"
            "Filters by state (default: open).  --limit caps the number of results.\n"
            "Use --state all to see every proposal regardless of state.\n"
            "Use --verbose to also show author and creation date per proposal.\n\n"
            "Agent quickstart:\n"
            "  muse hub proposal list --state open --json\n"
            "  muse hub proposal list --state all -n 100 --json | jq '.[] | .proposalId'\n\n"
            "Exit codes: 0 success, 1 not authenticated, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    proposal_list_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config (e.g. http://host.docker.internal:10003/owner/repo).",
    )
    proposal_list_p.add_argument(
        "--state", default="open", choices=["open", "merged", "closed", "all"],
        help="Filter by state: open (default), merged, closed, all.",
    )
    proposal_list_p.add_argument(
        "--limit", "-n", type=int, default=20,
        help="Maximum number of proposals to return (default: 20).",
    )
    proposal_list_p.add_argument(
        "--verbose", "-v", action="store_true", dest="verbose",
        help="Show author and creation date for each proposal.",
    )
    proposal_list_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON to stdout instead of human-readable output.",
    )
    proposal_list_p.set_defaults(func=run_proposal_list)

    proposal_merge_p = proposal_subs.add_parser(
        "merge",
        help="Merge a proposal.",
        description=(
            "Merge a proposal immediately — no confirmation dialog.\n\n"
            "The source branch is deleted by default; pass --no-delete-branch\n"
            "to keep it.\n\n"
            "Content merge strategies (--strategy): overlay (default), weave, replay, selective.\n"
            "Commit history styles (--history): merge (default), squash, rebase.\n\n"
            "Exit code 3 is returned on merge rejection in BOTH text and JSON mode\n"
            "so agent pipelines can always rely on the exit code:\n"
            "  muse hub proposal merge af54753d --json && echo ok || echo conflict\n\n"
            "Agent quickstart:\n"
            "  muse hub proposal merge af54753d --strategy overlay --history merge --json\n"
            "  # → {\"merged\": true, \"mergeCommitId\": \"...\", ...}\n\n"
            "Exit codes: 0 merged, 1 not found/not authenticated,\n"
            "            2 not in repo, 3 merge rejected or API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    proposal_merge_p.add_argument("proposal_id", help="Proposal ID (full ID or 8-char prefix).")
    proposal_merge_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    proposal_merge_p.add_argument(
        "--strategy", default="merge_commit",
        choices=["merge_commit", "squash", "rebase"],
        help="Commit history style (default: merge_commit).",
    )
    proposal_merge_p.add_argument(
        "--no-delete-branch", dest="delete_branch", action="store_false",
        help="Do not delete the source branch after merging.",
    )
    proposal_merge_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the proposal merge result.",
    )
    proposal_merge_p.set_defaults(func=run_proposal_merge, delete_branch=True)

    proposal_read_p = proposal_subs.add_parser(
        "read",
        help="Read a single proposal.",
        description=(
            "Read a single proposal by ID.\n\n"
            "Accepts the full ID or an 8-character prefix.  Prefix resolution\n"
            f"fetches the most recent {_PROPOSAL_PREFIX_RESOLVE_LIMIT} proposals — use the full ID\n"
            "on large repositories to avoid ambiguity.\n\n"
            "Text output shows state, title, ID, branches, author, date, and\n"
            f"up to {_MAX_PROPOSAL_BODY_LINES} body lines (truncation hint printed when exceeded).\n"
            "JSON output is the raw API response (camelCase field names).\n\n"
            "Agent quickstart:\n"
            "  muse hub proposal read af54753d --json | jq '.state'\n"
            "  muse hub proposal read af54753d --json | jq '{state,title,author}'\n\n"
            "Exit codes: 0 found, 1 not found/ambiguous, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    proposal_read_p.add_argument("proposal_id", help="Proposal ID (full ID or 8-char prefix).")
    proposal_read_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    proposal_read_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output", help="Emit JSON.",
    )
    proposal_read_p.set_defaults(func=run_proposal_read)

    # ── proposal comment ──────────────────────────────────────────────────────
    proposal_comment_p = proposal_subs.add_parser(
        "comment",
        help="Manage proposal comments.",
        description="Manage review comments on a merge proposal.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    proposal_comment_subs = proposal_comment_p.add_subparsers(
        dest="proposal_comment_subcommand", metavar="COMMENT_COMMAND",
    )
    proposal_comment_subs.required = True

    proposal_comment_list_p = proposal_comment_subs.add_parser(
        "list", help="List all comments on a proposal (threaded).",
    )
    proposal_comment_list_p.add_argument("proposal_id", help="Proposal ID (full ID or 8-char prefix).")
    proposal_comment_list_p.add_argument("--hub", dest="hub", default=None, metavar="URL")
    proposal_comment_list_p.add_argument(
        "--include-deleted", action="store_true", dest="include_deleted",
        help="Also show soft-deleted comments. Requires write/admin access or repo ownership.",
    )
    proposal_comment_list_p.add_argument("--json", "-j", action="store_true", dest="json_output")
    proposal_comment_list_p.set_defaults(func=run_proposal_comment_list)

    proposal_comment_create_p = proposal_comment_subs.add_parser(
        "create", help="Post a new comment on a proposal.",
        description=(
            "Post a Markdown comment on a merge proposal.\n\n"
            "  muse hub proposal comment create <proposal_id> --body 'LGTM'\n"
            "  muse hub proposal comment create <proposal_id> --body 'See inline' --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    proposal_comment_create_p.add_argument("proposal_id", help="ID of the proposal.")
    proposal_comment_create_p.add_argument("--hub", dest="hub", default=None, metavar="URL",
                                           help="Override the hub URL from config.")
    proposal_comment_create_p.add_argument("--repo", dest="repo", default=None, metavar="OWNER/REPO",
                                           help="Specify repo as owner/repo.")
    proposal_comment_create_p.add_argument("--body", "-b", default=None,
                                           help="Comment body (Markdown, inline text).")
    proposal_comment_create_p.add_argument(
        "--body-file", default=None, metavar="PATH", dest="body_file",
        help="Read comment body from PATH. Pass '-' for stdin. Takes precedence over --body.",
    )
    proposal_comment_create_p.add_argument("--json", "-j", action="store_true", dest="json_output",
                                           help="Emit JSON output.")
    proposal_comment_create_p.set_defaults(func=run_proposal_comment_create)

    proposal_comment_delete_p = proposal_comment_subs.add_parser(
        "delete", help="Delete a comment from a proposal.",
        description=(
            "Soft-delete (default) or hard-delete (--hard) a comment on a merge proposal.\n\n"
            "  muse hub proposal comment delete <proposal_id> --comment-id <id>\n"
            "  muse hub proposal comment delete <proposal_id> --comment-id <id> --hard\n\n"
            "Soft-delete requires write/admin access or repo ownership. --hard requires\n"
            "the repo owner or an admin collaborator specifically.\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    proposal_comment_delete_p.add_argument("proposal_id", help="Proposal ID (full ID or 8-char prefix).")
    proposal_comment_delete_p.add_argument("--comment-id", dest="comment_id", required=True,
                                           help="ID of the comment to delete.")
    proposal_comment_delete_p.add_argument(
        "--hard", action="store_true",
        help="Actually remove the row instead of soft-deleting. Requires owner or admin collaborator.",
    )
    proposal_comment_delete_p.add_argument("--hub", dest="hub", default=None, metavar="URL")
    proposal_comment_delete_p.add_argument("--json", "-j", action="store_true", dest="json_output")
    proposal_comment_delete_p.set_defaults(func=run_proposal_comment_delete)

    proposal_comment_p.set_defaults(func=lambda a: proposal_comment_p.print_help())

    # ── proposal reviewer ─────────────────────────────────────────────────────
    proposal_reviewer_p = proposal_subs.add_parser(
        "reviewer",
        help="Manage proposal reviewers.",
        description="Request or remove reviewers on a merge proposal.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    proposal_reviewer_subs = proposal_reviewer_p.add_subparsers(
        dest="proposal_reviewer_subcommand", metavar="REVIEWER_COMMAND",
    )
    proposal_reviewer_subs.required = True

    proposal_reviewer_request_p = proposal_reviewer_subs.add_parser(
        "request", help="Request reviewers on a proposal.",
    )
    proposal_reviewer_request_p.add_argument("proposal_id", help="Proposal ID (full ID or 8-char prefix).")
    proposal_reviewer_request_p.add_argument("reviewers", nargs="+", help="MSign handles to request.")
    proposal_reviewer_request_p.add_argument("--hub", dest="hub", default=None, metavar="URL")
    proposal_reviewer_request_p.add_argument("--json", "-j", action="store_true", dest="json_output")
    proposal_reviewer_request_p.set_defaults(func=run_proposal_reviewer_request)

    proposal_reviewer_remove_p = proposal_reviewer_subs.add_parser(
        "remove", help="Remove a pending reviewer from a proposal.",
    )
    proposal_reviewer_remove_p.add_argument("proposal_id", help="Proposal ID (full ID or 8-char prefix).")
    proposal_reviewer_remove_p.add_argument("reviewer", help="MSign handle of the reviewer to remove.")
    proposal_reviewer_remove_p.add_argument("--hub", dest="hub", default=None, metavar="URL")
    proposal_reviewer_remove_p.add_argument("--json", "-j", action="store_true", dest="json_output")
    proposal_reviewer_remove_p.set_defaults(func=run_proposal_reviewer_remove)

    proposal_reviewer_p.set_defaults(func=lambda a: proposal_reviewer_p.print_help())

    # ── proposal review ───────────────────────────────────────────────────────
    proposal_review_p = proposal_subs.add_parser(
        "review",
        help="Manage proposal reviews.",
        description="List or filter formal reviews on a merge proposal.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    proposal_review_subs = proposal_review_p.add_subparsers(
        dest="proposal_review_subcommand", metavar="REVIEW_COMMAND",
    )
    proposal_review_subs.required = True

    proposal_review_list_p = proposal_review_subs.add_parser(
        "list", help="List all reviews on a proposal.",
    )
    proposal_review_list_p.add_argument("proposal_id", help="Proposal ID (full ID or 8-char prefix).")
    proposal_review_list_p.add_argument(
        "--state",
        choices=["pending", "approved", "changes_requested", "dismissed"],
        default=None,
        help="Filter by review state.",
    )
    proposal_review_list_p.add_argument("--hub", dest="hub", default=None, metavar="URL")
    proposal_review_list_p.add_argument("--json", "-j", action="store_true", dest="json_output")
    proposal_review_list_p.set_defaults(func=run_proposal_review_list)

    proposal_review_submit_p = proposal_review_subs.add_parser(
        "submit", help="Submit a review (approve, request-changes, or comment).",
        description=(
            "Submit an approve, request-changes, or comment review on a proposal.\n\n"
            "  muse hub proposal review submit <proposal_id> --verdict approve\n"
            "  muse hub proposal review submit <proposal_id> --verdict request_changes --body 'Fix X'\n"
            "  muse hub proposal review submit <proposal_id> --verdict comment --body 'Notes' --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    proposal_review_submit_p.add_argument("proposal_id", help="ID of the proposal.")
    proposal_review_submit_p.add_argument("--hub", dest="hub", default=None, metavar="URL",
                                          help="Override the hub URL from config.")
    proposal_review_submit_p.add_argument("--repo", dest="repo", default=None, metavar="OWNER/REPO",
                                          help="Specify repo as owner/repo.")
    proposal_review_submit_p.add_argument(
        "--verdict", required=True,
        choices=["approve", "request_changes", "comment"],
        help="Review verdict.",
    )
    proposal_review_submit_p.add_argument("--body", "-b", default="",
                                          help="Review body (Markdown, inline text).")
    proposal_review_submit_p.add_argument(
        "--body-file", default=None, metavar="PATH", dest="body_file",
        help="Read review body from PATH. Pass '-' for stdin. Takes precedence over --body.",
    )
    proposal_review_submit_p.add_argument("--json", "-j", action="store_true", dest="json_output",
                                          help="Emit JSON output.")
    proposal_review_submit_p.set_defaults(func=run_proposal_review_submit)

    proposal_review_p.set_defaults(func=lambda a: proposal_review_p.print_help())

    # ── proposal update ───────────────────────────────────────────────────────
    _PROPOSAL_TYPES = [
        "state_merge", "stem_integration", "midi_evolution",
        "payment_settlement", "agent_delegation", "identity_transition",
        "canonical_release",
    ]
    _MERGE_STRATEGIES = ["state_overlay", "state_rebase", "state_squash"]

    proposal_update_p = proposal_subs.add_parser(
        "update",
        help="Partially update a proposal (title, body, type, strategy).",
        description=(
            "Partially update an open merge proposal on MuseHub.\n\n"
            "Only the fields you supply are changed — the rest are left untouched.\n"
            "At least one flag is required.\n\n"
            "Agent quickstart:\n"
            "  muse hub proposal update <id> --title 'New title' --json\n"
            "  muse hub proposal update <id> --type canonical_release --json\n"
            "  muse hub proposal update <id> --body-file notes.md --json\n\n"
            "Exit codes: 0 updated, 1 validation error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    proposal_update_p.add_argument("proposal_id", help="Proposal ID (full ID or 8-char prefix).")
    proposal_update_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    proposal_update_p.add_argument("--title", "-t", default=None, help="New proposal title.")
    proposal_update_p.add_argument("--body", "-b", default=None, help="New proposal body (inline Markdown).")
    proposal_update_p.add_argument(
        "--body-file", default=None, metavar="PATH", dest="body_file",
        help="Read new body from PATH. Pass '-' for stdin. Takes precedence over --body.",
    )
    proposal_update_p.add_argument(
        "--type", dest="proposal_type", default=None, choices=_PROPOSAL_TYPES,
        metavar="TYPE", help=f"New proposal type. One of: {', '.join(_PROPOSAL_TYPES)}.",
    )
    proposal_update_p.add_argument(
        "--strategy", dest="merge_strategy", default=None, choices=_MERGE_STRATEGIES,
        metavar="STRATEGY", help=f"New merge strategy. One of: {', '.join(_MERGE_STRATEGIES)}.",
    )
    proposal_update_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the updated proposal.",
    )
    proposal_update_p.set_defaults(func=run_proposal_update)

    # ── proposal close ────────────────────────────────────────────────────────
    proposal_close_p = proposal_subs.add_parser(
        "close",
        help="Close an open proposal without merging.",
        description=(
            "Close an open proposal without merging it.\n\n"
            "Issues POST .../proposals/{id}/close on MuseHub.\n"
            "Returns 409 if the proposal is already closed or merged.\n\n"
            "Agent quickstart:\n"
            "  muse hub proposal close af54753d --json\n"
            "  # → {\"state\": \"closed\", ...}\n\n"
            "Exit codes: 0 closed, 1 not found/not authenticated,\n"
            "            2 not in repo, 3 already closed/merged or API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    proposal_close_p.add_argument("proposal_id", help="Proposal ID (full ID or 8-char prefix).")
    proposal_close_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    proposal_close_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the closed proposal.",
    )
    proposal_close_p.set_defaults(func=run_proposal_close)

    proposal_p.set_defaults(func=lambda a: proposal_p.print_help())

