"""muse hub — MuseHub fabric connection management.

The hub is not just a remote.  It is the shared fabric where versioned
multidimensional state flows across agents, humans, and repositories.
Connecting a repo to a hub anchors it to the synchronisation layer that
enables push/pull, plugin discovery, and multi-agent coordination.

Subcommands are implemented across domain modules:

    hub/_core.py          — shared helpers, TypedDicts, constants
    hub/connection.py     — connect, disconnect, status, ping
    hub/repos.py          — repo create/delete/update/list/read/transfer
    hub/proposals.py      — proposal list/read/create/merge/review/comment
    hub/issues.py         — issue create/update/read/list/close/comment/assign/label
    hub/labels.py         — label create/list/update/delete
    hub/collaborators.py  — collaborator list/invite/update/remove
    hub/webhooks.py       — webhook create/list/delete + deliveries
    hub/releases.py       — release list/create/read/delete + assets
    hub/users.py          — user read/update + topics + forks
    hub/attestations.py   — attestation create/list/revoke
"""

import argparse

from . import (
    attestations,
    collaborators,
    connection,
    issues,
    labels,
    proposals,
    releases,
    repos,
    users,
    webhooks,
)
from ._core import (
    _HANDLE_RE,
    _MAX_API_RESPONSE_BYTES,
    _MAX_HANDLE_LEN,
    _MAX_ISSUE_COMMENT_LEN,
    _MAX_ISSUE_LABEL_LEN,
    _MAX_ISSUE_TITLE_LEN,
    _MAX_LABEL_DESC_LEN,
    _MAX_LABEL_NAME_LEN,
    _MAX_PROPOSAL_BODY_LINES,
    _MAX_PROPOSAL_TITLE_LEN,
    _MAX_REPO_DESC_LEN,
    _MAX_REPO_NAME_LEN,
    _PROPOSAL_PREFIX_RESOLVE_LIMIT,
    _PING_OPENER,
    _format_proposal,
    _get_hub_and_identity,
    _get_hub_and_optional_identity,
    _hub_api,
    _normalise_url,
    _ping_hub,
    _resolve_body,
    _resolve_proposal_id,
    _resolve_repo_id,
    _validate_assignee,
    get_hub_url,
)
from .labels import _validate_hex_color
from .issues import run_issue_create

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse hub`` subcommand tree and all its flags."""
    parser = subparsers.add_parser(
        "hub",
        help="MuseHub fabric connection management.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subs = parser.add_subparsers(dest="subcommand", metavar="SUBCOMMAND")
    subs.required = True

    connection.register(subs)
    repos.register(subs)
    proposals.register(subs)
    issues.register(subs)
    labels.register(subs)
    collaborators.register(subs)
    webhooks.register(subs)
    releases.register(subs)
    users.register(subs)
    attestations.register(subs)
