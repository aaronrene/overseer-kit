"""muse hub attestation — issue, list, and revoke Ed25519 attestations.

Attestations are cryptographically signed claims one identity makes about
another.  They are content-addressed (SHA-256 of the canonical message),
verified server-side, and auditable forever.

Subcommands
-----------
::

    muse hub attestation create --subject <handle> --type <claim_type> [flags]
    muse hub attestation list   [--subject <handle>] [--attester <handle>] [--type <type>]
    muse hub attestation revoke <attestation_id>

Agent quickstart
----------------
::

    # Attest that claude-code is a trustworthy agent
    muse hub attestation create --subject claude-code --type agent --json

    # Attest that you reviewed a specific commit
    muse hub attestation create \
      --subject gabriel/musehub --type code:reviewed \
      --scope commit \
      --scope-ref gabriel/musehub@sha256:abc123... \
      --commit-id sha256:abc123... \
      --json

    # List all attestations about a subject
    muse hub attestation list --subject gabriel --json

    # Revoke an attestation by ID
    muse hub attestation revoke <attestation_id> --json

Exit codes
----------
0  Success.
1  Validation error or not authenticated.
2  Not inside a Muse repository.
3  API error.

Canonical ATTEST message (identity scope)::

    ATTEST\\n{attester}\\n{subject}\\n{claim_json}\\n{issued_at_iso}

For repo/commit scope, scope_ref is appended::

    ATTEST\\n{attester}\\n{subject}\\n{claim_json}\\n{issued_at_iso}\\n{scope_ref}

The signature is computed over this canonical message with Ed25519,
using the private key from ``~/.muse/identity.toml``.
"""

import argparse
import base64
import json
import sys
import urllib.parse
from datetime import datetime, timezone

from ._core import (
    ExitCode,
    _get_hub_and_identity,
    _hub_api,
    _resolve_hub_override,
    make_envelope,
    sanitize_display,
    start_timer,
)

_MAX_METADATA_LEN = 4096   # guard against excessively large --metadata blobs


def _b64url(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def _attestation_canonical(
    attester: str,
    subject: str,
    claim_json: str,
    issued_at_iso: str,
    scope: str = "identity",
    scope_ref: str | None = None,
) -> str:
    parts = ["ATTEST", attester, subject, claim_json, issued_at_iso]
    if scope != "identity" and scope_ref:
        parts.append(scope_ref)
    return "\n".join(parts)


def run_attestation_create(args: argparse.Namespace) -> None:
    """Issue a signed attestation from the authenticated identity.

    The private key is loaded from ``~/.muse/identity.toml``.  The public key
    and signature are computed locally and sent to the hub for verification and
    storage.  The attestation_id is deterministic (SHA-256 of canonical
    message) so running the same command twice with the same --issued-at is
    idempotent.

    Agent quickstart
    ----------------
    ::

        muse hub attestation create --subject gabriel --type human --json
        muse hub attestation create --subject claude-code --type agent --json
        muse hub attestation create \\
          --subject gabriel/musehub --type code:reviewed \\
          --scope repo --scope-ref gabriel/musehub \\
          --json

    Exit codes
    ----------
    0  Attestation created (or already exists — idempotent).
    1  Validation error or not authenticated.
    2  Not inside a Muse repository.
    3  API error.
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    from muse.cli.config import get_signing_identity

    subject: str = args.subject.strip()
    claim_type: str = args.claim_type.strip()
    scope: str = args.scope
    scope_ref: str | None = (args.scope_ref or "").strip() or None
    commit_id: str | None = (args.commit_id or "").strip() or None
    metadata_str: str = (args.metadata or "").strip()
    expires_in: str | None = (args.expires_in or "").strip() or None
    json_output: bool = args.json_output

    # ── Validate locally before any network I/O ─────────────────────────────
    if not subject:
        print("❌ --subject must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    if not claim_type:
        print("❌ --type must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    if scope not in ("identity", "repo", "commit"):
        print("❌ --scope must be 'identity', 'repo', or 'commit'.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    if scope in ("repo", "commit") and not scope_ref:
        print(f"❌ --scope-ref is required when --scope is '{scope}'.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    if scope == "commit" and not commit_id:
        print("❌ --commit-id is required when --scope is 'commit'.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    # Parse optional --metadata JSON
    extra_claim = {}
    if metadata_str:
        if len(metadata_str) > _MAX_METADATA_LEN:
            print(f"❌ --metadata exceeds {_MAX_METADATA_LEN} character limit.", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        try:
            extra_claim = json.loads(metadata_str)
            if not isinstance(extra_claim, dict):
                raise ValueError("must be a JSON object")
        except (json.JSONDecodeError, ValueError) as exc:
            print(f"❌ --metadata is not valid JSON: {exc}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR) from exc

    # ── Get hub URL and resolve signing identity ─────────────────────────────
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))

    signing = get_signing_identity(remote_url=hub_url)
    if signing is None:
        print("❌ No signing identity for this hub.  Run:", file=sys.stderr)
        print("   muse auth keygen --hub <url>", file=sys.stderr)
        print("   muse auth register --hub <url> --handle <your-handle>", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    private_key = signing.private_key
    if not isinstance(private_key, Ed25519PrivateKey):
        print("❌ Signing key is not an Ed25519PrivateKey.", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    attester: str = signing.handle

    # ── Build claim JSON and canonical message ───────────────────────────────
    claim_dict = {"type": claim_type}
    claim_dict.update(extra_claim)
    claim_json: str = json.dumps(claim_dict, separators=(",", ":"), sort_keys=True)

    issued_at_iso: str = datetime.now(timezone.utc).isoformat(timespec="seconds")

    canonical = _attestation_canonical(attester, subject, claim_json, issued_at_iso, scope, scope_ref)

    # ── Sign ─────────────────────────────────────────────────────────────────
    sig_bytes = private_key.sign(canonical.encode("utf-8"))
    signature = f"ed25519:{_b64url(sig_bytes)}"

    pub_bytes = private_key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    attester_public_key = f"ed25519:{_b64url(pub_bytes)}"

    # ── Resolve path handle from subject (strip repo/commit suffix) ──────────
    path_handle = subject.split("/")[0]

    # ── Build request body ───────────────────────────────────────────────────
    payload = {
        "attester": attester,
        "subject": subject,
        "claim": claim_json,
        "signature": signature,
        "attesterPublicKey": attester_public_key,
        "issuedAt": issued_at_iso,
        "scope": scope,
    }
    if scope_ref:
        payload["scopeRef"] = scope_ref
    if commit_id:
        payload["commitId"] = commit_id

    # Optional expiry — parse simple duration like "90d", "7d", "1y"
    if expires_in:
        try:
            expiry_dt = _parse_expiry(expires_in, issued_at_iso)
            payload["expiresAt"] = expiry_dt
        except ValueError as exc:
            print(f"❌ --expires-in: {exc}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR) from exc

    data = _hub_api(hub_url, identity, "POST", f"/api/profiles/{path_handle}/attestations", body=payload)

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    attest_id = str(data.get("attestationId", data.get("attestation_id", "")))
    print(
        f"✅ Attestation issued.\n"
        f"   id:      {sanitize_display(attest_id)}\n"
        f"   type:    {sanitize_display(claim_type)}\n"
        f"   from:    {sanitize_display(attester)}\n"
        f"   about:   {sanitize_display(subject)}\n"
        f"   scope:   {sanitize_display(scope)}",
        file=sys.stderr,
    )


def run_attestation_list(args: argparse.Namespace) -> None:
    """List attestations for a subject from MuseHub.

    Client-side filtering is applied for --attester and --type since the
    MuseHub API filters by subject only.

    Agent quickstart
    ----------------
    ::

        muse hub attestation list --subject gabriel --json
        muse hub attestation list --subject gabriel --type agent --json
        muse hub attestation list --attester musehub --subject gabriel --json

    Exit codes
    ----------
    0  Success (including empty list).
    1  Validation or auth error.
    2  Not inside a Muse repository.
    3  API error.
    """
    subject: str = (args.subject or "").strip()
    attester_filter: str = (args.attester or "").strip()
    type_filter: str = (args.type_filter or "").strip()
    include_revoked: bool = args.include_revoked
    json_output: bool = args.json_output

    if not subject:
        print("❌ --subject is required for attestation list.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))

    params = ""
    if include_revoked:
        params = "?include_revoked=true"

    data = _hub_api(hub_url, identity, "GET", f"/api/profiles/{urllib.parse.quote(subject)}/attestations{params}")

    attestations = data.get("attestations", [])

    # Client-side filtering
    if attester_filter:
        attestations = [a for a in attestations if a.get("attester") == attester_filter]
    if type_filter:
        attestations = [
            a for a in attestations
            if _claim_type(a.get("claim", "{}")) == type_filter
        ]

    result = {**data, "attestations": attestations, "total": len(attestations)}

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **result}))
        return

    if not attestations:
        print(f"  No attestations found for {sanitize_display(subject)}.", file=sys.stderr)
        return

    print(f"\n  Attestations for {sanitize_display(subject)} ({len(attestations)} shown)", file=sys.stderr)
    print(f"  {'─' * 60}", file=sys.stderr)
    for a in attestations:
        ctype = _claim_type(a.get("claim", "{}"))
        attest_id = sanitize_display(str(a.get("attestationId", a.get("attestation_id", ""))))
        attester = sanitize_display(str(a.get("attester", "")))
        issued = sanitize_display(str(a.get("issuedAt", a.get("issued_at", "")))[:10])
        revoked = "  [revoked]" if a.get("revokedAt") or a.get("revoked_at") else ""
        print(
            f"  {attest_id}  {ctype:<20}  from {attester:<20}  {issued}{revoked}",
            file=sys.stderr,
        )


def run_attestation_revoke(args: argparse.Namespace) -> None:
    """Revoke an attestation by ID.

    Only the original attester can revoke their claim.  The authenticated
    identity must match the attester on the attestation record.

    Agent quickstart
    ----------------
    ::

        muse hub attestation revoke <attestation_id> --json

    Exit codes
    ----------
    0  Attestation revoked.
    1  Validation or auth error (including wrong attester).
    2  Not inside a Muse repository.
    3  API error (404 if not found, 403 if wrong attester).
    """
    from muse.cli.config import get_signing_identity

    attestation_id: str = args.attestation_id.strip()
    subject: str = (args.subject or "").strip()
    json_output: bool = args.json_output

    if not attestation_id:
        print("❌ attestation_id must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    if not subject:
        print("❌ --subject is required (the handle the attestation is about).", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))

    signing = get_signing_identity(remote_url=hub_url)
    if signing is None:
        print("❌ No signing identity for this hub.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    revoker = signing.handle

    # DELETE /api/profiles/{handle}/attestations/{id}?revoker={handle}
    path = (
        f"/api/profiles/{urllib.parse.quote(subject)}"
        f"/attestations/{urllib.parse.quote(attestation_id)}"
        f"?revoker={urllib.parse.quote(revoker)}"
    )
    data = _hub_api(hub_url, identity, "DELETE", path)

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    attest_id = sanitize_display(str(data.get("attestationId", data.get("attestation_id", attestation_id))))
    print(f"✅ Attestation {attest_id} revoked.", file=sys.stderr)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _claim_type(claim_json: str) -> str:
    """Extract the 'type' field from a claim JSON string, or return '?'."""
    try:
        return json.loads(claim_json).get("type", "?")
    except Exception:
        return "?"


def _parse_expiry(expires_in: str, from_iso: str) -> str:
    """Parse a duration string like '90d', '7d', '1y' into an ISO-8601 timestamp.

    Supported units: d (days), w (weeks), y (years, 365d).

    Returns an ISO-8601 UTC timestamp string.

    Raises:
        ValueError: If the format is unrecognised.
    """
    import re
    m = re.fullmatch(r"(\d+)([dwmy])", expires_in)
    if not m:
        raise ValueError(
            f"Unrecognised duration '{expires_in}'. Use <N>d (days), <N>w (weeks), or <N>y (years)."
        )
    n = int(m.group(1))
    unit = m.group(2)
    days = n if unit == "d" else n * 7 if unit == "w" else n * 30 if unit == "m" else n * 365
    from datetime import timedelta
    base = datetime.fromisoformat(from_iso)
    expiry = base + timedelta(days=days)
    return expiry.isoformat(timespec="seconds")


# ── argparse registration ─────────────────────────────────────────────────────

def register(subs: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register attestation subcommands."""
    attest_p = subs.add_parser(
        "attestation",
        help="Issue, list, and revoke Ed25519 attestations.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    attest_subs = attest_p.add_subparsers(dest="attestation_subcommand", metavar="ATTESTATION_COMMAND")
    attest_subs.required = True

    def _common_args(p: argparse.ArgumentParser) -> None:
        p.add_argument("--hub", dest="hub", default=None, metavar="URL",
                       help="Override the hub URL from config.")
        p.add_argument("--repo", dest="repo", default=None, metavar="OWNER/REPO",
                       help="Specify repo as owner/repo.")
        p.add_argument("--json", "-j", action="store_true", dest="json_output",
                       help="Emit JSON output.")

    # ── attestation create ────────────────────────────────────────────────────
    create_p = attest_subs.add_parser(
        "create",
        help="Issue a signed attestation.",
        description=(
            "Issue a cryptographic attestation from the authenticated identity.\n\n"
            "  muse hub attestation create --subject gabriel --type human\n"
            "  muse hub attestation create --subject claude-code --type agent --json\n"
            "  muse hub attestation create \\\n"
            "    --subject gabriel/musehub --type code:reviewed \\\n"
            "    --scope commit \\\n"
            "    --scope-ref gabriel/musehub@sha256:abc123... \\\n"
            "    --commit-id sha256:abc123... \\\n"
            "    --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _common_args(create_p)
    create_p.add_argument(
        "--subject", required=True, metavar="HANDLE",
        help="Handle being attested (for identity scope) or 'handle/repo' for repo/commit scope.",
    )
    create_p.add_argument(
        "--type", required=True, dest="claim_type", metavar="CLAIM_TYPE",
        help=(
            "Claim type key.  Valid types include: "
            "human, org, agent, spawned-by, delegate, trusted, collab, co-author, "
            "contractor, skill:verified, code:reviewed, code:approved, deploy:approved, "
            "audit:passed, audit:failed, identity:verified, music:released."
        ),
    )
    create_p.add_argument(
        "--scope", default="identity", choices=["identity", "repo", "commit"],
        help="Attestation scope (default: identity).",
    )
    create_p.add_argument(
        "--scope-ref", dest="scope_ref", default=None, metavar="REF",
        help=(
            "Full subject reference for repo/commit scope. "
            "E.g. 'gabriel/musehub' or 'gabriel/musehub@sha256:abc...'."
        ),
    )
    create_p.add_argument(
        "--commit-id", dest="commit_id", default=None, metavar="SHA256",
        help="Commit ID ('sha256:...') — required when --scope is 'commit'.",
    )
    create_p.add_argument(
        "--metadata", default=None, metavar="JSON",
        help="Optional JSON object of extra claim fields, e.g. '{\"skill\":\"python\"}'.",
    )
    create_p.add_argument(
        "--expires-in", dest="expires_in", default=None, metavar="DURATION",
        help="Optional expiry duration, e.g. '90d', '1y'.",
    )
    create_p.set_defaults(func=run_attestation_create)

    # ── attestation list ──────────────────────────────────────────────────────
    list_p = attest_subs.add_parser(
        "list",
        help="List attestations for a subject.",
        description=(
            "List active attestations about a subject identity.\n\n"
            "  muse hub attestation list --subject gabriel\n"
            "  muse hub attestation list --subject gabriel --type agent --json\n"
            "  muse hub attestation list --subject gabriel --attester musehub --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _common_args(list_p)
    list_p.add_argument(
        "--subject", required=True, metavar="HANDLE",
        help="Handle or slug to list attestations for.",
    )
    list_p.add_argument(
        "--attester", default=None, metavar="HANDLE",
        help="Filter by attester handle (client-side).",
    )
    list_p.add_argument(
        "--type", dest="type_filter", default=None, metavar="CLAIM_TYPE",
        help="Filter by claim type (client-side).",
    )
    list_p.add_argument(
        "--include-revoked", dest="include_revoked", action="store_true",
        help="Include revoked attestations.",
    )
    list_p.set_defaults(func=run_attestation_list)

    # ── attestation revoke ────────────────────────────────────────────────────
    revoke_p = attest_subs.add_parser(
        "revoke",
        help="Revoke an attestation.",
        description=(
            "Revoke an attestation by its ID.  Only the original attester can revoke.\n\n"
            "  muse hub attestation revoke <attestation_id> --subject gabriel --json\n\n"
            "Exit codes: 0 success, 1 auth/permission error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _common_args(revoke_p)
    revoke_p.add_argument(
        "attestation_id", metavar="ATTESTATION_ID",
        help="Full attestation ID to revoke.",
    )
    revoke_p.add_argument(
        "--subject", required=True, metavar="HANDLE",
        help="Handle the attestation is about (path handle).",
    )
    revoke_p.set_defaults(func=run_attestation_revoke)
