import argparse
from ._core import *

def run_webhook_create(args: argparse.Namespace) -> None:
    """Register a new webhook subscription for a repository.

    Requires write/admin access or repo ownership.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub webhook create --url https://ci.example.com/hook --events push --json
        # → {"muse_version": "...", ..., "webhookId": "...", "url": "...", "events": [...]}

    Exit codes
    ----------
    0  Webhook registered.
    1  Validation or auth error.
    2  Not inside a Muse repository.
    3  API error.
    """
    url: str = args.url
    events: list[str] = args.events
    secret: str = args.secret
    json_output: bool = args.json_output

    if not url.strip():
        print("❌ --url must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    if not events:
        print("❌ --events must include at least one event type.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    data = _hub_api(
        hub_url, identity, "POST",
        f"/api/repos/{repo_id}/webhooks",
        body={"url": url, "events": events, "secret": secret},
    )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    webhook_id = data.get("webhookId", data.get("webhook_id", ""))
    print(f"✅ Webhook registered: {webhook_id}", file=sys.stderr)
    print(f"   URL: {url}", file=sys.stderr)
    print(f"   Events: {', '.join(events)}", file=sys.stderr)

def run_webhook_list(args: argparse.Namespace) -> None:
    """List all webhook subscriptions for a repository.

    Authentication required.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stdout for easy piping.

    Agent quickstart
    ----------------
    ::

        muse hub webhook list --json
        muse hub webhook list --json | jq '.webhooks[].webhookId'

    Exit codes
    ----------
    0  Success.
    1  Auth error.
    2  Not inside a Muse repository.
    3  API error.
    """
    json_output: bool = args.json_output
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    data = _hub_api(hub_url, identity, "GET", f"/api/repos/{repo_id}/webhooks")

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    webhooks = data.get("webhooks", [])
    if not webhooks:
        print("No webhooks registered.", file=sys.stderr)
        return
    for wh in webhooks:
        wid = wh.get("webhookId", wh.get("webhook_id", ""))
        wurl = wh.get("url", "")
        evts = ", ".join(wh.get("events", []))
        print(f"  {wid}  {wurl}  [{evts}]")

def run_webhook_delete(args: argparse.Namespace) -> None:
    """Delete a webhook subscription and all its delivery history.

    Requires write/admin access or repo ownership.

    JSON output includes envelope fields plus ``deleted`` (bool) and
    ``webhook_id`` (str).

    Agent quickstart
    ----------------
    ::

        muse hub webhook delete <webhook-id> --json
        # → {"muse_version": "...", ..., "deleted": true, "webhook_id": "..."}

    Exit codes
    ----------
    0  Webhook deleted.
    1  Auth or not-found error.
    2  Not inside a Muse repository.
    3  API error.
    """
    webhook_id: str = args.webhook_id
    json_output: bool = args.json_output

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    _hub_api(hub_url, identity, "DELETE", f"/api/repos/{repo_id}/webhooks/{webhook_id}")

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **{"deleted": True, "webhook_id": webhook_id}}))
        return

    print(f"✅ Webhook {webhook_id} deleted.", file=sys.stderr)

def run_webhook_delivery_list(args: argparse.Namespace) -> None:
    """List recent deliveries for a webhook on MuseHub.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub webhook delivery-list --webhook-id <id> --json
        muse hub webhook delivery-list --webhook-id <id> --limit 20 --json | jq '.deliveries[].status'

    JSON output keys (from hub): ``deliveries`` (list), ``nextCursor``, ``total``.
    Each delivery: ``deliveryId``, ``event``, ``status``, ``statusCode``,
    ``duration``, ``createdAt``.

    Exit codes
    ----------
    0  Success.
    1  Auth error.
    2  Not inside a Muse repository.
    3  API error.
    """
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    params: dict[str, str | int] = {"limit": args.limit}
    data = _hub_api(hub_url, identity, "GET",
                    f"/api/repos/{repo_id}/webhooks/{args.webhook_id}/deliveries",
                    params=params)

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    deliveries = data.get("deliveries", [])
    if not deliveries:
        print("  No deliveries found.", file=sys.stderr)
        return

    print(f"\n  Deliveries for webhook {args.webhook_id} ({len(deliveries)} shown)", file=sys.stderr)
    print(f"  {'─' * 60}", file=sys.stderr)
    for d in deliveries:
        status = d.get("status", "unknown")
        code = d.get("statusCode", "")
        event = d.get("event", "")
        created = str(d.get("createdAt", ""))[:10]
        print(f"  [{created}] {event}  {status} ({code})", file=sys.stderr)

def run_webhook_redeliver(args: argparse.Namespace) -> None:
    """Re-send a previously attempted webhook delivery.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub webhook redeliver --webhook-id <id> --delivery-id <id> --json
        # → {"muse_version": "...", ..., "deliveryId": "...", "redelivered": true}

    JSON output keys (from hub): ``deliveryId``, ``redelivered``, ``status``.

    Exit codes
    ----------
    0  Redelivery triggered.
    1  Auth error.
    2  Not inside a Muse repository.
    3  API error.
    """
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    data = _hub_api(hub_url, identity, "POST",
                    f"/api/repos/{repo_id}/webhooks/{args.webhook_id}/deliveries/{args.delivery_id}/redeliver")

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"✅ Delivery {args.delivery_id} redelivered.", file=sys.stderr)

def register(subs: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register webhooks subcommands."""
    # ── webhook ───────────────────────────────────────────────────────────────
    webhook_p = subs.add_parser(
        "webhook",
        help="Manage webhook subscriptions on MuseHub.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    webhook_subs = webhook_p.add_subparsers(dest="webhook_subcommand", metavar="WEBHOOK_COMMAND")
    webhook_subs.required = True

    webhook_create_p = webhook_subs.add_parser(
        "create",
        help="Register a new webhook subscription.",
        description=(
            "Register a webhook that receives HTTP POST payloads for repository events.\n"
            "Valid event types: push, proposal, issue, release, branch, tag, session, analysis.\n"
            "Requires write/admin access or repo ownership.\n\n"
            "Agent quickstart:\n"
            "  muse hub webhook create --url https://example.com/hook --events push release --json\n\n"
            "Exit codes: 0 success, 1 validation/auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    webhook_create_p.add_argument(
        "--url", required=True, help="HTTPS URL to receive event payloads.",
    )
    webhook_create_p.add_argument(
        "--events", nargs="+", required=True, metavar="EVENT",
        help="Event types to subscribe to (e.g. push release issue).",
    )
    webhook_create_p.add_argument(
        "--secret", default="", help="HMAC-SHA256 signing secret (optional, plaintext).",
    )
    webhook_create_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    webhook_create_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    webhook_create_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON webhook record on success.",
    )
    webhook_create_p.set_defaults(func=run_webhook_create)

    webhook_list_p = webhook_subs.add_parser(
        "list",
        help="List webhook subscriptions for a repo.",
        description=(
            "List all registered webhook subscriptions for a repository.\n\n"
            "Agent quickstart:\n"
            "  muse hub webhook list --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    webhook_list_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    webhook_list_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    webhook_list_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON list of webhooks.",
    )
    webhook_list_p.set_defaults(func=run_webhook_list)

    webhook_delete_p = webhook_subs.add_parser(
        "delete",
        help="Delete a webhook subscription.",
        description=(
            "Delete a webhook subscription and all its delivery history.\n"
            "Requires write/admin access or repo ownership.\n\n"
            "Agent quickstart:\n"
            "  muse hub webhook delete <webhook-id> --json\n\n"
            "Exit codes: 0 success, 1 auth/not-found error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    webhook_delete_p.add_argument("webhook_id", help="ID of the webhook to delete.")
    webhook_delete_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    webhook_delete_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    webhook_delete_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON confirmation on success.",
    )
    webhook_delete_p.set_defaults(func=run_webhook_delete)

    webhook_p.set_defaults(func=lambda a: webhook_p.print_help())

    # ── webhook deliveries ────────────────────────────────────────────────────
    # Extend existing webhook subparser with delivery commands
    webhook_delivery_list_p = webhook_subs.add_parser(
        "delivery-list", help="List webhook deliveries.",
        description=(
            "List recent deliveries for a webhook.\n\n"
            "  muse hub webhook delivery-list --webhook-id <id>\n"
            "  muse hub webhook delivery-list --webhook-id <id> --limit 20 --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    webhook_delivery_list_p.add_argument("--hub", dest="hub", default=None, metavar="URL",
                                         help="Override the hub URL from config.")
    webhook_delivery_list_p.add_argument("--repo", dest="repo", default=None, metavar="OWNER/REPO",
                                         help="Specify repo as owner/repo.")
    webhook_delivery_list_p.add_argument("--webhook-id", dest="webhook_id", required=True,
                                         help="ID of the webhook.")
    webhook_delivery_list_p.add_argument("--limit", type=int, default=20, metavar="N",
                                         help="Max deliveries to return (default 20).")
    webhook_delivery_list_p.add_argument("--json", "-j", action="store_true", dest="json_output",
                                         help="Emit JSON output.")
    webhook_delivery_list_p.set_defaults(func=run_webhook_delivery_list)

    webhook_redeliver_p = webhook_subs.add_parser(
        "redeliver", help="Redeliver a webhook delivery.",
        description=(
            "Re-send a previously attempted webhook delivery.\n\n"
            "  muse hub webhook redeliver --webhook-id <id> --delivery-id <id>\n"
            "  muse hub webhook redeliver --webhook-id <id> --delivery-id <id> --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    webhook_redeliver_p.add_argument("--hub", dest="hub", default=None, metavar="URL",
                                     help="Override the hub URL from config.")
    webhook_redeliver_p.add_argument("--repo", dest="repo", default=None, metavar="OWNER/REPO",
                                     help="Specify repo as owner/repo.")
    webhook_redeliver_p.add_argument("--webhook-id", dest="webhook_id", required=True,
                                     help="ID of the webhook.")
    webhook_redeliver_p.add_argument("--delivery-id", dest="delivery_id", required=True,
                                     help="ID of the delivery to redeliver.")
    webhook_redeliver_p.add_argument("--json", "-j", action="store_true", dest="json_output",
                                     help="Emit JSON output.")
    webhook_redeliver_p.set_defaults(func=run_webhook_redeliver)

