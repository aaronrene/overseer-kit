import argparse
import urllib.parse
from ._core import *

def run_release_list(args: argparse.Namespace) -> None:
    """List releases for the repo on MuseHub, newest first.

    Supports cursor pagination.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub release list --json
        muse hub release list --limit 10 --json | jq '.releases[].tag'
        muse hub release list --cursor <token> --json

    JSON output keys (from hub): ``releases`` (list), ``nextCursor``
    (str|null), ``total`` (int).  Each release: ``tag``, ``title``,
    ``channel``, ``isDraft``, ``createdAt``, ``assetCount``.

    Exit codes
    ----------
    0  Success (including empty list).
    1  Validation or auth error.
    2  Not inside a Muse repository.
    3  API error.
    """
    json_output: bool = args.json_output
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    params: dict[str, str | int] = {"limit": args.limit}
    if args.cursor:
        params["cursor"] = args.cursor
    query = urllib.parse.urlencode(params)

    data = _hub_api(hub_url, identity, "GET", f"/api/repos/{repo_id}/releases?{query}")

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    releases = data.get("releases", [])
    if not releases:
        print("  No releases found.", file=sys.stderr)
        return

    print(f"\n  Releases ({len(releases)} shown)", file=sys.stderr)
    print(f"  {'─' * 50}", file=sys.stderr)
    for r in releases:
        draft = " [draft]" if r.get("isDraft") else ""
        channel = r.get("channel", "stable")
        print(f"  {r.get('tag')}  {r.get('title', '')}  ({channel}){draft}", file=sys.stderr)
    next_c = data.get("nextCursor")
    if next_c:
        print(f"\n  (more — pass --cursor {next_c})", file=sys.stderr)

def run_release_create(args: argparse.Namespace) -> None:
    """Create a new release for the repo on MuseHub.

    Tag must be a valid semver string (e.g. ``v1.0.0``, ``v2.0.0-beta.1``).

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub release create --tag v1.0.0 --title 'First release' --json
        muse hub release create --tag v1.0.0 --body 'Notes' --channel beta --json
        # → {"muse_version": "...", ..., "releaseId": "...", "tag": "v1.0.0"}

    JSON output keys (from hub): ``releaseId``, ``tag``, ``title``,
    ``channel``, ``isDraft``, ``createdAt``.

    Exit codes
    ----------
    0  Release created.
    1  Validation or auth error.
    2  Not inside a Muse repository.
    3  API error (409 if tag already exists).
    """
    if not args.tag.strip():
        print("❌ --tag must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    payload = {
        "tag": args.tag,
        "title": args.title,
        "body": _resolve_body(args),
        "channel": args.channel,
        "isDraft": args.is_draft,
    }
    if args.commit_id:
        payload["commitId"] = args.commit_id

    data = _hub_api(hub_url, identity, "POST", f"/api/repos/{repo_id}/releases", body=payload)

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"✅ Release {data.get('tag')} created (id={str(data.get('releaseId',''))}).", file=sys.stderr)

def run_release_read(args: argparse.Namespace) -> None:
    """Fetch a single release by tag from MuseHub.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub release read v1.0.0 --json
        muse hub release read v1.0.0 --json | jq '{tag,title,channel,isDraft}'

    JSON output keys (from hub): ``releaseId``, ``tag``, ``title``, ``body``,
    ``channel``, ``isDraft``, ``commitId``, ``assetCount``, ``createdAt``,
    ``downloadStats``.

    Exit codes
    ----------
    0  Success.
    1  Auth error.
    2  Not inside a Muse repository.
    3  API error (404 if tag not found).
    """
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    data = _hub_api(hub_url, identity, "GET", f"/api/repos/{repo_id}/releases/{args.tag}")

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"\n  Release: {data.get('tag')}  {data.get('title', '')}", file=sys.stderr)
    print(f"  Channel: {data.get('channel', 'stable')}  Draft: {data.get('isDraft', False)}", file=sys.stderr)
    if data.get("body"):
        print(f"\n  {data['body'][:200]}", file=sys.stderr)

def run_release_delete(args: argparse.Namespace) -> None:
    """Delete a release and its assets from MuseHub.

    JSON output includes envelope fields plus ``deleted`` (bool) and
    ``tag`` (str).

    Agent quickstart
    ----------------
    ::

        muse hub release delete v1.0.0 --json
        # → {"muse_version": "...", ..., "deleted": true, "tag": "v1.0.0"}

    Exit codes
    ----------
    0  Deleted.
    1  Auth error.
    2  Not inside a Muse repository.
    3  API error (404 if tag not found).
    """
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    _hub_api(hub_url, identity, "DELETE", f"/api/repos/{repo_id}/releases/{args.tag}")

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **{"deleted": True, "tag": args.tag}}))
        return

    print(f"✅ Release {args.tag} deleted.", file=sys.stderr)

def run_release_asset_list(args: argparse.Namespace) -> None:
    """List assets attached to a release.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub release asset-list v1.0.0 --json
        muse hub release asset-list v1.0.0 --json | jq '.assets[].downloadUrl'

    JSON output keys (from hub): ``assets`` (list), ``nextCursor``, ``total``.
    Each asset: ``assetId``, ``name``, ``label``, ``contentType``, ``size``,
    ``downloadUrl``, ``downloadCount``.

    Exit codes
    ----------
    0  Success.
    1  Auth error.
    2  Not inside a Muse repository.
    3  API error.
    """
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    data = _hub_api(hub_url, identity, "GET", f"/api/repos/{repo_id}/releases/{args.tag}/assets")

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    assets = data.get("assets", [])
    if not assets:
        print(f"  No assets for release {args.tag}.", file=sys.stderr)
        return

    print(f"\n  Assets for {args.tag} ({len(assets)} total)", file=sys.stderr)
    print(f"  {'─' * 50}", file=sys.stderr)
    for a in assets:
        size_kb = int(a.get("size", 0)) // 1024
        dl = a.get("downloadCount", 0)
        print(f"  {a.get('name')}  {size_kb}KB  {dl} downloads  {a.get('downloadUrl', '')[:60]}", file=sys.stderr)

def run_release_asset_attach(args: argparse.Namespace) -> None:
    """Attach a downloadable asset to a release on MuseHub.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub release asset-attach v1.0.0 --name track.mid --url https://cdn.example.com/track.mid --json
        muse hub release asset-attach v1.0.0 --name mpack.zip --url <url> --content-type application/zip --json
        # → {"muse_version": "...", ..., "assetId": "...", "name": "track.mid"}

    JSON output keys (from hub): ``assetId``, ``name``, ``label``,
    ``contentType``, ``size``, ``downloadUrl``.

    Exit codes
    ----------
    0  Asset attached.
    1  Auth error.
    2  Not inside a Muse repository.
    3  API error.
    """
    if not args.name.strip():
        print("❌ --name must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    if not args.download_url.strip():
        print("❌ --url must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    payload = {
        "name": args.name,
        "label": args.label,
        "contentType": args.content_type,
        "size": args.size,
        "downloadUrl": args.download_url,
    }

    data = _hub_api(hub_url, identity, "POST",
                    f"/api/repos/{repo_id}/releases/{args.tag}/assets", body=payload)

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"✅ Asset '{data.get('name')}' attached to release {args.tag}.", file=sys.stderr)

def run_release_asset_delete(args: argparse.Namespace) -> None:
    """Remove an asset from a release on MuseHub.

    JSON output includes envelope fields plus ``deleted`` (bool) and
    ``assetId`` (str).

    Agent quickstart
    ----------------
    ::

        muse hub release asset-delete v1.0.0 --asset-id <id> --json
        # → {"muse_version": "...", ..., "deleted": true, "assetId": "..."}

    Exit codes
    ----------
    0  Deleted.
    1  Auth error.
    2  Not inside a Muse repository.
    3  API error (404 if asset not found).
    """
    if not args.asset_id.strip():
        print("❌ --asset-id must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    _hub_api(hub_url, identity, "DELETE",
             f"/api/repos/{repo_id}/releases/{args.tag}/assets/{args.asset_id}")

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **{"deleted": True, "assetId": args.asset_id}}))
        return

    print(f"✅ Asset {args.asset_id} deleted from release {args.tag}.", file=sys.stderr)

def register(subs: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register releases subcommands."""
    # ── release ───────────────────────────────────────────────────────────────
    release_p = subs.add_parser(
        "release",
        help="Manage releases on MuseHub.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    release_subs = release_p.add_subparsers(dest="release_subcommand", metavar="RELEASE_COMMAND")
    release_subs.required = True

    def _release_repo_args(p: argparse.ArgumentParser) -> None:
        p.add_argument("--hub", dest="hub", default=None, metavar="URL",
                       help="Override the hub URL from config.")
        p.add_argument("--repo", dest="repo", default=None, metavar="OWNER/REPO",
                       help="Specify repo as owner/repo.")
        p.add_argument("--json", "-j", action="store_true", dest="json_output",
                       help="Emit JSON output.")

    # release list
    release_list_p = release_subs.add_parser(
        "list", help="List releases.",
        description=(
            "List all releases for the repo, newest first.\n\n"
            "  muse hub release list\n"
            "  muse hub release list --limit 10 --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _release_repo_args(release_list_p)
    release_list_p.add_argument("--limit", type=int, default=20, metavar="N",
                                help="Max releases to return (default 20).")
    release_list_p.add_argument("--cursor", default=None, metavar="CURSOR",
                                help="Pagination cursor.")
    release_list_p.set_defaults(func=run_release_list)

    # release create
    release_create_p = release_subs.add_parser(
        "create", help="Create a new release.",
        description=(
            "Create a new release for the repo.\n\n"
            "  muse hub release create --tag v1.0.0 --title 'First release'\n"
            "  muse hub release create --tag v1.0.0 --body 'Notes' --channel stable --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _release_repo_args(release_create_p)
    release_create_p.add_argument("--tag", required=True, help="Semver tag, e.g. v1.0.0.")
    release_create_p.add_argument("--title", default="", help="Release title.")
    release_create_p.add_argument("--body", default="", help="Release notes (Markdown, inline text).")
    release_create_p.add_argument(
        "--body-file", default=None, metavar="PATH", dest="body_file",
        help="Read release notes from PATH. Pass '-' for stdin. Takes precedence over --body.",
    )
    release_create_p.add_argument("--commit-id", dest="commit_id", default=None,
                                  help="Pin release to a specific commit ID.")
    release_create_p.add_argument(
        "--channel", default="stable",
        choices=["stable", "beta", "alpha", "nightly"],
        help="Distribution channel (default: stable).",
    )
    release_create_p.add_argument("--draft", action="store_true", dest="is_draft",
                                  help="Save as draft — not yet publicly visible.")
    release_create_p.set_defaults(func=run_release_create)

    # release read
    release_read_p = release_subs.add_parser(
        "read", help="Read a release by tag.",
        description=(
            "Fetch a single release by its tag.\n\n"
            "  muse hub release read v1.0.0\n"
            "  muse hub release read v1.0.0 --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _release_repo_args(release_read_p)
    release_read_p.add_argument("tag", help="Release tag, e.g. v1.0.0.")
    release_read_p.set_defaults(func=run_release_read)

    # release delete
    release_delete_p = release_subs.add_parser(
        "delete", help="Delete a release by tag.",
        description=(
            "Delete a release. Assets attached to the release are also removed.\n\n"
            "  muse hub release delete v1.0.0\n"
            "  muse hub release delete v1.0.0 --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _release_repo_args(release_delete_p)
    release_delete_p.add_argument("tag", help="Release tag to delete.")
    release_delete_p.set_defaults(func=run_release_delete)

    # release asset-list
    release_asset_list_p = release_subs.add_parser(
        "asset-list", help="List assets attached to a release.",
        description=(
            "List all assets for a release.\n\n"
            "  muse hub release asset-list v1.0.0\n"
            "  muse hub release asset-list v1.0.0 --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _release_repo_args(release_asset_list_p)
    release_asset_list_p.add_argument("tag", help="Release tag.")
    release_asset_list_p.set_defaults(func=run_release_asset_list)

    # release asset-attach
    release_asset_attach_p = release_subs.add_parser(
        "asset-attach", help="Attach an asset to a release.",
        description=(
            "Attach a downloadable asset to a release.\n\n"
            "  muse hub release asset-attach v1.0.0 --name track.mid --url https://cdn.example.com/track.mid\n"
            "  muse hub release asset-attach v1.0.0 --name mpack.zip --url <url> --content-type application/zip --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _release_repo_args(release_asset_attach_p)
    release_asset_attach_p.add_argument("tag", help="Release tag.")
    release_asset_attach_p.add_argument("--name", required=True, help="Filename shown in the UI.")
    release_asset_attach_p.add_argument("--url", required=True, dest="download_url",
                                        help="Direct download URL for the asset.")
    release_asset_attach_p.add_argument("--label", default="", help="Human-readable label.")
    release_asset_attach_p.add_argument("--content-type", dest="content_type", default="",
                                        help="MIME type, e.g. audio/midi.")
    release_asset_attach_p.add_argument("--size", type=int, default=0,
                                        help="File size in bytes (0 if unknown).")
    release_asset_attach_p.set_defaults(func=run_release_asset_attach)

    # release asset-delete
    release_asset_delete_p = release_subs.add_parser(
        "asset-delete", help="Delete an asset from a release.",
        description=(
            "Remove an asset from a release by asset ID.\n\n"
            "  muse hub release asset-delete v1.0.0 --asset-id <id>\n"
            "  muse hub release asset-delete v1.0.0 --asset-id <id> --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _release_repo_args(release_asset_delete_p)
    release_asset_delete_p.add_argument("tag", help="Release tag.")
    release_asset_delete_p.add_argument("--asset-id", dest="asset_id", required=True,
                                        help="ID of the asset to delete.")
    release_asset_delete_p.set_defaults(func=run_release_asset_delete)

    release_p.set_defaults(func=lambda a: release_p.print_help())

