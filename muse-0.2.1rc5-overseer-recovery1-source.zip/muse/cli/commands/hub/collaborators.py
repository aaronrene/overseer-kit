import argparse
from ._core import *

def run_collaborator_list(args: argparse.Namespace) -> None:
    """List all collaborators and their permission levels for a repository.

    Returns the list ordered by permission level.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stdout for easy piping.

    Agent quickstart
    ----------------
    ::

        muse hub collaborator list --json
        muse hub collaborator list --json | jq '.collaborators[].handle'

    Exit codes
    ----------
    0  Success.
    1  Auth error.
    2  Not inside a Muse repository.
    3  API error.
    """
    json_output: bool = args.json_output
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    data = _hub_api(hub_url, identity, "GET", f"/api/repos/{repo_id}/collaborators")

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    collaborators = data.get("collaborators", [])
    if not collaborators:
        print("No collaborators.", file=sys.stderr)
        return
    for c in collaborators:
        handle = c.get("handle", "")
        perm = c.get("permission", "")
        print(f"  {handle:<32}  {perm}")

def run_collaborator_invite(args: argparse.Namespace) -> None:
    """Invite a user as a collaborator on a repository.

    Requires admin or owner access.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub collaborator invite carol --permission write --json
        muse hub collaborator invite carol --permission admin --json
        # → {"muse_version": "...", ..., "handle": "carol", "permission": "write"}

    Exit codes
    ----------
    0  Collaborator invited.
    1  Auth or conflict error.
    2  Not inside a Muse repository.
    3  API error.
    """
    handle: str = args.handle
    permission: str = args.permission
    json_output: bool = args.json_output

    if not handle.strip():
        print("❌ Handle must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    data = _hub_api(
        hub_url, identity, "POST",
        f"/api/repos/{repo_id}/collaborators",
        body={"handle": handle, "permission": permission},
    )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"✅ Invited '{sanitize_display(handle)}' as {permission} collaborator.", file=sys.stderr)

def run_collaborator_accept(args: argparse.Namespace) -> None:
    """Accept your own pending collaborator invitation on a repository.

    Self-service — accepts the invitation addressed to your own authenticated
    identity; there is no target handle. Idempotent: accepting an
    already-accepted invitation succeeds. Until this is called, an invited
    collaborator's granted permission cannot be exercised (musehub#193) —
    every write requiring admin/write access will 403.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub collaborator accept --json
        # → {"muse_version": "...", ..., "handle": "carol", "accepted": true}

    Exit codes
    ----------
    0  Invitation accepted (or already accepted).
    1  Auth error or no pending invitation found.
    2  Not inside a Muse repository.
    3  API error.
    """
    json_output: bool = args.json_output

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    data = _hub_api(hub_url, identity, "POST", f"/api/repos/{repo_id}/collaborators/accept")

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print("✅ Invitation accepted.", file=sys.stderr)

def run_collaborator_update_permission(args: argparse.Namespace) -> None:
    """Update a collaborator's permission level.

    Requires admin or owner access.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub collaborator update-permission carol --permission admin --json
        muse hub collaborator update-permission carol --permission read --json
        # → {"muse_version": "...", ..., "handle": "carol", "permission": "admin"}

    Exit codes
    ----------
    0  Permission updated.
    1  Auth or not-found error.
    2  Not inside a Muse repository.
    3  API error.
    """
    handle: str = args.handle
    permission: str = args.permission
    json_output: bool = args.json_output

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    data = _hub_api(
        hub_url, identity, "PUT",
        f"/api/repos/{repo_id}/collaborators/{handle}/permission",
        body={"permission": permission},
    )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"✅ Updated '{sanitize_display(handle)}' permission to {permission}.", file=sys.stderr)

def run_collaborator_remove(args: argparse.Namespace) -> None:
    """Remove a collaborator from a repository.

    Requires admin or owner access. The owner cannot be removed.

    JSON output includes envelope fields plus ``removed`` (bool) and
    ``handle`` (str).

    Agent quickstart
    ----------------
    ::

        muse hub collaborator remove carol --json
        # → {"muse_version": "...", ..., "removed": true, "handle": "carol"}

    Exit codes
    ----------
    0  Collaborator removed.
    1  Auth or not-found error.
    2  Not inside a Muse repository.
    3  API error.
    """
    handle: str = args.handle
    json_output: bool = args.json_output

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    _hub_api(hub_url, identity, "DELETE", f"/api/repos/{repo_id}/collaborators/{handle}")

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **{"removed": True, "handle": handle}}))
        return

    print(f"✅ Removed '{sanitize_display(handle)}' from collaborators.", file=sys.stderr)

def register(subs: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register collaborators subcommands."""
    # ── collaborator ──────────────────────────────────────────────────────────
    collab_p = subs.add_parser(
        "collaborator",
        help="Manage repository collaborators on MuseHub.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    collab_subs = collab_p.add_subparsers(dest="collaborator_subcommand", metavar="COLLAB_COMMAND")
    collab_subs.required = True

    collab_list_p = collab_subs.add_parser(
        "list",
        help="List collaborators on a repo.",
        description=(
            "List all collaborators and their permission levels for a repository.\n\n"
            "Agent quickstart:\n"
            "  muse hub collaborator list --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    collab_list_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    collab_list_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    collab_list_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON list of collaborators.",
    )
    collab_list_p.set_defaults(func=run_collaborator_list)

    collab_invite_p = collab_subs.add_parser(
        "invite",
        help="Invite a user as a collaborator.",
        description=(
            "Invite a user to collaborate on a repository.\n"
            "Requires admin or owner access.\n\n"
            "Agent quickstart:\n"
            "  muse hub collaborator invite carol --permission write --json\n\n"
            "Exit codes: 0 success, 1 auth/conflict error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    collab_invite_p.add_argument("handle", help="MSign handle of the user to invite.")
    collab_invite_p.add_argument(
        "--permission", "-p", default="write", choices=["read", "write", "admin"],
        help="Permission level: read, write (default), or admin.",
    )
    collab_invite_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    collab_invite_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    collab_invite_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON collaborator record on success.",
    )
    collab_invite_p.set_defaults(func=run_collaborator_invite)

    collab_accept_p = collab_subs.add_parser(
        "accept",
        help="Accept your own pending collaborator invitation.",
        description=(
            "Accept your own pending invitation to a repository. Self-service\n"
            "— there is no target handle. Idempotent.\n\n"
            "Agent quickstart:\n"
            "  muse hub collaborator accept --json\n\n"
            "Exit codes: 0 success, 1 auth/no-invite error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    collab_accept_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    collab_accept_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    collab_accept_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the accepted collaborator record.",
    )
    collab_accept_p.set_defaults(func=run_collaborator_accept)

    collab_update_permission_p = collab_subs.add_parser(
        "update-permission",
        help="Update a collaborator's permission level.",
        description=(
            "Update an existing collaborator's permission level.\n"
            "Requires admin or owner access.\n\n"
            "Agent quickstart:\n"
            "  muse hub collaborator update-permission carol --permission admin --json\n\n"
            "Exit codes: 0 success, 1 auth/not-found error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    collab_update_permission_p.add_argument("handle", help="MSign handle of the collaborator to update.")
    collab_update_permission_p.add_argument(
        "--permission", "-p", required=True, choices=["read", "write", "admin"],
        help="New permission level.",
    )
    collab_update_permission_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    collab_update_permission_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    collab_update_permission_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the updated collaborator record.",
    )
    collab_update_permission_p.set_defaults(func=run_collaborator_update_permission)

    collab_remove_p = collab_subs.add_parser(
        "remove",
        help="Remove a collaborator from a repo.",
        description=(
            "Remove a collaborator from a repository.\n"
            "Requires admin or owner access. The owner cannot be removed.\n\n"
            "Agent quickstart:\n"
            "  muse hub collaborator remove carol --json\n\n"
            "Exit codes: 0 success, 1 auth/not-found error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    collab_remove_p.add_argument("handle", help="MSign handle of the collaborator to remove.")
    collab_remove_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    collab_remove_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    collab_remove_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON confirmation on success.",
    )
    collab_remove_p.set_defaults(func=run_collaborator_remove)

    collab_p.set_defaults(func=lambda a: collab_p.print_help())

