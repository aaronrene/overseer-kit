import argparse
from ._core import *

def run_connect(args: argparse.Namespace) -> None:
    """Attach this repository to a MuseHub instance.

    Writes ``[hub] url`` to ``.muse/config.toml``.  Does **not** modify
    credentials — authenticate separately with ``muse auth register``.

    URL normalisation
    -----------------
    - Bare hostnames (``musehub.ai``) are promoted to ``https://musehub.ai``.
    - Trailing slashes are stripped.
    - ``http://`` is rejected for non-loopback hosts; loopback addresses
      (``localhost``, ``127.0.0.1``, ``[::1]``) are accepted for local dev.
    - Disallowed schemes (``file://``, ``ftp://``, etc.) are rejected.

    Idempotent
    ----------
    Re-connecting to the same hub URL is a no-op (no warning, no write).
    Connecting to a *different* hub prints a warning on stderr and overwrites
    the stored URL.

    Agent quickstart
    ----------------
    ::

        muse hub connect https://musehub.ai --json && muse auth register --agent --json

    JSON output (``--json``, stdout)
    --------------------------------
    ::

        {
          "status":         "ok",
          "hub_url":        "https://musehub.ai",   ← normalised URL, no trailing slash
          "hostname":       "musehub.ai",            ← host[:port] display string
          "authenticated":  true | false,            ← true if identity stored
          "identity_name":  "<name>" | "",           ← display name or empty string
          "identity_type":  "human" | "agent" | ""  ← identity type or empty string
        }

    All diagnostic messages (warnings, errors) always go to stderr.

    Exit codes
    ----------
    0  Connected successfully (or no-op re-connect to same hub).
    1  Bad URL: disallowed scheme, http:// for non-loopback host.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    url: str = args.url
    json_output: bool = args.json_output

    root = find_repo_root()
    if root is None:
        print("❌ Not inside a Muse repository. Run `muse init` first.", file=sys.stderr)
        raise SystemExit(ExitCode.REPO_NOT_FOUND)

    try:
        normalised = _normalise_url(url)
    except ValueError as exc:
        print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR) from exc
    hostname = _hub_hostname(normalised)

    # Warn before overwriting an existing connection.
    existing = get_hub_url(root)
    if existing and existing != normalised:
        existing_host = _hub_hostname(existing)
        print(
            f"⚠️  This repo was connected to {sanitize_display(existing_host)}.\n"
            f"   Switching to {sanitize_display(hostname)}.\n"
            f"   Your credentials for {sanitize_display(existing_host)} remain "
            "in ~/.muse/identity.toml.\n"
            f"   To remove them: muse auth logout --hub {sanitize_display(existing_host)}",
            file=sys.stderr,
        )

    set_hub_url(normalised, root)

    identity = load_identity(normalised)
    authenticated = identity is not None
    identity_name = ""
    identity_type = ""
    if identity is not None:
        identity_name = str(identity.get("handle") or "")
        identity_type = str(identity.get("type") or "")

    if json_output:
        payload = {**make_envelope(elapsed), **{
            "status": "ok",
            "hub_url": normalised,
            "hostname": hostname,
            "authenticated": authenticated,
            "identity_name": identity_name,
            "identity_type": identity_type,
        }}
        payload.pop("timestamp", None)
        payload.pop("duration_ms", None)
        print(json.dumps(payload))
    else:
        print(f"✅ Connected to {sanitize_display(hostname)}", file=sys.stderr)
        if authenticated:
            print(
                f"   Authenticated as {sanitize_display(identity_type)} "
                f"'{sanitize_display(identity_name)}'",
                file=sys.stderr,
            )
        else:
            print("   No identity stored yet — run: muse auth register", file=sys.stderr)

def run_status(args: argparse.Namespace) -> None:
    """Show the hub connection and identity for this repository.

    Reads ``.muse/config.toml`` for the hub URL and ``~/.muse/identity.toml``
    for the stored identity.  Makes **no network calls**.

    ``--hub`` override
    ------------------
    Pass ``--hub <url>`` to inspect a hub URL that differs from the one stored
    in ``.muse/config.toml``.  Useful for containerised agents that reach the
    hub at a different address (e.g. ``http://host.docker.internal:10003``).
    The override is not persisted.

    Agent quickstart
    ----------------
    ::

        muse hub status --json || muse hub connect https://musehub.ai --json

    JSON output (``--json``, stdout)
    --------------------------------
    All keys are always present — agents never receive a ``KeyError``::

        {
          "hub_url":      "https://musehub.ai",   ← URL as stored in config
          "hostname":     "musehub.ai",            ← host[:port] display form
          "authenticated": true | false,
          "identity_type": "human" | "agent" | "", ← "" when not authenticated
          "identity_name": "<name>" | "",
          "identity_id":   "<id>"  | "",
          "capabilities":  ["read:*", ...] | []    ← [] for humans / unauthenticated
        }

    All text output (labels, warnings, errors) goes to stderr.

    Exit codes
    ----------
    0  Status printed successfully.
    1  No hub connected (no ``[hub] url`` in config and no ``--hub`` override).
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_output: bool = args.json_output

    root = find_repo_root()
    if root is None:
        print("❌ Not inside a Muse repository.", file=sys.stderr)
        raise SystemExit(ExitCode.REPO_NOT_FOUND)

    hub_url = args.hub or get_hub_url(root)
    if hub_url is None:
        print("No hub connected.\nRun: muse hub connect <url>", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    hostname = _hub_hostname(hub_url)
    identity = load_identity(hub_url)

    authenticated = identity is not None
    identity_type = str(identity.get("type") or "") if identity else ""
    identity_name = str(identity.get("handle") or "") if identity else ""
    identity_id = str(identity.get("fingerprint") or "") if identity else ""
    capabilities: list[str] = list(identity.get("capabilities") or []) if identity else []

    if json_output:
        payload = {**make_envelope(elapsed), **{
            "hub_url": hub_url,
            "hostname": hostname,
            "authenticated": authenticated,
            "identity_type": identity_type,
            "identity_name": identity_name,
            "identity_id": identity_id,
            "capabilities": capabilities,
        }}
        payload.pop("timestamp", None)
        payload.pop("duration_ms", None)
        print(json.dumps(payload))
        return

    print("", file=sys.stderr)
    print("  Hub", file=sys.stderr)
    print(f"    URL:       {sanitize_display(hub_url)}", file=sys.stderr)

    if not authenticated:
        print("    Auth:      not authenticated — run `muse auth register`", file=sys.stderr)
    else:
        handle = identity.get("handle", "") if identity else ""
        fingerprint = identity.get("fingerprint", "") if identity else ""
        print(f"    Type:      {sanitize_display(identity_type) or 'unknown'}", file=sys.stderr)
        print(f"    Name:      {sanitize_display(identity_name) or '—'}", file=sys.stderr)
        print(f"    ID:        {sanitize_display(identity_id) or '—'}", file=sys.stderr)
        print(
            f"    Auth:      {'Ed25519 key set (handle: ' + handle + ')' if handle else 'not set — run muse auth keygen'}",
            file=sys.stderr,
        )
        if capabilities:
            caps_display = " ".join(sanitize_display(str(c)) for c in capabilities)
            print(f"    Caps:      {caps_display}", file=sys.stderr)

    print("", file=sys.stderr)

def run_disconnect(args: argparse.Namespace) -> None:
    """Remove the hub association from this repository.

    Removes ``[hub] url`` from ``.muse/config.toml``.  Credentials in
    ``~/.muse/identity.toml`` are **preserved** — use ``muse auth logout``
    to remove them as well.  Makes no network calls.

    Idempotent
    ----------
    Disconnecting when no hub is configured exits 0 with
    ``status: "nothing_to_do"`` — safe to call unconditionally in scripts.

    Agent quickstart
    ----------------
    Full teardown (disconnect + revoke credentials)::

        muse hub disconnect --json | python3 -c "
        import json, subprocess, sys
        d = json.load(sys.stdin)
        if d['hub_url']:
            subprocess.run(['muse', 'auth', 'logout', '--hub', d['hub_url']], check=True)
        "

    JSON output (``--json``, stdout)
    --------------------------------
    ::

        {
          "status":   "ok" | "nothing_to_do",
          "hub_url":  "<url>" | "",   ← full normalised URL; "" on nothing_to_do
          "hostname": "<host>" | ""   ← host[:port]; "" on nothing_to_do
        }

    All text (success messages, hints) goes to stderr.

    Exit codes
    ----------
    0  Disconnected successfully, or nothing was connected.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_output: bool = args.json_output

    root = find_repo_root()
    if root is None:
        print("❌ Not inside a Muse repository.", file=sys.stderr)
        raise SystemExit(ExitCode.REPO_NOT_FOUND)

    hub_url = get_hub_url(root)
    if hub_url is None:
        if json_output:
            print(json.dumps({**make_envelope(elapsed), **{
                "status": "nothing_to_do",
                "hub_url": "",
                "hostname": "",
            }}))
        else:
            print("No hub connected — nothing to do.", file=sys.stderr)
        return

    hostname = _hub_hostname(hub_url)
    clear_hub_url(root)

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **{
            "status": "ok",
            "hub_url": hub_url,
            "hostname": hostname,
        }}))
    else:
        print(f"✅ Disconnected from {sanitize_display(hostname)}.", file=sys.stderr)
        print(
            "   Credentials in ~/.muse/identity.toml are preserved.\n"
            f"   To remove them too: muse auth logout --hub {sanitize_display(hub_url)}",
            file=sys.stderr,
        )

def run_ping(args: argparse.Namespace) -> None:
    """Test HTTP connectivity to the configured hub.

    Sends a ``GET <hub_url>/health`` request and reports the result.
    No authentication token is sent — the health endpoint is intentionally
    unauthenticated.  HTTP redirects are refused (the hub URL in config
    should be the final destination).

    ``--hub`` override
    ------------------
    Pass ``--hub <url>`` to test a URL that differs from the one in config
    (e.g. for containerised agents: ``--hub http://host.docker.internal:10003``).
    The URL is not persisted.

    Agent quickstart
    ----------------
    Health-check before any operation::

        muse hub ping --json || { echo "hub unreachable"; exit 1; }

    Startup readiness loop::

        until muse hub ping --json 2>/dev/null; do sleep 2; done

    JSON output (``--json``, stdout)
    --------------------------------
    ::

        {
          "status":    "ok" | "error",
          "hub_url":   "<url>",          ← URL that was pinged
          "hostname":  "<host[:port]>",
          "reachable": true | false,
          "message":   "HTTP 200 OK" | "<error reason>"
        }

    All text output (progress, errors) goes to stderr.

    Exit codes
    ----------
    0  Hub reachable (HTTP 2xx).
    1  No hub connected (no ``[hub] url`` in config and no ``--hub`` flag).
    2  Not inside a Muse repository.
    5  Hub unreachable (connection refused, timeout, non-2xx, bad response).
    """
    elapsed = start_timer()
    json_output: bool = args.json_output

    root = find_repo_root()
    if root is None:
        print("❌ Not inside a Muse repository.", file=sys.stderr)
        raise SystemExit(ExitCode.REPO_NOT_FOUND)

    hub_url = args.hub or get_hub_url(root)
    if hub_url is None:
        print("No hub connected.\nRun: muse hub connect <url>", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    hostname = _hub_hostname(hub_url)

    if not json_output:
        print(f"Pinging {sanitize_display(hostname)}…", end="", flush=True, file=sys.stderr)

    reachable, message = _ping_hub(hub_url)

    if json_output:
        payload = {**make_envelope(elapsed), **{
            "status": "ok" if reachable else "error",
            "hub_url": hub_url,
            "hostname": hostname,
            "reachable": reachable,
            "message": message,
        }}
        payload.pop("timestamp", None)
        payload.pop("duration_ms", None)
        print(json.dumps(payload))
        if not reachable:
            raise SystemExit(ExitCode.REMOTE_ERROR)
    else:
        if reachable:
            print(f" ✅ {sanitize_display(message)}", file=sys.stderr)
        else:
            print(f" ❌ {sanitize_display(message)}", file=sys.stderr)
            raise SystemExit(ExitCode.REMOTE_ERROR)

def register(subs: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register connection subcommands."""
    # ── connect ───────────────────────────────────────────────────────────────
    connect_p = subs.add_parser(
        "connect",
        help="Attach this repository to a MuseHub instance.",
        description=(
            "Write [hub] url to .muse/config.toml and confirm auth status.\n"
            "Does not touch credentials — authenticate with 'muse auth register'.\n\n"
            "URL is normalised: bare hostnames gain https://, trailing slashes\n"
            "are stripped, http:// is rejected for non-loopback hosts.\n\n"
            "Agent quickstart:\n"
            "  muse hub connect https://musehub.ai --json && muse auth register --agent --json\n\n"
            "JSON output keys: status, hub_url, hostname, authenticated,\n"
            "                  identity_name, identity_type"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    connect_p.add_argument(
        "url", metavar="URL",
        help="MuseHub URL (e.g. https://musehub.ai or just musehub.ai).",
    )
    connect_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output", default=False,
        help="Emit a JSON object to stdout on success.",
    )
    connect_p.set_defaults(func=run_connect)

    # ── disconnect ────────────────────────────────────────────────────────────
    disconnect_p = subs.add_parser(
        "disconnect",
        help="Remove the hub association from this repository.",
        description=(
            "Remove [hub] url from .muse/config.toml.  Credentials in\n"
            "~/.muse/identity.toml are preserved — use 'muse auth logout'\n"
            "to remove them too.  Makes no network calls.\n\n"
            "Operation is idempotent: exits 0 with status 'nothing_to_do'\n"
            "when no hub is configured.\n\n"
            "Agent quickstart:\n"
            "  muse hub disconnect --json   # get hub_url for cleanup\n\n"
            "JSON keys: status, hub_url, hostname"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    disconnect_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output", default=False,
        help="Emit a JSON object to stdout on completion.",
    )
    disconnect_p.set_defaults(func=run_disconnect)

    # ── ping ──────────────────────────────────────────────────────────────────
    ping_p = subs.add_parser(
        "ping",
        help="Test HTTP connectivity to the configured hub.",
        description=(
            "Send GET <hub>/health and report reachability.  No auth token\n"
            "is sent — the health endpoint is intentionally public.\n"
            "HTTP redirects are refused.\n\n"
            "Agent readiness loop:\n"
            "  until muse hub ping --json 2>/dev/null; do sleep 2; done\n\n"
            "JSON keys: status, hub_url, hostname, reachable, message\n"
            "Exit 0 = reachable, 5 = unreachable, 1 = no hub, 2 = no repo"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ping_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    ping_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output", default=False,
        help="Emit a JSON object to stdout with the ping result.",
    )
    ping_p.set_defaults(func=run_ping)

    # ── status ────────────────────────────────────────────────────────────────
    status_p = subs.add_parser(
        "status",
        help="Show the hub connection and identity for this repository.",
        description=(
            "Display the hub URL stored in .muse/config.toml and the identity\n"
            "stored in ~/.muse/identity.toml.  Makes no network calls.\n\n"
            "Agent quickstart:\n"
            "  muse hub status --json || muse hub connect https://musehub.ai --json\n\n"
            "JSON keys (always present): hub_url, hostname, authenticated,\n"
            "  identity_type, identity_name, identity_id, capabilities"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    status_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config (e.g. http://host.docker.internal:10003/owner/repo).",
    )
    status_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON to stdout instead of human-readable output.",
    )
    status_p.set_defaults(func=run_status)

