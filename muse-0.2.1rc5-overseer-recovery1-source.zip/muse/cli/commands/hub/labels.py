import argparse
from ._core import *

def _validate_hex_color(color: str) -> bool:
    """Return True if *color* is a valid 7-character hex color string (e.g. '#d73a4a').

    Validates without importing ``re`` — checks length, ``#`` prefix, and hex
    digit range explicitly so there is no import overhead on every CLI invocation.
    """
    if len(color) != 7 or color[0] != "#":
        return False
    try:
        int(color[1:], 16)
    except ValueError:
        return False
    return True

def _lookup_label_by_name(
    hub_url: str,
    identity: IdentityEntry,
    repo_id: str,
    name: str,
) -> _LabelEntry | None:
    """Fetch the label list and return the entry whose name matches *name*.

    Returns ``None`` if no label with that name exists.  Case-sensitive match.
    """
    data = _hub_api(hub_url, identity, "GET", f"/api/repos/{repo_id}/labels")
    items_val = data.get("items", [])
    items: list[_LabelEntry] = (
        [r for r in items_val if isinstance(r, dict)]
        if isinstance(items_val, list) else []
    )
    for item in items:
        if item.get("name") == name:
            return item
    return None

def run_label_create(args: argparse.Namespace) -> None:
    """Create a new label on MuseHub.

    Validates name length and colour format locally before any network call.
    Prints the label_id to stdout in text mode; use ``--json`` for the full
    API response merged with the standard envelope.

    Agent quickstart
    ----------------
    ::

        muse hub label create --name bug --color '#d73a4a' --json
        muse hub label create --name enhancement --color '#a2eeef' --json
        # → {"muse_version": "...", ..., "label_id": "...", "name": "bug"}

    Exit codes
    ----------
    0  Label created.
    1  Validation error, conflict (name already exists), or not authenticated.
    2  Not inside a Muse repository.
    3  API error.
    """
    name: str = args.name.strip()
    color: str = args.color.strip()
    description: str | None = args.description
    json_output: bool = args.json_output

    # ── Local validation — fail fast before any network I/O ──────────────────
    if not name:
        print("❌ Label name must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    if len(name) > _MAX_LABEL_NAME_LEN:
        print(
            f"❌ Label name is too long ({len(name)} chars); "
            f"maximum is {_MAX_LABEL_NAME_LEN}.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)
    if not _validate_hex_color(color):
        print(
            f"❌ Invalid colour '{sanitize_display(color)}'. "
            "Must be a 7-character hex string starting with '#' (e.g. '#d73a4a').",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)
    if description is not None and len(description) > _MAX_LABEL_DESC_LEN:
        print(
            f"❌ Description is too long ({len(description)} chars); "
            f"maximum is {_MAX_LABEL_DESC_LEN}.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    # ── Network calls ─────────────────────────────────────────────────────────
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    payload: _HubPayload = {"name": name, "color": color}
    if description is not None:
        payload["description"] = description
    data = _hub_api(hub_url, identity, "POST", f"/api/repos/{repo_id}/labels", body=payload)

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    label_id = sanitize_display(str(data.get("label_id", "")))
    print(f"✅ Label '{sanitize_display(name)}' created ({label_id}).", file=sys.stderr)
    print(label_id)

def run_label_list(args: argparse.Namespace) -> None:
    """List all labels for the current repo.

    The list endpoint is public — no authentication required for public repos.

    JSON output includes envelope fields plus ``labels`` (array) and
    ``total`` (int).

    Agent quickstart
    ----------------
    ::

        muse hub label list --json
        muse hub label list --json | jq '.labels[].name'

    Exit codes
    ----------
    0  Success (including empty list).
    1  Not authenticated (private repo).
    2  Not inside a Muse repository.
    3  API error.
    """
    json_output: bool = args.json_output

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    data = _hub_api(hub_url, identity, "GET", f"/api/repos/{repo_id}/labels")
    items_val = data.get("items", [])
    items: list[_LabelEntry] = (
        [r for r in items_val if isinstance(r, dict)]
        if isinstance(items_val, list) else []
    )
    label_total: int = int(data.get("total", len(items)))

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **{"labels": items, "total": label_total}}))
        return

    if not items:
        print("  No labels defined in this repo.", file=sys.stderr)
        return

    print(f"\n  Labels — {sanitize_display(hub_url)}", file=sys.stderr)
    print(f"  {'─' * 50}", file=sys.stderr)
    for lbl in items:
        _name = sanitize_display(str(lbl.get("name", "?")))
        _color = sanitize_display(str(lbl.get("color", "")))
        _desc = sanitize_display(str(lbl.get("description") or ""))
        suffix = f"  {_desc}" if _desc else ""
        print(f"  {_color}  {_name}{suffix}", file=sys.stderr)
    print("", file=sys.stderr)

def run_label_update(args: argparse.Namespace) -> None:
    """Update an existing label's name, colour, or description on MuseHub.

    Looks up the label by its current name, then sends a PATCH request with
    only the provided fields.  At least one of ``--new-name``, ``--new-color``,
    or ``--new-description`` must be supplied.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub label update --name bug --new-color '#b60205' --json
        muse hub label update --name bug --new-name bug-report --json
        # → {"muse_version": "...", ..., "name": "bug-report", "color": "#b60205"}

    Exit codes
    ----------
    0  Label updated.
    1  Validation error, label not found, or not authenticated.
    2  Not inside a Muse repository.
    3  API error.
    """
    name: str = args.name.strip()
    new_name: str | None = args.new_name
    new_color: str | None = args.new_color
    new_description: str | None = args.new_description
    json_output: bool = args.json_output

    # ── Local validation ──────────────────────────────────────────────────────
    if not name:
        print("❌ Label name must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    if new_name is None and new_color is None and new_description is None:
        print(
            "❌ Provide at least one of --new-name, --new-color, --new-description.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)
    if new_name is not None:
        new_name = new_name.strip()
        if not new_name:
            print("❌ New label name must not be empty.", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        if len(new_name) > _MAX_LABEL_NAME_LEN:
            print(
                f"❌ New name is too long ({len(new_name)} chars); "
                f"maximum is {_MAX_LABEL_NAME_LEN}.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)
    if new_color is not None:
        new_color = new_color.strip()
        if not _validate_hex_color(new_color):
            print(
                f"❌ Invalid colour '{sanitize_display(new_color)}'. "
                "Must be a 7-character hex string starting with '#' (e.g. '#d73a4a').",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)
    if new_description is not None and len(new_description) > _MAX_LABEL_DESC_LEN:
        print(
            f"❌ Description is too long ({len(new_description)} chars); "
            f"maximum is {_MAX_LABEL_DESC_LEN}.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    # ── Network calls ─────────────────────────────────────────────────────────
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    # Look up label by name to get the ID.
    label = _lookup_label_by_name(hub_url, identity, repo_id, name)
    if label is None:
        print(
            f"❌ Label '{sanitize_display(name)}' not found in this repo.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    label_id = str(label.get("label_id", ""))
    patch: _HubPayload = {}
    if new_name is not None:
        patch["name"] = new_name
    if new_color is not None:
        patch["color"] = new_color
    if new_description is not None:
        patch["description"] = new_description

    data = _hub_api(
        hub_url, identity, "PATCH",
        f"/api/repos/{repo_id}/labels/{urllib.parse.quote(label_id, safe='')}",
        body=patch,
    )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    display_name = sanitize_display(str(data.get("name", name)))
    print(f"✅ Label '{sanitize_display(name)}' updated → '{display_name}'.", file=sys.stderr)

def run_label_delete(args: argparse.Namespace) -> None:
    """Delete a label from MuseHub and remove it from all issues and proposals.

    Looks up the label by name, then sends a DELETE request.  This operation
    is irreversible.

    JSON output includes envelope fields plus ``deleted`` (bool), ``name``
    (str), and ``label_id`` (str).

    Agent quickstart
    ----------------
    ::

        muse hub label delete --name bug --json
        # → {"muse_version": "...", ..., "deleted": true, "name": "bug", "label_id": "..."}

    Exit codes
    ----------
    0  Label deleted.
    1  Label not found, or not authenticated.
    2  Not inside a Muse repository.
    3  API error.
    """
    name: str = args.name.strip()
    json_output: bool = args.json_output

    if not name:
        print("❌ Label name must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    # Look up label by name to get the ID.
    label = _lookup_label_by_name(hub_url, identity, repo_id, name)
    if label is None:
        print(
            f"❌ Label '{sanitize_display(name)}' not found in this repo.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    label_id = str(label.get("label_id", ""))
    # DELETE returns 204 with no body; _hub_api returns {} for empty responses.
    _hub_api(
        hub_url, identity, "DELETE",
        f"/api/repos/{repo_id}/labels/{urllib.parse.quote(label_id, safe='')}",
    )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **{"deleted": True, "name": name, "label_id": label_id}}))
        return

    print(f"✅ Label '{sanitize_display(name)}' deleted.", file=sys.stderr)

def register(subs: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register labels subcommands."""
    # ── label ─────────────────────────────────────────────────────────────────
    label_p = subs.add_parser(
        "label",
        help="Manage labels on MuseHub.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    label_subs = label_p.add_subparsers(dest="label_subcommand", metavar="LABEL_COMMAND")
    label_subs.required = True

    label_create_p = label_subs.add_parser(
        "create",
        help="Create a new label.",
        description=(
            "Create a repo-scoped label with a name, hex colour, and optional description.\n\n"
            f"Name must be non-empty and ≤ {_MAX_LABEL_NAME_LEN} characters.\n"
            "Colour must be a 7-character hex string starting with '#' (e.g. '#d73a4a').\n"
            "Names must be unique within the repository.\n\n"
            "Agent quickstart:\n"
            "  muse hub label create --name bug --color '#d73a4a' --json\n"
            "  muse hub label create --name enhancement --color '#a2eeef' "
            "--description 'New feature or request' --json\n\n"
            "JSON output keys: label_id, repo_id, name, color, description\n\n"
            "Exit codes: 0 created, 1 validation/conflict/auth error,\n"
            "            2 not in repo, 3 API/network error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    label_create_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    label_create_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo (hub base URL taken from config).",
    )
    label_create_p.add_argument(
        "--name", "-n", required=True,
        help="Label name (must be unique within the repo).",
    )
    label_create_p.add_argument(
        "--color", "-c", required=True,
        help="Hex colour string, e.g. '#d73a4a'.",
    )
    label_create_p.add_argument(
        "--description", "-d", default=None,
        help="Optional label description (≤ 200 characters).",
    )
    label_create_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the created label.",
    )
    label_create_p.set_defaults(func=run_label_create)

    label_list_p = label_subs.add_parser(
        "list",
        help="List all labels for the current repo.",
        description=(
            "List every label defined in the repository.\n\n"
            "The list endpoint is public — no authentication required for public repos.\n\n"
            "Agent quickstart:\n"
            "  muse hub label list --json\n\n"
            "JSON output: array of label objects (label_id, name, color, description)\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    label_list_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    label_list_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    label_list_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON array of labels.",
    )
    label_list_p.set_defaults(func=run_label_list)

    label_update_p = label_subs.add_parser(
        "update",
        help="Update an existing label's name, colour, or description.",
        description=(
            "Partially update a label identified by its current name.\n\n"
            "Only provided flags are changed; omitted fields are left unchanged.\n"
            f"New name must be ≤ {_MAX_LABEL_NAME_LEN} characters.\n"
            "Colour must be a 7-character hex string starting with '#'.\n\n"
            "Agent quickstart:\n"
            "  muse hub label update --name bug --new-color '#b60205' --json\n"
            "  muse hub label update --name bug --new-name bug-report --json\n\n"
            "JSON output keys: label_id, repo_id, name, color, description\n\n"
            "Exit codes: 0 updated, 1 validation/auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    label_update_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    label_update_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    label_update_p.add_argument(
        "--name", "-n", required=True,
        help="Current name of the label to update.",
    )
    label_update_p.add_argument(
        "--new-name", dest="new_name", default=None,
        help="New name for the label.",
    )
    label_update_p.add_argument(
        "--new-color", dest="new_color", default=None,
        help="New hex colour, e.g. '#b60205'.",
    )
    label_update_p.add_argument(
        "--new-description", dest="new_description", default=None,
        help="New description (pass empty string to clear).",
    )
    label_update_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the updated label.",
    )
    label_update_p.set_defaults(func=run_label_update)

    label_delete_p = label_subs.add_parser(
        "delete",
        help="Delete a label and remove it from all issues.",
        description=(
            "Permanently delete a label by name and remove it from every\n"
            "issue and proposal it is currently attached to.\n\n"
            "This operation is irreversible.\n\n"
            "Agent quickstart:\n"
            "  muse hub label delete --name bug --json\n\n"
            "Exit codes: 0 deleted, 1 auth/not-found error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    label_delete_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    label_delete_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    label_delete_p.add_argument(
        "--name", "-n", required=True,
        help="Name of the label to delete.",
    )
    label_delete_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON confirmation on success.",
    )
    label_delete_p.set_defaults(func=run_label_delete)

    label_p.set_defaults(func=lambda a: label_p.print_help())

