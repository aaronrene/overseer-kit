import argparse
import base64
from ._core import *

def run_issue_create(args: argparse.Namespace) -> None:
    """Open a new issue on MuseHub.

    Validates title length and emptiness before making any network calls.
    Prints the issue URL to stdout in text mode (scriptable); use ``--json``
    for the full API response merged with the standard envelope.

    Agent quickstart
    ----------------
    ::

        muse hub issue create --title "fix: bug" --body "details" --label bug --json
        muse hub issue create --title "feat: X" --label "phase/1" --json
        # → {"muse_version": "...", ..., "issueId": "...", "number": 42, ...}

    Exit codes
    ----------
    0  Issue created successfully.
    1  Validation error or not authenticated.
    2  Not inside a Muse repository.
    3  API error.
    """
    title: str = args.title
    body: str = _resolve_body(args)
    labels: list[str] = args.labels
    symbol_anchors: list[str] = args.symbol_anchors
    commit_anchors: list[str] = args.commit_anchors
    agent_id: str = args.agent_id
    model_id: str = args.model_id
    assignee: str | None = getattr(args, "assignee", None)
    json_output: bool = args.json_output

    # ── Local validation first — fail fast before any network I/O ────────────
    if not title.strip():
        print("❌ Issue title must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    if len(title) > _MAX_ISSUE_TITLE_LEN:
        print(
            f"❌ Issue title is too long ({len(title)} chars); "
            f"maximum is {_MAX_ISSUE_TITLE_LEN}.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)
    # Validate assignee handle before any network I/O.  allow_empty=False:
    # passing --assignee with an empty value is an error at creation time.
    if assignee is not None:
        _validate_assignee(assignee, allow_empty=False)

    # ── Network calls ─────────────────────────────────────────────────────────
    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_identity, _resolve_repo_id  # noqa: PLC0415
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    payload: _ProposalPayload = {
        "title": title,
        "body": body,
        "labels": labels,
        "symbol_anchors": symbol_anchors,
        "commit_anchors": commit_anchors,
        "agent_id": agent_id,
        "model_id": model_id,
    }
    data = _hub_api(hub_url, identity, "POST", f"/api/repos/{repo_id}/issues", body=payload)

    _num = data.get("number")
    try:
        number = int(_num) if _num is not None else 0
    except (ValueError, TypeError):
        number = 0

    # If an assignee was requested, dispatch the assignment now.
    if assignee is not None:
        issue_id = data.get("issueId") or str(number)
        data = _hub_api(
            hub_url, identity, "POST",
            f"/api/repos/{repo_id}/issues/{number}/assign",
            body={"assignee": assignee},
        )

    parsed = urllib.parse.urlparse(hub_url)
    parts = parsed.path.strip("/").split("/")
    if len(parts) >= 2:
        owner, slug = parts[0], parts[1]
        server_root = f"{parsed.scheme}://{parsed.netloc}"
        issue_url = f"{server_root}/{owner}/{slug}/issues/{number}"
    else:
        issue_url = str(data.get("issueId", ""))

    raw_issue_id = data.get("issueId", "")
    if raw_issue_id.startswith("sha256:"):
        issue_id_b64 = base64.urlsafe_b64encode(bytes.fromhex(raw_issue_id[7:])).rstrip(b"=").decode()
    else:
        issue_id_b64 = ""

    if json_output:
        extras = {"url": data.get("url") or issue_url, "issueIdB64": issue_id_b64}
        print(json.dumps({**make_envelope(elapsed), **data, **extras}))
        return

    print(f"✅ Issue #{number} created.", file=sys.stderr)
    if assignee:
        print(f"   Assigned to {sanitize_display(assignee)}.", file=sys.stderr)
    print(sanitize_display(issue_url))

def run_issue_update(args: argparse.Namespace) -> None:
    """Update an existing issue on MuseHub.

    Updates title, body, anchors, and/or status; omitted fields are left
    unchanged.  All validation runs before any network I/O.

    ``--status closed`` dispatches to the ``/close`` endpoint; ``--status open``
    dispatches to ``/reopen``.  Both may be combined with ``--title`` / ``--body``
    in a single call — field updates are applied first, then the status change.

    At least one of ``--title``, ``--body``, ``--anchor``, ``--commit-anchor``,
    ``--status``, or ``--assign`` must be provided.

    JSON output is the final API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub issue update 42 --status closed --body "done" --json
        muse hub issue update 42 --title "new title" --json
        # → {"muse_version": "...", ..., "number": 42, "status": "closed", ...}

    Exit codes
    ----------
    0  Issue updated successfully.
    1  Validation error or not authenticated.
    2  Not inside a Muse repository.
    3  API error.
    """
    number: int = args.number
    json_output: bool = args.json_output
    status: str | None = getattr(args, "status", None)
    assign: str | None = getattr(args, "assign", None)

    # ── Local validation first — fail fast before any network I/O ────────────
    if number <= 0:
        print(f"❌ Issue number must be a positive integer, got {number}.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    # Validate the --assign handle if provided.  allow_empty=True because an
    # empty string is the documented way to unassign an issue.
    if assign is not None:
        _validate_assignee(assign, allow_empty=True)

    patch: _ProposalPayload = {}
    if args.title is not None:
        if not args.title.strip():
            print("❌ Issue title must not be empty.", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        if len(args.title) > _MAX_ISSUE_TITLE_LEN:
            print(
                f"❌ Issue title is too long ({len(args.title)} chars); "
                f"maximum is {_MAX_ISSUE_TITLE_LEN}.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)
        patch["title"] = args.title
    resolved_body = _resolve_body(args)
    if args.body is not None or getattr(args, "body_file", None) is not None:
        patch["body"] = resolved_body
    if args.symbol_anchors is not None:
        patch["symbol_anchors"] = args.symbol_anchors
    if args.commit_anchors is not None:
        patch["commit_anchors"] = args.commit_anchors

    if not patch and status is None and assign is None:
        print(
            "❌ Nothing to update — provide --title, --body, --anchor, "
            "--commit-anchor, --status, and/or --assign.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    # ── Network calls ─────────────────────────────────────────────────────────
    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_identity, _resolve_repo_id  # noqa: PLC0415
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    data = {}

    # Apply field updates first (title, body, anchors) if any.
    if patch:
        data = _hub_api(
            hub_url, identity, "PATCH",
            f"/api/repos/{repo_id}/issues/{number}",
            body=patch,
        )

    # Then apply the status transition.
    if status == "closed":
        data = _hub_api(
            hub_url, identity, "POST",
            f"/api/repos/{repo_id}/issues/{number}/close",
        )
    elif status == "open":
        data = _hub_api(
            hub_url, identity, "POST",
            f"/api/repos/{repo_id}/issues/{number}/reopen",
        )

    # Then apply the assignment.
    if assign is not None:
        data = _hub_api(
            hub_url, identity, "POST",
            f"/api/repos/{repo_id}/issues/{number}/assign",
            body={"assignee": assign if assign else None},
        )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"✅ Issue #{number} updated.", file=sys.stderr)

def run_issue_read(args: argparse.Namespace) -> None:
    """Fetch a single issue by its per-repo number.

    Prints a one-line summary to stderr in text mode; use ``--json`` for the
    full API response merged with the standard envelope.

    Agent quickstart
    ----------------
    ::

        muse hub issue read 42 --json | jq '{number,title,state}'
        # → {"muse_version": "...", ..., "number": 42, "title": "...", "state": "open"}

    Exit codes
    ----------
    0  Issue found and printed.
    1  Not authenticated.
    2  Not inside a Muse repository.
    3  API error (includes 404 if the issue does not exist).
    """
    number: int = args.number
    json_output: bool = args.json_output

    if number <= 0:
        print(f"❌ Issue number must be a positive integer, got {number}.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_optional_identity, _resolve_repo_id  # noqa: PLC0415
    hub_url, identity = _get_hub_and_optional_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    data = _hub_api(hub_url, identity, "GET", f"/api/repos/{repo_id}/issues/{number}")

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    title = sanitize_display(str(data.get("title", "(no title)")))
    state = sanitize_display(str(data.get("state", "?")))
    state_icon = {"open": "🟢", "closed": "⛔"}.get(str(data.get("state", "")), "❓")
    author = sanitize_display(str(data.get("author", "")))
    created = sanitize_display(str(data.get("createdAt", ""))[:10])
    print(f"\n  {state_icon} [{state.upper()}] #{number} — {title}", file=sys.stderr)
    print(f"  Author: {author}  Created: {created}", file=sys.stderr)

def run_issue_list(args: argparse.Namespace) -> None:
    """List issues for the current repo.

    Returns open issues by default; filter with ``--state`` and ``--label``.

    User inputs are sanitized before use:
    - ``--state`` is constrained by argparse ``choices`` and URL-encoded.
    - ``--label`` is length-capped locally then percent-encoded in the query
      string — no raw label value is ever interpolated into the URL directly.
    - ``--limit`` is clamped to a safe integer range by :func:`clamp_int`.

    JSON output is an object with envelope fields plus ``issues`` (array),
    ``total`` (int), and ``next_cursor`` (str|null).

    Agent quickstart
    ----------------
    ::

        muse hub issue list --json
        muse hub issue list --state closed --label bug --json
        muse hub issue list --json | jq '.issues[].number'

    Exit codes
    ----------
    0  Success (including empty list).
    1  Validation error or not authenticated.
    2  Not inside a Muse repository.
    3  API error.
    """
    state: str = args.state
    label: str | None = args.label
    limit: int = clamp_int(args.limit, 1, 10000, "limit")
    json_output: bool = args.json_output

    # ── Local validation first — fail fast before any network I/O ────────────
    if label is not None and len(label) > _MAX_ISSUE_LABEL_LEN:
        print(
            f"❌ Label is too long ({len(label)} chars); "
            f"maximum is {_MAX_ISSUE_LABEL_LEN}.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    # ── Network calls ─────────────────────────────────────────────────────────
    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_optional_identity, _resolve_repo_id  # noqa: PLC0415
    hub_url, identity = _get_hub_and_optional_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    # URL-encode state even though argparse already constrains it to a known
    # set — defense-in-depth against any future code path that bypasses argparse.
    params = f"?state={urllib.parse.quote(state, safe='')}&per_page={limit}"
    if label:
        params += f"&label={urllib.parse.quote(label, safe='')}"
    data = _hub_api(hub_url, identity, "GET", f"/api/repos/{repo_id}/issues{params}")

    issues_val = data.get("issues", [])
    issues: list[_HubApiResponse] = (
        [r for r in issues_val if isinstance(r, dict)]
        if isinstance(issues_val, list) else []
    )
    total: int = int(data.get("total", len(issues)))
    next_cursor: str | None = data.get("nextCursor") or data.get("next_cursor")  # type: ignore[assignment]

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **{
            "issues": issues,
            "total": total,
            "next_cursor": next_cursor,
        }}))
        return

    if not issues:
        print(f"  No issues found (state={sanitize_display(state)}).", file=sys.stderr)
        return

    print(f"\n  Issues — {sanitize_display(hub_url)}  ({len(issues)} shown)", file=sys.stderr)
    print(f"  {'─' * 60}", file=sys.stderr)
    for issue in issues:
        _state = str(issue.get("state", "?"))
        state_icon = {"open": "🟢", "closed": "⛔"}.get(_state, "❓")
        _num = sanitize_display(str(issue.get("number", "?")))
        _title = sanitize_display(str(issue.get("title", "(no title)")))
        _author = sanitize_display(str(issue.get("author", "")))
        print(f"  {state_icon}  #{_num}  {_title}  [{_author}]", file=sys.stderr)
    print("", file=sys.stderr)

def run_issue_close(args: argparse.Namespace) -> None:
    """Close an open issue on MuseHub.

    Idempotent — closing an already-closed issue returns the issue unchanged.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub issue close 42 --json
        # → {"muse_version": "...", ..., "number": 42, "state": "closed", ...}

    Exit codes
    ----------
    0  Issue closed successfully.
    1  Not authenticated.
    2  Not inside a Muse repository.
    3  API error (includes 404 if the issue does not exist).
    """
    number: int = args.number
    json_output: bool = args.json_output

    if number <= 0:
        print(f"❌ Issue number must be a positive integer, got {number}.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_identity, _resolve_repo_id  # noqa: PLC0415
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    data = _hub_api(
        hub_url, identity, "POST",
        f"/api/repos/{repo_id}/issues/{number}/close",
    )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"✅ Issue #{number} closed.", file=sys.stderr)

def run_issue_reopen(args: argparse.Namespace) -> None:
    """Reopen a closed issue on MuseHub.

    Idempotent — reopening an already-open issue returns the issue unchanged.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub issue reopen 42 --json
        # → {"muse_version": "...", ..., "number": 42, "state": "open", ...}

    Exit codes
    ----------
    0  Issue reopened successfully.
    1  Not authenticated.
    2  Not inside a Muse repository.
    3  API error (includes 404 if the issue does not exist).
    """
    number: int = args.number
    json_output: bool = args.json_output

    if number <= 0:
        print(f"❌ Issue number must be a positive integer, got {number}.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_identity, _resolve_repo_id  # noqa: PLC0415
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    data = _hub_api(
        hub_url, identity, "POST",
        f"/api/repos/{repo_id}/issues/{number}/reopen",
    )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"✅ Issue #{number} reopened.", file=sys.stderr)

def run_issue_comment(args: argparse.Namespace) -> None:
    """Post a Markdown comment on an issue on MuseHub.

    Returns the created comment as a single flat resource merged with the
    standard envelope.

    Agent quickstart
    ----------------
    ::

        muse hub issue comment 42 --body 'Fixed in abc123' --json
        # → {"muse_version": "...", ..., "commentId": "...", "author": "..."}

    JSON output keys (from hub): ``commentId``, ``issueId``, ``author``,
    ``body``, ``parentId``, ``isDeleted``, ``createdAt``, ``updatedAt``.

    Exit codes
    ----------
    0  Comment posted successfully.
    1  Validation or auth error.
    2  Not inside a Muse repository.
    3  API error (includes 404 if the issue does not exist).
    """
    number: int = args.number
    body: str = _resolve_body(args)
    json_output: bool = args.json_output

    if number <= 0:
        print(f"❌ Issue number must be a positive integer, got {number}.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    if not body.strip():
        print("❌ Comment body must not be empty (use --body or --body-file).", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    if len(body) > _MAX_ISSUE_COMMENT_LEN:
        print(
            f"❌ Comment body is too long ({len(body)} chars); "
            f"maximum is {_MAX_ISSUE_COMMENT_LEN}.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_identity, _resolve_repo_id  # noqa: PLC0415
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    payload: _ProposalPayload = {"body": body}
    data = _hub_api(
        hub_url, identity, "POST",
        f"/api/repos/{repo_id}/issues/{number}/comments",
        body=payload,
    )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    comment_id = data.get("commentId", "")
    print(f"✅ Comment posted on issue #{number} (commentId={comment_id}).", file=sys.stderr)

def run_issue_comment_delete(args: argparse.Namespace) -> None:
    """Soft-delete a comment from an issue on MuseHub.

    Deleted comments are hidden from list results but preserved in the audit log.
    Requires write/admin access or repo ownership.

    JSON output includes envelope fields plus ``deleted`` (bool) and
    ``comment_id`` (str).

    Agent quickstart
    ----------------
    ::

        muse hub issue comment-delete 42 --comment-id <id> --json
        # → {"muse_version": "...", ..., "deleted": true, "comment_id": "..."}

    Exit codes
    ----------
    0  Comment deleted successfully.
    1  Validation or auth error.
    2  Not inside a Muse repository.
    3  API error (includes 404 if the comment does not exist).
    """
    number: int = args.number
    comment_id: str = args.comment_id
    json_output: bool = args.json_output

    if number <= 0:
        print(f"❌ Issue number must be a positive integer, got {number}.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    if not comment_id.strip():
        print("❌ --comment-id must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_identity, _resolve_repo_id  # noqa: PLC0415
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    _hub_api(
        hub_url, identity, "DELETE",
        f"/api/repos/{repo_id}/issues/{number}/comments/{comment_id}",
    )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **{"deleted": True, "comment_id": comment_id}}))
        return

    print(f"✅ Comment {comment_id} deleted from issue #{number}.", file=sys.stderr)

def run_issue_comment_list(args: argparse.Namespace) -> None:
    """List non-deleted comments on an issue, oldest first.

    Supports cursor pagination via ``--cursor``.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stdout (not stderr) for easy piping.

    Agent quickstart
    ----------------
    ::

        muse hub issue comment-list 42 --json
        muse hub issue comment-list 42 --limit 50 --json | jq '.comments[].author'
        muse hub issue comment-list 42 --cursor <token> --json

    JSON output keys (from hub): ``comments`` (list), ``nextCursor`` (str|null),
    ``total`` (int).  Each comment: ``commentId``, ``issueId``, ``author``,
    ``body``, ``createdAt``, ``updatedAt``.

    Exit codes
    ----------
    0  Success.
    1  Validation or auth error.
    2  Not inside a Muse repository.
    3  API error (includes 404 if the issue does not exist).
    """
    number: int = args.number
    limit: int = args.limit
    cursor: str | None = args.cursor
    json_output: bool = args.json_output

    if number <= 0:
        print(f"❌ Issue number must be a positive integer, got {number}.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_identity, _resolve_repo_id  # noqa: PLC0415
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    qs = f"?limit={limit}"
    if cursor:
        qs += f"&cursor={urllib.parse.quote(cursor, safe='')}"

    data = _hub_api(
        hub_url, identity, "GET",
        f"/api/repos/{repo_id}/issues/{number}/comments{qs}",
    )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    comments = data.get("comments", [])
    if not comments:
        print(f"No comments on issue #{number}.")
        return

    for c in comments:
        author = c.get("author", "unknown")
        created = c.get("createdAt", "")[:10]
        body = str(c.get("body", "")).split("\n")[0][:80]
        cid = str(c.get("commentId", ""))
        print(f"  [{created}] {author} ({cid}): {body}")

    next_cursor = data.get("nextCursor")
    if next_cursor:
        print(f"\n  (more — pass --cursor {next_cursor})")

def run_issue_assign(args: argparse.Namespace) -> None:
    """Assign or unassign a collaborator on an issue on MuseHub.

    Pass an empty string for ``--assignee`` to clear the current assignee.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub issue assign 42 --assignee gabriel --json
        muse hub issue assign 42 --assignee '' --json   # unassign
        # → {"muse_version": "...", ..., "number": 42, "assignee": "gabriel"}

    Exit codes
    ----------
    0  Assignee updated successfully.
    1  Not authenticated.
    2  Not inside a Muse repository.
    3  API error (includes 404 if the issue does not exist).
    """
    number: int = args.number
    assignee: str = args.assignee
    json_output: bool = args.json_output

    if number <= 0:
        print(f"❌ Issue number must be a positive integer, got {number}.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    # Validate handle before any network I/O.  allow_empty=True because an
    # empty string means "unassign" (documented behaviour of this command).
    _validate_assignee(assignee, allow_empty=True)

    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_identity, _resolve_repo_id  # noqa: PLC0415
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    payload: dict[str, str | None] = {"assignee": assignee if assignee else None}
    data = _hub_api(
        hub_url, identity, "POST",
        f"/api/repos/{repo_id}/issues/{number}/assign",
        body=payload,
    )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    if assignee:
        print(f"✅ Issue #{number} assigned to {sanitize_display(assignee)}.", file=sys.stderr)
    else:
        print(f"✅ Issue #{number} unassigned.", file=sys.stderr)

def run_issue_label(args: argparse.Namespace) -> None:
    """Manage labels on an issue on MuseHub.

    Use ``--set`` to replace the entire label list, or ``--remove`` to strip
    a single label without affecting others.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub issue label 42 --set bug enhancement --json
        muse hub issue label 42 --remove bug --json
        # → {"muse_version": "...", ..., "labels": [...]}

    Exit codes
    ----------
    0  Labels updated successfully.
    1  Not authenticated.
    2  Not inside a Muse repository.
    3  API error (includes 404 if the issue does not exist).
    """
    number: int = args.number
    set_labels: list[str] | None = args.set_labels
    remove_label: str | None = args.remove_label
    json_output: bool = args.json_output

    if number <= 0:
        print(f"❌ Issue number must be a positive integer, got {number}.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_identity, _resolve_repo_id  # noqa: PLC0415
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    if set_labels is not None:
        label_body: _ProposalPayload = {"labels": set_labels}
        data = _hub_api(
            hub_url, identity, "POST",
            f"/api/repos/{repo_id}/issues/{number}/labels",
            body=label_body,
        )
        if json_output:
            print(json.dumps({**make_envelope(elapsed), **data}))
            return
        print(f"✅ Issue #{number} labels set to {set_labels}.", file=sys.stderr)
    else:
        # remove_label is guaranteed non-None (mutually exclusive group)
        label_name: str = remove_label or ""
        data = _hub_api(
            hub_url, identity, "DELETE",
            f"/api/repos/{repo_id}/issues/{number}/labels/{urllib.parse.quote(label_name, safe='')}",
        )
        if json_output:
            print(json.dumps({**make_envelope(elapsed), **data}))
            return
        print(f"✅ Label '{label_name}' removed from issue #{number}.", file=sys.stderr)

def register(subs: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register issues subcommands."""
    # ── issue ─────────────────────────────────────────────────────────────────
    issue_p = subs.add_parser(
        "issue",
        help="Manage issues on MuseHub.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    issue_subs = issue_p.add_subparsers(dest="issue_subcommand", metavar="ISSUE_COMMAND")
    issue_subs.required = True

    issue_create_p = issue_subs.add_parser(
        "create",
        help="Open a new issue.",
        description=(
            "Open a new issue on MuseHub.\n\n"
            f"Title must be non-empty and ≤ {_MAX_ISSUE_TITLE_LEN} characters.\n"
            "Use --label (repeatable) to apply labels at creation time.\n"
            "Use --anchor (repeatable) to link to Muse symbols (path/to/file.py::Symbol).\n"
            "Use --commit-anchor (repeatable) to link to specific Muse commits.\n"
            "Use --agent-id / --model-id when filing on behalf of an AI agent.\n"
            "In text mode the issue URL is printed to stdout — capture it with $().\n\n"
            "Agent quickstart:\n"
            "  muse hub issue create --title 'bug: crash in create_issue' \\\n"
            "    --anchor musehub/services/musehub_issues.py::create_issue \\\n"
            "    --agent-id agentception-worker-42 --model-id claude-sonnet-4-6 --json\n"
            "  URL=$(muse hub issue create --title 'feat: X' --label enhancement)\n\n"
            "Exit codes: 0 created, 1 validation/auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    issue_create_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config (e.g. http://host.docker.internal:10003/owner/repo).",
    )
    issue_create_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Alias for --hub: specify repo as owner/repo (hub base URL taken from config).",
    )
    issue_create_p.add_argument("--title", "-t", required=True, help="Issue title.")
    issue_create_p.add_argument("--body", "-b", default="", help="Issue body (inline text).")
    issue_create_p.add_argument(
        "--body-file", default=None, metavar="PATH", dest="body_file",
        help="Read issue body from PATH (UTF-8). Pass '-' to read from stdin. "
             "Takes precedence over --body. Use this for large bodies with "
             "backticks, code blocks, or multi-line content.",
    )
    issue_create_p.add_argument(
        "--label", "-l", dest="labels", action="append", default=[],
        help="Label name to apply (repeatable).",
    )
    issue_create_p.add_argument(
        "--anchor", "-a", dest="symbol_anchors", action="append", default=[],
        metavar="FILE::SYMBOL",
        help=(
            "Muse symbol address to anchor this issue to (repeatable). "
            "Format: path/to/file.py::SymbolName. "
            "Example: --anchor musehub/services/musehub_issues.py::create_issue"
        ),
    )
    issue_create_p.add_argument(
        "--commit-anchor", dest="commit_anchors", action="append", default=[],
        metavar="COMMIT_ID",
        help="Muse commit ID to anchor this issue to (repeatable).",
    )
    issue_create_p.add_argument(
        "--agent-id", dest="agent_id", default="",
        help="Agent identifier when filing on behalf of an AI agent (e.g. agentception-worker-42).",
    )
    issue_create_p.add_argument(
        "--model-id", dest="model_id", default="",
        help="Model identifier when filing on behalf of an AI agent (e.g. claude-sonnet-4-6).",
    )
    issue_create_p.add_argument(
        "--assignee", dest="assignee", default=None, metavar="USER",
        help=(
            "Assign the issue to USER at creation time.  The handle is validated "
            "before any network I/O: must start with a letter or digit, contain "
            "only letters/digits/hyphens/underscores, be ASCII-only, and be ≤ "
            f"{_MAX_HANDLE_LEN} characters.  A second POST to the /assign endpoint "
            "is dispatched immediately after the issue is created."
        ),
    )
    issue_create_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the created issue.",
    )
    issue_create_p.set_defaults(func=run_issue_create)

    issue_update_p = issue_subs.add_parser(
        "update",
        help="Update an existing issue.",
        description=(
            "Update an existing issue on MuseHub.\n\n"
            "Updates title, body, anchors, and/or status; omitted fields are left unchanged.\n"
            "At least one of --title, --body, --anchor, --commit-anchor, --status, or --assign must be provided.\n"
            f"If --title is given it must be non-empty and ≤ {_MAX_ISSUE_TITLE_LEN} characters.\n"
            "--anchor / --commit-anchor replace the full anchor list (send all desired anchors).\n"
            "--status closed calls the /close endpoint; --status open calls /reopen.\n\n"
            "Agent quickstart:\n"
            "  muse hub issue update 42 --status closed\n"
            "  muse hub issue update 42 --status closed --body 'done' --json\n"
            "  muse hub issue update 42 --assign gabriel --status closed\n"
            "  muse hub issue update 42 --body 'updated description' --json\n"
            "  muse hub issue update 42 \\\n"
            "    --anchor musehub/services/musehub_issues.py::create_issue \\\n"
            "    --anchor musehub/db/musehub_models.py::MusehubIssue --json\n\n"
            "Exit codes: 0 updated, 1 validation/auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    issue_update_p.add_argument("number", type=int, help="Issue number.")
    issue_update_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    issue_update_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Alias for --hub: specify repo as owner/repo (hub base URL taken from config).",
    )
    issue_update_p.add_argument("--title", "-t", default=None, help="New title.")
    issue_update_p.add_argument("--body", "-b", default=None, help="New body (inline text).")
    issue_update_p.add_argument(
        "--body-file", default=None, metavar="PATH", dest="body_file",
        help="Read new body from PATH. Pass '-' for stdin. Takes precedence over --body.",
    )
    issue_update_p.add_argument(
        "--status", choices=["open", "closed"], default=None,
        help="Set issue status: 'open' (reopen) or 'closed'. Dispatches to the appropriate endpoint.",
    )
    issue_update_p.add_argument(
        "--anchor", "-a", dest="symbol_anchors", action="append", default=None,
        metavar="FILE::SYMBOL",
        help=(
            "Replacement symbol anchor (repeatable; replaces all existing anchors). "
            "Format: path/to/file.py::SymbolName."
        ),
    )
    issue_update_p.add_argument(
        "--commit-anchor", dest="commit_anchors", action="append", default=None,
        metavar="COMMIT_ID",
        help="Replacement commit anchor (repeatable; replaces all existing anchors).",
    )
    issue_update_p.add_argument(
        "--assign", dest="assign", default=None, metavar="USER",
        help=(
            "Assign the issue to USER. Pass an empty string to unassign. "
            "Dispatches to the /assign endpoint after any other field updates."
        ),
    )
    issue_update_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the updated issue.",
    )
    issue_update_p.set_defaults(func=run_issue_update)

    issue_read_p = issue_subs.add_parser(
        "read",
        help="Read a single issue.",
        description=(
            "Fetch a single issue by its per-repo number.\n\n"
            "Agent quickstart:\n"
            "  muse hub issue read 42 --json\n"
            "  muse hub issue read 42 --json | jq '{number,title,state}'\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    issue_read_p.add_argument("number", type=int, help="Issue number.")
    issue_read_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    issue_read_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    issue_read_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the issue.",
    )
    issue_read_p.set_defaults(func=run_issue_read)

    issue_list_p = issue_subs.add_parser(
        "list",
        help="List issues for this repo.",
        description=(
            "List issues on MuseHub for the current repo.\n\n"
            "Agent quickstart:\n"
            "  muse hub issue list --json\n"
            "  muse hub issue list --state closed --json\n"
            "  muse hub issue list --label bug --json\n\n"
            "Exit codes: 0 success (including empty list), 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    issue_list_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    issue_list_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    issue_list_p.add_argument(
        "--state", dest="state", default="open",
        choices=["open", "closed", "all"],
        help="Filter by state (default: open).",
    )
    issue_list_p.add_argument(
        "--label", dest="label", default=None, metavar="LABEL",
        help="Filter by label string.",
    )
    issue_list_p.add_argument(
        "--limit", dest="limit", type=int, default=100, metavar="N",
        help="Maximum number of issues to return (default: 100).",
    )
    issue_list_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON array of issues.",
    )
    issue_list_p.set_defaults(func=run_issue_list)

    issue_close_p = issue_subs.add_parser(
        "close",
        help="Close an open issue.",
        description=(
            "Close an issue on MuseHub.\n\n"
            "Agent quickstart:\n"
            "  muse hub issue close 42\n"
            "  muse hub issue close 42 --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    issue_close_p.add_argument("number", type=int, help="Issue number.")
    issue_close_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    issue_close_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    issue_close_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the updated issue.",
    )
    issue_close_p.set_defaults(func=run_issue_close)

    issue_reopen_p = issue_subs.add_parser(
        "reopen",
        help="Reopen a closed issue.",
        description=(
            "Reopen a closed issue on MuseHub.\n\n"
            "Agent quickstart:\n"
            "  muse hub issue reopen 42\n"
            "  muse hub issue reopen 42 --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    issue_reopen_p.add_argument("number", type=int, help="Issue number.")
    issue_reopen_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    issue_reopen_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    issue_reopen_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the updated issue.",
    )
    issue_reopen_p.set_defaults(func=run_issue_reopen)

    issue_comment_p = issue_subs.add_parser(
        "comment",
        help="Post a comment on an issue.",
        description=(
            "Post a Markdown comment on an issue on MuseHub.\n\n"
            "Agent quickstart:\n"
            "  muse hub issue comment 42 --body 'Fixed in commit abc123'\n"
            "  muse hub issue comment 42 --body 'see also #43' --json\n\n"
            "Exit codes: 0 success, 1 validation/auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    issue_comment_p.add_argument("number", type=int, help="Issue number.")
    issue_comment_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    issue_comment_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    issue_comment_p.add_argument(
        "--body", "-b", default=None, dest="body",
        help="Comment body (Markdown, inline text).",
    )
    issue_comment_p.add_argument(
        "--body-file", default=None, metavar="PATH", dest="body_file",
        help="Read comment body from PATH. Pass '-' for stdin. Takes precedence over --body.",
    )
    issue_comment_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the updated comment list.",
    )
    issue_comment_p.set_defaults(func=run_issue_comment)

    issue_comment_delete_p = issue_subs.add_parser(
        "comment-delete",
        help="Soft-delete a comment from an issue.",
        description=(
            "Soft-delete a comment on an issue on MuseHub.\n\n"
            "The comment is hidden from list results but preserved in the audit log.\n"
            "Requires write/admin access or repo ownership.\n\n"
            "Agent quickstart:\n"
            "  muse hub issue comment-delete 42 --comment-id <id>\n"
            "  muse hub issue comment-delete 42 --comment-id <id> --json\n\n"
            "Exit codes: 0 success, 1 validation/auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    issue_comment_delete_p.add_argument("number", type=int, help="Issue number.")
    issue_comment_delete_p.add_argument(
        "--comment-id", dest="comment_id", required=True, metavar="ID",
        help="ID of the comment to delete.",
    )
    issue_comment_delete_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    issue_comment_delete_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    issue_comment_delete_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON confirmation on success.",
    )
    issue_comment_delete_p.set_defaults(func=run_issue_comment_delete)

    issue_comment_list_p = issue_subs.add_parser(
        "comment-list",
        help="List comments on an issue.",
        description=(
            "List all non-deleted comments on an issue, oldest first.\n\n"
            "Agent quickstart:\n"
            "  muse hub issue comment-list 42\n"
            "  muse hub issue comment-list 42 --limit 50 --json\n\n"
            "Exit codes: 0 success, 1 validation/auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    issue_comment_list_p.add_argument("number", type=int, help="Issue number.")
    issue_comment_list_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    issue_comment_list_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    issue_comment_list_p.add_argument(
        "--limit", type=int, default=100, metavar="N",
        help="Maximum comments to return (default 100).",
    )
    issue_comment_list_p.add_argument(
        "--cursor", default=None, metavar="CURSOR",
        help="Pagination cursor from a previous call.",
    )
    issue_comment_list_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON list of comments.",
    )
    issue_comment_list_p.set_defaults(func=run_issue_comment_list)

    issue_assign_p = issue_subs.add_parser(
        "assign",
        help="Assign or unassign a collaborator on an issue.",
        description=(
            "Assign or unassign a collaborator on an issue on MuseHub.\n\n"
            "Agent quickstart:\n"
            "  muse hub issue assign 42 --assignee gabriel\n"
            "  muse hub issue assign 42 --assignee ''   # unassign\n"
            "  muse hub issue assign 42 --assignee gabriel --json\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    issue_assign_p.add_argument("number", type=int, help="Issue number.")
    issue_assign_p.add_argument(
        "--assignee", dest="assignee", required=True, metavar="USER",
        help="Username to assign, or empty string to unassign.",
    )
    issue_assign_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    issue_assign_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    issue_assign_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the updated issue.",
    )
    issue_assign_p.set_defaults(func=run_issue_assign)

    issue_label_p = issue_subs.add_parser(
        "label",
        help="Manage labels on an issue.",
        description=(
            "Add or remove labels on an issue on MuseHub.\n\n"
            "Agent quickstart:\n"
            "  muse hub issue label 42 --set bug enhancement\n"
            "  muse hub issue label 42 --remove bug\n"
            "  muse hub issue label 42 --set bug --json\n\n"
            "--set replaces the entire label list. --remove removes a single label.\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    issue_label_p.add_argument("number", type=int, help="Issue number.")
    _issue_label_mutex = issue_label_p.add_mutually_exclusive_group(required=True)
    _issue_label_mutex.add_argument(
        "--set", dest="set_labels", nargs="+", metavar="LABEL",
        help="Replace the entire label list with these labels.",
    )
    _issue_label_mutex.add_argument(
        "--remove", dest="remove_label", metavar="LABEL",
        help="Remove a single label from the issue.",
    )
    issue_label_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config.",
    )
    issue_label_p.add_argument(
        "--repo", dest="repo", default=None, metavar="OWNER/REPO",
        help="Specify repo as owner/repo.",
    )
    issue_label_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output",
        help="Emit JSON with the updated issue.",
    )
    issue_label_p.set_defaults(func=run_issue_label)

    issue_p.set_defaults(func=lambda a: issue_p.print_help())

