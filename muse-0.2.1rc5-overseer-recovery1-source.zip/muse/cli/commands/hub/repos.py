import argparse
import base64
from ._core import *

def run_repo_create(args: argparse.Namespace) -> None:  # noqa: C901
    """Create a new repository on MuseHub.

    All local validation (name format, length) runs before any network I/O so
    errors are reported immediately without contacting the hub.

    The owner defaults to the authenticated identity's handle.  Pass
    ``--owner`` to create under a different handle (requires the caller to
    have permission on the server).

    The repo is created with ``initialize=True`` by default so the default
    branch exists and the repo is immediately browsable and pushable.  Pass
    ``--no-init`` to skip the initial commit (useful when you are about to
    push an existing history).

    JSON output (``--json``, stdout)
    --------------------------------
    The standard 6-field envelope plus::

        {
          "repo_id":        "<sha256:...>",
          "name":           "<name>",
          "owner":          "<owner>",
          "owner_user_id":  "<sha256:...>",
          "slug":           "<url-safe-slug>",
          "visibility":     "public" | "private",
          "description":    "<desc>",
          "domain_id":      "<label>" | null,
          "domain":         "code" | "midi" | "mist" | "identity" | ...,
          "default_branch": "<branch>",
          "clone_url":      "<url>",
          "tags":           ["<tag>", ...],
          "created_at":     "<iso8601>",
          "updated_at":     "<iso8601>",
          "pushed_at":      "<iso8601>"
        }

    Agent quickstart
    ----------------
    ::

        muse hub repo create --name my-repo --json
        # → {"repo_id": "...", "slug": "my-repo", "clone_url": "...", ...}

        # Create private repo, push immediately:
        muse hub repo create --name my-repo --private --no-init --json
        muse push <remote> main

    Exit codes
    ----------
    0  Repo created.
    1  Validation error, name conflict (409), or not authenticated.
    2  Not inside a Muse repository (when hub URL is inferred from config).
    3  API / network error.
    """
    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_identity, _resolve_repo_id  # noqa: PLC0415
    name: str = args.name.strip()
    owner_override: str = getattr(args, "owner", "") or ""
    description: str = getattr(args, "description", "") or ""
    # --visibility public|private is an alias for --private (GitHub CLI muscle memory).
    # Detect contradictory use of both flags before resolving.
    _visibility_flag: str | None = getattr(args, "visibility_alias", None) or None
    _private_flag: bool = getattr(args, "private", False)
    if _visibility_flag is not None and _private_flag:
        vis_implies_private = _visibility_flag == "private"
        if not vis_implies_private:
            print(
                "❌ Contradictory flags: --visibility public and --private cannot both be set.",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)
    if _visibility_flag is not None:
        visibility: str = _visibility_flag
    else:
        visibility = "private" if _private_flag else "public"
    tags: list[str] = getattr(args, "tags", []) or []
    initialize: bool = not getattr(args, "no_init", False)
    default_branch: str = getattr(args, "default_branch", "main") or "main"
    json_output: bool = args.json_output

    # ── Local validation — fail fast before any network I/O ──────────────────

    if not name:
        print("❌ Repo name must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)
    if len(name) > _MAX_REPO_NAME_LEN:
        print(
            f"❌ Repo name is too long ({len(name)} chars); "
            f"maximum is {_MAX_REPO_NAME_LEN}.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)
    if len(description) > _MAX_REPO_DESC_LEN:
        print(
            f"❌ Description is too long ({len(description)} chars); "
            f"maximum is {_MAX_REPO_DESC_LEN}.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)
    if visibility not in ("public", "private"):
        print(
            f"❌ Invalid visibility '{sanitize_display(visibility)}'. "
            "Use 'public' or 'private'.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)
    if not default_branch.strip():
        print("❌ Default branch name must not be empty.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    # ── Network calls ─────────────────────────────────────────────────────────

    hub_url, identity = _get_hub_and_identity(hub_url_override=getattr(args, "hub", None))

    # Resolve owner: use --owner if given, else fall back to authenticated handle.
    owner = owner_override.strip() or str(identity.get("handle", ""))
    if not owner:
        print(
            "❌ Could not determine owner. Pass --owner or authenticate with "
            "`muse auth register`.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    payload: _HubPayload = {
        "name": name,
        "owner": owner,
        "visibility": visibility,
        "description": description,
        "tags": tags,
        "initialize": initialize,
        "defaultBranch": default_branch,
    }

    parsed_hub = urllib.parse.urlparse(hub_url)
    server_root = f"{parsed_hub.scheme}://{parsed_hub.netloc}"
    api_path = "/api/repos"

    try:
        data = _hub_api(hub_url, identity, "POST", api_path, body=payload)
    except SystemExit as exc:
        raise exc

    slug = str(data.get("slug", name))
    repo_id = str(data.get("repoId", data.get("repo_id", "")))
    clone_url = str(data.get("cloneUrl", data.get("clone_url", "")))
    created_at = str(data.get("createdAt", data.get("created_at", "")))
    resp_tags: list[str] = [str(t) for t in data.get("tags", [])] if isinstance(data.get("tags"), list) else []
    repo_url = f"{server_root}/{sanitize_display(owner)}/{sanitize_display(slug)}"

    if repo_id.startswith("sha256:"):
        repo_id_b64 = base64.urlsafe_b64encode(bytes.fromhex(repo_id[7:])).rstrip(b"=").decode()
    else:
        repo_id_b64 = ""

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **{
            "repo_id": repo_id,
            "name": name,
            "owner": owner,
            "owner_user_id": str(data.get("ownerUserId", data.get("owner_user_id", ""))),
            "slug": slug,
            "visibility": visibility,
            "description": description,
            "domain_id": data.get("domainId") or data.get("domain_id"),
            "domain": str(data.get("domain", "generic")),
            "default_branch": str(data.get("defaultBranch", data.get("default_branch", "main"))),
            "clone_url": clone_url,
            "tags": resp_tags,
            "created_at": created_at,
            "updated_at": str(data.get("updatedAt", data.get("updated_at", ""))),
            "pushed_at": str(data.get("pushedAt", data.get("pushed_at", ""))),
            "url": repo_url,
            "repoIdB64": repo_id_b64,
        }}))
        return

    print(
        f"✅ Repository created: {sanitize_display(owner)}/{sanitize_display(slug)}",
        file=sys.stderr,
    )
    print(f"   URL:  {sanitize_display(repo_url)}", file=sys.stderr)
    print(
        f"   Visibility: {sanitize_display(visibility)}  "
        f"Branch: {sanitize_display(default_branch)}  "
        f"Init: {'yes' if initialize else 'no'}",
        file=sys.stderr,
    )
    print(
        f"\n   To push an existing repo:\n"
        f"     muse remote add origin {sanitize_display(repo_url)}\n"
        f"     muse push origin {sanitize_display(default_branch)}",
        file=sys.stderr,
    )

def run_repo_delete(args: argparse.Namespace) -> None:
    """Delete a repository on MuseHub.

    Only the repository owner may delete. All data (commits, snapshots, objects,
    issues, proposals) is permanently removed via cascade delete.
    Requires explicit confirmation via ``--yes``.

    When ``target`` is provided it may be ``OWNER/SLUG`` or a repo ID,
    allowing bulk deletion without being inside the target repo's directory.
    When omitted the repo is resolved from the current directory's remote
    config (original behaviour)::

        muse hub repo delete --yes
        muse hub repo delete gabriel/my-repo --yes
        muse hub repo delete a3f2c9d1-... --yes --json

    JSON output (``--json``, stdout)
    --------------------------------
    The standard 6-field envelope plus::

        {
          "deleted": true,
          "repo_id": "<sha256:...>"
        }

    Exit codes
    ----------
    0  Deleted successfully.
    1  Auth error, not authorized, or ``--yes`` not passed.
    2  Not inside a Muse repository (and no target given).
    3  API error.
    """
    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_identity, _resolve_repo_id  # noqa: PLC0415
    yes: bool = args.yes
    json_output: bool = args.json_output
    target: str | None = getattr(args, "target", None)

    if not yes:
        print(
            "❌ Pass --yes to confirm deletion. This action cannot be undone.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    hub_url, identity = _get_hub_and_identity(hub_url_override=args.hub)

    if target is not None:
        if target.startswith("sha256:"):
            # Already a content-addressed repo ID — delete directly.
            repo_id = target
        elif "/" in target:
            owner, slug = target.split("/", 1)
            resp = _hub_api(hub_url, identity, "GET", f"/api/{owner}/{slug}")
            repo_id = resp.get("repoId") or resp.get("repo_id", "")
        else:
            # Bare slug — implies the authenticated user's repo.
            owner = str(identity.get("handle", ""))
            slug = target
            resp = _hub_api(hub_url, identity, "GET", f"/api/{owner}/{slug}")
            repo_id = resp.get("repoId") or resp.get("repo_id", "")
    else:
        repo_id = _resolve_repo_id(hub_url, identity)

    _hub_api(hub_url, identity, "DELETE", f"/api/repos/{repo_id}")

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **{
            "deleted": True,
            "repo_id": repo_id,
        }}))
        return

    print(f"✅ Repository {sanitize_display(repo_id)} deleted.", file=sys.stderr)

def run_repo_update(args: argparse.Namespace) -> None:
    """Show or update repository settings on MuseHub.

    Without flags, prints the current settings.  Pass update flags to patch
    specific fields — only provided flags are written::

        muse hub repo update
        muse hub repo update --visibility private
        muse hub repo update --description "My project" --json

    JSON output (``--json``, stdout)
    --------------------------------
    The standard 6-field envelope plus the raw settings object from the server.
    Field names follow MuseHub's camelCase convention (``defaultBranch``,
    ``hasIssues``, etc.).

    Exit codes
    ----------
    0  Success.
    1  Auth error or not authorized.
    2  Not inside a Muse repository.
    3  API error.
    """
    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_identity, _resolve_repo_id  # noqa: PLC0415
    json_output: bool = args.json_output

    patch = {}
    for field in ("name", "description", "visibility", "default_branch", "homepage_url"):
        val = getattr(args, field, None)
        if val is not None:
            patch[field] = val
    for bool_field in ("has_issues", "has_wiki", "allow_merge_commit",
                       "allow_squash_merge", "allow_rebase_merge", "delete_branch_on_merge"):
        val = getattr(args, bool_field, None)
        if val is not None:
            patch[bool_field] = val

    hub_url, identity = _get_hub_and_identity(hub_url_override=args.hub)
    repo_id = _resolve_repo_id(hub_url, identity)

    if patch:
        data = _hub_api(hub_url, identity, "PATCH", f"/api/repos/{repo_id}/settings", body=patch)
    else:
        data = _hub_api(hub_url, identity, "GET", f"/api/repos/{repo_id}/settings")

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"Name:        {sanitize_display(str(data.get('name', '')))}", file=sys.stderr)
    print(f"Description: {sanitize_display(str(data.get('description', '')))}", file=sys.stderr)
    print(f"Visibility:  {sanitize_display(str(data.get('visibility', '')))}", file=sys.stderr)
    print(f"Branch:      {sanitize_display(str(data.get('defaultBranch', '')))}", file=sys.stderr)
    print(f"Issues:      {data.get('hasIssues', True)}", file=sys.stderr)
    print(f"Wiki:        {data.get('hasWiki', False)}", file=sys.stderr)

def run_repo_list(args: argparse.Namespace) -> None:
    """List repositories owned by or collaborated on by the authenticated user.

    Results are ordered newest-first. Pass ``--limit`` to control page size and
    ``--cursor`` to page through results using the ``next_cursor`` value from a
    previous call.

    JSON output (``--json``, stdout)
    --------------------------------
    The standard 6-field envelope plus::

        {
          "total":       42,
          "next_cursor": "<opaque-string>" | null,
          "repos": [
            {
              "repo_id":        "<sha256:...>",
              "name":           "<name>",
              "owner":          "<handle>",
              "owner_user_id":  "<sha256:...>",
              "slug":           "<slug>",
              "visibility":     "public" | "private",
              "description":    "<desc>",
              "domain_id":      "<label>" | null,
              "domain":         "code" | "midi" | "mist" | "identity" | ...,
              "tags":           ["<tag>", ...],
              "default_branch": "<branch>",
              "created_at":     "<iso8601>",
              "updated_at":     "<iso8601>",
              "pushed_at":      "<iso8601>"
            },
            ...
          ]
        }

    Agent quickstart
    ----------------
    ::

        muse hub repo list --json
        muse hub repo list --limit 50 --json
        muse hub repo list --cursor "<cursor>" --json

    Exit codes
    ----------
    0  Success.
    1  Not authenticated.
    2  Not inside a Muse repository (when hub URL is inferred from config).
    3  API / network error.
    """
    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_identity, _resolve_repo_id  # noqa: PLC0415

    # --owner is not a server-side filter — hub repo list returns repos for the
    # authenticated user only.  Give an actionable error rather than silently
    # ignoring the flag (which looks like success but returns wrong results).
    owner_filter: str | None = getattr(args, "owner_filter", None) or None
    if owner_filter is not None:
        print(
            f"❌ --owner is not supported by 'hub repo list' — the server only returns "
            f"repos for the authenticated user.\n"
            f"\n"
            f"   To filter by owner '{sanitize_display(owner_filter)}', fetch all repos and filter in Python:\n"
            f"\n"
            f"     muse hub repo list --json \\\n"
            f"       | python3 -c \"import sys, json; "
            f"[print(r['slug']) for r in json.load(sys.stdin)['repos'] "
            f"if r['owner'] == '{sanitize_display(owner_filter)}']\"\n",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    limit: int = getattr(args, "limit", 20) or 20
    cursor: str | None = getattr(args, "cursor", None) or None
    json_output: bool = args.json_output

    hub_url, identity = _get_hub_and_identity(hub_url_override=getattr(args, "hub", None))

    params: list[str] = [f"limit={min(max(1, limit), 100)}"]
    if cursor:
        params.append(f"cursor={cursor}")
    api_path = f"/api/repos?{'&'.join(params)}"

    data = _hub_api(hub_url, identity, "GET", api_path)

    repos = data.get("repos", [])  # type: ignore[assignment]
    total: int = int(data.get("total", len(repos)))
    next_cursor: str | None = data.get("nextCursor") or data.get("next_cursor")  # type: ignore[assignment]

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **{
            "total": total,
            "next_cursor": next_cursor,
            "repos": [
                {
                    "repo_id": str(r.get("repoId", r.get("repo_id", ""))),
                    "name": str(r.get("name", "")),
                    "owner": str(r.get("owner", "")),
                    "owner_user_id": str(r.get("ownerUserId", r.get("owner_user_id", ""))),
                    "slug": str(r.get("slug", "")),
                    "visibility": str(r.get("visibility", "public")),
                    "description": str(r.get("description", "")),
                    "domain_id": r.get("domainId") or r.get("domain_id"),
                    "domain": str(r.get("domain", "generic")),
                    "tags": r.get("tags", []),
                    "default_branch": str(r.get("defaultBranch", r.get("default_branch", "main"))),
                    "created_at": str(r.get("createdAt", r.get("created_at", ""))),
                    "updated_at": str(r.get("updatedAt", r.get("updated_at", ""))),
                    "pushed_at": str(r.get("pushedAt", r.get("pushed_at", ""))),
                }
                for r in repos
                if isinstance(r, dict)
            ],
        }}))
        return

    if not repos:
        print("No repositories found.", file=sys.stderr)
        return

    print(f"Repositories ({total} total):", file=sys.stderr)
    for r in repos:
        if not isinstance(r, dict):
            continue
        owner = r.get("owner", "")
        slug = r.get("slug", r.get("name", ""))
        visibility = r.get("visibility", "public")
        desc = r.get("description", "")
        marker = "🔒 " if visibility == "private" else "   "
        print(f"  {marker}{sanitize_display(str(owner))}/{sanitize_display(str(slug))}", file=sys.stderr)
        if desc:
            print(f"       {sanitize_display(str(desc))[:72]}", file=sys.stderr)
    if next_cursor:
        print(f"\n  (more results — pass --cursor {sanitize_display(str(next_cursor))} to continue)", file=sys.stderr)

def run_repo_read(args: argparse.Namespace) -> None:
    """Read metadata for a single MuseHub repository.

    Resolves by ``owner/slug`` (positional ``OWNER/SLUG`` argument) or by the
    hub remote config of the current directory when no argument is given.

    JSON output (``--json``, stdout)
    --------------------------------
    The standard 6-field envelope plus::

        {
          "repo_id":        "<sha256:...>",
          "name":           "<name>",
          "owner":          "<handle>",
          "owner_user_id":  "<sha256:...>",
          "slug":           "<slug>",
          "visibility":     "public" | "private",
          "description":    "<desc>",
          "domain_id":      "<label>" | null,
          "domain":         "code" | "midi" | "mist" | "identity" | ...,
          "tags":           ["<tag>", ...],
          "default_branch": "<branch>",
          "clone_url":      "<url>",
          "created_at":     "<iso8601>",
          "updated_at":     "<iso8601>",
          "pushed_at":      "<iso8601>"
        }

    Agent quickstart
    ----------------
    ::

        muse hub repo read gabriel/my-repo --json
        muse hub repo read --json          # resolves from current repo's hub config

    Exit codes
    ----------
    0  Success.
    1  Not authenticated or not found (404).
    2  Not inside a Muse repository (when hub URL is inferred from config).
    3  API / network error.
    """
    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_identity, _resolve_repo_id  # noqa: PLC0415
    target: str | None = getattr(args, "target", None)
    json_output: bool = args.json_output

    hub_url, identity = _get_hub_and_identity(hub_url_override=getattr(args, "hub", None))

    if target and "/" in target:
        parts = target.split("/", 1)
        owner_part = parts[0].strip()
        slug_part = parts[1].strip()
        api_path = f"/api/{owner_part}/{slug_part}"
    else:
        repo_id = _resolve_repo_id(hub_url, identity)
        api_path = f"/api/repos/{repo_id}"

    data = _hub_api(hub_url, identity, "GET", api_path)

    repo_id_val = str(data.get("repoId", data.get("repo_id", "")))
    name = str(data.get("name", ""))
    owner = str(data.get("owner", ""))
    slug = str(data.get("slug", ""))
    visibility = str(data.get("visibility", "public"))
    description = str(data.get("description", ""))
    tags: list[str] = [str(t) for t in data.get("tags", [])] if isinstance(data.get("tags"), list) else []
    default_branch = str(data.get("defaultBranch", data.get("default_branch", "main")))
    clone_url = str(data.get("cloneUrl", data.get("clone_url", "")))
    created_at = str(data.get("createdAt", data.get("created_at", "")))
    updated_at = str(data.get("updatedAt", data.get("updated_at", "")))
    pushed_at = str(data.get("pushedAt", data.get("pushed_at", "")))

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **{
            "repo_id": repo_id_val,
            "name": name,
            "owner": owner,
            "owner_user_id": str(data.get("ownerUserId", data.get("owner_user_id", ""))),
            "slug": slug,
            "visibility": visibility,
            "description": description,
            "domain_id": data.get("domainId") or data.get("domain_id"),
            "domain": str(data.get("domain", "generic")),
            "tags": tags,
            "default_branch": default_branch,
            "clone_url": clone_url,
            "created_at": created_at,
            "updated_at": updated_at,
            "pushed_at": pushed_at,
        }}))
        return

    visibility_icon = "🔒 private" if visibility == "private" else "public"
    print(f"  {sanitize_display(owner)}/{sanitize_display(slug)}  [{visibility_icon}]", file=sys.stderr)
    if description:
        print(f"  {sanitize_display(description)}", file=sys.stderr)
    if tags:
        print(f"  Tags: {', '.join(sanitize_display(t) for t in tags)}", file=sys.stderr)
    print(f"  Branch: {sanitize_display(default_branch)}", file=sys.stderr)
    if clone_url:
        print(f"  Clone: {sanitize_display(clone_url)}", file=sys.stderr)
    if pushed_at:
        print(f"  Last push: {sanitize_display(pushed_at)}", file=sys.stderr)
    elif created_at:
        print(f"  Created:   {sanitize_display(created_at)}", file=sys.stderr)

def run_repo_transfer_ownership(args: argparse.Namespace) -> None:
    """Transfer ownership of a repository to another user.

    Only the current owner may initiate. After transfer the calling user loses
    owner privileges immediately.  Requires ``--new-owner``::

        muse hub repo transfer --new-owner alice
        muse hub repo transfer --new-owner alice --json

    JSON output (``--json``, stdout)
    --------------------------------
    The standard 6-field envelope plus the raw transfer response from the
    server.  Typically includes ``ownerUserId`` (new owner's ID) and
    ``slug`` of the transferred repo.

    Exit codes
    ----------
    0  Transfer succeeded.
    1  Auth error, not authorized, or ``--new-owner`` missing.
    2  Not inside a Muse repository.
    3  API error.
    """
    elapsed = start_timer()
    from muse.cli.commands.hub import _hub_api, _get_hub_and_identity, _resolve_repo_id  # noqa: PLC0415
    new_owner: str = args.new_owner
    json_output: bool = args.json_output

    hub_url, identity = _get_hub_and_identity(hub_url_override=args.hub)
    repo_id = _resolve_repo_id(hub_url, identity)

    data = _hub_api(
        hub_url, identity, "POST",
        f"/api/repos/{repo_id}/transfer",
        body={"newOwner": new_owner},
    )

    if json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    new_owner_out = sanitize_display(str(data.get("ownerUserId", new_owner)))
    print(f"✅ Repository transferred to {new_owner_out}.", file=sys.stderr)

def register(subs: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register repos subcommands."""
    # ── repo ──────────────────────────────────────────────────────────────────
    repo_p = subs.add_parser(
        "repo",
        help="Manage repositories on MuseHub.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    repo_subs = repo_p.add_subparsers(dest="repo_subcommand", metavar="REPO_COMMAND")
    repo_subs.required = True

    repo_create_p = repo_subs.add_parser(
        "create",
        help="Create a new repository on MuseHub.",
        description=(
            "Create a new remote Muse repository on MuseHub.\n\n"
            "Name must be non-empty and ≤ 255 characters.\n"
            "Owner defaults to the authenticated identity's handle.\n"
            "The repo is initialized with an empty commit by default so it\n"
            "is immediately pushable. Pass --no-init to skip initialization\n"
            "(useful when you are about to push existing history).\n\n"
            "Agent quickstart:\n"
            "  muse hub repo create --name my-repo --json\n"
            "  muse hub repo create --name my-repo --private --no-init --json\n\n"
            "JSON output keys: repo_id, name, owner, slug, visibility,\n"
            "                  description, clone_url, tags, created_at\n\n"
            "Exit codes: 0 created, 1 validation/conflict/auth error,\n"
            "            2 not in repo, 3 API/network error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    repo_create_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="Override the hub URL from config (e.g. https://localhost:1337/owner/repo).",
    )
    repo_create_p.add_argument(
        "--name", "-n", required=True,
        help="Repository name (used to generate the URL slug).",
    )
    repo_create_p.add_argument(
        "--owner", dest="owner", default="", metavar="OWNER",
        help="Owner username. Defaults to the authenticated identity's handle.",
    )
    repo_create_p.add_argument(
        "--description", "-d", default="",
        help="Short description shown on the explore page.",
    )
    repo_create_p.add_argument(
        "--private", action="store_true", default=False,
        help="Create as a private repository (default: public).",
    )
    repo_create_p.add_argument(
        "--visibility", dest="visibility_alias", default=None,
        choices=["public", "private"], metavar="public|private",
        help=(
            "Alias for --private: 'public' (default) or 'private'. "
            "Cannot be combined with --private."
        ),
    )
    repo_create_p.add_argument(
        "--tag", dest="tags", action="append", default=[], metavar="TAG",
        help="Tag to apply (repeatable, e.g. --tag jazz --tag piano).",
    )
    repo_create_p.add_argument(
        "--no-init", dest="no_init", action="store_true", default=False,
        help=(
            "Skip the initial empty commit. Use this when you are about to "
            "push existing history."
        ),
    )
    repo_create_p.add_argument(
        "--default-branch", dest="default_branch", default="main", metavar="BRANCH",
        help="Name of the default branch created on initialization (default: main).",
    )
    repo_create_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output", default=False,
        help="Emit a JSON object to stdout on success.",
    )
    repo_create_p.set_defaults(func=run_repo_create)

    # ── repo delete ───────────────────────────────────────────────────────────
    repo_delete_p = repo_subs.add_parser(
        "delete",
        help="Delete a repository (owner only). Permanent — all data removed.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=textwrap.dedent(
            """\
            Permanently delete a MuseHub repository.  Only the repository owner may
            delete.  All data (commits, snapshots, objects, issues, proposals) is
            removed via cascade delete.  This cannot be undone.

            TARGET may be OWNER/SLUG or a repo ID.  When omitted the repo is
            resolved from the current directory's hub remote config.

            Examples:
              muse hub repo delete --yes
              muse hub repo delete gabriel/my-repo --yes
              muse hub repo delete a3f2c9d1-... --yes --json
            """
        ),
    )
    repo_delete_p.add_argument("target", nargs="?", default=None,
                               metavar="OWNER/SLUG|REPO_ID",
                               help="Repo to delete: OWNER/SLUG or repo ID (default: current dir).")
    repo_delete_p.add_argument("--yes", "-y", action="store_true", dest="yes", default=False,
                               help="Confirm deletion (required).")
    repo_delete_p.add_argument("--hub", dest="hub", default=None, metavar="URL",
                               help="MuseHub base URL (overrides config).")
    repo_delete_p.add_argument("--json", "-j", action="store_true", dest="json_output",
                               default=False, help="Emit JSON on success.")
    repo_delete_p.set_defaults(func=run_repo_delete)

    # ── repo settings ─────────────────────────────────────────────────────────
    repo_update_p = repo_subs.add_parser(
        "update",
        help="View or update repository settings (owner/admin).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=textwrap.dedent(
            """\
            View or patch mutable settings for a MuseHub repository.
            Omit all patch flags to read current settings.
            The repository is resolved from the current directory's hub remote config.

            Examples:
              muse hub repo update
              muse hub repo update --description "New description" --visibility private
              muse hub repo update --json
            """
        ),
    )
    repo_update_p.add_argument("--name", dest="name", default=None, metavar="NAME",
                               help="New repository name.")
    repo_update_p.add_argument("--description", dest="description", default=None,
                               metavar="TEXT", help="New markdown description.")
    repo_update_p.add_argument("--visibility", dest="visibility", default=None,
                               choices=["public", "private"],
                               help="New visibility: public or private.")
    repo_update_p.add_argument("--default-branch", dest="default_branch", default=None,
                               metavar="BRANCH", help="New default branch name.")
    repo_update_p.add_argument("--homepage-url", dest="homepage_url", default=None,
                               metavar="URL", help="Project homepage URL.")
    repo_update_p.add_argument("--hub", dest="hub", default=None, metavar="URL",
                               help="MuseHub base URL (overrides config).")
    repo_update_p.add_argument("--json", "-j", action="store_true", dest="json_output",
                               default=False, help="Emit JSON on success.")
    repo_update_p.set_defaults(func=run_repo_update)

    # ── repo transfer ─────────────────────────────────────────────────────────
    repo_transfer_ownership_p = repo_subs.add_parser(
        "transfer-ownership",
        help="Transfer repository ownership to another user (owner only).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=textwrap.dedent(
            """\
            Transfer ownership of a MuseHub repository to another user.
            Only the current owner may initiate a transfer.
            The repository is resolved from the current directory's hub remote config.

            Examples:
              muse hub repo transfer-ownership --new-owner bob
              muse hub repo transfer-ownership --new-owner bob --json
            """
        ),
    )
    repo_transfer_ownership_p.add_argument("--new-owner", dest="new_owner", required=True,
                                           metavar="HANDLE", help="MSign handle of the new owner.")
    repo_transfer_ownership_p.add_argument("--hub", dest="hub", default=None, metavar="URL",
                                           help="MuseHub base URL (overrides config).")
    repo_transfer_ownership_p.add_argument("--json", "-j", action="store_true", dest="json_output",
                                           default=False, help="Emit JSON on success.")
    repo_transfer_ownership_p.set_defaults(func=run_repo_transfer_ownership)

    # ── repo list ─────────────────────────────────────────────────────────────
    repo_list_p = repo_subs.add_parser(
        "list",
        help="List repositories owned by or collaborated on by the authenticated user.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=textwrap.dedent(
            """\
            List MuseHub repositories owned by or collaborated on by the
            authenticated user.  Results are ordered newest-first.

            Examples:
              muse hub repo list --json
              muse hub repo list --limit 50 --json
              muse hub repo list --cursor "<cursor>" --json
            """
        ),
    )
    repo_list_p.add_argument(
        "--limit", dest="limit", type=int, default=20, metavar="N",
        help="Maximum repos per page (default 20, max 100).",
    )
    repo_list_p.add_argument(
        "--cursor", dest="cursor", default=None, metavar="CURSOR",
        help="Pagination cursor from a previous next_cursor field.",
    )
    repo_list_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="MuseHub base URL (overrides config).",
    )
    repo_list_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output", default=False,
        help="Emit JSON to stdout.",
    )
    repo_list_p.add_argument(
        "--owner", dest="owner_filter", default=None, metavar="HANDLE",
        help=(
            "No server-side owner filter exists. Passing this flag exits with "
            "a message showing how to filter client-side via --json | python3."
        ),
    )
    repo_list_p.set_defaults(func=run_repo_list)

    # ── repo read ─────────────────────────────────────────────────────────────
    repo_read_p = repo_subs.add_parser(
        "read",
        help="Read metadata for a single MuseHub repository.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=textwrap.dedent(
            """\
            Read metadata for a MuseHub repository.  Pass OWNER/SLUG to target
            a specific repo, or omit to resolve from the current directory's
            hub remote config.

            Examples:
              muse hub repo read gabriel/jazz-standards --json
              muse hub repo read --json
            """
        ),
    )
    repo_read_p.add_argument(
        "target", nargs="?", default=None, metavar="OWNER/SLUG",
        help="Repository to read (e.g. gabriel/my-repo). Omit to use current repo.",
    )
    repo_read_p.add_argument(
        "--hub", dest="hub", default=None, metavar="URL",
        help="MuseHub base URL (overrides config).",
    )
    repo_read_p.add_argument(
        "--json", "-j", action="store_true", dest="json_output", default=False,
        help="Emit JSON to stdout.",
    )
    repo_read_p.set_defaults(func=run_repo_read)

    repo_p.set_defaults(func=lambda a: repo_p.print_help())

