import argparse
from ._core import *

def run_user_read(args: argparse.Namespace) -> None:
    """Fetch a user's public profile from MuseHub.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub user read gabriel --json
        muse hub user read gabriel --json | jq '{username,repoCount,followerCount}'

    JSON output keys (from hub): ``username``, ``displayName``, ``bio``,
    ``avatarUrl``, ``repoCount``, ``followerCount``, ``followingCount``,
    ``pinnedRepos``, ``createdAt``.

    Exit codes
    ----------
    0  Success.
    1  Auth error.
    3  API error (404 if user not found).
    """
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))

    data = _hub_api(hub_url, identity, "GET", f"/api/users/{args.username}")

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"\n  {data.get('username')}  {data.get('displayName', '')}", file=sys.stderr)
    if data.get("bio"):
        print(f"  {data['bio']}", file=sys.stderr)
    print(f"  Repos: {data.get('repoCount', 0)}  Followers: {data.get('followerCount', 0)}", file=sys.stderr)

def run_user_update(args: argparse.Namespace) -> None:
    """Update the authenticated user's profile on MuseHub.

    At least one of ``--bio``, ``--avatar-url``, or ``--pinned-repo`` must be given.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub user update gabriel --bio 'Composer and engineer' --json
        muse hub user update gabriel --avatar-url https://example.com/avatar.png --json
        # → {"muse_version": "...", ..., "username": "gabriel", "bio": "..."}

    JSON output keys (from hub): ``username``, ``displayName``, ``bio``,
    ``avatarUrl``, ``pinnedRepos``.

    Exit codes
    ----------
    0  Updated.
    1  Auth error (caller must own the profile).
    3  API error.
    """
    if args.bio is None and args.avatar_url is None and args.pinned_repo_ids is None:
        print("❌ Provide at least one of --bio, --avatar-url, or --pinned-repo.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))

    payload = {}
    if args.bio is not None:
        payload["bio"] = args.bio
    if args.avatar_url is not None:
        payload["avatarUrl"] = args.avatar_url
    if args.pinned_repo_ids is not None:
        payload["pinnedRepoIds"] = args.pinned_repo_ids

    data = _hub_api(hub_url, identity, "PUT", f"/api/users/{args.username}", body=payload)

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"✅ Profile for {args.username} updated.", file=sys.stderr)

def run_topic_list(args: argparse.Namespace) -> None:
    """List topics on MuseHub, optionally filtered by query.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub topic list --json
        muse hub topic list --query jazz --json | jq '.topics[].name'

    JSON output keys (from hub): ``topics`` (list of ``{name, repoCount}``).

    Exit codes
    ----------
    0  Success.
    3  API error.
    """
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))

    params: dict[str, str | int] = {"limit": args.limit}
    if args.query:
        params["q"] = args.query

    data = _hub_api(hub_url, identity, "GET", "/api/topics", params=params)

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    topics = data.get("topics", [])
    if not topics:
        print("  No topics found.", file=sys.stderr)
        return

    for t in topics:
        print(f"  {t.get('name')}  ({t.get('repoCount', 0)} repos)", file=sys.stderr)

def run_topic_set(args: argparse.Namespace) -> None:
    """Set (replace) the topic list for a repo on MuseHub.

    Pass no ``--topic`` flags to clear all topics.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub topic set --topic jazz --topic midi --topic generative --json
        muse hub topic set --json   # clears all topics
        # → {"muse_version": "...", ..., "topics": ["jazz", "midi", "generative"]}

    JSON output keys (from hub): ``topics`` (list of applied topic strings).

    Exit codes
    ----------
    0  Updated.
    1  Auth error.
    2  Not inside a Muse repository.
    3  API error.
    """
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id(hub_url, identity)

    payload = {"topics": args.topics}
    data = _hub_api(hub_url, identity, "PUT", f"/api/repos/{repo_id}/topics", body=payload)

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    applied: list[str] = data.get("topics", [])
    if applied:
        print(f"✅ Topics set: {', '.join(applied)}", file=sys.stderr)
    else:
        print("✅ All topics cleared.", file=sys.stderr)

def run_fork_create(args: argparse.Namespace) -> None:
    """Fork a MuseHub repository into your account.

    ``--repo`` must be in ``owner/repo`` format.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub fork create --repo gabriel/muse --json
        muse hub fork create --repo gabriel/muse --slug my-muse-fork --json
        # → {"muse_version": "...", ..., "owner": "you", "slug": "muse", "forkedFrom": "..."}

    JSON output keys (from hub): ``repoId``, ``owner``, ``slug``,
    ``forkedFrom``, ``createdAt``.

    Exit codes
    ----------
    0  Forked.
    1  Auth error.
    3  API error (404 if source repo not found).
    """
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id_from_owner_repo(hub_url, identity, args.repo)

    payload = {}
    if args.slug:
        payload["slug"] = args.slug

    data = _hub_api(hub_url, identity, "POST", f"/api/repos/{repo_id}/forks", body=payload)

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    print(f"✅ Forked to {data.get('owner')}/{data.get('slug')} (id={str(data.get('repoId',''))}).", file=sys.stderr)

def run_fork_list(args: argparse.Namespace) -> None:
    """List all direct forks of a MuseHub repository.

    ``--repo`` must be in ``owner/repo`` format.

    JSON output is the raw API response merged with the standard envelope.
    Human-readable text goes to stderr.

    Agent quickstart
    ----------------
    ::

        muse hub fork list --repo gabriel/muse --json
        muse hub fork list --repo gabriel/muse --json | jq '.forks[] | .owner + "/" + .slug'

    JSON output keys (from hub): ``forks`` (list), ``total``.
    Each fork: ``repoId``, ``owner``, ``slug``, ``createdAt``.

    Exit codes
    ----------
    0  Success.
    3  API error.
    """
    elapsed = start_timer()
    hub_url, identity = _get_hub_and_identity(hub_url_override=_resolve_hub_override(args))
    repo_id = _resolve_repo_id_from_owner_repo(hub_url, identity, args.repo)

    data = _hub_api(hub_url, identity, "GET", f"/api/repos/{repo_id}/forks")

    if args.json_output:
        print(json.dumps({**make_envelope(elapsed), **data}))
        return

    forks = data.get("forks", [])
    if not forks:
        print("  No forks found.", file=sys.stderr)
        return

    print(f"\n  Forks ({len(forks)} total)", file=sys.stderr)
    for f in forks:
        print(f"  {f.get('owner')}/{f.get('slug')}", file=sys.stderr)

def register(subs: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register users subcommands."""
    # ── user ──────────────────────────────────────────────────────────────────
    user_p = subs.add_parser(
        "user",
        help="Manage user profiles on MuseHub.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    user_subs = user_p.add_subparsers(dest="user_subcommand", metavar="USER_COMMAND")
    user_subs.required = True

    def _user_hub_arg(p: argparse.ArgumentParser) -> None:
        p.add_argument("--hub", dest="hub", default=None, metavar="URL",
                       help="Override the hub URL from config.")
        p.add_argument("--json", "-j", action="store_true", dest="json_output",
                       help="Emit JSON output.")

    user_read_p = user_subs.add_parser(
        "read", help="Read a user's public profile.",
        description=(
            "Fetch a user's public profile: bio, avatar, pinned repos, stats.\n\n"
            "  muse hub user read gabriel\n"
            "  muse hub user read gabriel --json\n\n"
            "Exit codes: 0 success, 1 auth error, 3 API error (404 if not found)."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _user_hub_arg(user_read_p)
    user_read_p.add_argument("username", help="MuseHub username.")
    user_read_p.set_defaults(func=run_user_read)

    user_update_p = user_subs.add_parser(
        "update", help="Update your own profile.",
        description=(
            "Update the authenticated user's profile bio, avatar URL, or pinned repos.\n\n"
            "  muse hub user update --bio 'Composer and engineer'\n"
            "  muse hub user update --avatar-url https://example.com/avatar.png --json\n\n"
            "Exit codes: 0 success, 1 auth error, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _user_hub_arg(user_update_p)
    user_update_p.add_argument("username", help="Your MuseHub username.")
    user_update_p.add_argument("--bio", default=None, help="Profile bio text.")
    user_update_p.add_argument("--avatar-url", dest="avatar_url", default=None,
                               help="Avatar image URL.")
    user_update_p.add_argument("--pinned-repo", dest="pinned_repo_ids", action="append",
                               default=None, metavar="REPO_ID",
                               help="Pinned repo ID (repeatable, replaces all pinned repos).")
    user_update_p.set_defaults(func=run_user_update)

    user_p.set_defaults(func=lambda a: user_p.print_help())

    # ── topic ─────────────────────────────────────────────────────────────────
    topic_p = subs.add_parser(
        "topic",
        help="Manage repo topics on MuseHub.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    topic_subs = topic_p.add_subparsers(dest="topic_subcommand", metavar="TOPIC_COMMAND")
    topic_subs.required = True

    def _topic_repo_args(p: argparse.ArgumentParser) -> None:
        p.add_argument("--hub", dest="hub", default=None, metavar="URL",
                       help="Override the hub URL from config.")
        p.add_argument("--repo", dest="repo", default=None, metavar="OWNER/REPO",
                       help="Specify repo as owner/repo.")
        p.add_argument("--json", "-j", action="store_true", dest="json_output",
                       help="Emit JSON output.")

    topic_list_p = topic_subs.add_parser(
        "list", help="Browse global topics.",
        description=(
            "List all topics registered on MuseHub, optionally filtered by query.\n\n"
            "  muse hub topic list\n"
            "  muse hub topic list --query jazz --json\n\n"
            "Exit codes: 0 success, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    topic_list_p.add_argument("--hub", dest="hub", default=None, metavar="URL",
                              help="Override the hub URL from config.")
    topic_list_p.add_argument("--query", default=None, help="Filter topics by substring.")
    topic_list_p.add_argument("--limit", type=int, default=50, metavar="N",
                              help="Max topics to return (default 50).")
    topic_list_p.add_argument("--json", "-j", action="store_true", dest="json_output",
                              help="Emit JSON output.")
    topic_list_p.set_defaults(func=run_topic_list)

    topic_set_p = topic_subs.add_parser(
        "set", help="Set topics for a repo.",
        description=(
            "Replace the full topic list for a repo (max 20 topics).\n\n"
            "  muse hub topic set --topic jazz --topic midi --topic generative\n"
            "  muse hub topic set --topic jazz --json\n\n"
            "Pass no --topic flags to clear all topics.\n\n"
            "Exit codes: 0 success, 1 auth error, 2 not in repo, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _topic_repo_args(topic_set_p)
    topic_set_p.add_argument("--topic", dest="topics", action="append", default=[],
                             metavar="TOPIC", help="Topic to set (repeatable).")
    topic_set_p.set_defaults(func=run_topic_set)

    topic_p.set_defaults(func=lambda a: topic_p.print_help())

    # ── fork ──────────────────────────────────────────────────────────────────
    fork_p = subs.add_parser(
        "fork",
        help="Fork a repo on MuseHub.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    fork_subs = fork_p.add_subparsers(dest="fork_subcommand", metavar="FORK_COMMAND")
    fork_subs.required = True

    fork_create_p = fork_subs.add_parser(
        "create", help="Fork a repository.",
        description=(
            "Fork a MuseHub repository into your own account.\n\n"
            "  muse hub fork create --repo gabriel/muse\n"
            "  muse hub fork create --repo gabriel/muse --slug my-muse-fork --json\n\n"
            "Exit codes: 0 success, 1 auth error, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    fork_create_p.add_argument("--hub", dest="hub", default=None, metavar="URL",
                               help="Override the hub URL from config.")
    fork_create_p.add_argument("--repo", dest="repo", required=True, metavar="OWNER/REPO",
                               help="Source repo to fork, as owner/repo.")
    fork_create_p.add_argument("--slug", default=None,
                               help="Custom slug for the fork (defaults to source slug).")
    fork_create_p.add_argument("--json", "-j", action="store_true", dest="json_output",
                               help="Emit JSON output.")
    fork_create_p.set_defaults(func=run_fork_create)

    fork_list_p = fork_subs.add_parser(
        "list", help="List forks of a repo.",
        description=(
            "List all direct forks of a repository.\n\n"
            "  muse hub fork list --repo gabriel/muse\n"
            "  muse hub fork list --repo gabriel/muse --json\n\n"
            "Exit codes: 0 success, 3 API error."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    fork_list_p.add_argument("--hub", dest="hub", default=None, metavar="URL",
                             help="Override the hub URL from config.")
    fork_list_p.add_argument("--repo", dest="repo", required=True, metavar="OWNER/REPO",
                             help="Source repo, as owner/repo.")
    fork_list_p.add_argument("--json", "-j", action="store_true", dest="json_output",
                             help="Emit JSON output.")
    fork_list_p.set_defaults(func=run_fork_list)

    fork_p.set_defaults(func=lambda a: fork_p.print_help())

