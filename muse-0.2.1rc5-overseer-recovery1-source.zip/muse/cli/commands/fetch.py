"""muse fetch — download commits, snapshots, and objects from a remote.

Fetches the latest state of a remote branch without touching the local branch
HEAD or working tree.  After a successful fetch:

- All new commits, snapshots, and objects from the remote are stored locally.
- The remote tracking pointer ``.muse/remotes/<remote>/<branch>`` is updated.

Use ``muse pull`` to fetch *and* merge into the current branch, or run
``muse merge`` after fetching to integrate on your own schedule.

Flags
-----
``--all``
    Fetch every configured remote instead of just one.  When combined with
    ``--branch``, that branch is fetched from every remote.

``--prune / -p``
    After fetching, delete local remote-tracking refs (pointers under
    ``.muse/remotes/<remote>/``) for branches that no longer exist on the
    remote.  Mirrors ``git fetch --prune``.

``--dry-run / -n``
    Show what would be fetched without writing anything.

``--tags``
    Also fetch tags from the remote (default behaviour when tags exist).

``--no-tags``
    Do not fetch tags from the remote.

``--format {text,json}`` / ``--json``
    Emit a machine-readable JSON object on stdout instead of human text.
    Human-readable diagnostics always go to stderr regardless of format.

JSON output schema
------------------
Always emits a single JSON object on stdout::

    {
      "results": [
        {
          "remote":           "<name>",
          "branch":           "<branch>",
          "status":           "fetched | up_to_date | dry_run | branch_missing",
          "commits_received": <N>,
          "blobs_written":    <N>,
          "head":             "<commit-id> | null",
          "pruned":           ["<remote>/<branch>", ...],
          "dry_run":          false
        }
      ],
      "dry_run": false
    }

Exit codes::

    0 — success (fetched, up_to_date, dry_run, or branch_missing + prune)
    1 — remote not configured, network error, or no remotes when using --all
"""

import argparse
import json
import logging
import pathlib
import sys
import time
from collections.abc import Callable
from typing import TypedDict

from muse.cli.config import (
    get_signing_identity,
    get_remote,
    get_remote_head,
    list_remotes,
    set_remote_head,
)
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.mpack import apply_mpack
from muse.core.repo import require_repo
from muse.core.refs import read_current_branch
from muse.core.commits import get_all_commits
from muse.core.timing import start_timer
from muse.core.transport import TransportError, make_transport
from muse.core.validation import sanitize_display
from muse.core.types import BranchHeads
from muse.core.paths import remote_tracking_dir as _remote_tracking_dir

logger = logging.getLogger(__name__)

class _RemoteResultJson(TypedDict):
    """Per-remote/branch fetch result nested inside :class:`_FetchJson`.

    Fields
    ------
    remote            Remote name (e.g. ``"origin"``, ``"local"``).
    branch            Branch name fetched from the remote.
    status            Outcome string — one of:
                      ``"fetched"`` (new data received),
                      ``"up_to_date"`` (remote matches local),
                      ``"dry_run"`` (no writes performed),
                      ``"branch_missing"`` (branch not found on remote).
    commits_received  Number of new commit records written to local storage.
    blobs_written     Number of new blobs written.
    head              Remote commit ID that the branch tip points to after the
                      fetch, or ``None`` when nothing was fetched.
    pruned            List of ``"<remote>/<branch>"`` strings for each ref that
                      existed locally but is no longer present on the remote.
    dry_run           True when the fetch was simulated — no blobs were written.
    """

    remote: str
    branch: str
    status: str
    commits_received: int
    blobs_written: int
    head: str | None
    pruned: list[str]
    dry_run: bool

class _FetchJson(EnvelopeJson):
    """JSON output for ``muse fetch --json``.

    Inherits the 6 standard envelope fields from :class:`~muse.core.envelope.EnvelopeJson`.

    Fields
    ------
    results  One result entry per remote/branch combination fetched;
             see :class:`_RemoteResultJson`.
    dry_run  True when no objects were written (``--dry-run`` was passed).
    """

    results: list[_RemoteResultJson]
    dry_run: bool

class _FetchErrorJsonBase(EnvelopeJson):
    """Required fields for all ``muse fetch`` error JSON outputs."""

    error: str
    message: str

class _FetchErrorJson(_FetchErrorJsonBase, total=False):
    """JSON error output for ``muse fetch --json`` on failure.

    Fields
    ------
    error     Machine-readable error code (e.g. ``"remote_not_configured"``).
    message   Human-readable description of the failure.
    remote    Remote name involved, when applicable.
    branch    Branch name involved, when applicable.
    available Sorted list of available branch names (for ``branch_not_found``).
    hint      Suggested remediation command.
    retryable True when error is a 503 that exhausted the retry budget.
    """

    remote: str
    branch: str
    available: list[str]
    hint: str
    retryable: bool

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse fetch`` subcommand and all its flags."""
    parser = subparsers.add_parser(
        "fetch",
        help="Download commits, snapshots, and objects from a remote.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "remote",
        nargs="?",
        default="origin",
        help="Remote name to fetch from (default: origin). Ignored when --all is set.",
    )
    parser.add_argument(
        "--branch", "-b",
        default=None,
        help=(
            "Remote branch to fetch (default: current branch). "
            "When combined with --all, this branch is fetched from every remote."
        ),
    )
    parser.add_argument(
        "--all",
        action="store_true",
        default=False,
        help="Fetch all configured remotes.",
    )
    parser.add_argument(
        "--prune", "-p",
        action="store_true",
        default=False,
        help=(
            "Remove local remote-tracking refs for branches that no longer exist "
            "on the remote (mirrors git fetch --prune)."
        ),
    )
    parser.add_argument(
        "--dry-run", "-n",
        action="store_true",
        default=False,
        dest="dry_run",
        help="Show what would be fetched without writing any objects or tracking refs.",
    )
    # Tag handling flags — reserved for future use when tag storage is added.
    tag_group = parser.add_mutually_exclusive_group()
    tag_group.add_argument(
        "--tags",
        action="store_true",
        default=None,
        dest="tags",
        help="Fetch tags from the remote (default).",
    )
    tag_group.add_argument(
        "--no-tags",
        action="store_false",
        dest="tags",
        help="Do not fetch tags from the remote.",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON.",
    )
    parser.add_argument(
        "--retry-timeout",
        type=float,
        default=None,
        dest="retry_budget_s",
        metavar="SECONDS",
        help=(
            "Maximum seconds to wait for the remote to finish preparing fetch data "
            "(503 Retry-After loop). Default: 120 s or MUSE_FETCH_RETRY_BUDGET_S env."
        ),
    )
    parser.add_argument(
        "--no-retry",
        action="store_const",
        const=0.0,
        dest="retry_budget_s",
        help=(
            "Disable the 503 retry loop — fail immediately on the first 503 response. "
            "Useful for deterministic CI. Overrides --retry-timeout."
        ),
    )
    parser.set_defaults(func=run)

def _stale_ref_names(
    root: pathlib.Path,
    remote: str,
    live_branch_heads: BranchHeads,
) -> list[str]:
    """Return branch names whose local tracking refs are absent from *live_branch_heads*.

    Branch names may contain slashes (e.g. ``feat/my-thing``), so the refs are
    stored as nested files under ``.muse/remotes/<remote>/``.  We walk the tree
    recursively and compute the relative path from ``refs_dir`` to get the full
    branch name to compare against *live_branch_heads*.

    Symlinks inside the refs directory are skipped to prevent path-traversal
    attacks via a malicious remote name or branch name.
    """
    refs_dir = _remote_tracking_dir(root, remote)
    if not refs_dir.is_dir():
        return []
    stale: list[str] = []
    for ref_file in refs_dir.rglob("*"):
        if ref_file.is_symlink() or not ref_file.is_file():
            continue
        branch_name = str(ref_file.relative_to(refs_dir))
        if branch_name not in live_branch_heads:
            stale.append(branch_name)
    return stale

def _prune_stale_refs(
    root: pathlib.Path,
    remote: str,
    live_branch_heads: BranchHeads,
    *,
    dry_run: bool,
) -> list[str]:
    """Prune stale remote-tracking refs, returning the list of pruned branch names.

    Walks ``.muse/remotes/<remote>/`` recursively (branch names may contain
    slashes and are stored as nested paths) and, unless *dry_run* is True,
    deletes any file whose relative path is not a key in *live_branch_heads*.
    Prints a ``- [deleted]`` or ``Would prune`` line for each, mirroring
    ``git fetch --prune`` output.  All output goes to stderr so stdout stays
    clean for structured JSON.
    """
    refs_dir = _remote_tracking_dir(root, remote)
    pruned: list[str] = []
    for branch_name in sorted(_stale_ref_names(root, remote, live_branch_heads)):
        safe_ref = f"{sanitize_display(remote)}/{sanitize_display(branch_name)}"
        if dry_run:
            print(f"  Would prune {safe_ref}", file=sys.stderr)
        else:
            ref_file = refs_dir / branch_name
            ref_file.unlink()
            # Remove empty parent directories left behind (e.g. feat/ after feat/my-thing).
            for parent in ref_file.parents:
                if parent == refs_dir:
                    break
                try:
                    parent.rmdir()
                except OSError:
                    break
            logger.debug("🗑  Pruned stale tracking ref %s/%s", remote, branch_name)
            print(f" - [deleted]  {safe_ref}", file=sys.stderr)
        pruned.append(f"{remote}/{branch_name}")
    return pruned

def _fetch_one(
    root: pathlib.Path,
    remote: str,
    branch: str,
    *,
    prune: bool,
    dry_run: bool,
    json_out: bool = False,
    elapsed: Callable[[], float] = lambda: 0.0,
    retry_budget_s: "float | None" = None,
) -> _RemoteResultJson:
    """Fetch a single remote/branch pair.

    Returns a :class:`_RemoteResultJson` describing the outcome.  Raises
    ``SystemExit`` on unrecoverable errors (unknown remote, network failure).
    Writes nothing when *dry_run* is True.

    Full local history is sent as the ``have`` list so the server can compute
    the minimal delta.
    """
    result: _RemoteResultJson = {
        "remote": remote,
        "branch": branch,
        "status": "fetched",
        "commits_received": 0,
        "blobs_written": 0,
        "head": None,
        "pruned": [],
        "dry_run": dry_run,
    }

    url = get_remote(remote, root)
    if url is None:
        if json_out:
            print(json.dumps(_FetchErrorJson(
                **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                error="remote_not_configured",
                remote=remote,
                message=f"remote '{remote}' is not configured",
                hint=f"muse remote add {remote} <url>",
            )))
        print(
            f"❌ Remote '{sanitize_display(remote)}' is not configured.",
            file=sys.stderr,
        )
        print(
            f"  Add it with: muse remote add {sanitize_display(remote)} <url>",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    token = get_signing_identity(root, remote_url=url)
    transport = make_transport(url)

    try:
        info = transport.fetch_remote_info(url, token)
    except TransportError as exc:
        if json_out:
            print(json.dumps(_FetchErrorJson(
                **make_envelope(elapsed, exit_code=ExitCode.INTERNAL_ERROR),
                error="remote_unreachable",
                remote=remote,
                message=str(exc),
            )))
        print(
            f"❌ Cannot reach remote '{sanitize_display(remote)}': "
            f"{sanitize_display(str(exc))}",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    remote_commit_id = info["branch_heads"].get(branch)
    if remote_commit_id is None:
        if prune:
            # The branch we were tracking is gone from the remote.
            # Prune it (and any other stale refs) then return cleanly —
            # this mirrors `git fetch --prune` behaviour where a deleted
            # upstream branch produces " - [deleted]  remote/branch" rather
            # than an error.
            pruned = _prune_stale_refs(root, remote, info["branch_heads"], dry_run=dry_run)
            result["status"] = "branch_missing"
            result["pruned"] = pruned
            return result
        available = sorted(info["branch_heads"])
        if json_out:
            print(json.dumps(_FetchErrorJson(
                **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                error="branch_not_found",
                remote=remote,
                branch=branch,
                available=available,
                message=f"branch '{branch}' does not exist on remote '{remote}'",
            )))
        print(
            f"❌ Branch '{sanitize_display(branch)}' does not exist on "
            f"remote '{sanitize_display(remote)}'.",
            file=sys.stderr,
        )
        print(f"  Available branches: {', '.join(sanitize_display(b) for b in available)}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    already_known = get_remote_head(remote, branch, root)
    if already_known == remote_commit_id:
        print(
            f"✅ {sanitize_display(remote)}/{sanitize_display(branch)} "
            f"is already up to date ({remote_commit_id})",
            file=sys.stderr,
        )
        if prune and not dry_run:
            pruned = _prune_stale_refs(root, remote, info["branch_heads"], dry_run=False)
            result["pruned"] = pruned
        result["status"] = "up_to_date"
        result["head"] = remote_commit_id
        return result

    if dry_run:
        print(
            f"  Would fetch {sanitize_display(remote)}/{sanitize_display(branch)} "
            f"→ {remote_commit_id}",
            file=sys.stderr,
        )
        if prune:
            pruned = _prune_stale_refs(root, remote, info["branch_heads"], dry_run=True)
            result["pruned"] = pruned
        result["status"] = "dry_run"
        result["head"] = remote_commit_id
        return result

    have_for_fetch = [c.commit_id for c in get_all_commits(root)]

    print(f"Fetching {sanitize_display(remote)}/{sanitize_display(branch)} …", file=sys.stderr)

    t0_fetch = time.perf_counter()
    try:
        fetch_result = transport.fetch_mpack(
            url, token,
            want=[remote_commit_id],
            have=have_for_fetch,
            retry_budget_s=retry_budget_s,
        )
    except TransportError as exc:
        _is_503 = exc.status_code == 503
        if _is_503:
            from muse.core.transport import _resolve_retry_budget
            _budget = _resolve_retry_budget(retry_budget_s)
            _msg = f"Remote still preparing fetch data after {int(_budget)}s — try again shortly."
        else:
            _msg = str(exc)
        if json_out:
            print(json.dumps(_FetchErrorJson(
                **make_envelope(elapsed, exit_code=ExitCode.INTERNAL_ERROR),
                error="fetch_failed",
                remote=remote,
                branch=branch,
                message=_msg,
                retryable=_is_503,
            )))
        print(f"❌ {sanitize_display(_msg)}", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR)
    t_fetch = time.perf_counter() - t0_fetch

    apply_result = apply_mpack(root, {
        "commits":   fetch_result["commits"],
        "snapshots": fetch_result["snapshots"],
        "blobs":     fetch_result["blobs"],
    })

    if not apply_result["failed_blobs"]:
        set_remote_head(remote, branch, remote_commit_id, root)

    commits_received: int = apply_result["commits_written"]
    blobs_written: int = apply_result["blobs_written"]
    print(
        f"[mpack] fetch/mpack: {t_fetch:.2f}s  "
        f"blobs: {fetch_result.get('blobs_received', 0)}  "
        f"commits: {commits_received}",
        file=sys.stderr,
    )
    print(
        f"✅ Fetched {commits_received} commit(s), "
        f"{blobs_written} new blob(s) "
        f"from {sanitize_display(remote)}/{sanitize_display(branch)} "
        f"({remote_commit_id})",
        file=sys.stderr,
    )

    if prune:
        pruned = _prune_stale_refs(root, remote, info["branch_heads"], dry_run=False)
        result["pruned"] = pruned

    result["commits_received"] = commits_received
    result["blobs_written"] = blobs_written
    result["head"] = remote_commit_id
    return result

def run(args: argparse.Namespace) -> None:
    """Download commits, snapshots, and objects from a remote.

    Updates remote tracking pointers but does NOT change local HEAD or the
    working tree.  Run ``muse pull`` to fetch and merge in one step.
    ``--all`` fetches every configured remote; ``--prune`` deletes stale
    remote-tracking refs after a successful fetch.

    Agent quickstart
    ----------------
    ::

        muse fetch local --json
        muse fetch local main --json
        muse fetch --all --json
        muse fetch local --prune --json

    JSON fields
    -----------
    results  List of per-remote result objects: ``remote``, ``branch``,
             ``new_commits``, ``objects_fetched``, ``ok``, ``error``.
    dry_run  ``true`` if ``--dry-run`` was passed (no writes occurred).

    Exit codes
    ----------
    0  Fetch complete (all remotes succeeded).
    1  One or more remotes failed, no remotes configured, or bad arguments.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    root = require_repo()
    current_branch = read_current_branch(root)
    dry_run: bool = args.dry_run
    prune: bool = args.prune
    retry_budget_s: float | None = getattr(args, "retry_budget_s", None)
    json_out: bool = args.json_out

    if dry_run:
        print("(dry run — no objects or refs will be written)", file=sys.stderr)

    results: list[_RemoteResultJson] = []

    if args.all:
        remotes = list_remotes(root)
        if not remotes:
            if json_out:
                print(json.dumps(_FetchErrorJson(
                    **make_envelope(elapsed, exit_code=ExitCode.USER_ERROR),
                    error="no_remotes",
                    message="no remotes configured",
                    hint="muse remote add <name> <url>",
                )))
            print("❌ No remotes configured.", file=sys.stderr)
            print("  Add one with: muse remote add <name> <url>", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        # --branch with --all: fetch the specified branch from every remote.
        branch: str = args.branch or current_branch
        for remote_cfg in remotes:
            result = _fetch_one(
                root,
                remote_cfg["name"],
                branch,
                prune=prune,
                dry_run=dry_run,
                json_out=json_out,
                elapsed=elapsed,
                retry_budget_s=retry_budget_s,
            )
            results.append(result)
    else:
        remote: str = args.remote
        # Use the explicitly passed branch, or fall back to the current local branch.
        # Do NOT use get_upstream() here — that returns the remote *name*, not branch.
        branch_single: str = args.branch or current_branch
        result = _fetch_one(
            root, remote, branch_single,
            prune=prune, dry_run=dry_run, json_out=json_out, elapsed=elapsed,
            retry_budget_s=retry_budget_s,
        )
        results.append(result)

    if json_out:
        print(json.dumps(_FetchJson(
            **make_envelope(elapsed),
            results=results,
            dry_run=dry_run,
        )))
