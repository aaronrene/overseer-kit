"""``muse social`` — cryptographically-grounded, algo-free social network on Muse.

Every post is a content-addressed object signed with Ed25519.  Your timeline
is a live DAG merge of every feed you follow.  No algorithm.  No suppression.
Pure chronological state owned by you.

State layout (social repo working tree)
----------------------------------------
    posts/sha256/<hex>.json          — individual signed posts
    reactions/sha256/<hex>.json      — emoji reactions, optional MPay tip
    graph/follows/<handle>.json   — one file per followed identity
    profile.json                  — handle, bio, avatar ref, AVAX address

Subcommands
-----------
post        Publish a new post (optionally as a reply or quote).
follow      Add a handle to your follow graph.
unfollow    Remove a handle from your follow graph.
timeline    Display your merged chronological feed.
react       Add an emoji reaction to a post.
profile     Show or update your social profile.

All subcommands accept ``--json`` for machine-readable output.

Exit codes
----------
0  Success.
1  User error — missing required argument.
2  Not inside a social-domain Muse repository.
"""

import argparse
import json
import pathlib
import sys
from collections.abc import Mapping
from datetime import datetime, timezone

from muse.cli.domain_command_registry import register_namespace
from muse.core.types import blob_id, load_json_file, split_id

# ---------------------------------------------------------------------------
# Internal helpers — pure state logic, no repo, no network
# ---------------------------------------------------------------------------

def _utc_now() -> str:
    """Return the current UTC time as an ISO-8601 string."""
    return datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _build_post(
    body: str,
    *,
    reply_to: str | None = None,
    quote_of: str | None = None,
    created_at: str | None = None,
) -> Mapping[str, object]:
    """Build a post dict with a deterministic content-addressed ``post_id``.

    The ``post_id`` is derived from the canonical JSON of the post content
    (body + reply_to + quote_of + created_at), so the same inputs always
    produce the same ID.

    Args:
        body:       Post text (required).
        reply_to:   ``post_id`` of the parent post, or ``None``.
        quote_of:   ``post_id`` of the quoted post, or ``None``.
        created_at: ISO-8601 UTC timestamp; defaults to now.

    Returns:
        A dict with ``post_id``, ``body``, ``created_at``, and optional
        ``reply_to`` / ``quote_of`` fields.
    """
    ts = created_at or _utc_now()
    canonical = json.dumps(
        {"body": body, "reply_to": reply_to, "quote_of": quote_of, "created_at": ts},
        sort_keys=True,
        separators=(",", ":"),
    ).encode()
    post_id = blob_id(canonical)
    post = {"post_id": post_id, "body": body, "created_at": ts}
    if reply_to is not None:
        post["reply_to"] = reply_to
    if quote_of is not None:
        post["quote_of"] = quote_of
    return post

def _write_post(state_dir: pathlib.Path, post: Mapping[str, object]) -> pathlib.Path:
    """Write a post dict to ``<state_dir>/posts/sha256/<hex>.json``.

    Idempotent: writing the same post twice produces one file.

    Args:
        state_dir: Root of the social repo working tree.
        post:      Post dict produced by :func:`_build_post`.

    Returns:
        The path of the written file.
    """
    algo, hex_digest = split_id(post["post_id"])
    posts_dir = state_dir / "posts" / algo
    posts_dir.mkdir(parents=True, exist_ok=True)
    path = posts_dir / f"{hex_digest}.json"
    path.write_text(json.dumps(post, ensure_ascii=False, indent=2))
    return path

def _write_follow(state_dir: pathlib.Path, handle: str) -> pathlib.Path:
    """Write a follow entry for *handle* to ``graph/follows/<handle>.json``.

    Idempotent: calling twice with the same handle produces one file.

    Args:
        state_dir: Root of the social repo working tree.
        handle:    Handle to follow (e.g. ``"alice"``).

    Returns:
        The path of the written file.
    """
    follows_dir = state_dir / "graph" / "follows"
    follows_dir.mkdir(parents=True, exist_ok=True)
    path = follows_dir / f"{handle}.json"
    if not path.exists():
        path.write_text(json.dumps({"handle": handle, "since": _utc_now()}, indent=2))
    return path

def _delete_follow(state_dir: pathlib.Path, handle: str) -> None:
    """Remove the follow entry for *handle*, if it exists.

    No-op when the handle is not currently followed.

    Args:
        state_dir: Root of the social repo working tree.
        handle:    Handle to unfollow.
    """
    path = state_dir / "graph" / "follows" / f"{handle}.json"
    path.unlink(missing_ok=True)

def _write_reaction(
    state_dir: pathlib.Path,
    *,
    post_id: str,
    emoji: str,
    mpay: Mapping[str, object] | None = None,
) -> pathlib.Path:
    """Write a reaction to ``reactions/<reaction_id>.json``.

    The reaction file is content-addressed on (post_id + emoji) so the same
    reaction from the same user is idempotent — reacting with ❤️ twice
    produces one file.

    Args:
        state_dir: Root of the social repo working tree.
        post_id:   The ``sha256:<hex>`` ID of the target post.
        emoji:     Emoji string (e.g. ``"❤️"``).
        mpay:      Optional MPay tip dict ``{from, to, amount_usdc, sig}``.

    Returns:
        The path of the written reaction file.
    """
    canonical = json.dumps(
        {"post_id": post_id, "emoji": emoji},
        sort_keys=True, separators=(",", ":"),
    ).encode()
    reaction_id = blob_id(canonical)
    algo, hex_digest = split_id(reaction_id)
    reactions_dir = state_dir / "reactions" / algo
    reactions_dir.mkdir(parents=True, exist_ok=True)
    reaction = {"post_id": post_id, "emoji": emoji, "reacted_at": _utc_now()}
    if mpay is not None:
        reaction["mpay"] = mpay
    path = reactions_dir / f"{hex_digest}.json"
    path.write_text(json.dumps(reaction, ensure_ascii=False, indent=2))
    return path

def _read_profile(state_dir: pathlib.Path) -> Mapping[str, object] | None:
    """Read ``profile.json`` from *state_dir*, returning ``None`` if absent.

    Args:
        state_dir: Root of the social repo working tree.

    Returns:
        Profile dict or ``None``.
    """
    return load_json_file(state_dir / "profile.json")

def _write_profile(state_dir: pathlib.Path, profile: Mapping[str, object]) -> pathlib.Path:
    """Write *profile* to ``profile.json`` in *state_dir*.

    Overwrites any existing profile.  Call :func:`_read_profile` first to
    merge changes rather than replace the whole object.

    Args:
        state_dir: Root of the social repo working tree.
        profile:   Profile dict to serialise.

    Returns:
        The path of the written file.
    """
    path = state_dir / "profile.json"
    path.write_text(json.dumps(profile, ensure_ascii=False, indent=2))
    return path

def _load_posts(state_dir: pathlib.Path, *, limit: int | None = None) -> list[dict]:
    """Load all posts from ``<state_dir>/posts/``, sorted newest-first.

    Args:
        state_dir: Root of the social repo working tree.
        limit:     Maximum number of posts to return; ``None`` = all.

    Returns:
        List of post dicts ordered by ``created_at`` descending.
    """
    posts_dir = state_dir / "posts"
    if not posts_dir.exists():
        return []
    posts: list[dict] = []
    for algo_dir in posts_dir.iterdir():
        if not algo_dir.is_dir():
            continue
        for path in algo_dir.iterdir():
            if path.suffix == ".json":
                data = load_json_file(path)
                if data is not None:
                    posts.append(data)
    posts.sort(key=lambda p: p.get("created_at", ""), reverse=True)
    if limit is not None:
        posts = posts[:limit]
    return posts

# ---------------------------------------------------------------------------
# run_* handlers
# ---------------------------------------------------------------------------

def run_post(args: argparse.Namespace) -> None:
    """Publish a new post to the local social repo state.

    Writes ``posts/sha256/<hex>.json`` to the working tree.  Does not commit —
    stage and commit separately with ``muse code add . && muse commit``.

    JSON output (``--json``)::

        {"post_id": "sha256:...", "body": "...", "created_at": "..."}

    Args:
        args: Parsed argument namespace with ``body``, ``reply_to``,
              ``quote_of``, and ``json_output`` attributes.
    """
    state_dir = pathlib.Path(".")
    post = _build_post(
        body=args.body,
        reply_to=getattr(args, "reply_to", None),
        quote_of=getattr(args, "quote_of", None),
    )
    path = _write_post(state_dir, post)
    if args.json_output:
        print(json.dumps(post, ensure_ascii=False))
    else:
        print(f"✅ Posted: {post['post_id']}")
        print(f"   {post['body'][:80]}")

def run_follow(args: argparse.Namespace) -> None:
    """Add a handle to your follow graph.

    Writes ``graph/follows/<handle>.json`` to the working tree.
    Idempotent — following the same handle twice is a no-op.

    Args:
        args: Parsed argument namespace with ``handle`` and ``json_output``.
    """
    state_dir = pathlib.Path(".")
    path = _write_follow(state_dir, args.handle)
    if args.json_output:
        data = json.loads(path.read_text())
        print(json.dumps(data))
    else:
        print(f"✅ Following {args.handle}")

def run_unfollow(args: argparse.Namespace) -> None:
    """Remove a handle from your follow graph.

    Deletes ``graph/follows/<handle>.json`` from the working tree.
    No-op if the handle is not currently followed.

    Args:
        args: Parsed argument namespace with ``handle`` and ``json_output``.
    """
    state_dir = pathlib.Path(".")
    _delete_follow(state_dir, args.handle)
    if args.json_output:
        print(json.dumps({"handle": args.handle, "unfollowed": True}))
    else:
        print(f"✅ Unfollowed {args.handle}")

def run_timeline(args: argparse.Namespace) -> None:
    """Display your merged chronological feed, newest-first.

    Reads all posts from ``posts/`` in the current working tree.
    Pass ``--limit N`` to cap the output.

    Args:
        args: Parsed argument namespace with ``limit`` and ``json_output``.
    """
    state_dir = pathlib.Path(".")
    limit: int | None = getattr(args, "limit", None)
    posts = _load_posts(state_dir, limit=limit)
    if args.json_output:
        print(json.dumps({"posts": posts, "total": len(posts)}))
    else:
        if not posts:
            print("📭 No posts yet.")
            return
        for post in posts:
            reply_marker = f" ↩ {post['reply_to']}" if post.get("reply_to") else ""
            ts = post.get("created_at", "")[:16].replace("T", " ")
            print(f"● {ts}{reply_marker}")
            print(f"  {post['body']}")
            print(f"  {post['post_id']}")
            print()

def run_react(args: argparse.Namespace) -> None:
    """Add an emoji reaction to a post.

    Writes ``reactions/sha256/<hex>.json`` to the working tree.
    Content-addressed on (post_id, emoji) — reacting with the same emoji
    twice is idempotent.

    Args:
        args: Parsed argument namespace with ``post_id``, ``emoji``, and
              ``json_output``.
    """
    state_dir = pathlib.Path(".")
    path = _write_reaction(state_dir, post_id=args.post_id, emoji=args.emoji)
    if args.json_output:
        data = json.loads(path.read_text())
        print(json.dumps(data))
    else:
        print(f"✅ Reacted {args.emoji} to {args.post_id}")

def run_profile(args: argparse.Namespace) -> None:
    """Show or update your social profile.

    Without ``--set-bio`` or ``--set-avatar``, prints the current profile.
    With flags, updates ``profile.json`` in the working tree.

    Args:
        args: Parsed argument namespace with ``set_bio``, ``set_avatar``,
              and ``json_output``.
    """
    state_dir = pathlib.Path(".")
    set_bio: str | None = getattr(args, "set_bio", None)
    set_avatar: str | None = getattr(args, "set_avatar", None)

    if set_bio is not None or set_avatar is not None:
        profile = _read_profile(state_dir) or {}
        if set_bio is not None:
            profile["bio"] = set_bio
        if set_avatar is not None:
            profile["avatar_ref"] = set_avatar
        _write_profile(state_dir, profile)
        if args.json_output:
            print(json.dumps(profile))
        else:
            print("✅ Profile updated.")
    else:
        profile = _read_profile(state_dir)
        if profile is None:
            if args.json_output:
                print(json.dumps(None))
            else:
                print("📭 No profile found. Run: muse social profile --set-bio 'Your bio'")
            return
        if args.json_output:
            print(json.dumps(profile))
        else:
            handle = profile.get("handle", "unknown")
            bio = profile.get("bio", "")
            print(f"@{handle}")
            if bio:
                print(f"  {bio}")

# ---------------------------------------------------------------------------
# CLI registration
# ---------------------------------------------------------------------------

def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``muse social`` subcommand tree and all its flags.

    Subcommands
    -----------
    post        Publish a new post.
    follow      Add a handle to your follow graph.
    unfollow    Remove a handle from your follow graph.
    timeline    Display your merged chronological feed.
    react       Add an emoji reaction to a post.
    profile     Show or update your social profile.

    All subcommands accept ``--json`` for machine-readable output.

    Args:
        subparsers: The top-level argument parser's subparsers action.
    """
    parser = subparsers.add_parser(
        "social",
        help="Algo-free, cryptographically-grounded social network on Muse.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subs = parser.add_subparsers(dest="social_subcommand", metavar="SUBCOMMAND")
    subs.required = True

    # ── post ──────────────────────────────────────────────────────────────────
    post_p = subs.add_parser("post", help="Publish a new post.")
    post_p.add_argument("body", metavar="TEXT", help="Post body text.")
    post_p.add_argument("--reply-to", dest="reply_to", metavar="POST_ID",
                        help="post_id of the parent post (for replies).")
    post_p.add_argument("--quote", dest="quote_of", metavar="POST_ID",
                        help="post_id of a post to quote.")
    post_p.add_argument("--json", dest="json_output", action="store_true",
                        help="Output JSON.")
    post_p.set_defaults(func=run_post)

    # ── follow ────────────────────────────────────────────────────────────────
    follow_p = subs.add_parser("follow", help="Follow a handle.")
    follow_p.add_argument("handle", metavar="HANDLE", help="Handle to follow.")
    follow_p.add_argument("--json", dest="json_output", action="store_true")
    follow_p.set_defaults(func=run_follow)

    # ── unfollow ──────────────────────────────────────────────────────────────
    unfollow_p = subs.add_parser("unfollow", help="Unfollow a handle.")
    unfollow_p.add_argument("handle", metavar="HANDLE", help="Handle to unfollow.")
    unfollow_p.add_argument("--json", dest="json_output", action="store_true")
    unfollow_p.set_defaults(func=run_unfollow)

    # ── timeline ──────────────────────────────────────────────────────────────
    tl_p = subs.add_parser("timeline", help="Show your merged chronological feed.")
    tl_p.add_argument("--limit", type=int, default=None, metavar="N",
                      help="Maximum number of posts to show.")
    tl_p.add_argument("--json", dest="json_output", action="store_true")
    tl_p.set_defaults(func=run_timeline)

    # ── react ─────────────────────────────────────────────────────────────────
    react_p = subs.add_parser("react", help="React to a post with an emoji.")
    react_p.add_argument("post_id", metavar="POST_ID", help="ID of the post to react to.")
    react_p.add_argument("emoji", metavar="EMOJI", help="Emoji to react with.")
    react_p.add_argument("--json", dest="json_output", action="store_true")
    react_p.set_defaults(func=run_react)

    # ── profile ───────────────────────────────────────────────────────────────
    prof_p = subs.add_parser("profile", help="Show or update your social profile.")
    prof_p.add_argument("--set-bio", dest="set_bio", metavar="TEXT",
                        help="Set your bio.")
    prof_p.add_argument("--set-avatar", dest="set_avatar", metavar="PATH",
                        help="Set your avatar (object ID or path).")
    prof_p.add_argument("--json", dest="json_output", action="store_true")
    prof_p.set_defaults(func=run_profile)

    register_namespace("social", subs.choices.keys())
