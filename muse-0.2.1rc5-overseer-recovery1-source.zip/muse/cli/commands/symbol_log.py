"""muse code symbol-log -- track a single semantic symbol through commit history.

This command is impossible in Git: Git's ``git log -p src/utils.py`` shows
every line that changed in a file; it has no concept of a *function*.
``muse code symbol-log`` tracks the full lifecycle of a single named symbol --
when it was created, when its implementation changed, when it was renamed,
and when it was deleted -- across the entire commit DAG, including all
branches that were ever merged in.

Usage::

    muse code symbol-log "src/utils.py::calculate_total"
    muse code symbol-log "src/models.py::User.save"

Output::

    Symbol: src/utils.py::calculate_total
    ----------------------------------------------------------------------

    * a3f2c9  2026-03-14  "Refactor: extract validation logic"
      created  function calculate_total

    * cb4afa  2026-03-15  "Perf: optimise total calculation"
      modified  implementation changed

    * 1d2e3f  2026-03-16  "Rename: calculate_total -> compute_total"
      renamed   calculate_total -> compute_total
      (tracking continues as src/utils.py::compute_total)

    * 4a5b6c  2026-03-17  "Move: refactor to helpers module"
      moved     src/utils.py::compute_total -> src/helpers.py::compute_total
      (tracking continues at src/helpers.py::compute_total)

    4 events  (created: 1  modified: 1  renamed: 1  moved: 1)

Flags::

    --from <ref>
        Start walking from this commit instead of HEAD.
        Accepts a full or abbreviated commit SHA or a branch name.

    --max <n>
        Cap the number of commits inspected (default: 500).
        When the cap is reached a warning is shown; increase it with
        --max to see the full history.

    --json
        Emit a structured JSON object::

            {
              "address":               "<file>::<symbol>",
              "start_ref":             "HEAD",
              "total_commits_scanned": 282,
              "truncated":             false,
              "events": [
                {
                  "event":        "created",
                  "commit_id":    "<sha256>",
                  "message":      "...",
                  "committed_at": "2026-03-14T...",
                  "address":      "<file>::<symbol>",
                  "detail":       "...",
                  "new_address":  null
                }
              ]
            }
"""

import argparse
import json
import logging
import pathlib
import sys
from typing import Literal, TypedDict

from muse.core.types import short_id
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.refs import read_current_branch
from muse.core.commits import (
    CommitRecord,
    resolve_commit_ref,
)
from muse.core.timing import start_timer
from muse.domain import DomainOp
from muse.plugins.code._query import walk_commits_bfs
from muse.core.validation import clamp_int, sanitize_display

class _SymbolLogJson(EnvelopeJson):
    address: str
    start_ref: str
    total_commits_scanned: int
    truncated: bool
    events: list[_SymbolLogDict]

type _IntMap = dict[str, int]
type _SymbolLogDict = dict[str, str | None]
logger = logging.getLogger(__name__)

_EventKind = Literal["created", "modified", "renamed", "moved", "deleted", "signature"]

# ---------------------------------------------------------------------------
# Repository helpers
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Event extraction
# ---------------------------------------------------------------------------

def _flat_ops(ops: list[DomainOp]) -> list[DomainOp]:
    """Flatten PatchOp children into a single list for address scanning."""
    result: list[DomainOp] = []
    for op in ops:
        if op["op"] == "patch":
            result.extend(op["child_ops"])
        else:
            result.append(op)
    return result

class SymbolEvent:
    """A single event in a symbol's lifecycle."""

    __slots__ = ("kind", "commit", "address", "detail", "new_address")

    def __init__(
        self,
        kind: _EventKind,
        commit: CommitRecord,
        address: str,
        detail: str,
        new_address: str | None = None,
    ) -> None:
        self.kind = kind
        self.commit = commit
        self.address = address
        self.detail = detail
        self.new_address = new_address

    def to_dict(self) -> _SymbolLogDict:
        return {
            "event":        self.kind,
            "commit_id":    self.commit.commit_id,
            "message":      self.commit.message,
            "committed_at": self.commit.committed_at.isoformat(),
            "address":      self.address,
            "detail":       self.detail,
            "new_address":  self.new_address,
        }

def _find_events_in_commit(
    commit: CommitRecord,
    address: str,
) -> tuple[list[SymbolEvent], str]:
    """Scan *commit*'s structured delta for events touching *address*.

    Returns ``(events, next_address)`` where *next_address* is the address to
    track in older commits (updated on rename events so history is continuous).
    """
    events: list[SymbolEvent] = []
    next_address = address

    if commit.structured_delta is None:
        return events, next_address

    all_ops = _flat_ops(commit.structured_delta["ops"])

    for op in all_ops:
        op_address = op["address"]

        if op["op"] == "insert" and op_address == address:
            events.append(SymbolEvent(
                kind="created",
                commit=commit,
                address=address,
                detail=op.get("content_summary", "created"),
            ))

        elif op["op"] == "delete" and op_address == address:
            detail = op.get("content_summary", "deleted")
            if "moved to" in detail:
                events.append(SymbolEvent(
                    kind="moved",
                    commit=commit,
                    address=address,
                    detail=detail,
                    new_address=None,
                ))
            else:
                events.append(SymbolEvent(
                    kind="deleted",
                    commit=commit,
                    address=address,
                    detail=detail,
                ))

        elif op["op"] == "replace" and op_address == address:
            new_summary: str = op.get("new_summary", "")
            if new_summary.startswith("renamed to "):
                new_name = new_summary.removeprefix("renamed to ").strip()
                file_prefix = address.rsplit("::", 1)[0]
                new_addr = f"{file_prefix}::{new_name}"
                events.append(SymbolEvent(
                    kind="renamed",
                    commit=commit,
                    address=address,
                    detail=f"{address.rsplit('::', 1)[-1]} → {new_name}",
                    new_address=new_addr,
                ))
                next_address = new_addr
            elif new_summary.startswith("moved to "):
                events.append(SymbolEvent(
                    kind="moved",
                    commit=commit,
                    address=address,
                    detail=new_summary,
                    new_address=None,
                ))
            elif "signature" in new_summary:
                events.append(SymbolEvent(
                    kind="signature",
                    commit=commit,
                    address=address,
                    detail=new_summary,
                ))
            else:
                events.append(SymbolEvent(
                    kind="modified",
                    commit=commit,
                    address=address,
                    detail=new_summary or "modified",
                ))

    return events, next_address

# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------

def _print_human(
    address: str,
    events: list[SymbolEvent],
    total_commits: int,
    truncated: bool,
) -> None:
    print(f"\nSymbol: {sanitize_display(address)}")
    print("─" * 62)

    if truncated:
        print(
            f"\n⚠️  History may be incomplete — scanned {total_commits:,} commits "
            f"(use --max to increase the limit).",
        )

    if not events:
        print("  (no events found — symbol may not exist in this range)")
        return

    # Collected newest-first; reverse for chronological (oldest-first) display.
    chrono = list(reversed(events))

    counts: _IntMap = {}
    for ev in chrono:
        counts[ev.kind] = counts.get(ev.kind, 0) + 1
        date_str = ev.commit.committed_at.strftime("%Y-%m-%d")
        cid = short_id(ev.commit.commit_id)
        print(f'\n● {cid}  {date_str}  "{sanitize_display(ev.commit.message)}"')
        print(f"  {ev.kind:<12}  {ev.detail}")
        if ev.new_address:
            print(f"  (tracking continues as {ev.new_address})")

    total = len(events)
    summary_parts = [f"{k}: {v}" for k, v in sorted(counts.items())]
    print(f"\n{total} event(s)  ({',  '.join(summary_parts)})")

# ---------------------------------------------------------------------------
# Argument parser registration
# ---------------------------------------------------------------------------

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the symbol-log subcommand.

    Arguments
    ---------
    ADDRESS
        Fully-qualified symbol address, e.g. ``src/utils.py::calculate_total``.
        Must contain ``::``.
    --from REF
        Start walking from this commit / branch (default: HEAD).
    --max N
        Maximum commits to inspect (default: 500).
    --json / -j
        Emit the full event list as structured JSON with schema_version,
        exit_code, and duration_ms in the envelope.
    """
    parser = subparsers.add_parser(
        "symbol-log",
        help="Track a single symbol through the entire commit history.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "address",
        metavar="ADDRESS",
        help=(
            'Fully-qualified symbol address, e.g. "src/utils.py::calculate_total" '
            'or "src/models.py::User.save".  Must contain "::".'
        ),
    )
    parser.add_argument(
        "--from",
        dest="from_ref",
        default=None,
        metavar="REF",
        help="Start walking from this commit / branch (default: HEAD).",
    )
    parser.add_argument(
        "--max",
        dest="max_commits",
        type=int,
        default=500,
        metavar="N",
        help="Maximum number of commits to inspect (default: 500).",
    )
    parser.add_argument(
        "--json", "-j",
        dest="json_out",
        action="store_true",
        help="Emit the full event list as structured JSON.",
    )
    parser.set_defaults(func=run, json_out=False)

# ---------------------------------------------------------------------------
# Command entry point
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Track a single symbol through the entire commit history.

    ``muse code symbol-log`` is impossible in Git: Git tracks file lines, not
    semantic symbols.  This command follows a function, class, or method
    across every commit — detecting creation, implementation changes, renames,
    cross-file moves, and deletion, including events on merged feature branches.

    Agent quickstart::

        muse code symbol-log "src/utils.py::calculate_total" --json
        muse code symbol-log "src/models.py::User.save" --json
        muse code symbol-log "src/utils.py::Fn" --from v1.0.0 --json
        muse code symbol-log "src/utils.py::Fn" --max 1000 --json

    JSON fields::

        address                Symbol address that was tracked.
        start_ref              Ref the walk started from (``"HEAD"`` by default).
        total_commits_scanned  Number of commits actually walked.
        truncated              ``true`` when ``--max`` capped the walk.
        events                 Lifecycle events (oldest first): ``event``, ``commit_id``,
                               ``message``, ``committed_at``, ``address``, ``detail``, ``new_address``.
        muse_version           Muse release that produced this output.
        schema                 Envelope schema version (int).
        exit_code              ``0`` on success.
        duration_ms            Wall-clock milliseconds for the command.
        timestamp              ISO-8601 UTC timestamp of command completion.
        warnings               List of non-fatal advisory messages.

    Exit codes::

        0  Success.
        1  User error (invalid address, bad ref).
    """
    elapsed = start_timer()
    address: str = args.address
    from_ref: str | None = args.from_ref
    max_commits: int = clamp_int(args.max_commits, 1, 100000, 'max_commits')
    json_out: bool = args.json_out

    # ── Input validation ──────────────────────────────────────────────────────

    if "::" not in address:
        print(
            f"❌ '{address}' is not a valid symbol address.\n"
            "   Expected 'file_path::SymbolName', "
            "e.g. 'src/utils.py::calculate_total'.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    if max_commits < 1:
        print("❌ --max must be at least 1.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    # ── Repo / commit resolution ──────────────────────────────────────────────

    root = require_repo()
    branch = read_current_branch(root)

    start_commit = resolve_commit_ref(root, branch, from_ref)
    if start_commit is None:
        label = from_ref or "HEAD"
        print(f"❌ Commit '{label}' not found.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    # ── DAG walk ──────────────────────────────────────────────────────────────

    commits, truncated = walk_commits_bfs(root, start_commit.commit_id, max_commits)

    # ── Event scan ────────────────────────────────────────────────────────────
    # Walk commits newest-first, tracking address changes on rename events.

    current_address = address
    all_events: list[SymbolEvent] = []

    for commit in commits:
        evs, current_address = _find_events_in_commit(commit, current_address)
        all_events.extend(evs)

    # ── Output ────────────────────────────────────────────────────────────────

    if json_out:
        print(json.dumps(_SymbolLogJson(
            **make_envelope(elapsed),
            address=address,
            start_ref=from_ref or "HEAD",
            total_commits_scanned=len(commits),
            truncated=truncated,
            events=[e.to_dict() for e in reversed(all_events)],
        )))
        return

    _print_human(address, all_events, total_commits=len(commits), truncated=truncated)
