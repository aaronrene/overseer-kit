"""muse hooks — declare, activate, and inspect commit-lifecycle hooks.

Subcommands
-----------

``muse hooks list``
    Parse ``.musehooks.toml`` and print every declared hook point and its
    commands. Absence of the file is not an error — it means no hooks are
    defined for this repo.

``muse hooks install``
    Activate declared hooks for *this clone only*. Hooks are never
    auto-executed on clone — this is an explicit, local, one-time step per
    clone (musehub#192; mirrors git's own precedent of never auto-installing
    hooks from a fresh checkout). Local state lives in
    ``.muse/hooks-installed.toml`` and is never shared via push/pull.

``muse hooks uninstall``
    Deactivate hooks for this clone. Idempotent — safe to run when never
    installed.

``muse hooks status``
    Report the three-state summary: ``not_defined`` (nothing declared),
    ``defined_not_installed`` (declared but not yet activated here), or
    ``installed``.

Note: as of Phase 2, installed hooks are not yet executed by ``muse
commit`` — that integration lands in Phase 3. Today, ``install``/
``uninstall``/``status`` only manage local activation state.

Security model
--------------
- Hooks are declarative data (a list of commands) — ``list``/``status``
  only read and display them, never execute anything.
- ``install``/``uninstall`` only write/remove a local marker file; they do
  not execute any of the declared commands either.
- TOML parse errors and unknown-hook-point errors are reported to stderr
  without a raw Python traceback.

Agent UX
--------
``--json`` for machine-readable output on stdout. All diagnostics go to stderr.

JSON schemas
------------

``muse hooks list --json``::

    {"hooks": {"pre-commit": ["muse agent-config status --json"]}}

``muse hooks install --json`` / ``muse hooks uninstall --json``::

    {"installed": true}

``muse hooks status --json``::

    {"state": "installed", "hooks": {"pre-commit": ["..."]}}

Exit codes
----------
- 0 — success (no hooks defined is still success; idempotent install/uninstall too)
- 1 — user error (malformed TOML, unknown hook point)
- 2 — not inside a Muse repository
"""

import argparse
import json
import sys

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.hooks import get_status, install_hooks, load_hooks, uninstall_hooks
from muse.core.repo import require_repo
from muse.core.timing import start_timer


class _ListJson(EnvelopeJson):
    """JSON output of ``muse hooks list``."""

    hooks: dict[str, list[str]]


class _InstallJson(EnvelopeJson):
    """JSON output of ``muse hooks install`` / ``muse hooks uninstall``."""

    installed: bool


class _StatusJson(EnvelopeJson):
    """JSON output of ``muse hooks status``."""

    state: str
    hooks: dict[str, list[str]]


def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``hooks`` subcommand tree and all its flags."""
    parser = subparsers.add_parser(
        "hooks",
        help="Declare and inspect .musehooks.toml commit-lifecycle hooks.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subs = parser.add_subparsers(dest="subcommand", metavar="SUBCOMMAND")
    subs.required = True

    list_p = subs.add_parser(
        "list",
        help="Print all hook points and commands declared in .musehooks.toml.",
        description=(
            "Parse ``.musehooks.toml`` and display every declared hook point\n"
            "and its ordered command list. An absent file means no hooks are\n"
            "defined — this is success, not an error.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse hooks list --json\n"
            "  muse hooks list -j\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"hooks": {"<hook-point>": ["<command>", ...]}}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — success (no hooks defined is still success)\n"
            "  1 — malformed TOML or unknown hook point\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    list_p.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        default=False,
        help="Emit a JSON object with a 'hooks' field to stdout.",
    )
    list_p.set_defaults(func=run_list)

    install_p = subs.add_parser(
        "install",
        help="Activate declared hooks for this clone only.",
        description=(
            "Write a local marker (.muse/hooks-installed.toml) activating\n"
            "this clone's declared hooks. Never automatic — must be run\n"
            "explicitly once per clone. Idempotent.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse hooks install --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"installed": true}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — success (already installed is still success)\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    install_p.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        default=False,
        help="Emit a JSON object with an 'installed' field to stdout.",
    )
    install_p.set_defaults(func=run_install)

    uninstall_p = subs.add_parser(
        "uninstall",
        help="Deactivate hooks for this clone.",
        description=(
            "Remove the local hooks-installed marker for this clone.\n"
            "Idempotent — safe to run when never installed.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse hooks uninstall --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"installed": false}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — success (never installed is still success)\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    uninstall_p.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        default=False,
        help="Emit a JSON object with an 'installed' field to stdout.",
    )
    uninstall_p.set_defaults(func=run_uninstall)

    status_p = subs.add_parser(
        "status",
        help="Report declared hooks and this clone's local install state.",
        description=(
            "Report the three-state summary: 'not_defined' (nothing\n"
            "declared in .musehooks.toml), 'defined_not_installed'\n"
            "(declared but 'muse hooks install' hasn't run here), or\n"
            "'installed'.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse hooks status --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"state": "<not_defined|defined_not_installed|installed>",\n'
            '   "hooks": {"<hook-point>": ["<command>", ...]}}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — success\n"
            "  1 — malformed TOML or unknown hook point\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    status_p.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        default=False,
        help="Emit a JSON object with 'state' and 'hooks' fields to stdout.",
    )
    status_p.set_defaults(func=run_status)


def run_list(args: argparse.Namespace) -> None:
    """Display all hook points and commands declared in ``.musehooks.toml``.

    Agent quickstart
    ----------------
    ::

        muse hooks list --json

    JSON fields
    -----------
    hooks   Mapping of hook point name to its ordered command list. Empty
            dict when ``.musehooks.toml`` is absent or defines no hooks.

    Exit codes
    ----------
    0  Success (no hooks defined is still success).
    1  Malformed TOML or unknown hook point.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out

    root = require_repo()
    try:
        hooks_file = load_hooks(root)
    except ValueError as exc:
        print(f"❌  {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR.value) from exc

    if json_out:
        print(json.dumps(_ListJson(**make_envelope(elapsed), hooks=hooks_file.hooks)))
        return

    if not hooks_file.hooks:
        print("No hooks defined. Create .musehooks.toml at the repository root.")
        return

    for hook_point, commands in hooks_file.hooks.items():
        print(f"[{hook_point}]")
        if not commands:
            print("  (no commands)")
        for cmd in commands:
            print(f"  - {cmd}")


def run_install(args: argparse.Namespace) -> None:
    """Activate declared hooks for this clone.

    Agent quickstart
    ----------------
    ::

        muse hooks install --json

    JSON fields
    -----------
    installed   Always ``true`` on success.

    Exit codes
    ----------
    0  Success (already installed is still success).
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out

    root = require_repo()
    install_hooks(root)

    if json_out:
        print(json.dumps(_InstallJson(**make_envelope(elapsed), installed=True)))
        return
    print("✅  Hooks installed for this clone.")


def run_uninstall(args: argparse.Namespace) -> None:
    """Deactivate hooks for this clone.

    Agent quickstart
    ----------------
    ::

        muse hooks uninstall --json

    JSON fields
    -----------
    installed   Always ``false`` on success.

    Exit codes
    ----------
    0  Success (never installed is still success).
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out

    root = require_repo()
    uninstall_hooks(root)

    if json_out:
        print(json.dumps(_InstallJson(**make_envelope(elapsed), installed=False)))
        return
    print("✅  Hooks uninstalled for this clone.")


def run_status(args: argparse.Namespace) -> None:
    """Report declared hooks and this clone's local install state.

    Agent quickstart
    ----------------
    ::

        muse hooks status --json

    JSON fields
    -----------
    state   One of ``"not_defined"``, ``"defined_not_installed"``, ``"installed"``.
    hooks   Mapping of hook point name to its ordered command list.

    Exit codes
    ----------
    0  Success.
    1  Malformed TOML or unknown hook point.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out

    root = require_repo()
    try:
        status = get_status(root)
    except ValueError as exc:
        print(f"❌  {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR.value) from exc

    if json_out:
        print(json.dumps(_StatusJson(
            **make_envelope(elapsed),
            state=status.state,
            hooks=status.hooks_file.hooks,
        )))
        return

    if status.state == "not_defined":
        print("No hooks defined. Create .musehooks.toml at the repository root.")
    elif status.state == "defined_not_installed":
        print("Hooks are defined but not installed for this clone.")
        print("Run 'muse hooks install' to enable them.")
    else:
        print("✅  Hooks are installed and active for this clone.")
