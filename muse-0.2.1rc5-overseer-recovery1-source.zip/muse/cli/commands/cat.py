"""muse code cat — print the source of one or more symbols from HEAD or any commit.

Address format::

    muse code cat cache.py::LRUCache.get
    muse code cat cache.py::LRUCache.get --at abc123
    muse code cat cache.py::LRUCache.get --at v0.1.4

    # Multiple symbols in one call (useful for agents):
    muse code cat cache.py::LRUCache.get cache.py::LRUCache.set

    # All symbols in a file:
    muse code cat cache.py --all

    # Structured output for downstream processing:
    muse code cat cache.py::LRUCache.get --json
    muse code cat cache.py::LRUCache.get --format json

The ``::`` separator is the same format used throughout Muse's symbol graph.
The right-hand side is matched against the symbol's ``qualified_name`` first,
then ``name`` (allowing short references like ``get`` when unambiguous).

Without ``--at``, a file is readable if it is in the HEAD snapshot or the
stage index (``muse code add`` has been called).  Uncommitted working-tree
edits are visible because disk is preferred over the object store for tracked
files.  Untracked files — on disk but not in the snapshot or stage index —
are rejected with ``FILE_NOT_TRACKED``.  With ``--at <ref>`` the specified
committed snapshot is used instead.

Exit codes
----------
0   All requested symbols found and printed.
1   Address malformed, symbol not found, or file not tracked.
3   I/O error reading from the object store or disk.
"""

import argparse
import json
import pathlib
import sys
from typing import TypedDict

import re

from muse.core.errors import ExitCode
from muse.core.object_store import read_object
from muse.core.repo import require_repo
from muse.core.types import Manifest
from muse.core.refs import read_current_branch
from muse.core.commits import resolve_commit_ref
from muse.core.snapshots import (
    get_commit_snapshot_manifest,
    get_head_snapshot_manifest,
)
from muse.core.validation import clamp_int, sanitize_display
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.timing import start_timer
from muse.plugins.code.ast_parser import SymbolRecord, SymbolTree, adapter_for_path
from muse.plugins.code.stage import read_stage

#: Matches ``<addr>@{N}`` in a code cat address, e.g. ``billing.py::fn@{2}``.
_SYMLOG_AT_RE = re.compile(r"^(.+)@\{(\d+)\}$")

type _FileCache = dict[str, tuple[bytes, "SymbolTree"]]
# ── Types ─────────────────────────────────────────────────────────────────────

class CatResult(TypedDict):
    """One resolved symbol returned in --json mode."""

    address: str
    path: str
    symbol: str
    kind: str
    lineno: int
    end_lineno: int
    source: str
    source_ref: str  # "working tree" | "commit <sha> on <branch>"

class CatError(TypedDict, total=False):
    """A failed lookup returned in --json mode.

    Fields
    ------
    address     The address that was requested.
    error       Human-readable description of the failure.
    error_code  Machine-parseable failure category (always present).
    hint        Actionable recovery instruction for the caller.
    """

    address: str
    error: str
    error_code: str
    hint: str

class _CatWarningDict(TypedDict, total=False):
    address: str
    warning: str
    warning_code: str
    candidates: list[str]
    hint: str

class _CatOutputJson(EnvelopeJson, total=False):
    """Top-level JSON envelope emitted by ``muse code cat --json``.

    Fields
    ------
    source_ref      "working tree" or "commit <sha> on <branch>".
    results         Resolved :class:`CatResult` entries.
    errors          Failed lookups as :class:`CatError` entries.
    total_symbols   Pre-filter symbol count; only present with ``--all``.
    truncated       True when ``--limit`` capped the results; only with ``--all``.
    """

    source_ref: str
    results: list[CatResult]
    errors: list[CatError]
    total_symbols: int
    truncated: bool

class _FileError(Exception):
    """Raised by :func:`_get_file_bytes` instead of ``SystemExit`` so callers
    can map the failure to a precise ``error_code`` in JSON output."""

    def __init__(self, message: str, code: str, hint: str = "") -> None:
        super().__init__(message)
        self.code = code
        self.hint = hint

# ── Helpers ───────────────────────────────────────────────────────────────────

def _get_file_bytes(
    root: pathlib.Path,
    file_path: str,
    manifest: Manifest,
    source_is_workdir: bool,
) -> bytes:
    """Return raw bytes for *file_path* from the object store or working tree.

    A file is "tracked" if it appears in the HEAD snapshot manifest OR in the
    stage index (staged-but-not-committed).  Files that exist only on disk with
    no tracking record are rejected with FILE_NOT_TRACKED — this prevents
    silent symbol reads from arbitrary workspace files Muse knows nothing about.

    When *source_is_workdir* is True and the file is tracked, disk is preferred
    so uncommitted edits are visible.  Falling back to the object store only
    when the file has been deleted from disk.  When False (historical commit)
    the object store is always used.

    Raises :class:`_FileError` on all failure paths so callers can decide how
    to surface the error (stderr + SystemExit for text mode; JSON errors list
    for ``--json`` mode).

    Security
    --------
    Workdir reads include a symlink guard and path containment check to prevent
    symlink-based directory traversal attacks.
    """
    if source_is_workdir:
        disk = root / file_path
        if disk.is_symlink():
            raise _FileError(
                f"refusing to read symlink: {file_path}",
                code="SYMLINK_REJECTED",
                hint="dereference the symlink and commit the real file instead",
            )
        try:
            disk.resolve().relative_to(root.resolve())
        except ValueError:
            raise _FileError(
                f"path escapes repository root: {file_path}",
                code="PATH_TRAVERSAL",
                hint="file paths must be relative to the repository root",
            )

        stage = read_stage(root)
        in_manifest = file_path in manifest
        stage_entry = stage.get(file_path)
        in_stage = stage_entry is not None and stage_entry["mode"] != "D"

        if not in_manifest and not in_stage:
            raise _FileError(
                f"file not tracked: {file_path}",
                code="FILE_NOT_TRACKED",
                hint="use 'muse code add <file>' to track it",
            )

        try:
            return disk.read_bytes()
        except (FileNotFoundError, OSError):
            pass  # deleted from disk — fall through to object store

        if in_stage and stage_entry is not None:
            raw = read_object(root, stage_entry["object_id"])
            if raw is not None:
                return raw
        if in_manifest:
            raw = read_object(root, manifest[file_path])
            if raw is not None:
                return raw
        raise _FileError(
            f"blob not found in object store for: {file_path}",
            code="BLOB_NOT_FOUND",
            hint="the object store may be corrupted; try `muse gc` to diagnose",
        )

    if file_path not in manifest:
        raise _FileError(
            f"file not tracked: {file_path}",
            code="FILE_NOT_TRACKED",
            hint="use 'muse code add <file>' to track it",
        )

    raw = read_object(root, manifest[file_path])
    if raw is None:
        raise _FileError(
            f"blob not found in object store: {manifest[file_path]}",
            code="BLOB_NOT_FOUND",
            hint="the object store may be corrupted; try `muse gc` to diagnose",
        )
    return raw

def _resolve_symbol(
    tree: SymbolTree,
    symbol_ref: str,
    file_path: str,
) -> tuple[SymbolRecord | None, str]:
    """Resolve *symbol_ref* against *tree*.

    Returns ``(record, "")`` on success or ``(None, error_message)`` on failure
    so callers can decide how to surface the error (stderr vs JSON errors list).

    Resolution order
    ----------------
    1. Exact ``qualified_name`` match (e.g. ``Invoice.compute_total``).
    2. Bare ``name`` match when unambiguous (e.g. ``compute_total``).
    3. Failure — returns ``None`` with a descriptive error message that lists
       available symbols (capped at :data:`_MAX_AVAIL_SHOWN`).
    """
    # Exact qualified_name match first.
    match: SymbolRecord | None = next(
        (rec for rec in tree.values() if rec["qualified_name"] == symbol_ref),
        None,
    )
    if match is not None:
        return match, ""

    # Fall back to bare name (unambiguous only).
    candidates = [rec for rec in tree.values() if rec["name"] == symbol_ref]
    if len(candidates) == 1:
        return candidates[0], ""
    if len(candidates) > 1:
        opts = ", ".join(rec["qualified_name"] for rec in candidates)
        return None, (
            f"❌ Ambiguous symbol '{sanitize_display(symbol_ref)}' in "
            f"{sanitize_display(file_path)}. Qualify it:\n   {opts}"
        )

    # Not found — show a capped sample of available symbols.
    available = sorted(
        rec["qualified_name"]
        for rec in tree.values()
        if rec["kind"] != "import"
    )
    return None, (
        f"❌ Symbol '{sanitize_display(symbol_ref)}' not found in "
        f"{sanitize_display(file_path)}.\n"
        f"   Available ({len(available)} total): {', '.join(available)}"
    )

def _extract_source(raw: bytes, lineno: int, end_lineno: int, context: int = 0) -> str:
    """Slice the source lines for a symbol, with optional surrounding context."""
    text = raw.decode("utf-8", errors="replace")
    lines = text.splitlines()
    start = max(0, lineno - 1 - context)
    end = min(len(lines), end_lineno + context)
    return "\n".join(lines[start:end])

def _format_line_numbers(source: str, start_lineno: int, context: int = 0) -> str:
    """Prefix each line with its 1-based line number."""
    first = max(1, start_lineno - context)
    lines = source.splitlines()
    width = len(str(first + len(lines) - 1))
    return "\n".join(f"{first + i:{width}d}  {line}" for i, line in enumerate(lines))

# ── CLI registration ──────────────────────────────────────────────────────────

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the cat subcommand on *subparsers*."""
    parser = subparsers.add_parser(
        "cat",
        help="Print the source code of one or more symbols.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "addresses",
        nargs="*",
        metavar="address",
        help=(
            "One or more symbol addresses: 'file.py::ClassName.method'. "
            "When --all is given, treat each argument as a file path instead. "
            "May be omitted when --file is provided."
        ),
    )
    parser.add_argument(
        "--at", default=None, metavar="REF",
        help=(
            "Commit ref (SHA prefix, branch, tag, HEAD~N) to read from. "
            "Defaults to the working tree (disk content, uncommitted edits visible). "
            "Mutually exclusive with --staged."
        ),
    )
    parser.add_argument(
        "--staged", action="store_true", default=False,
        help=(
            "Read the staged version of each file — the content that would be "
            "committed if you ran 'muse commit' now. Ignores working-tree edits "
            "made after the last 'muse code add'. Mirrors 'git show :path'."
        ),
    )
    parser.add_argument(
        "--all", "-a", action="store_true", dest="all_symbols",
        help="Print every symbol in each file. Arguments are treated as file paths.",
    )
    parser.add_argument(
        "--kind", "-k", default=None, metavar="KIND", dest="kind_filter",
        help="With --all: restrict to symbols of this kind (function, class, method, …).",
    )
    parser.add_argument(
        "--line-numbers", action="store_true", dest="line_numbers",
        help="Prefix each output line with its 1-based line number.",
    )
    parser.add_argument(
        "--context", "-C", default=0, type=int, metavar="N", dest="context",
        help="Include N lines of context before and after each symbol (default: 0).",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit JSON output to stdout.",
    )
    parser.add_argument(
        "--file",
        default=None,
        metavar="PATH",
        dest="file_alias",
        help=(
            "Convenience alias: treat PATH as a file and print all its symbols. "
            "Equivalent to: muse code cat PATH --all. "
            "Canonical form: muse code symbols --file PATH"
        ),
    )
    parser.add_argument(
        "--limit",
        default=None,
        type=int,
        metavar="N",
        dest="limit",
        help=(
            "With --all: cap results at N symbols. JSON output includes "
            "'truncated: true' and 'total_symbols' when the cap applies."
        ),
    )
    parser.set_defaults(func=run)

# ── Main logic ────────────────────────────────────────────────────────────────

def run(args: argparse.Namespace) -> None:
    """Print the source code of one or more symbols by address.

    Resolves each ``file.py::Symbol`` address against the working tree or a
    historical commit (``--at REF``), extracts exact source lines from the
    content-addressed object store or disk, and prints them.  Use ``--all`` to
    dump every symbol in a file; file bytes and symbol trees are cached per-file
    so a 50-symbol batch costs one read, not 50.

    Agent quickstart
    ----------------
    ::

        muse code cat "cache.py::LRUCache.get" --json
        muse code cat "cache.py::LRUCache.get" --at v0.1.4 --json
        muse code cat "cache.py" --all --json

    JSON fields
    -----------
    source_ref  ``"working tree"`` or ``"commit <sha> on <branch>"``.
    results     List of resolved symbol objects, each with: ``address``,
                ``name``, ``kind``, ``file``, ``source`` (full source text),
                ``start_line``, ``end_line``.
    errors      List of error objects for unresolved addresses, each with:
                ``address`` and ``message``.
    exit_code   0 = all resolved; 1 = any error present.

    Exit codes
    ----------
    0  All requested symbols found and printed.
    1  Any address malformed, symbol not found, or file not tracked.
    2  Not inside a Muse repository.
    3  I/O error reading from the object store or disk.
    """
    elapsed = start_timer()

    addresses: list[str] = args.addresses
    at: str | None = args.at
    staged: bool = getattr(args, "staged", False)
    all_symbols: bool = args.all_symbols
    kind_filter: str | None = args.kind_filter
    line_numbers: bool = args.line_numbers
    context: int = clamp_int(args.context, 0, 500, 'context')
    json_out: bool = args.json_out
    limit: int | None = getattr(args, "limit", None)

    if staged and at is not None:
        msg = "--staged and --at are mutually exclusive"
        if json_out:
            print(json.dumps({"error": msg, "exit_code": ExitCode.USER_ERROR}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    # --file PATH is a convenience alias for `muse code cat PATH --all`.
    # Agents and users reaching for --file (by analogy with muse code symbols)
    # get the same result without an argparse error.
    if args.file_alias is not None:
        addresses = [args.file_alias] + addresses
        all_symbols = True

    if not addresses:
        msg = "no address given — usage: muse code cat FILE::Symbol  (or --file FILE)"
        if json_out:
            print(json.dumps({"error": msg, "exit_code": ExitCode.USER_ERROR}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()
    branch = read_current_branch(root)

    # ── Resolve the manifest and source label ─────────────────────────────────
    source_is_workdir = at is None and not staged
    manifest: Manifest
    source_ref: str

    if staged:
        head_manifest = get_head_snapshot_manifest(root, branch) or {}
        _stage = read_stage(root)
        staged_manifest: dict[str, str] = dict(head_manifest)
        for _path, _entry in _stage.items():
            if _path.startswith(".muse/"):
                continue
            if _entry["mode"] == "D":
                staged_manifest.pop(_path, None)
            else:
                staged_manifest[_path] = _entry["object_id"]
        manifest = staged_manifest
        source_ref = "staged"
    elif source_is_workdir:
        manifest = get_head_snapshot_manifest(root, branch) or {}
        source_ref = "working tree"
    else:
        resolved = resolve_commit_ref(root, branch, at)
        if resolved is None:
            msg = f"Ref not found: {sanitize_display(at or '')}"
            if json_out:
                print(json.dumps({"error": msg, "exit_code": ExitCode.USER_ERROR}))
            else:
                print(f"❌ {msg}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        manifest = get_commit_snapshot_manifest(root, resolved.commit_id) or {}
        source_ref = f"commit {resolved.commit_id} on {branch}"

    # ── Per-invocation file cache: path → (raw bytes, symbol tree) ────────────
    # Avoids re-reading and re-parsing the same file for each address in a
    # batch request (e.g. 50 addresses all referencing billing.py).
    _file_cache: _FileCache = {}
    _file_failed: set[str] = set()  # paths that errored; skip on repeat

    def _cached_file(file_path: str) -> tuple[bytes, SymbolTree] | _FileError:
        """Return cached (raw, tree) for *file_path*, or a _FileError."""
        if file_path in _file_cache:
            return _file_cache[file_path]
        if file_path in _file_failed:
            return _FileError(
                f"file not tracked in snapshot: {file_path}",
                code="FILE_NOT_TRACKED",
                hint="run `muse code add .` to stage all files, then `muse commit`",
            )
        try:
            raw = _get_file_bytes(root, file_path, manifest, source_is_workdir)
        except _FileError as exc:
            _file_failed.add(file_path)
            return exc
        adapter = adapter_for_path(file_path)
        tree = adapter.parse_symbols(raw, file_path)
        _file_cache[file_path] = (raw, tree)
        return (raw, tree)

    # ── Dispatch: --all mode (file paths) vs address mode ────────────────────
    results: list[CatResult] = []
    errors: list[CatError] = []
    warnings: list[_CatWarningDict] = []
    any_ok = False

    total_symbols_all = 0  # pre-filter symbol count across all files (--all mode)

    if all_symbols:
        for file_path in addresses:
            cached = _cached_file(file_path)
            if isinstance(cached, _FileError):
                errors.append({
                    "address": file_path,
                    "error": str(cached),
                    "error_code": cached.code,
                    "hint": cached.hint,
                })
                if not json_out:
                    print(f"❌ {sanitize_display(str(cached))}", file=sys.stderr)
                continue

            raw, tree = cached
            # Count all non-import symbols before applying kind filter.
            all_syms = [rec for rec in tree.values() if rec["kind"] != "import"]
            total_symbols_all += len(all_syms)
            syms = [
                rec for rec in all_syms
                if kind_filter is None or rec["kind"] == kind_filter
            ]
            syms.sort(key=lambda r: r["lineno"])

            for rec in syms:
                lineno = rec["lineno"]
                end_lineno = rec["end_lineno"]
                src = _extract_source(raw, lineno, end_lineno, context)
                if line_numbers:
                    src = _format_line_numbers(src, lineno, context)
                result: CatResult = {
                    "address": f"{file_path}::{rec['qualified_name']}",
                    "path": file_path,
                    "symbol": rec["qualified_name"],
                    "kind": rec["kind"],
                    "lineno": lineno,
                    "end_lineno": end_lineno,
                    "source": src,
                    "source_ref": source_ref,
                }
                results.append(result)
                any_ok = True
    else:
        for address in addresses:
            # ── @{N} symlog ref  e.g. billing.py::compute_total@{2} ──────────
            _at_m = _SYMLOG_AT_RE.match(address)
            if _at_m:
                addr = _at_m.group(1)
                index = int(_at_m.group(2))

                if "::" not in addr:
                    hint = f"'@{{N}}' requires a symbol address: 'file.py::Symbol@{{{index}}}'"
                    errors.append({
                        "address": address,
                        "error": hint,
                        "error_code": "INVALID_ADDRESS",
                        "hint": hint,
                    })
                    if not json_out:
                        print(f"❌ {hint}", file=sys.stderr)
                        raise SystemExit(ExitCode.USER_ERROR)
                    continue

                file_path_at = addr.partition("::")[0]

                from muse.core.symlog import resolve_symlog_addr, resolve_symbol_body

                try:
                    resolution = resolve_symlog_addr(address, root)
                except FileNotFoundError:
                    err = f"no symlog entries for {addr!r}"
                    errors.append({
                        "address": address,
                        "error": err,
                        "error_code": "SYMLOG_NOT_FOUND",
                        "hint": f"run `muse symlog {addr!r}` to check",
                    })
                    if not json_out:
                        print(f"❌ {err}", file=sys.stderr)
                        raise SystemExit(ExitCode.USER_ERROR)
                    continue
                except IndexError as exc:
                    bad_idx, total = exc.args[0], exc.args[1]
                    err = (
                        f"@{{{bad_idx}}} is out of range — "
                        f"valid range: @{{0}} to @{{{max(0, total - 1)}}}"
                    )
                    errors.append({
                        "address": address,
                        "error": err,
                        "error_code": "SYMLOG_OUT_OF_RANGE",
                        "hint": err,
                    })
                    if not json_out:
                        print(f"❌ {err}", file=sys.stderr)
                        raise SystemExit(ExitCode.USER_ERROR)
                    continue

                assert resolution is not None
                body_info = resolve_symbol_body(root, addr, resolution.commit_id)
                if body_info is None:
                    err = (
                        f"could not reconstruct body for {addr!r} "
                        f"at commit {resolution.commit_id[:8]}"
                    )
                    errors.append({
                        "address": address,
                        "error": err,
                        "error_code": "BODY_NOT_FOUND",
                        "hint": "the commit may not exist in the local object store",
                    })
                    if not json_out:
                        print(f"❌ {err}", file=sys.stderr)
                        raise SystemExit(ExitCode.USER_ERROR)
                    continue

                src = body_info["source"]
                if line_numbers:
                    src = _format_line_numbers(src, body_info["lineno"], context)
                result = CatResult(
                    address=address,
                    path=file_path_at,
                    symbol=body_info["qualified_name"],
                    kind=body_info["kind"],
                    lineno=body_info["lineno"],
                    end_lineno=body_info["end_lineno"],
                    source=src,
                    source_ref=f"symlog@{{{index}}}: commit {resolution.commit_id[:8]}",
                )
                results.append(result)
                any_ok = True
                continue
            # ── end @{N} block ────────────────────────────────────────────────

            if "::" not in address:
                hint = (
                    f"To read a symbol:  muse code cat \"{address}::SymbolName\"\n"
                    f"To list symbols:   muse code symbols --file {address}\n"
                    f"To read the file:  use the Read tool or your editor"
                )
                errors.append({
                    "address": address,
                    "error": f"{address!r} is a file path, not a symbol address — add '::SymbolName'",
                    "error_code": "INVALID_ADDRESS",
                    "hint": hint,
                })
                if not json_out:
                    print(
                        f"❌ {sanitize_display(address)!r} is a file path, not a symbol address.\n"
                        f"   To read a symbol:  muse code cat \"{address}::SymbolName\"\n"
                        f"   To list symbols:   muse code symbols --file {address}\n"
                        f"   To read the file:  use the Read tool or your editor",
                        file=sys.stderr,
                    )
                    raise SystemExit(ExitCode.USER_ERROR)
                continue

            file_path, _, symbol_ref = address.partition("::")

            cached = _cached_file(file_path)
            if isinstance(cached, _FileError):
                errors.append({
                    "address": address,
                    "error": str(cached),
                    "error_code": cached.code,
                    "hint": cached.hint,
                })
                if not json_out:
                    print(f"❌ {sanitize_display(str(cached))}", file=sys.stderr)
                    raise SystemExit(ExitCode.USER_ERROR)
                continue

            raw, tree = cached

            if not tree:
                errors.append({
                    "address": address,
                    "error": f"no symbols found in {file_path}",
                    "error_code": "SYMBOL_PARSE_EMPTY",
                    "hint": (
                        "symbol cache miss — run `muse code add .` to rebuild the index, "
                        "or check that the file contains parseable Python/JS/TS"
                    ),
                })
                if not json_out:
                    print(
                        f"❌ no symbols found in {sanitize_display(file_path)}",
                        file=sys.stderr,
                    )
                    raise SystemExit(ExitCode.USER_ERROR)
                continue

            # Filter out import pseudo-symbols before matching.
            code_tree: SymbolTree = {
                addr: rec for addr, rec in tree.items() if rec["kind"] != "import"
            }

            found, err_msg = _resolve_symbol(code_tree, symbol_ref, file_path)
            if found is None:
                # Global fallback: search all other tracked files for the symbol.
                # Covers the common agent mistake of specifying the wrong file —
                # e.g. `file.py::symbol` when the symbol is actually in `other.py`.
                fb_matches: list[tuple[str, SymbolRecord, bytes]] = []
                for tracked_path in manifest:
                    if tracked_path == file_path:
                        continue
                    fb_cached = _cached_file(tracked_path)
                    if isinstance(fb_cached, _FileError):
                        continue
                    fb_raw, fb_tree = fb_cached
                    fb_code_tree: SymbolTree = {
                        a: r for a, r in fb_tree.items() if r["kind"] != "import"
                    }
                    fb_found, _ = _resolve_symbol(fb_code_tree, symbol_ref, tracked_path)
                    if fb_found is not None:
                        fb_matches.append((tracked_path, fb_found, fb_raw))

                if len(fb_matches) == 1:
                    # Unambiguous — cat from the actual file, note the redirect.
                    actual_path, actual_rec, actual_raw = fb_matches[0]
                    fb_lineno = actual_rec["lineno"]
                    fb_end_lineno = actual_rec["end_lineno"]
                    fb_src = _extract_source(actual_raw, fb_lineno, fb_end_lineno, context)
                    if line_numbers:
                        fb_src = _format_line_numbers(fb_src, fb_lineno, context)
                    result = {
                        "address": f"{actual_path}::{actual_rec['qualified_name']}",
                        "path": actual_path,
                        "symbol": actual_rec["qualified_name"],
                        "kind": actual_rec["kind"],
                        "lineno": fb_lineno,
                        "end_lineno": fb_end_lineno,
                        "source": fb_src,
                        "source_ref": source_ref,
                        "redirected_from": address,  # original requested address
                    }
                    results.append(result)
                    any_ok = True
                    if not json_out:
                        note = (
                            f"# note: '{sanitize_display(symbol_ref)}' not in "
                            f"{sanitize_display(file_path)} — found in "
                            f"{sanitize_display(actual_path)}"
                        )
                        print(note)
                    continue

                if len(fb_matches) > 1:
                    locs_inline = ", ".join(
                        f"{p}::{r['qualified_name']}" for p, r, _ in fb_matches
                    )
                    locs_lines = "\n   ".join(
                        f"{p}::{r['qualified_name']}" for p, r, _ in fb_matches
                    )
                    if not json_out:
                        print(
                            f"⚠️  '{sanitize_display(symbol_ref)}' not in "
                            f"{sanitize_display(file_path)} — found in multiple files:\n"
                            f"   {locs_lines}\n"
                            f"   Specify the file explicitly.",
                            file=sys.stderr,
                        )
                    else:
                        warnings.append({
                            "address": address,
                            "warning": f"symbol not found in {file_path}; ambiguous across: {locs_inline}",
                            "warning_code": "SYMBOL_AMBIGUOUS",
                            "candidates": [
                                f"{p}::{r['qualified_name']}" for p, r, _ in fb_matches
                            ],
                            "hint": "specify the file explicitly",
                        })
                    continue

                # Truly not found anywhere.
                errors.append({
                    "address": address,
                    "error": f"symbol not found: {symbol_ref}",
                    "error_code": "SYMBOL_NOT_FOUND",
                    "hint": (
                        f"run `muse code symbols --file {file_path}` to list available symbols, "
                        f"or `muse code grep \"{symbol_ref}\"` to search the full snapshot"
                    ),
                })
                if not json_out:
                    print(err_msg, file=sys.stderr)
                    raise SystemExit(ExitCode.USER_ERROR)
                continue

            lineno = found["lineno"]
            end_lineno = found["end_lineno"]
            src = _extract_source(raw, lineno, end_lineno, context)
            if line_numbers:
                src = _format_line_numbers(src, lineno, context)
            result = {
                "address": address,
                "path": file_path,
                "symbol": found["qualified_name"],
                "kind": found["kind"],
                "lineno": lineno,
                "end_lineno": end_lineno,
                "source": src,
                "source_ref": source_ref,
            }
            results.append(result)
            any_ok = True

    # ── Apply --limit (--all mode only; silently ignored in address mode) ────────
    truncated = False
    if all_symbols and limit is not None:
        if limit < len(results):
            results = results[:limit]
            truncated = True

    # ── Output ────────────────────────────────────────────────────────────────

    if json_out:
        _exit_code = 0 if not errors else ExitCode.USER_ERROR
        out = _CatOutputJson(
            **make_envelope(elapsed, exit_code=_exit_code, warnings=warnings or []),
            source_ref=source_ref,
            results=results,
            errors=errors,
        )
        if all_symbols:
            out["total_symbols"] = total_symbols_all
            out["truncated"] = truncated
        print(json.dumps(out))
        raise SystemExit(_exit_code)

    for result in results:
        header = (
            f"# {result['path']}::{result['symbol']}"
            f"  [{result['kind']}]"
            f"  L{result['lineno']}–{result['end_lineno']}"
            f"  ({result['source_ref']})"
        )
        print(header)
        print(result["source"])
        if len(results) > 1:
            print()  # blank separator between multiple symbols

    if truncated:
        print(f"# … truncated at {limit} symbol(s). Use --limit N or omit to see all.")

    if errors and not json_out:
        raise SystemExit(ExitCode.USER_ERROR)
