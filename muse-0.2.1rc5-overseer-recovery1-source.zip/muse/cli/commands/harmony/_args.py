"""muse harmony — Resolution Intelligence for domain-agnostic conflict resolution.

The harmony engine provides three-tier resolution intelligence:

  1. Policy match  — a declarative rule fires automatically.
  2. Exact replay  — blob fingerprint matches a saved resolution.
  3. Semantic match — domain-plugin similarity score ≥ threshold.
  4. Escalate      — create a hub issue, flag for human or specialist agent.

Subcommands
-----------

``muse harmony record``         Record a new conflict pattern.
``muse harmony list``           List all recorded conflict patterns.
``muse harmony show``           Show a pattern and all its resolutions.
``muse harmony resolve``        Save a resolution for a conflict pattern.
``muse harmony best``           Show the highest-quality resolution for a pattern.
``muse harmony forget``         Remove a conflict pattern and all its resolutions.
``muse harmony clear``          Remove all conflict patterns.
``muse harmony gc``             Garbage-collect stale unresolved patterns.
``muse harmony policy-add``     Add or replace a declarative resolution policy.
``muse harmony policy-list``    List all policies (scope-sorted).
``muse harmony policy-remove``  Remove a policy.
``muse harmony audit``          Show the harmony audit log.

Storage
-------

``.muse/harmony/patterns/<pattern_id>/pattern.json``
``.muse/harmony/patterns/<pattern_id>/resolutions/<resolution_id>.json``
``.muse/harmony/policies/<policy_id>.json``
``.muse/harmony/audit/<YYYYMMDD>-<content-id>.json``

Security model
--------------

Pattern IDs and resolution IDs are validated as exactly 64 lowercase hex
characters before any filesystem path is constructed — preventing ``../``
path-traversal.  Policy IDs are validated as URL-safe alphanumeric strings.
Error messages go to **stderr**; **stdout** carries only data.

Agent UX
--------

Pass ``--json`` to any subcommand for machine-readable output.  JSON schemas
are defined by TypedDicts in ``_shapes.py`` — all fields are always present.

JSON schemas
~~~~~~~~~~~~

``muse harmony record --json``::

    {"pattern_id": "<hex64>", "already_existed": <bool>}

``muse harmony list --json``::

    {
      "total": <int>,
      "patterns": [
        {
          "pattern_id": "<hex64>",
          "path": "<str>",
          "domain": "<str>",
          "conflict_type": "<str>",
          "resolution_count": <int>,
          "recorded_at": "<iso8601>",
          "recorded_by": "<str>"
        }, ...
      ]
    }

``muse harmony show <pattern_id> --json``::

    {
      "pattern": {
        "pattern_id": "<hex64>", "path": "<str>", "domain": "<str>",
        "conflict_type": "<str>", "blob_fingerprint": "<hex64>",
        "semantic_fingerprint": "<hex64>", "ours_id": "<hex64>",
        "theirs_id": "<hex64>", "description": {}, "recorded_at": "<iso8601>",
        "recorded_by": "<str>"
      },
      "resolutions": [
        {
          "resolution_id": "<hex64>", "strategy": "<str>",
          "confidence": <float>, "human_verified": <bool>,
          "applied_count": <int>, "resolved_by": {"type": "...", ...},
          "resolved_at": "<iso8601>", "rationale": "<str>"
        }, ...
      ]
    }

``muse harmony resolve --json``::

    {"resolution_id": "<hex64>", "pattern_id": "<hex64>", "already_existed": <bool>}

``muse harmony best <pattern_id> --json``::

    {"pattern_id": "<hex64>", "resolution": {<resolution object> | null}}

``muse harmony forget <pattern_id> --json``::

    {"pattern_id": "<hex64>", "removed": <bool>}

``muse harmony clear --json`` / ``muse harmony gc --json``::

    {"removed": <int>}   (gc also includes "age_days": <int>)

``muse harmony policy-add --json``::

    {"policy_id": "<str>", "action": "<str>", "scope": "<str>"}

``muse harmony policy-list --json``::

    {
      "total": <int>,
      "policies": [
        {
          "policy_id": "<str>", "description": "<str>", "scope": "<str>",
          "action": "<str>", "confidence": <float>,
          "conflict_type": "<str>|null", "domain": "<str>|null",
          "path_pattern": "<str>|null", "created_at": "<iso8601>",
          "created_by": "<str>"
        }, ...
      ]
    }

``muse harmony policy-remove <policy_id> --json``::

    {"policy_id": "<str>", "removed": <bool>}

``muse harmony audit --json``::

    {"total": <int>, "entries": [{<AuditEvent>}, ...]}

Exit codes
----------

- 0 — success
- 1 — invalid arguments, not-found, or validation failure
- 2 — not inside a Muse repository
"""

from __future__ import annotations

import argparse

from ._handlers import (
    run_audit,
    run_best,
    run_clear,
    run_engine,
    run_escalate,
    run_escalations,
    run_forget,
    run_gc,
    run_list,
    run_policy_add,
    run_policy_list,
    run_policy_remove,
    run_record,
    run_resolve,
    run_resolve_escalation,
    run_show,
    run_similar,
)


def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the harmony subcommand group."""
    parser = subparsers.add_parser(
        "harmony",
        help="Resolution Intelligence — record, resolve, and replay conflict patterns.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subs = parser.add_subparsers(dest="subcommand", metavar="SUBCOMMAND")
    subs.required = True

    # -- record ---------------------------------------------------------------
    record_p = subs.add_parser(
        "record",
        help="Record a new conflict pattern.",
        description=(
            "Persist a ConflictPattern to the harmony store.\n\n"
            "The pattern is identified by a blob fingerprint (SHA-256 of sorted\n"
            "ours_id:theirs_id) and an optional semantic fingerprint supplied by\n"
            "a domain plugin.  Recording the same pattern twice is idempotent.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony record --path track.mid --domain midi \\\n"
            "    --conflict-type content \\\n"
            "    --ours-id <hex64> --theirs-id <hex64> --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"pattern_id": "<hex64>", "already_existed": <bool>}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — pattern recorded (or already existed)\n"
            "  1 — invalid arguments or validation failure\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    record_p.add_argument("--path", required=True,
                          help="Workspace-relative POSIX path of the conflicting file.")
    record_p.add_argument("--domain", required=True,
                          help="Domain name, e.g. 'midi' or 'code'.")
    record_p.add_argument("--conflict-type", required=True, dest="conflict_type",
                          help="Conflict category (content, structural, metadata, relational, ...).")
    record_p.add_argument("--ours-id", required=True, dest="ours_id",
                          help="64-char hex SHA-256 object ID for the 'ours' version.")
    record_p.add_argument("--theirs-id", required=True, dest="theirs_id",
                          help="64-char hex SHA-256 object ID for the 'theirs' version.")
    record_p.add_argument("--semantic-fingerprint", dest="semantic_fingerprint", default=None,
                          help="64-char hex semantic fingerprint from a domain plugin. "
                               "Defaults to the blob fingerprint.")
    record_p.add_argument("--description", default=None,
                          help="JSON-encoded domain-specific metadata (optional).")
    record_p.add_argument("--recorded-by", dest="recorded_by", default="human",
                          help="Agent ID or 'human' (default: human).")
    record_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    record_p.set_defaults(func=run_record)

    # -- list -----------------------------------------------------------------
    list_p = subs.add_parser(
        "list",
        help="List recorded conflict patterns.",
        description=(
            "List all ConflictPatterns in the harmony store, newest first.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony list --json\n"
            "  muse harmony list --domain midi --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"total": <int>, "patterns": [{...}, ...]}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — list returned (may be empty)\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    list_p.add_argument("--domain", default=None,
                        help="Filter to patterns in this domain only.")
    list_p.add_argument("--conflict-type", dest="conflict_type", default=None,
                        help="Filter to patterns of this conflict type only.")
    list_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    list_p.set_defaults(func=run_list)

    # -- show -----------------------------------------------------------------
    show_p = subs.add_parser(
        "show",
        help="Show a conflict pattern and all its resolutions.",
        description=(
            "Display the full ConflictPattern metadata and every saved Resolution,\n"
            "sorted by quality (human_verified > confidence > applied_count).\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony show <pattern_id> --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"pattern": {...}, "resolutions": [{...}, ...]}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — pattern found and shown\n"
            "  1 — invalid pattern_id or pattern not found\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    show_p.add_argument("pattern_id", metavar="PATTERN_ID",
                        help="64-char hex pattern ID.")
    show_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    show_p.set_defaults(func=run_show)

    # -- resolve --------------------------------------------------------------
    resolve_p = subs.add_parser(
        "resolve",
        help="Save a resolution for a conflict pattern.",
        description=(
            "Persist a Resolution to the harmony store.  The parent pattern must\n"
            "already exist (run 'muse harmony record' first).  Saving the same\n"
            "resolution twice is idempotent.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony resolve --pattern-id <hex64> \\\n"
            "    --strategy manual --outcome-blob <hex64> \\\n"
            "    --confidence 0.9 --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"resolution_id": "<hex64>", "pattern_id": "<hex64>",\n'
            '   "already_existed": <bool>}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — resolution saved (or already existed)\n"
            "  1 — validation failure, pattern not found, or confidence out of range\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    resolve_p.add_argument("--pattern-id", required=True, dest="pattern_id",
                           help="64-char hex pattern ID to resolve.")
    resolve_p.add_argument("--strategy", required=True,
                           help="Resolution strategy (manual, exact-replay, "
                                "semantic-proposal, policy).")
    resolve_p.add_argument("--outcome-blob", required=True, dest="outcome_blob",
                           help="64-char hex SHA-256 of the resolved object.")
    resolve_p.add_argument("--confidence", required=True, type=float,
                           help="Resolution confidence 0.0–1.0.")
    resolve_p.add_argument("--rationale", default="",
                           help="Human-readable reasoning for this resolution.")
    resolve_p.add_argument("--agent-id", dest="agent_id", default=None,
                           help="Agent ID for provenance (omit for human).")
    resolve_p.add_argument("--model-id", dest="model_id", default=None,
                           help="Model ID for agent provenance.")
    resolve_p.add_argument("--human-verified", dest="human_verified",
                           action="store_true",
                           help="Mark this resolution as human-verified.")
    resolve_p.add_argument("--policy-id", dest="policy_id", default=None,
                           help="Policy ID that triggered this resolution (if any).")
    resolve_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    resolve_p.set_defaults(func=run_resolve)

    # -- best -----------------------------------------------------------------
    best_p = subs.add_parser(
        "best",
        help="Show the highest-quality resolution for a pattern.",
        description=(
            "Return the best Resolution for a pattern, ranked by\n"
            "human_verified > confidence > applied_count.  Returns null if\n"
            "no resolutions exist yet.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony best <pattern_id> --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"pattern_id": "<hex64>", "resolution": {<resolution>|null}}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — result returned (resolution may be null)\n"
            "  1 — invalid pattern_id\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    best_p.add_argument("pattern_id", metavar="PATTERN_ID",
                        help="64-char hex pattern ID.")
    best_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    best_p.set_defaults(func=run_best)

    # -- forget ---------------------------------------------------------------
    forget_p = subs.add_parser(
        "forget",
        help="Remove a conflict pattern and all its resolutions.",
        description=(
            "Delete the pattern and every resolution stored under it.  Returns\n"
            "removed=false if the pattern does not exist.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony forget <pattern_id> --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"pattern_id": "<hex64>", "removed": <bool>}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — result returned\n"
            "  1 — invalid pattern_id\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    forget_p.add_argument("pattern_id", metavar="PATTERN_ID",
                          help="64-char hex pattern ID.")
    forget_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    forget_p.set_defaults(func=run_forget)

    # -- clear ----------------------------------------------------------------
    clear_p = subs.add_parser(
        "clear",
        help="Remove all conflict patterns and their resolutions.",
        description=(
            "Delete every pattern entry from the harmony store.  This is\n"
            "irreversible.  Pass --yes to skip the confirmation prompt.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony clear --yes --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"removed": <int>}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — clear completed (removed may be 0)\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    clear_p.add_argument("--yes", "-y", action="store_true",
                         help="Skip the confirmation prompt.")
    clear_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    clear_p.set_defaults(func=run_clear)

    # -- gc -------------------------------------------------------------------
    gc_p = subs.add_parser(
        "gc",
        help="Garbage-collect stale unresolved conflict patterns.",
        description=(
            "Remove patterns older than --age days that have no saved resolution.\n"
            "Patterns with at least one resolution are always kept.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony gc --json\n"
            "  muse harmony gc --age 30 --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"removed": <int>, "age_days": <int>}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — gc completed (removed may be 0)\n"
            "  1 — invalid --age value\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    gc_p.add_argument("--age", type=int, default=90, metavar="DAYS",
                      help="Age threshold in days (default: 90).")
    gc_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    gc_p.set_defaults(func=run_gc)

    # -- policy-add -----------------------------------------------------------
    padd_p = subs.add_parser(
        "policy-add",
        help="Add or replace a declarative resolution policy.",
        description=(
            "Persist a Policy to the harmony store.  Overwrites any existing\n"
            "policy with the same policy_id.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony policy-add --policy-id prefer-ours \\\n"
            "    --description 'Always prefer ours for MIDI' \\\n"
            "    --scope domain --action prefer-ours --domain midi --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"policy_id": "<str>", "action": "<str>", "scope": "<str>"}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — policy saved\n"
            "  1 — invalid policy_id or argument\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    padd_p.add_argument("--policy-id", required=True, dest="policy_id",
                        help="URL-safe alphanumeric policy identifier (1–128 chars).")
    padd_p.add_argument("--description", required=True,
                        help="Human-readable explanation of what this policy does.")
    padd_p.add_argument("--scope", required=True,
                        help="Scope: workspace, repo, domain, or file.")
    padd_p.add_argument("--action", required=True,
                        help="Action: prefer-ours, prefer-theirs, escalate, "
                             "require-human, or delegate.")
    padd_p.add_argument("--confidence", type=float, default=1.0,
                        help="Confidence 0.0–1.0 assigned to policy-driven resolutions "
                             "(default: 1.0).")
    padd_p.add_argument("--conflict-type", dest="conflict_type", default=None,
                        help="Filter: only fire for this conflict type.")
    padd_p.add_argument("--domain", default=None,
                        help="Filter: only fire for this domain.")
    padd_p.add_argument("--path-pattern", dest="path_pattern", default=None,
                        help="Filter: fnmatch glob for file paths, e.g. '*.mid'.")
    padd_p.add_argument("--escalate-to", dest="escalate_to", default=None,
                        help="Target for ESCALATE action: 'human' or an agent ID.")
    padd_p.add_argument("--delegate-to", dest="delegate_to", default=None,
                        help="Agent ID for DELEGATE action.")
    padd_p.add_argument("--created-by", dest="created_by", default="human",
                        help="Creator attribution (default: human).")
    padd_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    padd_p.set_defaults(func=run_policy_add)

    # -- policy-list ----------------------------------------------------------
    plist_p = subs.add_parser(
        "policy-list",
        help="List all harmony policies, scope-sorted.",
        description=(
            "List every Policy from the harmony store.  Sorted by scope order\n"
            "(workspace → repo → domain → file) then by created_at ascending.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony policy-list --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"total": <int>, "policies": [{...}, ...]}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — list returned (may be empty)\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    plist_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    plist_p.set_defaults(func=run_policy_list)

    # -- policy-remove --------------------------------------------------------
    premove_p = subs.add_parser(
        "policy-remove",
        help="Remove a harmony policy.",
        description=(
            "Delete a policy by ID.  Returns removed=false if the policy\n"
            "does not exist.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony policy-remove <policy_id> --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"policy_id": "<str>", "removed": <bool>}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — result returned\n"
            "  1 — invalid policy_id\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    premove_p.add_argument("policy_id", metavar="POLICY_ID",
                           help="URL-safe policy identifier.")
    premove_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    premove_p.set_defaults(func=run_policy_remove)

    # -- audit ----------------------------------------------------------------
    audit_p = subs.add_parser(
        "audit",
        help="Show the harmony audit log.",
        description=(
            "List recent audit log entries (newest first).  The audit log is\n"
            "append-only — a tamper-evident record of all harmony engine actions.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony audit --json\n"
            "  muse harmony audit --limit 50 --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"total": <int>, "entries": [{<AuditEvent>}, ...]}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — audit log returned (may be empty)\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    audit_p.add_argument("--limit", type=int, default=100, metavar="N",
                         help="Maximum entries to return (default: 100).")
    audit_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    audit_p.set_defaults(func=run_audit)

    # -- engine ---------------------------------------------------------------
    engine_p = subs.add_parser(
        "engine",
        help="Run the three-tier resolution engine for a conflict pattern.",
        description=(
            "Evaluate a ConflictPattern through the resolution pipeline:\n"
            "  1. Policy match  — declarative rule fires automatically.\n"
            "  2. Exact replay  — saved resolution above confidence threshold.\n"
            "  3. Semantic match — similar pattern found via domain plugin.\n"
            "  4. Escalate      — no match; human or specialist-agent required.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony engine <pattern_id> --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"status": "applied|proposed|escalated",\n'
            '   "pattern_id": "<hex64>",\n'
            '   "proposal": {<proposal>|null},\n'
            '   "applied_resolution_id": "<hex64>|null",\n'
            '   "escalation_reason": "<str>|null"}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — engine ran successfully (check status field)\n"
            "  1 — invalid pattern_id or invalid threshold\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    engine_p.add_argument("pattern_id", metavar="PATTERN_ID",
                          help="64-char hex pattern ID to resolve.")
    engine_p.add_argument("--auto-apply-threshold", dest="auto_apply_threshold",
                          type=float, default=None,
                          help="Override auto-apply confidence threshold (0.0–1.0). "
                               "Default: 0.85.")
    engine_p.add_argument("--auto-escalate", dest="auto_escalate", action="store_true",
                          help="Automatically record an EscalationRecord when the engine "
                               "returns status=escalated.")
    engine_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    engine_p.set_defaults(func=run_engine)

    # -- similar --------------------------------------------------------------
    similar_p = subs.add_parser(
        "similar",
        help="Find conflict patterns semantically similar to the given pattern.",
        description=(
            "Search the harmony store for patterns whose semantic fingerprint is\n"
            "similar to the given pattern.  Uses DefaultPlugin (exact fingerprint\n"
            "match) unless a domain plugin is injected at the engine level.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony similar <pattern_id> --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"pattern_id": "<hex64>",\n'
            '   "total": <int>,\n'
            '   "proposals": [{<proposal>}, ...]}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — result returned (proposals may be empty)\n"
            "  1 — invalid pattern_id\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    similar_p.add_argument("pattern_id", metavar="PATTERN_ID",
                           help="64-char hex pattern ID to find similar patterns for.")
    similar_p.add_argument("--limit", type=int, default=None, metavar="N",
                           help="Maximum proposals to return (default: engine max_proposals=5).")
    similar_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    similar_p.set_defaults(func=run_similar)

    # -- escalate -------------------------------------------------------------
    escalate_p = subs.add_parser(
        "escalate",
        help="Record an escalation for a conflict pattern requiring human attention.",
        description=(
            "Persist an EscalationRecord marking a conflict pattern as open and\n"
            "awaiting human or specialist-agent resolution.  Recording the same\n"
            "(pattern_id, reason) pair twice is idempotent.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony escalate <pattern_id> --json\n"
            "  muse harmony escalate <pattern_id> --reason 'No policy found' --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"escalation_id": "<hex64>", "pattern_id": "<hex64>",\n'
            '   "already_existed": <bool>}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — escalation recorded (or already existed)\n"
            "  1 — invalid pattern_id\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    escalate_p.add_argument("pattern_id", metavar="PATTERN_ID",
                            help="64-char hex pattern ID to escalate.")
    escalate_p.add_argument("--reason", default="Escalated for human review",
                            help="Human-readable reason for escalation.")
    escalate_p.add_argument("--agent-id", dest="agent_id", default=None,
                            help="Agent ID for provenance (omit for human).")
    escalate_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    escalate_p.set_defaults(func=run_escalate)

    # -- escalations ----------------------------------------------------------
    escalations_p = subs.add_parser(
        "escalations",
        help="List conflict pattern escalations (operator dashboard).",
        description=(
            "List EscalationRecords — the operator dashboard of unresolved conflicts.\n"
            "Filter by --status to see open, resolved, or all escalations.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony escalations --json\n"
            "  muse harmony escalations --status open --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"total": <int>, "escalations": [{...}, ...]}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — list returned (may be empty)\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    escalations_p.add_argument("--status", default=None,
                                choices=["open", "resolved"],
                                help="Filter by escalation status.")
    escalations_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    escalations_p.set_defaults(func=run_escalations)

    # -- resolve-escalation ---------------------------------------------------
    resolve_esc_p = subs.add_parser(
        "resolve-escalation",
        help="Close an escalation after a conflict is manually resolved.",
        description=(
            "Transition an EscalationRecord from OPEN to RESOLVED.  Links the\n"
            "escalation to the resolution that closed it.  Returns resolved=false\n"
            "if the escalation does not exist.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse harmony resolve-escalation <esc_id> --resolution-id <hex64> --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"escalation_id": "<hex64>", "resolved": <bool>}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — result returned (resolved may be false)\n"
            "  1 — invalid escalation_id or resolution_id\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    resolve_esc_p.add_argument("escalation_id", metavar="ESCALATION_ID",
                               help="64-char hex escalation ID to close.")
    resolve_esc_p.add_argument("--resolution-id", required=True, dest="resolution_id",
                               help="64-char hex resolution ID that closes this escalation.")
    resolve_esc_p.add_argument("--agent-id", dest="agent_id", default=None,
                               help="Agent ID for resolved_by provenance (omit for human).")
    resolve_esc_p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Emit JSON output.")
    resolve_esc_p.set_defaults(func=run_resolve_escalation)
