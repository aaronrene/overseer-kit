"""Handler functions for the harmony CLI subcommands."""

from __future__ import annotations

import argparse
import datetime
import json
import logging
import sys
from typing import Any

from muse.core.envelope import make_envelope
from muse.core.errors import ExitCode
from muse.core.harmony import (
    AgentProvenance,
    AuditEventType,
    ConflictPattern,
    EscalationRecord,
    Policy,
    PolicyCondition,
    Resolution,
    _validate_fingerprint,
    _validate_id,
    _validate_policy_id,
    append_audit,
    best_resolution,
    blob_fingerprint,
    clear_all,
    compute_escalation_id,
    compute_pattern_id,
    compute_resolution_id,
    forget_pattern,
    gc_stale,
    list_audit,
    list_escalations,
    list_patterns,
    list_policies,
    list_resolutions,
    load_pattern,
    patterns_dir,
    record_escalation,
    record_pattern,
    remove_policy,
    resolve_escalation,
    save_policy,
    save_resolution,
)
from muse.core.harmony.engine import EngineConfig, find_similar as _engine_find_similar, resolve as _engine_resolve
from muse.core.repo import require_repo
from muse.core.timing import start_timer
from muse.core.types import blob_id, short_id
from muse.core.validation import clamp_int, sanitize_display
from ._shapes import (
    _HarmonyAuditJson,
    _HarmonyBestJson,
    _HarmonyEngineJson,
    _HarmonyEscalateJson,
    _HarmonyEscalationEntryJson,
    _HarmonyEscalationsJson,
    _HarmonyForgetJson,
    _HarmonyGcJson,
    _HarmonyListEntryJson,
    _HarmonyListJson,
    _HarmonyPolicyAddJson,
    _HarmonyPolicyListJson,
    _HarmonyPolicyRemoveJson,
    _HarmonyProposalJson,
    _HarmonyRecordJson,
    _HarmonyResolveEscalationJson,
    _HarmonyResolveJson,
    _HarmonyScalarJson,
    _HarmonySimilarJson,
    _HarmonyShowJson,
    _escalation_to_entry,
    _pattern_to_detail,
    _pattern_to_list_entry,
    _policy_to_entry,
    _resolution_to_detail,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# record
# ---------------------------------------------------------------------------

def run_record(args: argparse.Namespace) -> None:
    """Record a new conflict pattern in the harmony store.

    Computes a blob fingerprint from the sorted (ours_id, theirs_id) pair.
    If ``--semantic-fingerprint`` is not supplied the blob fingerprint is reused
    as the semantic fingerprint.  Recording the same pattern twice is idempotent
    — the existing entry is returned unchanged.  Writes an audit entry on first record.

    Agent quickstart
    ----------------
    ::

        muse harmony record <path> --ours-id <hex> --theirs-id <hex> --format json
        muse harmony record config.py --ours-id <hex> --theirs-id <hex> --domain code --format json

    JSON fields
    -----------
    pattern_id      Hex-64 fingerprint identifying the pattern.
    already_existed ``true`` if the pattern was already in the store.

    Exit codes
    ----------
    0  Success.
    1  Invalid IDs, fingerprints, or description.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    path: str = args.path
    domain: str = args.domain
    conflict_type: str = args.conflict_type
    ours_id: str = args.ours_id
    theirs_id: str = args.theirs_id
    semantic_fp_arg: str | None = args.semantic_fingerprint
    description_raw: str | None = args.description
    recorded_by: str = args.recorded_by
    json_out: bool = args.json_out

    # Validate hex IDs before touching the filesystem.
    for label, value in (("ours_id", ours_id), ("theirs_id", theirs_id)):
        try:
            _validate_id(value, label)
        except ValueError as exc:
            if json_out:
                print(json.dumps({"error": str(exc)}))
            else:
                print(f"❌ {exc}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

    if semantic_fp_arg is not None:
        try:
            _validate_fingerprint(semantic_fp_arg, "semantic_fingerprint")
        except ValueError as exc:
            if json_out:
                print(json.dumps({"error": str(exc)}))
            else:
                print(f"❌ {exc}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

    description = {}
    if description_raw is not None:
        try:
            description = json.loads(description_raw)
            if not isinstance(description, dict):
                raise ValueError("description must be a JSON object")
        except (json.JSONDecodeError, ValueError) as exc:
            if json_out:
                print(json.dumps({"error": f"Invalid --description: {exc}"}))
            else:
                print(f"❌ Invalid --description: {exc}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()

    blob_fp = blob_fingerprint(ours_id, theirs_id)
    semantic_fp = semantic_fp_arg if semantic_fp_arg is not None else blob_fp
    pattern_id = compute_pattern_id(path, blob_fp, semantic_fp)

    # Check idempotency before building the full object.
    existing = load_pattern(root, pattern_id)
    already_existed = existing is not None

    if not already_existed:
        pattern = ConflictPattern(
            pattern_id=pattern_id,
            path=path,
            domain=domain,
            conflict_type=conflict_type,
            blob_fingerprint=blob_fp,
            semantic_fingerprint=semantic_fp,
            ours_id=ours_id,
            theirs_id=theirs_id,
            description=description,
            recorded_at=datetime.datetime.now(datetime.timezone.utc),
            recorded_by=recorded_by,
        )
        record_pattern(root, pattern)
        append_audit(
            root,
            AuditEventType.PATTERN_RECORDED,
            AgentProvenance.human() if recorded_by == "human"
            else AgentProvenance.agent(recorded_by),
            pattern_id=pattern_id,
        )
        logger.debug("harmony: recorded pattern %s for '%s'", short_id(pattern_id), path)

    if json_out:
        print(json.dumps(_HarmonyRecordJson(
            **make_envelope(elapsed),
            pattern_id=pattern_id,
            already_existed=already_existed,
        )))
        return

    if already_existed:
        print(f"  ℹ pattern {pattern_id}  already recorded for '{sanitize_display(path)}'")
    else:
        print(f"  ✅ recorded pattern {pattern_id}  '{sanitize_display(path)}'")

# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------

def run_list(args: argparse.Namespace) -> None:
    """List all conflict patterns in the harmony store.

    Returns patterns sorted newest-first.  Use ``--domain`` and
    ``--conflict-type`` to narrow the results.

    Agent quickstart
    ----------------
    ::

        muse harmony patterns --format json
        muse harmony patterns --domain code --format json

    JSON fields
    -----------
    total     Total number of patterns matching the filter.
    patterns  List of pattern objects: ``pattern_id``, ``path``, ``domain``,
              ``conflict_type``, ``resolution_count``, ``recorded_at``.

    Exit codes
    ----------
    0  Success (may be empty).
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    domain_filter: str | None = args.domain
    ct_filter: str | None = args.conflict_type
    json_out: bool = args.json_out

    root = require_repo()
    patterns = list_patterns(root)

    if domain_filter is not None:
        patterns = [p for p in patterns if p.domain == domain_filter]
    if ct_filter is not None:
        patterns = [p for p in patterns if p.conflict_type == ct_filter]

    entries: list[_HarmonyListEntryJson] = []
    for p in patterns:
        resolutions = list_resolutions(root, p.pattern_id)
        entries.append(_pattern_to_list_entry(p, len(resolutions)))

    if json_out:
        print(json.dumps(_HarmonyListJson(
            **make_envelope(elapsed),
            total=len(entries),
            patterns=entries,
        )))
        return

    if not entries:
        print("No harmony conflict patterns recorded.")
        return

    print(f"{'pattern_id':14}  {'domain':8}  {'type':12}  {'res':>3}  path")
    print("─" * 70)
    for e in entries:
        pid_short = short_id(e["pattern_id"])
        print(
            f"  {pid_short}  {e['domain']:8}  {e['conflict_type']:12}  "
            f"{e['resolution_count']:>3}  {e['path']}"
        )

# ---------------------------------------------------------------------------
# show
# ---------------------------------------------------------------------------

def run_show(args: argparse.Namespace) -> None:
    """Show a conflict pattern and all its resolutions.

    Exits 1 if the pattern_id is invalid or the pattern does not exist.

    JSON schema::

        {"pattern": {...}, "resolutions": [{...}, ...]}

    Exit codes:
        0 — pattern found
        1 — invalid pattern_id or pattern not found
        2 — not inside a Muse repository
    """
    elapsed = start_timer()
    pattern_id: str = args.pattern_id
    json_out: bool = args.json_out

    try:
        _validate_id(pattern_id, "pattern_id")
    except ValueError as exc:
        if json_out:
            print(json.dumps({"error": str(exc)}))
        else:
            print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()
    pattern = load_pattern(root, pattern_id)
    if pattern is None:
        msg = f"Pattern {pattern_id} not found."
        if json_out:
            print(json.dumps({"error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    resolutions = list_resolutions(root, pattern_id)

    if json_out:
        print(json.dumps(_HarmonyShowJson(
            **make_envelope(elapsed),
            pattern=_pattern_to_detail(pattern),
            resolutions=[_resolution_to_detail(r) for r in resolutions],
        )))
        return

    print(f"\nPattern {pattern_id}  '{sanitize_display(pattern.path)}'")
    print(f"  domain:       {pattern.domain}")
    print(f"  type:         {pattern.conflict_type}")
    print(f"  blob_fp:      {short_id(pattern.blob_fingerprint)}…")
    print(f"  recorded_at:  {pattern.recorded_at.strftime('%Y-%m-%d %H:%M')}")
    print(f"  recorded_by:  {sanitize_display(pattern.recorded_by)}")
    if resolutions:
        print(f"\n  Resolutions ({len(resolutions)}):")
        for r in resolutions:
            hv = " ✅ verified" if r.human_verified else ""
            print(
                f"    {short_id(r.resolution_id)}  {r.strategy:18}  "
                f"conf={r.confidence:.2f}  applied={r.applied_count}{hv}"
            )
    else:
        print("\n  No resolutions saved yet.")

# ---------------------------------------------------------------------------
# resolve
# ---------------------------------------------------------------------------

def run_resolve(args: argparse.Namespace) -> None:
    """Save a resolution for a conflict pattern.

    The parent pattern must already exist.  Saving the same resolution_id
    twice is idempotent.  Writes an audit entry on first save.

    JSON schema::

        {"resolution_id": "<hex64>", "pattern_id": "<hex64>",
         "already_existed": <bool>}

    Exit codes:
        0 — resolution saved (or already existed)
        1 — invalid ID, pattern not found, or confidence out of range
        2 — not inside a Muse repository
    """
    elapsed = start_timer()
    pattern_id: str = args.pattern_id
    strategy: str = args.strategy
    outcome_blob: str = args.outcome_blob
    confidence: float = args.confidence
    rationale: str = args.rationale
    agent_id: str | None = args.agent_id
    model_id: str | None = args.model_id
    human_verified: bool = args.human_verified
    policy_id: str | None = args.policy_id
    json_out: bool = args.json_out

    # Validate IDs.
    for label, value in (("pattern_id", pattern_id), ("outcome_blob", outcome_blob)):
        try:
            _validate_id(value, label)
        except ValueError as exc:
            if json_out:
                print(json.dumps({"error": str(exc)}))
            else:
                print(f"❌ {exc}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

    if not (0.0 <= confidence <= 1.0):
        msg = f"--confidence must be between 0.0 and 1.0, got {confidence}"
        if json_out:
            print(json.dumps({"error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()

    provenance = (
        AgentProvenance.agent(agent_id, model_id)
        if agent_id is not None
        else AgentProvenance.human()
    )

    actor = provenance.agent_id or "human"

    # Check idempotency: scan existing resolutions for one that matches the
    # key fields (outcome_blob, strategy, actor).  resolution_id encodes
    # resolved_at so two calls at different times would otherwise produce
    # distinct IDs for semantically identical resolutions.
    existing_resolutions = list_resolutions(root, pattern_id)
    already_existed = False
    resolution_id: str | None = None
    for existing in existing_resolutions:
        existing_actor = existing.resolved_by.agent_id or "human"
        if (
            existing.outcome_blob == outcome_blob
            and existing.strategy == strategy
            and existing_actor == actor
        ):
            resolution_id = existing.resolution_id
            already_existed = True
            break

    resolved_at = datetime.datetime.now(datetime.timezone.utc)
    if resolution_id is None:
        resolution_id = compute_resolution_id(
            pattern_id, outcome_blob, strategy, provenance, resolved_at
        )

    if not already_existed:
        try:
            resolution = Resolution(
                resolution_id=resolution_id,
                pattern_id=pattern_id,
                strategy=strategy,
                policy_id=policy_id,
                outcome_blob=outcome_blob,
                resolved_by=provenance,
                human_verified=human_verified,
                confidence=confidence,
                rationale=rationale,
                resolved_at=resolved_at,
            )
            save_resolution(root, resolution)
        except FileNotFoundError as exc:
            msg = str(exc)
            if json_out:
                print(json.dumps({"error": msg}))
            else:
                print(f"❌ {msg}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

        append_audit(
            root,
            AuditEventType.RESOLUTION_SAVED,
            provenance,
            pattern_id=pattern_id,
            resolution_id=resolution_id,
        )

    if json_out:
        print(json.dumps(_HarmonyResolveJson(
            **make_envelope(elapsed),
            resolution_id=resolution_id,
            pattern_id=pattern_id,
            already_existed=already_existed,
        )))
        return

    if already_existed:
        print(f"  ℹ resolution {resolution_id}  already saved.")
    else:
        print(f"  ✅ saved resolution {resolution_id}  for pattern {pattern_id}")

# ---------------------------------------------------------------------------
# best
# ---------------------------------------------------------------------------

def run_best(args: argparse.Namespace) -> None:
    """Show the highest-quality resolution for a pattern.

    Quality ranking: human_verified > confidence > applied_count.
    Returns null if no resolutions exist.

    JSON schema::

        {"pattern_id": "<hex64>", "resolution": {<resolution>|null}}

    Exit codes:
        0 — result returned
        1 — invalid pattern_id
        2 — not inside a Muse repository
    """
    elapsed = start_timer()
    pattern_id: str = args.pattern_id
    json_out: bool = args.json_out

    try:
        _validate_id(pattern_id, "pattern_id")
    except ValueError as exc:
        if json_out:
            print(json.dumps({"error": str(exc)}))
        else:
            print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()
    best = best_resolution(root, pattern_id)

    if json_out:
        print(json.dumps(_HarmonyBestJson(
            **make_envelope(elapsed),
            pattern_id=pattern_id,
            resolution=_resolution_to_detail(best) if best is not None else None,
        )))
        return

    if best is None:
        print(f"  ℹ No resolutions for pattern {pattern_id}.")
        return

    hv = " ✅ verified" if best.human_verified else ""
    print(
        f"  best for {pattern_id}:\n"
        f"    {best.resolution_id}  {best.strategy}  "
        f"conf={best.confidence:.2f}  applied={best.applied_count}{hv}\n"
        f"    rationale: {sanitize_display(best.rationale)}"
    )

# ---------------------------------------------------------------------------
# forget
# ---------------------------------------------------------------------------

def run_forget(args: argparse.Namespace) -> None:
    """Remove a conflict pattern and all its resolutions.

    JSON schema::

        {"pattern_id": "<hex64>", "removed": <bool>}

    Exit codes:
        0 — result returned
        1 — invalid pattern_id
        2 — not inside a Muse repository
    """
    elapsed = start_timer()
    pattern_id: str = args.pattern_id
    json_out: bool = args.json_out

    try:
        _validate_id(pattern_id, "pattern_id")
    except ValueError as exc:
        if json_out:
            print(json.dumps({"error": str(exc)}))
        else:
            print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()
    removed = forget_pattern(root, pattern_id)

    if json_out:
        print(json.dumps(_HarmonyForgetJson(
            **make_envelope(elapsed),
            pattern_id=pattern_id,
            removed=removed,
        )))
        return

    if removed:
        print(f"  🗑  forgot pattern {pattern_id}")
    else:
        print(f"  ℹ pattern {pattern_id} not found.")

# ---------------------------------------------------------------------------
# clear
# ---------------------------------------------------------------------------

def run_clear(args: argparse.Namespace) -> None:
    """Remove all conflict patterns and their resolutions.

    JSON schema::

        {"removed": <int>}

    Exit codes:
        0 — clear completed (removed may be 0)
        2 — not inside a Muse repository
    """
    elapsed = start_timer()
    yes: bool = args.yes
    json_out: bool = args.json_out

    root = require_repo()

    if not yes:
        pdir = patterns_dir(root)
        count = (
            sum(1 for e in pdir.iterdir() if not e.is_symlink() and e.is_dir())
            if pdir.exists()
            else 0
        )
        if count == 0:
            if json_out:
                print(json.dumps(_HarmonyScalarJson(**make_envelope(elapsed), removed=0)))
            else:
                print("Harmony store is already empty.")
            return
        confirmed = input(
            f"This will permanently delete {count} harmony pattern(s). Continue? [y/N]: "
        ).strip().lower() in ("y", "yes")
        if not confirmed:
            print("Aborted.")
            return

    removed = clear_all(root)

    if json_out:
        print(json.dumps(_HarmonyScalarJson(**make_envelope(elapsed), removed=removed)))
        return

    print(f"✅ Cleared {removed} harmony pattern(s).")

# ---------------------------------------------------------------------------
# gc
# ---------------------------------------------------------------------------

def run_gc(args: argparse.Namespace) -> None:
    """Remove stale unresolved patterns older than --age days.

    Patterns with at least one resolution are always kept.

    JSON schema::

        {"removed": <int>, "age_days": <int>}

    Exit codes:
        0 — gc completed (removed may be 0)
        1 — invalid --age value
        2 — not inside a Muse repository
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    try:
        age_days: int = clamp_int(args.age, 1, 36_500, "age")
    except ValueError as exc:
        if json_out:
            print(json.dumps({"error": str(exc)}))
        else:
            print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()
    removed = gc_stale(root, age_days=age_days)

    if json_out:
        print(json.dumps(_HarmonyGcJson(
            **make_envelope(elapsed),
            removed=removed,
            age_days=age_days,
        )))
        return

    if removed:
        print(
            f"✅ gc: removed {removed} stale unresolved pattern(s) "
            f"older than {age_days} day(s)."
        )
    else:
        print(f"gc: nothing to remove (threshold: {age_days} day(s)).")

# ---------------------------------------------------------------------------
# policy-add
# ---------------------------------------------------------------------------

def run_policy_add(args: argparse.Namespace) -> None:
    """Add or replace a declarative resolution policy.

    Overwrites any existing policy with the same policy_id.

    JSON schema::

        {"policy_id": "<str>", "action": "<str>", "scope": "<str>"}

    Exit codes:
        0 — policy saved
        1 — invalid policy_id
        2 — not inside a Muse repository
    """
    elapsed = start_timer()
    policy_id: str = args.policy_id
    description: str = args.description
    scope: str = args.scope
    action: str = args.action
    confidence: float = args.confidence
    conflict_type: str | None = args.conflict_type
    domain: str | None = args.domain
    path_pattern: str | None = args.path_pattern
    escalate_to: str | None = args.escalate_to
    delegate_to: str | None = args.delegate_to
    created_by: str = args.created_by
    json_out: bool = args.json_out

    try:
        _validate_policy_id(policy_id)
    except ValueError as exc:
        if json_out:
            print(json.dumps({"error": str(exc)}))
        else:
            print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()

    policy = Policy(
        policy_id=policy_id,
        description=description,
        when=PolicyCondition(
            conflict_type=conflict_type,
            domain=domain,
            path_pattern=path_pattern,
        ),
        action=action,
        confidence=confidence,
        escalate_to=escalate_to,
        delegate_to=delegate_to,
        scope=scope,
        created_at=datetime.datetime.now(datetime.timezone.utc),
        created_by=created_by,
    )
    save_policy(root, policy)
    append_audit(
        root,
        AuditEventType.POLICY_SAVED,
        AgentProvenance.human() if created_by == "human"
        else AgentProvenance.agent(created_by),
        policy_id=policy_id,
    )

    if json_out:
        print(json.dumps(_HarmonyPolicyAddJson(
            **make_envelope(elapsed),
            policy_id=policy_id,
            action=action,
            scope=scope,
        )))
        return

    print(f"  ✅ saved policy '{policy_id}'  scope={scope}  action={action}")

# ---------------------------------------------------------------------------
# policy-list
# ---------------------------------------------------------------------------

def run_policy_list(args: argparse.Namespace) -> None:
    """List all policies from the harmony store, scope-sorted.

    JSON schema::

        {"total": <int>, "policies": [{...}, ...]}

    Exit codes:
        0 — list returned (may be empty)
        2 — not inside a Muse repository
    """
    elapsed = start_timer()
    json_out: bool = args.json_out

    root = require_repo()
    policies = list_policies(root)

    entries = [_policy_to_entry(p) for p in policies]

    if json_out:
        print(json.dumps(_HarmonyPolicyListJson(
            **make_envelope(elapsed),
            total=len(entries),
            policies=entries,
        )))
        return

    if not entries:
        print("No harmony policies defined.")
        return

    print(f"{'policy_id':24}  {'scope':10}  {'action':14}  conf")
    print("─" * 60)
    for e in entries:
        print(
            f"  {e['policy_id']:<22}  {e['scope']:10}  "
            f"{e['action']:14}  {e['confidence']:.2f}"
        )

# ---------------------------------------------------------------------------
# policy-remove
# ---------------------------------------------------------------------------

def run_policy_remove(args: argparse.Namespace) -> None:
    """Remove a policy from the harmony store.

    JSON schema::

        {"policy_id": "<str>", "removed": <bool>}

    Exit codes:
        0 — result returned
        1 — invalid policy_id
        2 — not inside a Muse repository
    """
    elapsed = start_timer()
    policy_id: str = args.policy_id
    json_out: bool = args.json_out

    try:
        _validate_policy_id(policy_id)
    except ValueError as exc:
        if json_out:
            print(json.dumps({"error": str(exc)}))
        else:
            print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()
    removed = remove_policy(root, policy_id)

    if json_out:
        print(json.dumps(_HarmonyPolicyRemoveJson(
            **make_envelope(elapsed),
            policy_id=policy_id,
            removed=removed,
        )))
        return

    if removed:
        print(f"  🗑  removed policy '{policy_id}'")
    else:
        print(f"  ℹ policy '{policy_id}' not found.")

# ---------------------------------------------------------------------------
# audit
# ---------------------------------------------------------------------------

def run_audit(args: argparse.Namespace) -> None:
    """Show the harmony audit log (newest first).

    JSON schema::

        {"total": <int>, "entries": [{<AuditEvent>}, ...]}

    Exit codes:
        0 — audit log returned (may be empty)
        2 — not inside a Muse repository
    """
    elapsed = start_timer()
    limit: int = args.limit
    json_out: bool = args.json_out

    root = require_repo()
    entries = list_audit(root, limit=limit)

    if json_out:
        print(json.dumps(_HarmonyAuditJson(
            **make_envelope(elapsed),
            total=len(entries),
            entries=entries,
        )))
        return

    if not entries:
        print("Harmony audit log is empty.")
        return

    print(f"{'occurred_at':22}  {'event_type':28}  {'pattern_id':14}")
    print("─" * 72)
    for e in entries:
        pid_short = short_id(e["pattern_id"] or "") or "-"
        ts = e["occurred_at"][:19]
        print(f"  {ts}  {e['event_type']:28}  {pid_short}")

# ---------------------------------------------------------------------------
# engine helpers
# ---------------------------------------------------------------------------

def _proposal_to_json(p: "Any") -> _HarmonyProposalJson:
    """Serialise a ResolutionProposal to its JSON TypedDict form."""
    from muse.core.harmony import ResolutionProposal  # local to avoid circular
    return _HarmonyProposalJson(
        pattern_id=p.pattern_id,
        strategy=p.strategy,
        proposed_action=p.proposed_action,
        confidence=p.confidence,
        rationale=p.rationale,
        policy_id=p.policy_id,
        similar_pattern_id=p.similar_pattern_id,
        similarity=p.similarity,
        requires_confirmation=p.requires_confirmation,
    )

def _stub_id(seed: str) -> str:
    """Return a deterministic ``sha256:``-prefixed ID derived from seed (for stub patterns)."""
    return blob_id(seed.encode())

# ---------------------------------------------------------------------------
# engine
# ---------------------------------------------------------------------------

def run_engine(args: argparse.Namespace) -> None:
    """Run the three-tier resolution engine for a conflict pattern.

    The engine evaluates the pattern against policies, saved resolutions, and
    semantically similar patterns.  Returns status=applied|proposed|escalated.

    JSON schema::

        {
            "status": "applied|proposed|escalated",
            "pattern_id": "<hex64>",
            "proposal": {<proposal>|null},
            "applied_resolution_id": "<hex64>|null",
            "escalation_reason": "<str>|null"
        }

    Exit codes:
        0 — engine ran successfully
        1 — invalid pattern_id or invalid threshold
        2 — not inside a Muse repository
    """
    elapsed = start_timer()

    pattern_id: str = args.pattern_id
    threshold: float | None = args.auto_apply_threshold
    auto_escalate: bool = getattr(args, "auto_escalate", False)
    json_out: bool = args.json_out

    try:
        _validate_id(pattern_id, "pattern_id")
    except ValueError as exc:
        if json_out:
            print(json.dumps({"error": str(exc)}))
        else:
            print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    if threshold is not None and not (0.0 <= threshold <= 1.0):
        msg = f"--auto-apply-threshold must be between 0.0 and 1.0, got {threshold}"
        if json_out:
            print(json.dumps({"error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()

    # Build a ConflictPattern from the stored pattern, or synthesize a
    # minimal stub if it does not exist (engine escalates gracefully).
    pattern = load_pattern(root, pattern_id)
    if pattern is None:
        blob_fp = _stub_id(pattern_id)
        pattern = ConflictPattern(
            pattern_id=pattern_id,
            path="<unknown>",
            domain="<unknown>",
            conflict_type="<unknown>",
            blob_fingerprint=blob_fp,
            semantic_fingerprint=blob_fp,
            ours_id=blob_fp,
            theirs_id=blob_fp,
            description={},
            recorded_at=datetime.datetime.now(datetime.timezone.utc),
            recorded_by="engine-cli",
        )

    cfg_kwargs = {}
    if threshold is not None:
        cfg_kwargs["auto_apply_threshold"] = threshold
    cfg = EngineConfig(**cfg_kwargs)

    result = _engine_resolve(root, pattern, cfg)

    proposal_json: _HarmonyProposalJson | None = (
        _proposal_to_json(result.proposal) if result.proposal is not None else None
    )

    # Auto-escalate: record an EscalationRecord when the engine escalates.
    if auto_escalate and result.status == "escalated":
        reason = result.escalation_reason or "Engine escalated — no automatic resolution found"
        esc_id = compute_escalation_id(pattern_id, reason)
        esc_rec = EscalationRecord(
            escalation_id=esc_id,
            pattern_id=pattern_id,
            reason=reason,
            escalated_at=datetime.datetime.now(datetime.timezone.utc),
            escalated_by=AgentProvenance.agent("harmony-engine"),
        )
        record_escalation(root, esc_rec)
        append_audit(
            root,
            AuditEventType.ESCALATION_RECORDED,
            AgentProvenance.agent("harmony-engine"),
            pattern_id=pattern_id,
            metadata={"escalation_id": esc_id},
        )

    if json_out:
        print(json.dumps(_HarmonyEngineJson(
            **make_envelope(elapsed),
            status=result.status,
            pattern_id=result.pattern_id,
            proposal=proposal_json,
            applied_resolution_id=result.applied_resolution_id,
            escalation_reason=result.escalation_reason,
        )))
        return

    status_icon = {"applied": "✅", "proposed": "💡", "escalated": "⚠️"}.get(result.status, "")
    print(f"  {status_icon} [{result.status.upper()}]  pattern {pattern_id}")
    if result.proposal is not None:
        p = result.proposal
        print(f"    strategy:    {p.strategy}")
        print(f"    confidence:  {p.confidence:.3f}")
        print(f"    rationale:   {sanitize_display(p.rationale)}")
    if result.escalation_reason:
        print(f"    reason:      {sanitize_display(result.escalation_reason)}")

# ---------------------------------------------------------------------------
# similar
# ---------------------------------------------------------------------------

def run_similar(args: argparse.Namespace) -> None:
    """Find conflict patterns semantically similar to the given pattern.

    Uses DefaultPlugin (exact fingerprint match) at the CLI level.

    JSON schema::

        {
            "pattern_id": "<hex64>",
            "total": <int>,
            "proposals": [{<proposal>}, ...]
        }

    Exit codes:
        0 — result returned (proposals may be empty)
        1 — invalid pattern_id
        2 — not inside a Muse repository
    """
    elapsed = start_timer()

    pattern_id: str = args.pattern_id
    limit: int | None = args.limit
    json_out: bool = args.json_out

    try:
        _validate_id(pattern_id, "pattern_id")
    except ValueError as exc:
        if json_out:
            print(json.dumps({"error": str(exc)}))
        else:
            print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()

    pattern = load_pattern(root, pattern_id)
    if pattern is None:
        # Pattern not found — return empty results gracefully.
        if json_out:
            print(json.dumps(_HarmonySimilarJson(**make_envelope(elapsed), pattern_id=pattern_id, total=0, proposals=[])))
        else:
            print(f"  ℹ pattern {pattern_id} not found — no similar patterns.")
        return

    cfg_kwargs = {}
    if limit is not None:
        cfg_kwargs["max_proposals"] = limit
    cfg = EngineConfig(**cfg_kwargs)

    proposals = _engine_find_similar(root, pattern, config=cfg)
    proposal_jsons = [_proposal_to_json(p) for p in proposals]

    if json_out:
        print(json.dumps(_HarmonySimilarJson(
            **make_envelope(elapsed),
            pattern_id=pattern_id,
            total=len(proposal_jsons),
            proposals=proposal_jsons,
        )))
        return

    if not proposal_jsons:
        print(f"  ℹ no similar patterns found for {pattern_id}.")
        return

    print(f"  Similar patterns for {pattern_id} ({len(proposal_jsons)} proposal(s)):")
    for p in proposal_jsons:
        sim_str = f"{p['similarity']:.2f}" if p["similarity"] is not None else "n/a"
        print(
            f"    {short_id(p['similar_pattern_id'] or '')}  "
            f"sim={sim_str}  conf={p['confidence']:.3f}  {p['strategy']}"
        )

# ---------------------------------------------------------------------------
# escalate
# ---------------------------------------------------------------------------

def run_escalate(args: argparse.Namespace) -> None:
    """Record an escalation for a conflict pattern.

    Creates an EscalationRecord with status=open.  Idempotent — the same
    (pattern_id, reason) pair always maps to the same escalation_id.

    JSON schema::

        {"escalation_id": "<hex64>", "pattern_id": "<hex64>",
         "already_existed": <bool>}

    Exit codes:
        0 — escalation recorded (or already existed)
        1 — invalid pattern_id
        2 — not inside a Muse repository
    """
    elapsed = start_timer()

    pattern_id: str = args.pattern_id
    reason: str = args.reason
    agent_id: str | None = args.agent_id
    json_out: bool = args.json_out

    try:
        _validate_id(pattern_id, "pattern_id")
    except ValueError as exc:
        if json_out:
            print(json.dumps({"error": str(exc)}))
        else:
            print(f"❌ {exc}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()

    provenance = (
        AgentProvenance.agent(agent_id) if agent_id is not None
        else AgentProvenance.human()
    )

    esc_id = compute_escalation_id(pattern_id, reason)
    rec = EscalationRecord(
        escalation_id=esc_id,
        pattern_id=pattern_id,
        reason=reason,
        escalated_at=datetime.datetime.now(datetime.timezone.utc),
        escalated_by=provenance,
    )
    newly_created = record_escalation(root, rec)
    already_existed = not newly_created

    if newly_created:
        append_audit(
            root,
            AuditEventType.ESCALATION_RECORDED,
            provenance,
            pattern_id=pattern_id,
            metadata={"escalation_id": esc_id},
        )

    if json_out:
        print(json.dumps(_HarmonyEscalateJson(
            **make_envelope(elapsed),
            escalation_id=esc_id,
            pattern_id=pattern_id,
            already_existed=already_existed,
        )))
        return

    if already_existed:
        print(f"  ℹ escalation {esc_id}  already open for pattern {pattern_id}")
    else:
        print(f"  ⚠️ escalated pattern {pattern_id}  (esc={esc_id})")

# ---------------------------------------------------------------------------
# escalations
# ---------------------------------------------------------------------------

def run_escalations(args: argparse.Namespace) -> None:
    """List conflict pattern escalations.

    The operator dashboard: lists all open (or resolved, or all) escalations.

    JSON schema::

        {"total": <int>, "escalations": [{...}, ...]}

    Exit codes:
        0 — list returned (may be empty)
        2 — not inside a Muse repository
    """
    elapsed = start_timer()
    status_filter: str | None = args.status
    json_out: bool = args.json_out

    root = require_repo()
    records = list_escalations(root, status=status_filter)
    entries = [_escalation_to_entry(r) for r in records]

    if json_out:
        print(json.dumps(_HarmonyEscalationsJson(
            **make_envelope(elapsed),
            total=len(entries),
            escalations=entries,
        )))
        return

    if not entries:
        label = f" ({status_filter})" if status_filter else ""
        print(f"No harmony escalations{label}.")
        return

    print(f"{'escalation_id':14}  {'status':8}  {'pattern_id':14}  reason")
    print("─" * 76)
    for e in entries:
        eid_short = short_id(e["escalation_id"])
        pid_short = short_id(e["pattern_id"])
        print(
            f"  {eid_short}  {e['status']:8}  {pid_short}  "
            f"{e['reason'][:40]}"
        )

# ---------------------------------------------------------------------------
# resolve-escalation
# ---------------------------------------------------------------------------

def run_resolve_escalation(args: argparse.Namespace) -> None:
    """Close an escalation after a conflict is manually resolved.

    JSON schema::

        {"escalation_id": "<hex64>", "resolved": <bool>}

    Exit codes:
        0 — result returned (resolved may be false if escalation not found)
        1 — invalid escalation_id or resolution_id
        2 — not inside a Muse repository
    """
    elapsed = start_timer()

    escalation_id: str = args.escalation_id
    resolution_id: str = args.resolution_id
    agent_id: str | None = args.agent_id
    json_out: bool = args.json_out

    for label, value in (("escalation_id", escalation_id), ("resolution_id", resolution_id)):
        try:
            _validate_id(value, label)
        except ValueError as exc:
            if json_out:
                print(json.dumps({"error": str(exc)}))
            else:
                print(f"❌ {exc}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()

    provenance = (
        AgentProvenance.agent(agent_id) if agent_id is not None
        else AgentProvenance.human()
    )
    now = datetime.datetime.now(datetime.timezone.utc)
    resolved = resolve_escalation(root, escalation_id, resolution_id, provenance, now)

    if resolved:
        append_audit(
            root,
            AuditEventType.ESCALATION_RESOLVED,
            provenance,
            metadata={
                "escalation_id": escalation_id,
                "resolution_id": resolution_id,
            },
        )

    if json_out:
        print(json.dumps(_HarmonyResolveEscalationJson(
            **make_envelope(elapsed),
            escalation_id=escalation_id,
            resolved=resolved,
        )))
        return

    if resolved:
        print(f"  ✅ resolved escalation {escalation_id}")
    else:
        print(f"  ℹ escalation {escalation_id} not found.")
