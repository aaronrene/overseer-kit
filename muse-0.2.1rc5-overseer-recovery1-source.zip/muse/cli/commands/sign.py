"""muse sign — MSign request signing for humans, agents, and scripts.

Makes MSign a first-class tool rather than a library implementation detail.
Every authenticated call to MuseHub, Stori, Maestro, or MPay nodes can be
signed, verified, and debugged without implementing the protocol by hand.

Subcommands
-----------

::

    muse sign header   --method POST --path /owner/repo/push --hub URL
    muse sign verify   --header 'MSign ...' --method POST --url URL [--body-file F]
    muse sign request  --method POST --url URL [--body-file F | --body STR]
    muse sign curl     --method POST --url URL [--body-file F | --body STR]
    muse sign payment  --from HANDLE --to HANDLE --amount N --nonce HEX

Identity resolution (for ``header``, ``request``, ``curl``, ``payment``)
--------------------------------------------------------------------------

1. ``MUSE_AGENT_KEY_FD`` env var — file descriptor carrying 64-byte sub-seed
   (the only supported env-based injection; secret travels through kernel
   pipe buffer, never visible in ``/proc/<pid>/environ``).
2. ``--agent-id ID`` → ``~/.muse/identity.toml`` agent entry.
3. ``~/.muse/identity.toml`` human entry keyed by hub hostname.
4. Hub URL from ``.muse/config.toml`` in the current repository.

JSON schemas
-----------

``muse sign header --json``::

    {
      "handle":        "<hub handle>",
      "hub":           "<hub url>",
      "method":        "<HTTP verb>",
      "path":          "<URL path+query>",
      "timestamp":     <unix int>,
      "body_sha256":   "sha256:<hex>",
      "signature_b64": "<base64url>",
      "header_value":  "MSign handle=... ts=... sig=...",
      "algorithm":     "ed25519",
      "fingerprint":   "<sha256hex of public key>",
      "duration_ms":    0.3,
      "exit_code":     0
    }

``muse sign verify --json``::

    {"valid": true|false, "reason": "<ok | why it failed>", "duration_ms": 0.3, "exit_code": 0}

``muse sign request --json``::

    {
      "ok": true|false,
      "header_value": "MSign ...", "response": <decoded body>,
      "duration_ms": 12.1, "exit_code": 0
    }

``muse sign payment --json``::

    {
      "from_handle": "...", "to_handle": "...", "amount_nano": N,
      "currency": "...", "nonce_hex": "...", "memo": "...",
      "ts": <unix>, "signature_b64": "...", "canonical_message": "...",
      "duration_ms": 0.5, "exit_code": 0
    }

Security
--------

- ``sign request`` refuses non-HTTPS URLs when credentials are present
  (same gate as :class:`~muse.core.transport.HttpTransport`).
- ``--timestamp`` override is for **testing only** — any production caller
  omitting it gets ``int(time.time())`` at signing time.
- The private key is never logged or printed.
"""

import argparse
import json
import pathlib
import sys
import time
from datetime import datetime, timezone
from muse.core.types import DEFAULT_SIGN_ALGO, b64url_encode, blob_id, encode_pubkey, encode_sig, public_key_fingerprint
from muse.core.envelope import EnvelopeJson, JsonValue, make_envelope
from muse.core.timing import start_timer
from typing import TYPE_CHECKING, TypedDict

if TYPE_CHECKING:
    from muse.core.transport import SigningIdentity

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _load_signing(
    hub: str | None,
    agent_id: str | None = None,
) -> "SigningIdentity":
    """Resolve a signing identity or exit with a clear error."""
    from muse.cli.config import get_signing_identity
    signing = get_signing_identity(remote_url=hub, agent_id=agent_id)
    if signing is None:
        hub_hint = hub or "the configured hub"
        print(
            f"❌ No signing identity found for {hub_hint}.\n"
            "   Run: muse auth keygen && muse auth register",
            file=sys.stderr,
        )
        raise SystemExit(1)
    return signing

def _read_body(args: argparse.Namespace) -> bytes:
    """Read body bytes from --body-file or --body flag."""
    body_file: str | None = getattr(args, "body_file", None)
    body_str: str | None = getattr(args, "body", None)

    if body_file:
        if body_file == "-":
            return sys.stdin.buffer.read()
        return pathlib.Path(body_file).read_bytes()
    if body_str:
        return body_str.encode()
    return b""

def _public_key_info(signing: "SigningIdentity") -> tuple[str, str]:
    """Return (public_key_b64, fingerprint) for a signing identity."""
    pub_raw = signing.private_key.public_key().public_bytes_raw()
    pub_b64 = b64url_encode(pub_raw)
    fingerprint = public_key_fingerprint(pub_raw)
    return pub_b64, fingerprint

# ---------------------------------------------------------------------------
# JSON wire format
# ---------------------------------------------------------------------------

class _SignHeaderJson(EnvelopeJson):
    """JSON envelope for ``muse sign header --json``."""

    handle: str
    hub: str
    method: str
    path: str
    signing_ts: int
    body_sha256: str
    signature_b64: str
    header_value: str
    algorithm: str
    fingerprint: str

class _SignVerifyJson(EnvelopeJson):
    """JSON envelope for ``muse sign verify --json``."""

    valid: bool
    reason: str

class _SignRequestJson(EnvelopeJson, total=False):
    """JSON envelope for ``muse sign request --json``."""

    ok: bool
    header_value: str
    response: JsonValue

class _SignPaymentJson(EnvelopeJson, total=False):
    """JSON envelope for ``muse sign payment --json``."""

    from_handle: str
    to_handle: str
    amount_nano: int
    currency: str
    nonce_hex: str
    memo: str
    ts: int
    signature_b64: str
    canonical_message: str

# ---------------------------------------------------------------------------
# Subcommand: header
# ---------------------------------------------------------------------------

def run_header(args: argparse.Namespace) -> None:
    """Emit an ``Authorization: MSign …`` header value.

    Computes the MSign Authorization header for a request and prints it to
    stdout.  With ``--json`` emits structured metadata useful for debugging
    or pipeline consumption.

    Agent quickstart::

        muse sign header --method POST --path /gabriel/muse/push --hub https://staging.musehub.ai --json
        muse sign header --method GET --url https://staging.musehub.ai/gabriel/muse/repo --json

    JSON fields::

        handle          str     Hub handle of the signing identity
        hub             str     Hub URL the key is registered with
        method          str     HTTP verb (uppercased)
        path            str     URL path + query string
        timestamp       int     Unix timestamp embedded in the signature
        body_sha256     str     ``sha256:``-prefixed SHA-256 of the request body
        signature_b64   str     URL-safe base64 Ed25519 signature
        header_value    str     Full "MSign handle=... ts=... sig=..." value
        algorithm       str     Always "ed25519"
        fingerprint     str     Hex SHA-256 of the signing public key

    Exit codes::

        0  Success.
        1  No signing identity found.
    """
    from muse.core.msign import build_msign_header
    import urllib.parse

    elapsed = start_timer()

    signing = _load_signing(
        getattr(args, "hub", None),
        getattr(args, "agent_id", None),
    )
    body = _read_body(args)
    method = args.method.upper()
    ts: int | None = getattr(args, "timestamp", None)

    # Resolve path vs full URL.
    path: str = getattr(args, "path", None) or ""
    hub: str = getattr(args, "hub", None) or ""
    if path and hub:
        url = f"{hub.rstrip('/')}/{path.lstrip('/')}"
    elif path:
        url = f"http://localhost{'' if path.startswith('/') else '/'}{path}"
    else:
        url = args.url if hasattr(args, "url") else ""

    header_value = build_msign_header(signing, method, url, body, ts=ts)

    if getattr(args, "json_out", False):
        import urllib.parse as _up
        parsed = _up.urlparse(url)
        path_with_query = parsed.path + (f"?{parsed.query}" if parsed.query else "")
        _ts = int(header_value.split("ts=")[1].split(" ")[0])
        body_sha256 = blob_id(body)
        _, fingerprint = _public_key_info(signing)
        sig_b64 = header_value.split('sig="')[1].rstrip('"')
        print(json.dumps(_SignHeaderJson(
            **make_envelope(elapsed),
            handle=signing.handle,
            hub=hub or f"{parsed.scheme}://{parsed.netloc}",
            method=method,
            path=path_with_query,
            signing_ts=_ts,
            body_sha256=body_sha256,
            signature_b64=sig_b64,
            header_value=header_value,
            algorithm=DEFAULT_SIGN_ALGO,
            fingerprint=fingerprint,
        )))
    else:
        print(header_value)

# ---------------------------------------------------------------------------
# Subcommand: verify
# ---------------------------------------------------------------------------

def run_verify(args: argparse.Namespace) -> None:
    """Verify an MSign Authorization header value.

    Checks the signature, timestamp freshness, and canonical message against
    the supplied public key.  Exits 0 if valid, 1 if not.

    Agent quickstart::

        muse sign verify --header 'MSign handle=...' --method POST --url URL --public-key-b64 KEY --json

    JSON fields::

        valid   bool    True if the signature is valid and within max_age
        reason  str     "ok" on success, or a description of the failure

    Exit codes::

        0  Valid signature.
        1  Invalid signature, expired timestamp, or key mismatch.
    """
    from muse.core.msign import verify_msign_header

    elapsed = start_timer()

    body = _read_body(args)
    method = args.method.upper()
    url: str = args.url
    pub_b64: str = args.public_key_b64
    header_value: str = args.header
    max_age: int = getattr(args, "max_age", 30)

    ok, reason = verify_msign_header(
        header_value, method, url, body, pub_b64, max_age=max_age
    )

    exit_code = 0 if ok else 1
    as_json = getattr(args, "json_out", False)
    if as_json:
        print(json.dumps(_SignVerifyJson(
            **make_envelope(elapsed, exit_code=exit_code),
            valid=ok,
            reason=reason,
        )))
    else:
        if ok:
            print("✅ Valid", file=sys.stderr)
        else:
            print(f"❌ Invalid: {reason}", file=sys.stderr)

    if not ok:
        raise SystemExit(exit_code)

# ---------------------------------------------------------------------------
# Subcommand: request
# ---------------------------------------------------------------------------

def run_request(args: argparse.Namespace) -> None:
    """Sign and execute an HTTP request, printing the response.

    Signs the request with MSign and executes it via
    :class:`~muse.core.transport.HttpTransport`.  The response body is
    decoded as JSON or raw text in that order.

    Agent quickstart::

        muse sign request --method POST --url https://staging.musehub.ai/gabriel/muse/repair-object --body-file payload.json --json
        muse sign request --method GET --url https://staging.musehub.ai/gabriel/muse/repo --json

    JSON fields::

        ok              bool    True when the request completed
        header_value    str     The MSign Authorization header that was sent
        response        any     Decoded response body (JSON object, list, or string)

    Exit codes::

        0  Request completed (check response for API-level errors).
        1  No signing identity found.
        2  Network or transport error.
    """
    from muse.core.msign import build_msign_header
    from muse.core.transport import HttpTransport, TransportError

    elapsed = start_timer()

    hub: str | None = getattr(args, "hub", None)
    url: str = args.url
    method: str = args.method.upper()
    content_type: str = getattr(args, "content_type", "application/json")
    as_json = getattr(args, "json_out", False)
    ts: int | None = getattr(args, "timestamp", None)

    signing = _load_signing(
        hub or url,
        getattr(args, "agent_id", None),
    )
    body = _read_body(args)
    header_value = build_msign_header(signing, method, url, body, ts=ts)

    transport = HttpTransport()
    req = transport._build_request(method, url, signing, body or None, content_type)

    try:
        raw = transport._execute(req)
    except TransportError as exc:
        print(f"❌ Request failed: {exc}", file=sys.stderr)
        raise SystemExit(2)

    # Decode response: JSON first, then raw text.
    response_data = None
    try:
        response_data = json.loads(raw)
    except Exception:
        response_data = raw.decode(errors="replace")

    if as_json:
        print(json.dumps(_SignRequestJson(
            **make_envelope(elapsed),
            ok=True,
            header_value=header_value,
            response=response_data,
        ), default=str))
    else:
        if isinstance(response_data, (dict, list)):
            print(json.dumps(response_data, default=str))
        else:
            print(response_data)

# ---------------------------------------------------------------------------
# Subcommand: curl
# ---------------------------------------------------------------------------

def run_curl(args: argparse.Namespace) -> None:
    """Print a signed curl command ready to copy-paste or pipe to bash.

    Emits a multi-line curl invocation with the ``Authorization: MSign ...``
    header pre-computed.  Suitable for direct execution via ``| bash`` or
    inclusion in deployment scripts.

    Agent quickstart::

        muse sign curl --method POST --url https://staging.musehub.ai/gabriel/muse/repair-object --body-file payload.json
        muse sign curl --method GET --url https://staging.musehub.ai/gabriel/muse/repo | bash

    JSON fields::

        (no --json output; curl command is always emitted as plain text)

    Exit codes::

        0  Success.
        1  No signing identity found.
    """
    from muse.core.msign import build_msign_header

    hub: str | None = getattr(args, "hub", None)
    url: str = args.url
    method: str = args.method.upper()
    content_type: str = getattr(args, "content_type", "application/json")
    body_file: str | None = getattr(args, "body_file", None)
    body_str: str | None = getattr(args, "body", None)
    ts: int | None = getattr(args, "timestamp", None)

    signing = _load_signing(
        hub or url,
        getattr(args, "agent_id", None),
    )
    body = _read_body(args)
    header_value = build_msign_header(signing, method, url, body, ts=ts)

    lines = [f"curl -X {method}"]
    lines.append(f"  -H 'Authorization: {header_value}'")
    if body:
        lines.append(f"  -H 'Content-Type: {content_type}'")
    if body_file and body_file != "-":
        lines.append(f"  --data-binary @{body_file}")
    elif body_str:
        safe = body_str.replace("'", "'\\''")
        lines.append(f"  --data '{safe}'")
    elif body and not body_file:
        lines.append(f"  --data-binary -")
    lines.append(f"  {url}")

    print(" \\\n".join(lines))

# ---------------------------------------------------------------------------
# Subcommand: payment
# ---------------------------------------------------------------------------

def run_payment(args: argparse.Namespace) -> None:
    """Sign an MPay micropayment claim.

    Produces a signed micropayment claim for the MPay streaming protocol.
    The canonical message is Ed25519-signed, and the nonce can be chained
    to the previous signature to form a tamper-evident payment chain.

    Agent quickstart::

        muse sign payment --from alice --to bob --amount 1000000 --nonce HEXNONCE --json
        muse sign payment --from alice --to bob --amount 500 --nonce HEXNONCE --memo "stem:sha256:abc" --json

    JSON fields::

        from_handle         str     Sender hub handle
        to_handle           str     Recipient hub handle
        amount_nano         int     Amount in nanoMUSE
        currency            str     Currency identifier (default: nanoMUSE)
        nonce_hex           str     64-char hex nonce
        memo                str     Free-form memo
        ts                  int     Unix timestamp
        signature_b64       str     URL-safe base64 Ed25519 signature
        canonical_message   str     The signed canonical message string

    Exit codes::

        0  Success.
        1  No signing identity found.
    """
    from muse.core.msign import build_payment_claim

    elapsed = start_timer()

    hub: str | None = getattr(args, "hub", None)
    as_json = getattr(args, "json_out", False)
    ts: int | None = getattr(args, "timestamp", None)

    signing = _load_signing(
        hub,
        getattr(args, "agent_id", None),
    )

    claim = build_payment_claim(
        signing,
        from_handle=args.from_handle,
        to_handle=args.to_handle,
        amount_nano=args.amount,
        currency=getattr(args, "currency", "nanoMUSE"),
        nonce_hex=args.nonce,
        memo=getattr(args, "memo", ""),
        ts=ts,
    )

    if as_json:
        print(json.dumps(_SignPaymentJson(
            **make_envelope(elapsed),
            **claim,
        )))
    else:
        print(f"From:      {claim['from_handle']}", file=sys.stderr)
        print(f"To:        {claim['to_handle']}", file=sys.stderr)
        print(f"Amount:    {claim['amount_nano']} {claim['currency']}", file=sys.stderr)
        print(f"Nonce:     {claim['nonce_hex']}", file=sys.stderr)
        print(f"Timestamp: {claim['ts']}", file=sys.stderr)
        print(f"Signature: {claim['signature_b64']}", file=sys.stderr)

# ---------------------------------------------------------------------------
# Subcommand: propose
# ---------------------------------------------------------------------------

def canonical_propose_message(
    *,
    repo_id: str,
    from_branch: str,
    to_branch: str,
    author: str,
    created_at: datetime,
    proposal_id: str | None = None,
) -> bytes:
    """Return the canonical UTF-8 bytes that a proposer signs over.

    Used by ``muse sign propose`` and by the MuseHub server to verify.
    The format is intentionally minimal and line-oriented so it is trivial
    to reconstruct in any language.

    Canonical PROPOSE message (UTF-8, LF line endings)::

        PROPOSE
        [proposal_id: sha256:<hex>]   ← only when proposal_id is given
        repo_id: sha256:<hex>
        from_branch: <name>
        to_branch: <name>
        author: <handle>
        created_at: <ISO-8601 UTC with offset>
    """
    lines = ["PROPOSE"]
    if proposal_id is not None:
        lines.append(f"proposal_id: {proposal_id}")
    lines += [
        f"repo_id: {repo_id}",
        f"from_branch: {from_branch}",
        f"to_branch: {to_branch}",
        f"author: {author}",
        f"created_at: {created_at.isoformat()}",
    ]
    return "\n".join(lines).encode("utf-8")


class _SignProposeJson(EnvelopeJson):
    """JSON envelope for ``muse sign propose --json``."""

    handle: str
    hub: str
    repo_id: str
    from_branch: str
    to_branch: str
    author: str
    proposer_timestamp: str
    proposer_public_key: str
    proposer_signature: str
    canonical_message: str


def run_propose(args: argparse.Namespace) -> None:
    """Sign a canonical PROPOSE message ready for ``muse hub proposal create``.

    Loads the signing identity for the target hub, builds the canonical
    PROPOSE pre-image, signs it with Ed25519, and emits the three fields
    needed by the MuseHub API:  ``proposerPublicKey``,
    ``proposerSignature``, and ``proposerTimestamp``.

    Agent quickstart::

        muse sign propose \\
          --repo-id sha256:<hex> \\
          --from-branch feat/my-thing \\
          --to-branch dev \\
          --hub https://localhost:1337 --json

    JSON fields::

        handle              str     Hub handle of the signing identity
        hub                 str     Hub URL
        repo_id             str     sha256-prefixed repo ID
        from_branch         str     Source branch name
        to_branch           str     Target branch name
        author              str     Proposer's hub handle (same as handle)
        proposer_timestamp  str     ISO-8601 UTC timestamp embedded in the message
        proposer_public_key str     ``ed25519:<base64url>`` public key
        proposer_signature  str     ``ed25519:<base64url>`` signature
        canonical_message   str     The exact message bytes that were signed

    Exit codes::

        0  Success.
        1  No signing identity found.
    """
    elapsed = start_timer()

    hub: str | None = getattr(args, "hub", None)
    signing = _load_signing(hub, getattr(args, "agent_id", None))

    repo_id: str = args.repo_id
    from_branch: str = args.from_branch
    to_branch: str = args.to_branch
    author: str = signing.handle

    # Use a caller-supplied timestamp if provided (for testing), otherwise now.
    ts_override: int | None = getattr(args, "timestamp", None)
    if ts_override is not None:
        created_at = datetime.fromtimestamp(ts_override, tz=timezone.utc)
    else:
        created_at = datetime.now(tz=timezone.utc)
    proposer_timestamp = created_at.isoformat()

    message = canonical_propose_message(
        repo_id=repo_id,
        from_branch=from_branch,
        to_branch=to_branch,
        author=author,
        created_at=created_at,
    )

    # Sign
    sig_bytes = signing.private_key.sign(message)
    pub_bytes = signing.private_key.public_key().public_bytes_raw()
    proposer_signature = encode_sig("ed25519", sig_bytes)
    proposer_public_key = encode_pubkey("ed25519", pub_bytes)

    as_json = getattr(args, "json_out", False)
    if as_json:
        print(json.dumps(_SignProposeJson(
            **make_envelope(elapsed),
            handle=signing.handle,
            hub=hub or "",
            repo_id=repo_id,
            from_branch=from_branch,
            to_branch=to_branch,
            author=author,
            proposer_timestamp=proposer_timestamp,
            proposer_public_key=proposer_public_key,
            proposer_signature=proposer_signature,
            canonical_message=message.decode("utf-8"),
        )))
    else:
        print(f"PROPOSER:          @{author}", file=sys.stderr)
        print(f"repo_id:           {repo_id}", file=sys.stderr)
        print(f"from_branch:       {from_branch}", file=sys.stderr)
        print(f"to_branch:         {to_branch}", file=sys.stderr)
        print(f"proposer_timestamp: {proposer_timestamp}", file=sys.stderr)
        print(f"proposer_public_key: {proposer_public_key}", file=sys.stderr)
        print(f"proposer_signature:  {proposer_signature}", file=sys.stderr)


# ---------------------------------------------------------------------------
# argparse registration
# ---------------------------------------------------------------------------

def _add_common_flags(p: argparse.ArgumentParser) -> None:
    """Add identity + output flags shared by most subcommands."""
    p.add_argument(
        "--hub",
        metavar="URL",
        help="Hub URL (determines which key to use, e.g. https://staging.musehub.ai).",
    )
    p.add_argument(
        "--agent-id",
        metavar="ID",
        dest="agent_id",
        help="Sign as a specific agent identity from identity.toml.",
    )
    p.add_argument(
        "--timestamp",
        metavar="N",
        type=int,
        default=None,
        help="Override Unix timestamp (testing only — omit in production).",
    )
    p.add_argument("--json", "-j", action="store_true", dest="json_out", help="Machine-readable JSON output.")

def _add_body_flags(p: argparse.ArgumentParser) -> None:
    """Add --body and --body-file flags."""
    grp = p.add_mutually_exclusive_group()
    grp.add_argument(
        "--body-file",
        metavar="FILE",
        dest="body_file",
        help="Read request body from FILE (use '-' for stdin).",
    )
    grp.add_argument(
        "--body",
        metavar="STRING",
        help="Inline request body string (UTF-8 encoded).",
    )

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register ``muse sign`` and its subcommands."""
    p = subparsers.add_parser(
        "sign",
        help="MSign request signing — produce, verify, and execute signed requests.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = p.add_subparsers(dest="sign_cmd", metavar="SUBCOMMAND")
    sub.required = True

    # ── header ────────────────────────────────────────────────────────────────
    ph = sub.add_parser(
        "header",
        help="Emit an Authorization: MSign … header value.",
        description=(
            "Compute and print the MSign Authorization header for a request.\n\n"
            "Shell use:\n"
            "  AUTH=$(muse sign header --method POST --path /owner/repo/push --hub URL)\n"
            "  curl -X POST -H \"Authorization: $AUTH\" URL --data-binary @mpack.bin"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ph.set_defaults(func=run_header)
    ph.add_argument("--method", default="POST", metavar="VERB", help="HTTP method (default: POST).")
    grp = ph.add_mutually_exclusive_group(required=True)
    grp.add_argument("--path", metavar="PATH", help="URL path (e.g. /gabriel/muse/push). Combined with --hub.")
    grp.add_argument("--url", metavar="URL", help="Full URL (alternative to --path + --hub).")
    _add_body_flags(ph)
    _add_common_flags(ph)

    # ── verify ────────────────────────────────────────────────────────────────
    pv = sub.add_parser(
        "verify",
        help="Verify an MSign Authorization header.",
        description=(
            "Exit 0 if the header is valid, exit 1 if not.\n"
            "Useful in test harnesses and pre-receive hooks."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    pv.set_defaults(func=run_verify)
    pv.add_argument("--header", required=True, metavar="VALUE",
                    help="Full Authorization header value to verify.")
    pv.add_argument("--method", required=True, metavar="VERB", help="HTTP method.")
    pv.add_argument("--url", required=True, metavar="URL", help="Full request URL.")
    pv.add_argument("--public-key-b64", required=True, dest="public_key_b64",
                    metavar="B64", help="URL-safe base64 Ed25519 public key (no padding).")
    pv.add_argument("--max-age", type=int, default=30, dest="max_age",
                    metavar="SECS", help="Replay window in seconds (default: 30).")
    _add_body_flags(pv)
    pv.add_argument("--json", "-j", action="store_true", dest="json_out", help="JSON output.")

    # ── request ───────────────────────────────────────────────────────────────
    pr = sub.add_parser(
        "request",
        help="Sign and execute an authenticated HTTP request.",
        description=(
            "Sign a request with MSign and execute it, printing the response.\n\n"
            "Example:\n"
            "  muse sign request --method POST \\\\\n"
            "    --url https://staging.musehub.ai/gabriel/muse/repair-object \\\\\n"
            "    --body-file payload.json --json"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    pr.set_defaults(func=run_request)
    pr.add_argument("--method", default="POST", metavar="VERB", help="HTTP method (default: POST).")
    pr.add_argument("--url", required=True, metavar="URL", help="Full request URL.")
    pr.add_argument(
        "--content-type",
        default="application/json",
        dest="content_type",
        metavar="TYPE",
        help="Content-Type header (default: application/json).",
    )
    _add_body_flags(pr)
    _add_common_flags(pr)

    # ── curl ──────────────────────────────────────────────────────────────────
    pc = sub.add_parser(
        "curl",
        help="Print a signed curl command (copy-paste or pipe to bash).",
        description=(
            "Emit a ready-to-run curl command with the MSign Authorization header.\n\n"
            "Example:\n"
            "  muse sign curl --method POST \\\\\n"
            "    --url https://staging.musehub.ai/gabriel/muse/repair-object \\\\\n"
            "    --body-file payload.json | bash"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    pc.set_defaults(func=run_curl)
    pc.add_argument("--method", default="POST", metavar="VERB", help="HTTP method.")
    pc.add_argument("--url", required=True, metavar="URL", help="Full request URL.")
    pc.add_argument(
        "--content-type",
        default="application/json",
        dest="content_type",
        metavar="TYPE",
        help="Content-Type header (default: application/json).",
    )
    _add_body_flags(pc)
    _add_common_flags(pc)

    # ── payment ───────────────────────────────────────────────────────────────
    pp = sub.add_parser(
        "payment",
        help="Sign an MPay micropayment claim.",
        description=(
            "Sign a micropayment claim for the MPay streaming protocol.\n\n"
            "Canonical message: MPAY\\nFROM\\nTO\\nAMOUNT_NANO\\nCURRENCY\\nNONCE_HEX\\nMEMO\\nTS\n\n"
            "Chain linkage: set --nonce to sha256(prev_signature_b64) to create\n"
            "a tamper-evident chain settleable on Avalanche L1."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    pp.set_defaults(func=run_payment)
    pp.add_argument("--from", dest="from_handle", required=True, metavar="HANDLE",
                    help="Sender's hub handle.")
    pp.add_argument("--to", dest="to_handle", required=True, metavar="HANDLE",
                    help="Recipient's hub handle.")
    pp.add_argument("--amount", required=True, type=int, metavar="N",
                    help="Amount in nanoMUSE (1 MUSE = 1_000_000_000 nanoMUSE).")
    pp.add_argument("--nonce", required=True, metavar="HEX",
                    help="64-char hex nonce. Use sha256(prev_sig_b64) for chain linkage.")
    pp.add_argument("--currency", default="nanoMUSE", metavar="CURRENCY",
                    help="Currency identifier (default: nanoMUSE).")
    pp.add_argument("--memo", default="", metavar="TEXT",
                    help="Free-form memo (e.g. 'stem:sha256:abc123').")
    _add_common_flags(pp)

    # ── propose ───────────────────────────────────────────────────────────────
    ppr = sub.add_parser(
        "propose",
        help="Sign a canonical PROPOSE message for a merge proposal.",
        description=(
            "Sign a PROPOSE message with Ed25519 and emit the three fields\n"
            "needed by the MuseHub API: proposerPublicKey, proposerSignature,\n"
            "and proposerTimestamp.\n\n"
            "Example:\n"
            "  muse sign propose \\\\\n"
            "    --repo-id sha256:<hex> \\\\\n"
            "    --from-branch feat/my-thing \\\\\n"
            "    --to-branch dev \\\\\n"
            "    --hub https://localhost:1337 --json"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ppr.set_defaults(func=run_propose)
    ppr.add_argument("--repo-id", required=True, dest="repo_id", metavar="REPO_ID",
                     help="sha256-prefixed repository ID.")
    ppr.add_argument("--from-branch", required=True, dest="from_branch", metavar="BRANCH",
                     help="Source branch name.")
    ppr.add_argument("--to-branch", required=True, dest="to_branch", metavar="BRANCH",
                     help="Target branch name.")
    _add_common_flags(ppr)
