"""``muse blame`` (core VCS) — line-level attribution for any text file.

Shows which commit last modified each line of a tracked text file — the
universal, domain-agnostic counterpart to ``muse code blame`` (symbol-level)
and ``muse midi note-blame`` (bar-level).

Usage::

    muse blame README.md
    muse blame --ref v1.0.0 docs/design.md
    muse blame --json state/config.toml          # machine-readable output
    muse blame --range 10-20 src/main.py         # restrict to lines 10-20
    muse blame --author gabriel src/main.py      # filter by author

Output format (default)::

    <sha12>  (<author>  <date>)   1  line content here

The ``--json`` / ``-j`` flag emits a single JSON object for pipeline use.

Domain-specific blame (symbols, notes) lives under ``muse code`` and
``muse midi`` respectively.
"""

import argparse
import json
import logging
import pathlib
import re
import sys
from typing import TypedDict

from muse.core.types import split_id
from muse.core.paths import ref_path as _ref_path
from muse.core.blame import blame_file
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.refs import read_ref
from muse.core.repo import require_repo
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import resolve_commit_ref
from muse.core.timing import start_timer
from muse.core.validation import clamp_int, sanitize_display

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# TypedDicts — JSON output schema
# ---------------------------------------------------------------------------

_RANGE_RE = re.compile(r"^(\d+)-(\d+)$")

class _BlameLineJson(TypedDict):
    lineno: int
    commit_id: str
    short_id: str
    author: str
    committed_at: str
    message: str
    content: str

class _BlameJson(EnvelopeJson):
    file: str
    ref: str
    line_count: int
    lines: list[_BlameLineJson]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _read_branch(root: pathlib.Path) -> str:
    return read_current_branch(root)

def _parse_range(raw: str) -> tuple[int, int]:
    """Parse 'START-END' into a (start, end) tuple (1-based, inclusive).

    Raises ``ValueError`` with a user-facing message on bad input.
    """
    m = _RANGE_RE.match(raw)
    if not m:
        raise ValueError(f"Invalid range '{sanitize_display(raw)}' — expected START-END (e.g. 1-10).")
    start, end = int(m.group(1)), int(m.group(2))
    if start < 1:
        raise ValueError(f"Range start must be ≥ 1, got {start}.")
    if start > end:
        raise ValueError(f"Range start ({start}) must be ≤ end ({end}).")
    return start, end

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the blame subcommand."""
    parser = subparsers.add_parser(
        "blame",
        help="Show which commit last modified each line of a text file.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "file",
        help="Workspace-relative path to the file to blame.",
    )
    parser.add_argument(
        "--ref", default=None,
        help="Commit ref (SHA, branch, tag) to blame at (default: HEAD).",
    )
    parser.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit a single JSON object (machine-readable).",
    )
    parser.add_argument(
        "--range", default=None, dest="range_",
        metavar="START-END",
        help="Restrict output to a 1-based inclusive line range (e.g. 10-20).",
    )
    parser.add_argument(
        "--author", default=None,
        help="Filter lines whose attributed author contains PATTERN (case-insensitive).",
    )
    parser.add_argument(
        "--short", type=int, default=12, metavar="N",
        help="Number of hex characters to show for each commit SHA (default: 12).",
    )
    parser.set_defaults(func=run)

# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Show which commit last modified each line of a text file.

    Walks the commit history of the file and annotates each line with the
    commit that last changed it.  Use ``--range START-END`` to narrow to a
    line range; ``--author`` to filter to commits by a specific author.

    Agent quickstart
    ----------------
    ::

        muse core-blame src/billing.py --json
        muse core-blame src/billing.py --range 10-50 --json
        muse core-blame src/billing.py --ref HEAD~10 --json

    JSON fields
    -----------
    file       Workspace-relative path blamed.
    ref        Commit ref used as the starting point.
    line_count Number of lines in the output.
    lines      List of line objects: ``lineno``, ``commit_id``, ``short_id``,
               ``author``, ``committed_at``, ``message``, ``content``.

    Exit codes
    ----------
    0  Blame complete.
    1  File not tracked, ref not found, or invalid arguments.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    file_arg: str = args.file
    ref: str | None = args.ref
    json_out: bool = args.json_out
    range_raw: str | None = args.range_
    author_pattern: str | None = args.author
    short: int = clamp_int(args.short, 1, 1000, "short")

    # --- Validate path for null bytes ----------------------------------------
    if "\x00" in file_arg:
        print("❌ File path contains null bytes.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    # --- Parse --range --------------------------------------------------------
    range_filter: tuple[int, int] | None = None
    if range_raw is not None:
        try:
            range_filter = _parse_range(range_raw)
        except ValueError as exc:
            print(f"❌ {exc}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()
    branch = _read_branch(root)

    # --- Resolve ref ----------------------------------------------------------
    if ref is None:
        commit_id = get_head_commit_id(root, branch)
        if not commit_id:
            print("❌ No commits yet on this branch.", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
    else:
        # Try branch name first (refs/heads/<ref>), then SHA prefix scan.
        branch_ref_path = _ref_path(root, ref)
        commit_id = read_ref(branch_ref_path)
        if commit_id is None:
            commit = resolve_commit_ref(root, branch, ref)
            if commit is None:
                print(f"❌ Ref '{sanitize_display(ref)}' not found.", file=sys.stderr)
                raise SystemExit(ExitCode.USER_ERROR)
            commit_id = commit.commit_id

    # --- Blame ----------------------------------------------------------------
    lines = blame_file(root, file_arg, commit_id)
    if lines is None:
        print(f"❌ File '{sanitize_display(file_arg)}' not found at {commit_id[:len('sha256:') + short]}.",
              file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    # --- Apply filters --------------------------------------------------------
    if range_filter is not None:
        start, end = range_filter
        lines = [bl for bl in lines if start <= bl.lineno <= end]

    if author_pattern is not None:
        pat_lower = author_pattern.lower()
        lines = [bl for bl in lines if pat_lower in bl.author.lower()]

    # --- Output ---------------------------------------------------------------
    if json_out:
        line_dicts: list[_BlameLineJson] = []
        for bl in lines:
            _algo, _hex = split_id(bl.commit_id)
            line_dicts.append(_BlameLineJson(
                lineno=bl.lineno,
                commit_id=sanitize_display(bl.commit_id),
                short_id=f"{_algo}:{_hex[:short]}",
                author=sanitize_display(bl.author),
                committed_at=sanitize_display(bl.committed_at),
                message=sanitize_display(bl.message.splitlines()[0] if bl.message else ""),
                content=sanitize_display(bl.content.rstrip("\n")),
            ))
        print(json.dumps(_BlameJson(
            **make_envelope(elapsed),
            file=file_arg,
            ref=commit_id,
            line_count=len(line_dicts),
            lines=line_dicts,
        )))
        return

    # Human-readable output.
    if not lines:
        return

    author_w = min(20, max((len(bl.author) for bl in lines), default=0))
    date_w = 10
    lineno_w = len(str(lines[-1].lineno if lines else 1))

    for bl in lines:
        _algo, _hex = split_id(bl.commit_id)
        sha = f"{_algo}:{_hex[:short]}"
        author = sanitize_display(bl.author[:author_w].ljust(author_w))
        date = sanitize_display(bl.committed_at[:date_w])
        lineno = str(bl.lineno).rjust(lineno_w)
        content = sanitize_display(bl.content.rstrip("\n"))
        print(f"{sha}  ({author}  {date})  {lineno}  {content}")
