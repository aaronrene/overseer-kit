"""muse init — initialize a new Muse repository.

Creates the ``.muse/`` directory tree in the current working directory.

Layout::

    .muse/
        repo.json           — repo_id, schema_version, domain, created_at
        HEAD                — symbolic ref → refs/heads/main
        refs/heads/main     — empty (no commits yet)
        config.toml         — [user], [hub], [remotes], [domain] stubs
        objects/            — content-addressed objects: blobs, commits, snapshots (SHA-256 sharded)
        tags/               — semantic tags (JSON, one file per tag)
    .museattributes         — TOML merge strategy overrides (working-tree only)
    .museignore             — TOML ignore rules (working-tree only)

The repository root IS the working tree.  There is no ``state/`` subdirectory.
Bare repositories (``--bare``) have no working tree; they store only ``.muse/``
and do not receive ``.museattributes`` or ``.museignore``.

Agent use
---------
Pass ``--json`` to receive a machine-readable result instead of prose::

    muse init --json | jq .repo_id

JSON schema (exit 0) — all keys always present::

    {
      "status":         "ok",    // always "ok" on success
      "error":          "",      // always empty string on success
      "warnings":       [],      // notices (e.g. template symlinks skipped)
      "repo_id":        "...",   // sha256:<hex> genesis fingerprint — stable across reinit with --force
      "branch":         "main",  // initial branch name
      "domain":         "code",  // active domain plugin
      "path":           "/abs",  // absolute path to the .muse directory
      "reinitialized":  false,   // true when --force was used on an existing repo
      "bare":           false,
      "schema_version": 1,       // integer; bumps only on breaking layout changes
      "created_at":     "...",   // ISO 8601 UTC timestamp written to repo.json
      "duration_ms":   0.0,     // wall-clock time for the init operation
      "exit_code":      0
    }

JSON schema (exit non-zero) — error payload::

    {
      "status":    "error",
      "error":     "<human-readable message>",
      "warnings":  [],
      "exit_code": 1
    }
"""

import argparse
import json
import logging
import os
import pathlib
import shutil
import sys
from muse import __version__ as _MUSE_VERSION
from muse.core.types import content_hash, load_json_file, now_utc_iso
from muse.core.paths import muse_dir as _muse_dir, ref_path as _ref_path, init_repo_dirs as _init_repo_dirs, user_identity_toml_path
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.io import write_text_atomic
from muse.core.refs import write_head_branch
from muse.core.timing import start_timer
from muse.core.validation import (
    assert_not_symlink,
    sanitize_display,
    validate_branch_name,
    validate_domain_name,
    validate_repo_id,
)

type _RepoMeta = dict[str, str | int | bool]
type _StrMap = dict[str, str]

# ---------------------------------------------------------------------------
# Default hub environments
# ---------------------------------------------------------------------------

HUB_LOCAL      = "https://localhost:1337"
HUB_STAGING    = "https://staging.musehub.ai"
HUB_PRODUCTION = "https://musehub.ai"

_DEFAULT_REMOTES = {
    "local":      HUB_LOCAL,
    "staging":    HUB_STAGING,
    "production": HUB_PRODUCTION,
}

def resolve_default_handle() -> str | None:
    """Return the authenticated handle from ``~/.muse/identity.toml``, or None.

    Tries the localhost hub first, then staging, then production.  Returns the
    first non-empty handle found, or ``None`` when no identity is configured.
    """
    try:
        import tomllib as _tomllib
    except ImportError:
        return None
    identity_path = user_identity_toml_path()
    if not identity_path.is_file():
        return None
    try:
        with identity_path.open("rb") as fh:
            data = _tomllib.load(fh)
    except Exception:
        return None
    for hub_key in ("localhost:1337", "staging.musehub.ai", "musehub.ai"):
        entry = data.get(hub_key, {})
        handle = entry.get("handle", "")
        if handle:
            return handle
    return None

class _InitJson(EnvelopeJson):
    status: str            # "ok"
    error: str             # "" on success
    repo_id: str
    branch: str
    domain: str
    path: str
    reinitialized: bool
    bare: bool
    schema_version: int
    created_at: str        # ISO 8601 UTC
    remotes: dict[str, str]  # remote_name → url (empty when no handle)

class _InitErrorJson(EnvelopeJson):
    status: str            # "error"
    error: str

logger = logging.getLogger(__name__)

# Bumped only when the on-disk .muse/ layout changes in a breaking way.
# Intentionally separate from the package version (pyproject.toml) so that
# patch releases do not falsely signal a schema migration.
_REPO_SCHEMA_VERSION: int = 1

# Subdirectories created unconditionally at init time.  Must be a superset of
# muse.core.repo._CRITICAL_MUSE_DIRS so that _verify_muse_dir_integrity() is
# satisfied on the very first require_repo() call after init.
# NOTE: "refs" is listed explicitly even though "refs/heads" (with parents=True)
# would create it implicitly — explicit listing ensures it is covered by the
# post-init integrity check loop.
_INIT_SUBDIRS: tuple[str, ...] = (
    "refs",
    "refs/heads",
    "objects",
    "tags",
    "cache",
)

_DEFAULT_CONFIG = """\
[user]
name = ""
email = ""
type = "human"    # "human" | "agent"

[hub]
# url = "https://musehub.ai"
# Run `muse hub connect <url>` to attach this repo to MuseHub.
# Run `muse auth register` to authenticate.
# Credentials are stored in ~/.muse/identity.toml — never here.

[remotes]

[domain]
# Domain-specific configuration. Keys depend on the active domain plugin.
"""

def _build_default_config(handle: str | None, slug: str) -> str:
    """Return the default config.toml content for a new repo.

    When *handle* is known, pre-wires ``local``, ``staging``, and
    ``production`` remotes and sets ``hub.url`` to localhost.  Without a
    handle the section stubs are written but left empty so the user fills
    them in after running ``muse auth register``.
    """
    hub_line = f'url = "{HUB_LOCAL}"'
    if handle:
        remotes_block = "\n".join(
            f'[remotes.{name}]\nurl = "{base}/{handle}/{slug}"\n'
            for name, base in _DEFAULT_REMOTES.items()
        )
    else:
        remotes_block = (
            "[remotes]\n"
            "# Remotes will be wired automatically after `muse auth register`.\n"
        )

    return (
        "[user]\n"
        'name = ""\n'
        'email = ""\n'
        'type = "human"    # "human" | "agent"\n'
        "\n"
        "[hub]\n"
        f"{hub_line}\n"
        "# Credentials are stored in ~/.muse/identity.toml — never here.\n"
        "\n"
        f"{remotes_block}\n"
        "[domain]\n"
        "# Domain-specific configuration. Keys depend on the active domain plugin.\n"
    )

_BARE_CONFIG = """\
[core]
bare = true

[user]
name = ""
email = ""
type = "human"    # "human" | "agent"

[hub]
# url = "https://musehub.ai"

[remotes]

[domain]
"""

_MUSEIGNORE_HEADER = """\
# .museignore — snapshot exclusion rules for this repository.

"""

_MUSEIGNORE_GLOBAL = """\
[global]
patterns = [
    ".DS_Store",
    "Thumbs.db",
    "*.tmp",
    "*.swp",
    "*.swo",

    # IDE / editor state — applies to every domain
    ".vscode/",
    ".idea/",
    "*.iml",
]
"""

_MUSEIGNORE_DOMAIN_BLOCKS: _StrMap = {
    "midi": """\
[domain.midi]
patterns = [
    "*.bak",
    "*.autosave",
    "/renders/",
    "/exports/",
    "/previews/",
]
""",
    "code": """\
[domain.code]
# Secrets (.env, *.key, *.pem, *.p12) are blocked by the Muse engine
# automatically — no need to list them here.
patterns = [
    # ── Universal build / output directories ─────────────────────────
    "dist/",
    "build/",
    "out/",
    "tmp/",

    # ── Dependency trees ─────────────────────────────────────────────
    "node_modules/",      # JavaScript / Node
    "vendor/",            # Go, PHP (Composer)

    # ── Python ───────────────────────────────────────────────────────
    "__pycache__/",
    "*.pyc",
    "*.pyo",
    ".venv/",
    "venv/",
    ".tox/",
    "*.egg-info/",

    # ── Rust ─────────────────────────────────────────────────────────
    # "target/",

    # ── Java / Kotlin / Scala ────────────────────────────────────────
    # "*.class",
    # "*.jar",

    # ── Ruby ─────────────────────────────────────────────────────────
    # ".mpack/",

]
""",
}

_MUSEIGNORE_FORCE_TRACK_BLOCK = """\
# [force_track]
# Exact repo-relative paths to track even if they match a secrets pattern.
# Use for dev infrastructure (e.g. self-signed TLS certs) that must survive
# clean pulls.  No glob expansion — each entry must be an exact file path.
# paths = [
#     "deploy/local-tls/localhost.key",
#     "deploy/local-tls/localhost.crt",
# ]
"""

def _museignore_template(domain: str) -> str:
    """Return a TOML ``.museignore`` template pre-filled for *domain*.

    The ``[global]`` section covers cross-domain OS artifacts.  The
    ``[domain.<name>]`` section lists patterns specific to the chosen domain.
    Patterns from other domains are never loaded at snapshot time.
    The ``[force_track]`` block is documented but commented out — uncomment
    and fill in paths to whitelist specific files from the secrets blocklist.
    """
    domain_block = _MUSEIGNORE_DOMAIN_BLOCKS.get(domain, f"""\
[domain.{domain}]
# patterns = []
""")
    return f"{_MUSEIGNORE_HEADER}{_MUSEIGNORE_GLOBAL}\n{domain_block}\n{_MUSEIGNORE_FORCE_TRACK_BLOCK}"

def _museattributes_template(domain: str) -> str:
    """Return a TOML `.museattributes` template pre-filled with *domain*."""
    return f"""\
# .museattributes — merge strategy overrides for this repository.

[meta]
domain = "{domain}"

# [[rules]]
# path      = "*"
# dimension = "*"
# strategy  = "auto"
"""

def _copy_template(
    template_path: pathlib.Path,
    dest_root: pathlib.Path,
    warnings: list[str],
    *,
    json_out: bool = False,
) -> None:
    """Copy *template_path* contents into *dest_root*, with two safety guards.

    Guards:
    1. Any item whose name is ``.muse`` is skipped — prevents a malicious
       template from overwriting the freshly created VCS state directory.
    2. Any item that is a symlink is skipped — prevents a template with
       symlinks pointing outside the tree from reading or overwriting
       sensitive files (e.g. ``/etc/passwd``).

    Skipped items are appended to *warnings* so agents can audit what was
    omitted without parsing log output.  When *json_out* is True the human-
    readable ``logger.warning`` is suppressed — the warnings list is the
    sole channel, keeping stderr clean for machine consumers.

    Args:
        template_path: Verified-existing directory to copy from.
        dest_root:     Repository working-tree root (``cwd``).
        warnings:      Mutable list; skipped-item notices are appended here.
        json_out:       When True, suppress human-readable stderr log lines.
    """
    for item in template_path.iterdir():
        if item.name == ".muse":
            msg = (
                "init: skipping .muse/ in template — "
                "templates must not contain VCS state directories."
            )
            if not json_out:
                logger.warning("⚠️  %s", msg)
            warnings.append(msg)
            continue
        if item.is_symlink():
            msg = (
                f"init: skipping symlink {item.name!r} in template — "
                "symlinks are not copied to prevent path-traversal."
            )
            if not json_out:
                logger.warning("⚠️  %s", msg)
            warnings.append(msg)
            continue
        dest = dest_root / item.name
        if item.is_dir():
            shutil.copytree(item, dest, dirs_exist_ok=True)
        else:
            item.copy(dest)

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the init subcommand."""
    parser = subparsers.add_parser(
        "init",
        help="Initialize a new Muse repository.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--bare",
        action="store_true",
        help="Initialize as a bare repository (no working tree).",
    )
    parser.add_argument(
        "--template",
        default=None,
        metavar="PATH",
        help="Copy PATH contents into the working tree after initializing.",
    )
    parser.add_argument(
        "--default-branch",
        default="main",
        metavar="BRANCH",
        dest="default_branch",
        help="Name of the initial branch (default: main).",
    )
    parser.add_argument(
        "--force", "-f",
        action="store_true",
        help="Re-initialize even if already a Muse repository. Preserves repo_id.",
    )
    parser.add_argument(
        "--domain", "-d",
        default="code",
        help="Domain plugin to activate (e.g. code, midi). Default: code.",
    )
    parser.add_argument(
        "directory",
        nargs="?",
        default=None,
        metavar="DIRECTORY",
        help=(
            "Directory to initialize as a Muse repository.  "
            "Created (including any missing parents) if it does not yet exist.  "
            "Defaults to the current working directory."
        ),
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit a machine-readable JSON result and exit.",
    )
    parser.set_defaults(func=run)

def _emit_error(json_out: bool, msg: str, code: ExitCode, warnings: list[str], elapsed: float) -> None:
    """Print an error and raise SystemExit.  Never returns."""
    if json_out:
        print(json.dumps(_InitErrorJson(
            **make_envelope(elapsed, exit_code=int(code), warnings=list(warnings)),
            status="error",
            error=msg,
        )))
    else:
        print(f"❌ {sanitize_display(msg)}", file=sys.stderr)
    raise SystemExit(code)

def run(args: argparse.Namespace) -> None:
    """Initialize a new Muse repository in the current directory (or DIRECTORY).

    Creates the ``.muse/`` directory structure and writes an initial
    ``HEAD``, ``config.toml``, and empty ``objects/`` tree.  Safe to re-run
    with ``--force`` on an existing repo (reinitializes without data loss).

    Agent quickstart
    ----------------
    ::

        muse init --json
        muse init --domain code --json
        muse init /tmp/new-repo --json
        muse init --bare --json

    JSON fields
    -----------
    status          ``"ok"`` on success.
    repo_id         Content-addressed ID of the new repository.
    branch          Default branch name created.
    domain          Domain plugin name configured.
    path            Absolute path to the ``.muse/`` directory.
    reinitialized   ``true`` if an existing repo was reinitialized.
    bare            ``true`` if initialized as a bare repository.
    schema_version  On-disk layout version.
    created_at      ISO 8601 UTC timestamp of creation.

    Exit codes
    ----------
    0  Repository initialized (or reinitialized).
    1  Invalid arguments or domain name.
    3  I/O error creating the repository.
    """
    elapsed = start_timer()
    bare: bool = args.bare
    template: str | None = args.template
    default_branch: str = args.default_branch
    force: bool = args.force
    domain: str = args.domain
    json_out: bool = args.json_out
    directory: str | None = args.directory

    warnings: list[str] = []

    try:
        validate_branch_name(default_branch)
    except ValueError as exc:
        _emit_error(json_out, f"Invalid --default-branch: {exc}", ExitCode.USER_ERROR, warnings, elapsed)

    try:
        validate_domain_name(domain)
    except ValueError as exc:
        _emit_error(json_out, f"Invalid --domain: {exc}", ExitCode.USER_ERROR, warnings, elapsed)

    # Resolve the target directory (defaults to CWD when no argument is given).
    if directory is not None:
        raw_dir = pathlib.Path(directory)
        target = (pathlib.Path.cwd() / raw_dir).resolve() if not raw_dir.is_absolute() else raw_dir.resolve()
        try:
            target.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            _emit_error(
                json_out,
                f"Cannot create directory '{sanitize_display(str(target))}': {exc}",
                ExitCode.INTERNAL_ERROR,
                warnings,
                elapsed,
            )
        os.chdir(target)

    cwd = pathlib.Path.cwd()
    muse_dir = _muse_dir(cwd)
    written_remotes: dict[str, str] = {}

    template_path: pathlib.Path | None = None
    if template is not None:
        raw_template = pathlib.Path(template)
        # Check for symlink BEFORE resolving so a symlinked path is caught
        # before .resolve() follows it to the real target.  A symlinked
        # template directory could be swapped between validation and use.
        if raw_template.is_symlink():
            _emit_error(
                json_out,
                "Template path must not be a symbolic link.",
                ExitCode.USER_ERROR,
                warnings,
                elapsed,
            )
        template_path = raw_template.resolve()
        if not template_path.is_dir():
            _emit_error(
                json_out,
                f"Template path is not a directory: {template_path}",
                ExitCode.USER_ERROR,
                warnings,
                elapsed,
            )

    already_exists = muse_dir.is_dir()
    if already_exists and not force:
        _emit_error(
            json_out,
            "Already a Muse repository. Use --force to reinitialize.",
            ExitCode.USER_ERROR,
            warnings,
            elapsed,
        )

    existing_repo_id: str | None = None
    if force and already_exists:
        repo_json = muse_dir / "repo.json"
        if repo_json.exists():
            _repo_data = load_json_file(repo_json)
            if _repo_data is not None:
                raw_id = _repo_data.get("repo_id")
                try:
                    if isinstance(raw_id, str):
                        existing_repo_id = validate_repo_id(raw_id)
                except (ValueError, TypeError):
                    pass  # non-sha256: repo_id (e.g. legacy plain string) — generate fresh

    try:
        # Create the canonical layout first, then any init-specific extras.
        _init_repo_dirs(cwd)
        for subdir in _INIT_SUBDIRS:
            (muse_dir / subdir).mkdir(parents=True, exist_ok=True)

        created_at = now_utc_iso()
        if existing_repo_id:
            repo_id = existing_repo_id
        else:
            repo_id = content_hash({"created_at": created_at, "domain": domain, "path": str(cwd)})
        repo_meta: _RepoMeta = {
            "repo_id": repo_id,
            "schema_version": _REPO_SCHEMA_VERSION,
            "created_at": created_at,
            "domain": domain,
            "bare": bare,
            "muse_version": _MUSE_VERSION,
        }

        # Use write_text_atomic for repo.json: a SIGKILL between write and
        # rename would otherwise leave a zero-byte file, breaking every
        # subsequent command that reads repo_id.
        write_text_atomic(
            muse_dir / "repo.json",
            f"{json.dumps(repo_meta)}\n",
        )

        write_head_branch(muse_dir.parent, default_branch)

        # Write an empty branch ref only when the file does not yet exist.
        # Never overwrite an existing ref — even under --force — to avoid
        # orphaning commits on the branch.
        ref_file = _ref_path(cwd, default_branch)
        if not ref_file.exists():
            write_text_atomic(ref_file, "")

        config_path = muse_dir / "config.toml"
        written_remotes: dict[str, str] = {}
        if not config_path.exists():
            if bare:
                write_text_atomic(config_path, _BARE_CONFIG)
            else:
                handle = resolve_default_handle()
                slug = cwd.name
                written_remotes = (
                    {name: f"{base}/{handle}/{slug}" for name, base in _DEFAULT_REMOTES.items()}
                    if handle else {}
                )
                write_text_atomic(config_path, _build_default_config(handle, slug))

        if not bare:
            attrs_path = cwd / ".museattributes"
            if not attrs_path.exists():
                write_text_atomic(attrs_path, _museattributes_template(domain))

            ignore_path = cwd / ".museignore"
            if not ignore_path.exists():
                write_text_atomic(ignore_path, _museignore_template(domain))

        if not bare and template_path is not None:
            _copy_template(template_path, cwd, warnings, json_out=json_out)

        # Post-init integrity check: verify every critical directory is a real
        # directory (not a symlink) before returning success.  This catches
        # environmental races and confirms the layout is self-consistent.
        for subdir in _INIT_SUBDIRS:
            candidate = muse_dir / subdir
            try:
                assert_not_symlink(candidate, label=f".muse/{subdir}")
            except ValueError as exc:
                _emit_error(
                    json_out,
                    f"Repository structure compromised during init: {exc}",
                    ExitCode.INTERNAL_ERROR,
                    warnings,
                    elapsed,
                )

    except PermissionError:
        _emit_error(
            json_out,
            f"Permission denied: cannot write to {cwd}.",
            ExitCode.USER_ERROR,
            warnings,
            elapsed,
        )
    except OSError as exc:
        _emit_error(
            json_out,
            f"Failed to initialize repository: {exc}",
            ExitCode.INTERNAL_ERROR,
            warnings,
            elapsed,
        )

    reinitialized = bool(force and already_exists)

    if json_out:
        print(json.dumps(_InitJson(
            **make_envelope(elapsed, warnings=warnings),
            status="ok",
            error="",
            repo_id=repo_id,
            branch=default_branch,
            domain=domain,
            path=str(muse_dir),
            reinitialized=reinitialized,
            bare=bare,
            schema_version=_REPO_SCHEMA_VERSION,
            created_at=created_at,
            remotes=written_remotes,
        )))
    else:
        action = "Reinitialized" if reinitialized else "Initialized"
        kind = "bare " if bare else ""
        print(f"✅ {action} {kind}Muse repository in {sanitize_display(str(muse_dir))}")
