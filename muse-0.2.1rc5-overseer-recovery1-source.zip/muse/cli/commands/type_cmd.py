"""muse code type — type-health analysis for optionally-typed languages.

What makes ``muse code type`` different from ``mypy`` or ``pyright``?

Those tools check *correctness* of annotations against runtime types.
``muse code type`` answers questions that *only a VCS* can answer:

* **Any-blast-radius** — if ``billing.py::compute`` returns ``Any``, which
  callers inherit that type blindspot?  Static checkers cannot answer this
  without a full type-graph.  Muse can, because it has the call graph.

* **Type drift** — is the team *gaining* or *losing* type coverage across
  commits?  mypy sees a snapshot; Muse sees the time-series.

* **Migration targets** — which untyped function, if typed *today*, would
  propagate type safety to the most callers?  The call-graph gives
  a centrality score.  No static checker ranks by impact.

* **Type diff** — between HEAD and a branch (or any ref), which signatures
  *widened* (became less safe) vs. *narrowed* (became safer)?  Detects
  type regressions before merge, not after.

Usage examples::

    muse code type                          # health report for HEAD
    muse code type --json                   # machine-readable (agent-safe)
    muse code type --file muse/core         # restrict to a subtree
    muse code type --any-blast-radius muse/core/merge_engine.py::MergeState
    muse code type --drift                  # coverage over time (current branch)
    muse code type --drift --since 2025-01-01
    muse code type --migration-targets --top 10
    muse code type --diff HEAD~5            # type conflicts since 5 commits ago
"""

import argparse
import datetime
import json
import logging
import pathlib
import sys

from muse.core.types import short_id
from muse.core.paths import muse_dir as _muse_dir
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.timing import start_timer
from muse.core.repo import require_repo
from muse.core.types import Manifest
from muse.core.refs import read_current_branch
from muse.core.commits import resolve_commit_ref
from muse.core.snapshots import (
    get_head_snapshot_manifest,
    read_snapshot,
)
from muse.core.type_analysis import (
    AnyBlastNode,
    MigrationTarget,
    TypeConflict,
    TypeDriftPoint,
    TypeHealthReport,
    any_blast_radius,
    compute_type_health,
    migration_targets,
    type_diff,
    type_drift,
)


logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# JSON output types
# ---------------------------------------------------------------------------

class _HealthJson(EnvelopeJson):
    """Top-level JSON output for the default (health) mode."""

    mode: str
    total_symbols: int
    fully_typed: int
    partially_typed: int
    untyped: int
    any_count: int
    coverage_fraction: float
    symbols: list[TypeHealthReport]

class _BlastJson(EnvelopeJson):
    """Top-level JSON output for ``--any-blast-radius`` mode."""

    mode: str
    address: str
    nodes: list[AnyBlastNode]

class _DriftJson(EnvelopeJson):
    """Top-level JSON output for ``--drift`` mode."""

    mode: str
    branch: str
    drift: list[TypeDriftPoint]

class _MigrateJson(EnvelopeJson):
    """Top-level JSON output for ``--migration-targets`` mode."""

    mode: str
    targets: list[MigrationTarget]

class _DiffJson(EnvelopeJson):
    """Top-level JSON output for ``--diff REF`` mode."""

    mode: str
    diff_ref: str
    conflicts: list[TypeConflict]

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``type`` subcommand under the ``code`` sub-parser.

    Arguments
    ---------
    --any-blast-radius ADDR
        Trace Any-annotation propagation from ADDR through the call graph.
        Exits non-zero when blast radius > 0.
    --drift
        Show type-coverage trend across commit history (oldest → newest).
    --migration-targets
        Rank untyped symbols by call-graph centrality.
    --diff REF
        Show type-signature changes between REF and HEAD.
        Exits non-zero when widened signatures are found.
    --file PREFIX, -f PREFIX
        Restrict analysis to files whose path starts with PREFIX.
    --depth N, -d N
        BFS depth for --any-blast-radius (default 5, max 10).
    --top N, -n N
        Maximum results for --migration-targets (default 20).
    --since DATE
        Earliest date for --drift (ISO-8601, e.g. 2025-01-01).
    --max-commits N
        Maximum commits to walk for --drift (default 200).
    --json, -j
        Emit machine-readable JSON (agent-safe).
    """
    parser = subparsers.add_parser(
        "type",
        help="Type-health analysis: coverage, Any-blast-radius, drift, and migration targets.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # -- Mode flags (mutually exclusive set) --
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--any-blast-radius",
        metavar="ADDR",
        dest="blast_address",
        default=None,
        help=(
            "Trace how an Any annotation at ADDR propagates through callers "
            "(e.g. 'billing.py::compute').  "
            "Exits non-zero when blast radius > 0."
        ),
    )
    mode.add_argument(
        "--drift",
        action="store_true",
        help="Show type-coverage trend across commit history (oldest → newest).",
    )
    mode.add_argument(
        "--migration-targets",
        action="store_true",
        dest="migrate",
        help=(
            "Rank untyped / poorly-typed symbols by call-graph centrality.  "
            "The top result is the highest-ROI symbol to type next."
        ),
    )
    mode.add_argument(
        "--diff",
        metavar="REF",
        dest="diff_ref",
        default=None,
        help=(
            "Show type-signature changes between REF and HEAD.  "
            "REF can be a commit ID, tag, or HEAD~N notation.  "
            "Exits non-zero when widened signatures are found."
        ),
    )

    # -- Shared flags --
    parser.add_argument(
        "--file",
        "-F",
        metavar="PREFIX",
        dest="file_filter",
        default=None,
        help="Restrict analysis to files whose path starts with PREFIX.",
    )
    parser.add_argument(
        "--depth",
        type=int,
        default=5,
        metavar="N",
        help="BFS depth for --any-blast-radius (default 5, max 10).",
    )
    parser.add_argument(
        "--top",
        type=int,
        default=20,
        metavar="N",
        help="Maximum results for --migration-targets (default 20).",
    )
    parser.add_argument(
        "--since",
        metavar="DATE",
        default=None,
        help="Earliest date for --drift (ISO-8601, e.g. 2025-01-01).",
    )
    parser.add_argument(
        "--max-commits",
        type=int,
        default=200,
        metavar="N",
        dest="max_commits",
        help="Maximum commits to walk for --drift (default 200).",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON (agent-safe).",
    )

    parser.set_defaults(func=run, json_out=False)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_manifest(root: "pathlib.Path") -> Manifest:
    """Return HEAD snapshot manifest; abort with a clear error when missing."""
    muse_dir = _muse_dir(root)
    branch = read_current_branch(root)
    manifest = get_head_snapshot_manifest(root, branch)
    if manifest is None:
        print("❌  No snapshot found for HEAD.  Commit first.", file=sys.stderr)
        sys.exit(1)
    return manifest

def _parse_since(since_str: str | None) -> datetime.datetime | None:
    if since_str is None:
        return None
    try:
        return datetime.datetime.fromisoformat(since_str)
    except ValueError:
        print(
            f"❌  --since: invalid date '{since_str}' (expected ISO-8601, e.g. 2025-01-01)",
            file=sys.stderr,
        )
        sys.exit(1)

# ---------------------------------------------------------------------------
# Text renderers
# ---------------------------------------------------------------------------

def _render_health_text(report: TypeHealthReport, file_filter: str | None) -> None:
    scope = f"  (filtered to '{file_filter}')" if file_filter else ""
    pct = report["coverage_fraction"] * 100
    bar_filled = int(pct / 5)
    bar = f"{'█' * bar_filled}{'░' * (20 - bar_filled)}"
    print()
    print(f"  Type Health Report{scope}")
    print(f"  {'─' * 50}")
    print(f"  [{bar}] {pct:5.1f}%")
    print()
    print(f"  Total callable symbols : {report['total_symbols']}")
    print(f"  Fully typed            : {report['fully_typed']}")
    print(f"  Partially typed        : {report['partially_typed']}")
    print(f"  Untyped                : {report['untyped']}")
    print(f"  Any occurrences        : {report['any_count']}")
    print()

    # Show worst-scoring symbols (bottom 10).
    worst = sorted(report["symbols"], key=lambda s: s["type_score"])[:10]
    if worst:
        print("  Lowest-scored symbols (type first for max impact):")
        for s in worst:
            pct_s = s["type_score"] * 100
            print(f"    {pct_s:5.1f}%  {s['address']}")
    print()

def _render_blast_text(nodes: list[AnyBlastNode], address: str) -> None:
    if not nodes:
        print(f"\n  ✅  No Any propagation found from {address!r}.\n")
        return
    source = nodes[0]
    callers = nodes[1:]
    print()
    print(f"  Any-Blast-Radius from  {source['address']}")
    print(f"  {'─' * 50}")
    if not callers:
        print("  ⚠️   Symbol has Any annotations but no known callers.\n")
        return
    by_depth: dict[int, list[AnyBlastNode]] = {}
    for n in callers:
        by_depth.setdefault(n["depth"], []).append(n)
    for depth in sorted(by_depth):
        depth_nodes = by_depth[depth]
        print(f"  Depth {depth} ({len(depth_nodes)} caller{'s' if len(depth_nodes) != 1 else ''}):")
        for n in depth_nodes:
            print(f"    ↳  {n['address']}")
    print()
    print(f"  ⚠️   {len(callers)} caller(s) inherit type blindspot.\n")

def _render_drift_text(points: list[TypeDriftPoint]) -> None:
    if not points:
        print("\n  No commit history found for drift analysis.\n")
        return
    print()
    print("  Type Coverage Drift")
    print(f"  {'─' * 60}")
    print(f"  {'Commit':<10}  {'Date':<12}  {'Coverage':>8}  {'Δ':>7}  Message")
    print(f"  {'─' * 60}")
    for p in points:
        cid = short_id(p["commit_id"])
        date = p["committed_at"][:10]
        cov = f"{p['coverage_fraction'] * 100:6.1f}%"
        delta = p["delta_coverage"]
        arrow = "▲" if delta > 0.001 else ("▼" if delta < -0.001 else "─")
        delta_str = f"{arrow} {abs(delta) * 100:.1f}%"
        msg = p["message"][:35]
        print(f"  {cid:<10}  {date:<12}  {cov:>8}  {delta_str:>7}  {msg}")
    print()
    start = points[0]["coverage_fraction"]
    end = points[-1]["coverage_fraction"]
    trend = end - start
    direction = "▲ improving" if trend > 0.001 else ("▼ degrading" if trend < -0.001 else "─ stable")
    print(f"  Overall trend: {direction}  ({start * 100:.1f}% → {end * 100:.1f}%)\n")

def _render_migrate_text(targets: list[MigrationTarget]) -> None:
    if not targets:
        print("\n  ✅  All symbols are fully typed.\n")
        return
    print()
    print("  Migration Targets — highest ROI symbols to type next")
    print(f"  {'─' * 70}")
    print(f"  {'Priority':>8}  {'Callers':>7}  {'Score':>6}  Address")
    print(f"  {'─' * 70}")
    for t in targets:
        print(
            f"  {t['priority_score']:8.2f}  {t['caller_count']:7d}  "
            f"{t['type_score'] * 100:5.1f}%  {t['address']}"
        )
    print()
    top = targets[0]
    print(
        f"  💡  Start with {top['address']!r}:  "
        f"{top['caller_count']} callers, currently {top['type_score'] * 100:.0f}% typed.\n"
    )

def _render_diff_text(conflicts: list[TypeConflict], diff_ref: str) -> None:
    if not conflicts:
        print(f"\n  ✅  No type-signature changes between {diff_ref!r} and HEAD.\n")
        return
    widened = [c for c in conflicts if c["change_kind"] == "widened"]
    narrowed = [c for c in conflicts if c["change_kind"] == "narrowed"]
    changed = [c for c in conflicts if c["change_kind"] == "changed"]
    added = [c for c in conflicts if c["change_kind"] == "added"]
    removed = [c for c in conflicts if c["change_kind"] == "removed"]

    print()
    print(f"  Type Diff  {diff_ref!r} → HEAD")
    print(f"  {'─' * 70}")
    for label, group, prefix in [
        ("Widened (type safety ↓)", widened, "  ⚠️ "),
        ("Narrowed (type safety ↑)", narrowed, "  ✅ "),
        ("Changed", changed, "  ~  "),
        ("Added", added, "  +  "),
        ("Removed", removed, "  -  "),
    ]:
        if not group:
            continue
        print(f"\n  {label}:")
        for c in group:
            print(f"{prefix} {c['address']}")
            if c["signature_a"] and c["signature_b"]:
                print(f"       was: {c['signature_a']}")
                print(f"       now: {c['signature_b']}")
    print()
    if widened:
        print(f"  ❌  {len(widened)} widened signature(s) detected — type safety regressed.\n")
    else:
        print(f"  {len(conflicts)} change(s); no widenings.\n")

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Run type-health analysis on the current repository.

    Measures type annotation coverage by symbol, tracks type drift across
    commits, traces Any-annotation propagation through the call graph, and
    diffs type signatures between refs.  Defaults to a health summary of HEAD.

    Agent quickstart::

        # Health report for HEAD
        muse code type --json

        # Trace Any propagation from a symbol
        muse code type --any-blast-radius billing.py::compute --json

        # Coverage trend on current branch
        muse code type --drift --json

        # Rank symbols by typing ROI
        muse code type --migration-targets --top 10 --json

        # Type-signature diff since a ref
        muse code type --diff HEAD~5 --json

    JSON fields::

        mode             str   "health"|"blast"|"drift"|"migration-targets"|"diff"
        exit_code        int   0 on success; 1 for blast>0 or widened sigs (CI gate)
        duration_ms      float wall-clock time in milliseconds

        health fields:   total_symbols, fully_typed, partially_typed, untyped,
                         any_count, coverage_fraction, symbols[]
        blast fields:    address, nodes[]
        drift fields:    branch, drift[]
        migrate fields:  targets[]
        diff fields:     diff_ref, conflicts[]

    Exit codes::

        0  success or no blast / no widened signatures
        1  blast radius > 0 (--any-blast-radius) or widened sigs found (--diff)
    """
    elapsed = start_timer()
    root = require_repo()
    muse_dir = _muse_dir(root)
    json_out: bool = args.json_out
    file_filter: str | None = args.file_filter

    # ------------------------------------------------------------------
    # Mode: --any-blast-radius ADDR
    # ------------------------------------------------------------------
    if args.blast_address:
        manifest = _get_manifest(root)
        depth: int = max(1, min(args.depth, 10))
        nodes = any_blast_radius(root, manifest, args.blast_address, depth=depth)

        blast_exit = 1 if len(nodes) > 1 else 0
        if json_out:
            print(json.dumps(_BlastJson(
                **make_envelope(elapsed, exit_code=blast_exit),
                mode="blast",
                address=args.blast_address,
                nodes=list(nodes),
            )))
        else:
            _render_blast_text(nodes, args.blast_address)

        # Exit non-zero when blast radius > 0 (callers found) — useful for CI.
        sys.exit(blast_exit)

    # ------------------------------------------------------------------
    # Mode: --drift
    # ------------------------------------------------------------------
    if args.drift:
        branch = read_current_branch(root)
        since = _parse_since(args.since)
        points = type_drift(
            root,
            branch,
            max_commits=args.max_commits,
            since=since,
            file_filter=file_filter,
        )
        if json_out:
            print(json.dumps(_DriftJson(
                **make_envelope(elapsed),
                mode="drift",
                branch=branch,
                drift=list(points),
            )))
        else:
            _render_drift_text(points)
        return

    # ------------------------------------------------------------------
    # Mode: --migration-targets
    # ------------------------------------------------------------------
    if args.migrate:
        manifest = _get_manifest(root)
        targets = migration_targets(
            root,
            manifest,
            top_n=args.top,
            file_filter=file_filter,
        )
        if json_out:
            print(json.dumps(_MigrateJson(
                **make_envelope(elapsed),
                mode="migration-targets",
                targets=list(targets),
            )))
        else:
            _render_migrate_text(targets)
        return

    # ------------------------------------------------------------------
    # Mode: --diff REF
    # ------------------------------------------------------------------
    if args.diff_ref:
        branch = read_current_branch(root)
        head_manifest = _get_manifest(root)

        # Resolve REF to a commit and its snapshot manifest.
        ref_commit = resolve_commit_ref(root, branch, args.diff_ref)
        if ref_commit is None:
            print(f"❌  Cannot resolve ref {args.diff_ref!r}.", file=sys.stderr)
            sys.exit(1)
        snap = read_snapshot(root, ref_commit.snapshot_id)
        if snap is None:
            print(
                f"❌  Snapshot {ref_commit.snapshot_id!r} not found "
                f"for ref {args.diff_ref!r}.",
                file=sys.stderr,
            )
            sys.exit(1)
        ref_manifest: Manifest = snap.manifest

        conflicts = type_diff(root, ref_manifest, head_manifest, file_filter=file_filter)
        widened = [c for c in conflicts if c["change_kind"] == "widened"]
        diff_exit = 1 if widened else 0
        if json_out:
            print(json.dumps(_DiffJson(
                **make_envelope(elapsed, exit_code=diff_exit),
                mode="diff",
                diff_ref=args.diff_ref,
                conflicts=list(conflicts),
            )))
        else:
            _render_diff_text(conflicts, args.diff_ref)

        sys.exit(diff_exit)

    # ------------------------------------------------------------------
    # Default mode: health report
    # ------------------------------------------------------------------
    manifest = _get_manifest(root)
    report = compute_type_health(root, manifest, file_filter=file_filter)

    if json_out:
        print(json.dumps(_HealthJson(
            **make_envelope(elapsed),
            mode="health",
            total_symbols=report["total_symbols"],
            fully_typed=report["fully_typed"],
            partially_typed=report["partially_typed"],
            untyped=report["untyped"],
            any_count=report["any_count"],
            coverage_fraction=report["coverage_fraction"],
            symbols=report["symbols"],
        )))
    else:
        _render_health_text(report, file_filter)
