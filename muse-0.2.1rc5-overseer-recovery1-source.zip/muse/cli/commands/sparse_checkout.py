"""``muse sparse-checkout`` — partial working-tree materialization.

Sparse-checkout lets you work with only a subset of a large repository's files
in your working tree.  The full snapshot manifest is always stored and tracked
by Muse; only the files that match your sparse rules are written to disk.

Subcommands
-----------
``init [--no-cone] [--json]``
    Activate sparse-checkout.  ``--cone`` (default) uses directory-prefix rules;
    ``--no-cone`` uses glob patterns.  If a config already exists, running init
    again with a *different* mode switches the mode while preserving patterns.
    Running init with the *same* mode is a no-op.

``set <pattern...> [--json]``
    Replace the current pattern list.  Requires ``init`` first.

``add <pattern...> [--json]``
    Append patterns to the current list (deduplicates).  Requires ``init`` first.

``list [--json]``
    Show the active patterns and mode.

``stats [--json]``
    Show how many files in the HEAD snapshot match or are excluded by the current
    sparse config.  Reports total_files, matching_files, excluded_files, and
    efficiency (ratio of matching to total).

``disable [--json]``
    Remove the sparse-checkout configuration.  The next ``checkout`` or ``merge``
    will restore the full working tree.

Modes
-----
``cone`` (default)
    Patterns are directory prefixes, e.g. ``src/``.  Root-level files always
    match.  Subdirectory files match when their path starts with a prefix.

``pattern``
    Patterns are glob expressions, e.g. ``**/*.py`` or ``src/**``.

Pattern safety rules
--------------------
Patterns are validated before storage.  The following are rejected:

- ANSI escape sequences (terminal-injection guard)
- Null bytes (filesystem attack vector)
- Whitespace-only strings (meaningless; likely a user error)
- Path traversal via ``..`` segments (e.g. ``../../etc/passwd``)

JSON output schemas
-------------------

``init --json``::

    {"mode": str, "switched": bool, "previous_mode": str|null,
     "duration_ms": float, "exit_code": int}

``set --json``::

    {"patterns": [str, ...], "total": int, "duration_ms": float, "exit_code": int}

``add --json``::

    {"added": int, "skipped": int, "patterns": [str, ...],
     "total": int, "duration_ms": float, "exit_code": int}

``list --json``::

    {"enabled": bool, "mode": str|null, "patterns": [str, ...],
     "duration_ms": float, "exit_code": int}

``stats --json``::

    {"enabled": bool, "mode": str|null, "patterns": [str, ...],
     "total_files": int, "matching_files": int, "excluded_files": int,
     "efficiency": float, "duration_ms": float, "exit_code": int}

``disable --json``::

    {"was_enabled": bool, "duration_ms": float, "exit_code": int}

Exit codes::

    0 — success
    1 — operation failed (no config, invalid patterns, config corruption)
    2 — usage error
"""

import argparse
import json as _json
import re
import sys

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.paths import sparse_checkout_path as _sparse_checkout_path
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.sparse import (
    SparseConfig,
    filter_manifest_sparse,
    read_sparse_config,
    remove_sparse_config,
    write_sparse_config,
)
from muse.core.validation import sanitize_display
from muse.core.timing import start_timer

# ---------------------------------------------------------------------------
# Wire types
# ---------------------------------------------------------------------------

class _SparseInitJson(EnvelopeJson):
    mode: str
    switched: bool
    previous_mode: str | None

class _SparseSetJson(EnvelopeJson):
    patterns: list[str]
    total: int

class _SparseAddJson(EnvelopeJson):
    added: int
    skipped: int
    patterns: list[str]
    total: int

class _SparseListJson(EnvelopeJson):
    enabled: bool
    mode: str | None
    patterns: list[str]

class _SparseStatsJson(EnvelopeJson):
    enabled: bool
    mode: str | None
    patterns: list[str]
    total_files: int
    matching_files: int
    excluded_files: int
    efficiency: float

class _SparseDisableJson(EnvelopeJson):
    was_enabled: bool

# ---------------------------------------------------------------------------
# Pattern validation
# ---------------------------------------------------------------------------

_ANSI_RE = re.compile(r"\x1b|\x9b|\x1c|\x1d|\x1e|\x1f")

# Matches ".." as a path component: preceded/followed by separator or string boundary.
_TRAVERSAL_RE = re.compile(r"(^|[/\\])\.\.([/\\]|$)")

def _check_pattern(pat: str) -> tuple[bool, str]:
    """Validate *pat* and return ``(ok, reason)``.

    Rejects patterns that are:

    - ANSI escape sequences — prevent terminal-injection when patterns are
      printed to stdout/stderr.
    - Null bytes — filesystem attack vector; ``open()`` rejects them on most
      platforms, causing misleading errors deep in the call stack.
    - Whitespace-only — meaningless as a path prefix or glob; almost certainly
      a user error.
    - Path traversal via ``..`` — a pattern like ``../../etc/passwd`` would
      match files outside the repository root after prefix expansion.
    """
    if _ANSI_RE.search(pat):
        return False, "ANSI escape sequence detected"
    if "\x00" in pat:
        return False, "null byte detected"
    if not pat.strip():
        return False, "empty or whitespace-only pattern"
    if _TRAVERSAL_RE.search(pat):
        return False, "path traversal via '..' detected"
    if pat.strip("/\\") == "..":
        return False, "path traversal via '..' detected"
    return True, ""

def _validate_patterns(patterns: list[str]) -> None:
    """Check every pattern in *patterns*, exiting on the first invalid one."""
    for pat in patterns:
        ok, reason = _check_pattern(pat)
        if not ok:
            print(
                f"❌ Invalid pattern {sanitize_display(repr(pat))}: {reason}",
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)

# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def _read_config_safe(root: pathlib.Path) -> SparseConfig | None:
    """Read the sparse config, exiting with a clear error on JSON corruption.

    ``load_json_file`` (used by ``read_sparse_config``) returns ``None`` for
    both "file not found" and "file is corrupt JSON".  We distinguish the two
    cases by checking whether the file exists before falling back to ``None``.
    A present-but-unreadable config is always a user-visible error.
    """
    import json as _stdlib_json
    cfg_path = _sparse_checkout_path(root)
    if not cfg_path.exists():
        return None
    try:
        raw = cfg_path.read_text(encoding="utf-8")
        data = _stdlib_json.loads(raw)
        if not isinstance(data, dict):
            raise ValueError(f"expected a JSON object, got {type(data).__name__}")
        return data
    except Exception as exc:
        print(
            f"❌ Sparse-checkout config is corrupted and cannot be read: {exc}",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

def _validate_config_structure(cfg: SparseConfig) -> None:
    """Exit with USER_ERROR if *cfg* is missing required fields or has invalid values.

    Called after a successful JSON parse to catch configs that are syntactically
    valid JSON but semantically invalid for sparse-checkout (e.g. missing 'mode'
    or 'patterns' keys, unknown mode value).
    """
    if "mode" not in cfg:
        print(
            "❌ Sparse-checkout config is missing required 'mode' field.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)
    if cfg["mode"] not in ("cone", "pattern"):
        print(
            f"❌ Sparse-checkout config has invalid mode "
            f"'{sanitize_display(str(cfg['mode']))}'. Expected 'cone' or 'pattern'.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)
    if "patterns" not in cfg:
        print(
            "❌ Sparse-checkout config is missing required 'patterns' field.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

def _require_config(root: pathlib.Path) -> SparseConfig:
    """Return the sparse config or exit with a helpful message if not initialised."""
    cfg = _read_config_safe(root)
    if cfg is None:
        print(
            "❌ Sparse-checkout is not initialised. Run `muse sparse-checkout init` first.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)
    _validate_config_structure(cfg)
    return cfg

# ---------------------------------------------------------------------------
# Subcommand handlers
# ---------------------------------------------------------------------------

def _cmd_init(args: argparse.Namespace, root: pathlib.Path) -> None:
    """Activate sparse-checkout or switch its mode.

    Initialises a new sparse-checkout configuration with the requested mode
    (``cone`` by default, ``pattern`` when ``--no-cone`` is set).  When a
    config already exists, running init again with the *same* mode is a no-op
    (``switched=False``); a *different* mode switches the mode, preserving
    existing patterns (``switched=True``).

    Agent quickstart::

        muse sparse-checkout init --json
        muse sparse-checkout init --no-cone --json

    JSON fields::

        mode           Active mode after this command: ``"cone"`` or ``"pattern"``.
        switched       ``true`` when the mode was changed from a previous setting.
        previous_mode  Prior mode when switched; ``null`` on first init or no-op.
        muse_version   Muse release that produced this output.
        schema         Envelope schema version (int).
        exit_code      ``0`` on success, ``1`` on config validation failure.
        duration_ms    Wall-clock milliseconds for the command.
        timestamp      ISO-8601 UTC timestamp of command completion.
        warnings       List of non-fatal advisory messages.

    Exit codes::

        0  Success.
        1  User error (invalid config).
        2  Usage error.
    """
    elapsed = start_timer()

    json_out: bool = getattr(args, "json_out", False)
    requested_mode = "pattern" if args.no_cone else "cone"

    cfg = _read_config_safe(root)

    if cfg is None:
        write_sparse_config(root, {"mode": requested_mode, "patterns": []})
        if json_out:
            print(_json.dumps(_SparseInitJson(
                **make_envelope(elapsed),
                mode=requested_mode,
                switched=False,
                previous_mode=None,
            )))
        else:
            print(f"Sparse-checkout enabled (mode: {requested_mode}).")
        return

    _validate_config_structure(cfg)
    previous_mode = cfg["mode"]
    switched = previous_mode != requested_mode

    if switched:
        cfg["mode"] = requested_mode
        write_sparse_config(root, cfg)

    if json_out:
        print(_json.dumps(_SparseInitJson(
            **make_envelope(elapsed),
            mode=requested_mode,
            switched=switched,
            previous_mode=previous_mode if switched else None,
        )))
    else:
        if switched:
            print(f"Sparse-checkout mode switched: {previous_mode} → {requested_mode}.")
        else:
            print(f"Sparse-checkout already enabled (mode: {previous_mode}).")

def _cmd_set(args: argparse.Namespace, root: pathlib.Path) -> None:
    """Replace the full pattern list.

    Validates every pattern for safety before writing.  Overwrites the
    previous pattern list entirely — use ``add`` to append instead.  Exits
    with ``USER_ERROR`` if any pattern is invalid or if sparse-checkout has
    not been initialised.

    Agent quickstart::

        muse sparse-checkout set 'src/' 'tests/' --json
        muse sparse-checkout set '**/*.py' --json

    JSON fields::

        patterns     Updated pattern list after the operation.
        total        Number of patterns now active.
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    ``0`` on success, ``1`` on error.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  Success.
        1  User error (not initialised, invalid pattern).
        2  Usage error.
    """
    elapsed = start_timer()

    json_out: bool = getattr(args, "json_out", False)
    cfg = _require_config(root)
    _validate_patterns(args.patterns)

    cfg["patterns"] = list(args.patterns)
    write_sparse_config(root, cfg)

    if json_out:
        print(_json.dumps(_SparseSetJson(
            **make_envelope(elapsed),
            patterns=cfg["patterns"],
            total=len(cfg["patterns"]),
        )))
    else:
        print(f"Patterns set ({len(cfg['patterns'])} total).")

def _cmd_add(args: argparse.Namespace, root: pathlib.Path) -> None:
    """Append new patterns, skipping duplicates.

    Validates every candidate pattern before adding.  Patterns already present
    are silently counted as ``skipped``; only genuinely new patterns are stored.
    Exits with ``USER_ERROR`` if any pattern is invalid or if sparse-checkout
    has not been initialised.

    Agent quickstart::

        muse sparse-checkout add 'docs/' --json
        muse sparse-checkout add '**/*.md' '**/*.rst' --json

    JSON fields::

        added        Number of new patterns appended.
        skipped      Number of patterns already present (not re-added).
        patterns     Full pattern list after the operation.
        total        Total number of patterns now active.
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    ``0`` on success, ``1`` on error.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  Success.
        1  User error (not initialised, invalid pattern).
        2  Usage error.
    """
    elapsed = start_timer()

    json_out: bool = getattr(args, "json_out", False)
    cfg = _require_config(root)
    _validate_patterns(args.patterns)

    existing = set(cfg["patterns"])
    new_pats = [p for p in args.patterns if p not in existing]
    cfg["patterns"].extend(new_pats)
    write_sparse_config(root, cfg)

    added = len(new_pats)
    skipped = len(args.patterns) - added

    if json_out:
        print(_json.dumps(_SparseAddJson(
            **make_envelope(elapsed),
            added=added,
            skipped=skipped,
            patterns=cfg["patterns"],
            total=len(cfg["patterns"]),
        )))
    else:
        msg = f"Added {added} pattern(s)"
        if skipped:
            msg += f" ({skipped} already present)"
        print(f"{msg}.")

def _cmd_list(args: argparse.Namespace, root: pathlib.Path) -> None:
    """Display the active patterns and mode.

    Returns exit code 0 even when sparse-checkout is disabled — the absence
    of a config is not an error, just a state.  Validates the config structure
    when a config file is present (catches post-hoc corruption).

    Agent quickstart::

        muse sparse-checkout list --json

    JSON fields::

        enabled      ``true`` when sparse-checkout is configured.
        mode         ``"cone"`` or ``"pattern"`` when enabled; ``null`` when disabled.
        patterns     Active pattern list; empty list when disabled.
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    ``0`` on success, ``1`` on config corruption.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  Success (including when sparse-checkout is disabled).
        1  User error (corrupt config).
    """
    elapsed = start_timer()

    json_out: bool = getattr(args, "json_out", False)
    cfg = _read_config_safe(root)

    if cfg is not None:
        _validate_config_structure(cfg)

    if cfg is None:
        if json_out:
            print(_json.dumps(_SparseListJson(
                **make_envelope(elapsed),
                enabled=False,
                mode=None,
                patterns=[],
            )))
        else:
            print("Sparse-checkout is disabled (full working tree).")
        return

    if json_out:
        print(_json.dumps(_SparseListJson(
            **make_envelope(elapsed),
            enabled=True,
            mode=cfg["mode"],
            patterns=cfg["patterns"],
        )))
    else:
        mode = cfg["mode"]
        patterns = cfg["patterns"]
        print(f"Mode:     {mode}")
        print(f"Patterns: {len(patterns)}")
        if patterns:
            print()
            for pat in patterns:
                print(f"  {pat}")
        else:
            print("  (none — matches nothing)")

def _cmd_stats(args: argparse.Namespace, root: pathlib.Path) -> None:
    """Report how many HEAD-snapshot files match the current sparse config.

    Reads the HEAD commit's snapshot manifest and applies the sparse filter,
    counting matching vs. excluded files.  When sparse-checkout is disabled,
    all files are considered matching (efficiency = 1.0).  When no commits
    exist yet, all counts are zero.

    Agent quickstart::

        muse sparse-checkout stats --json

    JSON fields::

        enabled         ``true`` when a sparse-checkout config is present.
        mode            ``"cone"`` or ``"pattern"``; ``null`` when disabled.
        patterns        Active pattern list; empty list when disabled.
        total_files     Total files in the HEAD snapshot (0 if no commits).
        matching_files  Files that pass the sparse filter (or total when disabled).
        excluded_files  ``total_files - matching_files``.
        efficiency      ``matching_files / total_files``; 1.0 when disabled or no files.
        muse_version    Muse release that produced this output.
        schema          Envelope schema version (int).
        exit_code       Always ``0`` on success.
        duration_ms     Wall-clock milliseconds for the command.
        timestamp       ISO-8601 UTC timestamp of command completion.
        warnings        List of non-fatal advisory messages.

    Exit codes::

        0  Success.
        1  User error (corrupt config).
    """
    elapsed = start_timer()

    cfg = _read_config_safe(root)
    if cfg is not None:
        _validate_config_structure(cfg)

    # Resolve the HEAD snapshot manifest.
    total = 0
    manifest = {}
    try:
        from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
        )
        from muse.core.commits import read_commit
        from muse.core.snapshots import read_snapshot
        branch = read_current_branch(root)
        commit_id = get_head_commit_id(root, branch)
        if commit_id is not None:
            commit = read_commit(root, commit_id)
            if commit is not None:
                snap = read_snapshot(root, commit.snapshot_id)
                if snap is not None:
                    manifest = snap.manifest
                    total = len(manifest)
    except Exception:
        pass  # No commits yet — counts stay zero.

    if cfg is None:
        matching = total
    elif total == 0:
        matching = 0
    else:
        matching = len(filter_manifest_sparse(manifest, cfg["patterns"], mode=cfg["mode"]))

    excluded = total - matching
    if total > 0:
        efficiency = round(matching / total, 6)
    else:
        efficiency = 1.0 if cfg is None else 0.0

    print(_json.dumps(_SparseStatsJson(
        **make_envelope(elapsed),
        enabled=cfg is not None,
        mode=cfg["mode"] if cfg else None,
        patterns=cfg["patterns"] if cfg else [],
        total_files=total,
        matching_files=matching,
        excluded_files=excluded,
        efficiency=efficiency,
    )))

def _cmd_disable(args: argparse.Namespace, root: pathlib.Path) -> None:
    """Remove the sparse-checkout config.

    Idempotent — no error if already disabled.  The next ``checkout`` or
    ``merge`` will materialise the full working tree.

    Agent quickstart::

        muse sparse-checkout disable --json

    JSON fields::

        was_enabled  ``true`` when sparse-checkout was active before this command.
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    ``0`` on success.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  Success (including when sparse-checkout was already disabled).
        1  User error (corrupt config).
    """
    elapsed = start_timer()

    json_out: bool = getattr(args, "json_out", False)
    cfg = _read_config_safe(root)
    was_enabled = cfg is not None

    if was_enabled:
        remove_sparse_config(root)

    if json_out:
        print(_json.dumps(_SparseDisableJson(
            **make_envelope(elapsed),
            was_enabled=was_enabled,
        )))
    else:
        if was_enabled:
            print("Sparse-checkout disabled. Full working tree will be restored on next checkout.")
        else:
            print("Sparse-checkout is already disabled.")

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``muse sparse-checkout`` subcommand."""
    parser = subparsers.add_parser(
        "sparse-checkout",
        help="Partial working-tree materialization.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="sc_command", metavar="SUBCOMMAND")
    sub.required = True

    # init
    p_init = sub.add_parser(
        "init",
        help="Activate sparse-checkout (or switch mode on existing config).",
    )
    p_init.add_argument(
        "--no-cone",
        action="store_true",
        default=False,
        help="Use glob-pattern mode instead of cone (directory-prefix) mode.",
    )
    p_init.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON output.",
    )
    p_init.set_defaults(sc_func=_cmd_init)

    # set
    p_set = sub.add_parser("set", help="Replace pattern list.")
    p_set.add_argument("patterns", nargs="+", metavar="PATTERN")
    p_set.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON output.",
    )
    p_set.set_defaults(sc_func=_cmd_set)

    # add
    p_add = sub.add_parser("add", help="Append patterns.")
    p_add.add_argument("patterns", nargs="+", metavar="PATTERN")
    p_add.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON output.",
    )
    p_add.set_defaults(sc_func=_cmd_add)

    # list
    p_list = sub.add_parser("list", help="Show active patterns.")
    p_list.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON output.",
    )
    p_list.set_defaults(sc_func=_cmd_list)

    # stats
    p_stats = sub.add_parser(
        "stats",
        help="Show how many HEAD-snapshot files match the sparse config.",
    )
    p_stats.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON output (default for stats).",
    )
    p_stats.set_defaults(sc_func=_cmd_stats)

    # disable
    p_dis = sub.add_parser("disable", help="Remove sparse-checkout configuration.")
    p_dis.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON output.",
    )
    p_dis.set_defaults(sc_func=_cmd_disable)

    parser.set_defaults(func=run)

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    """Dispatch ``muse sparse-checkout`` to the appropriate subcommand handler.

    Subcommands: ``init``, ``set``, ``add``, ``list``, ``stats``, ``disable``.
    Each handler carries its own docstring, JSON schema, and exit codes.
    """
    root = require_repo()
    args.sc_func(args, root)
