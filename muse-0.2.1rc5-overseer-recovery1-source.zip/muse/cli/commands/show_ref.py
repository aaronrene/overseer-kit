"""muse show-ref — list all refs known to this repository.

Enumerates every branch ref stored under ``.muse/refs/heads/`` and reports
the commit ID each one points to.  Optionally filters by a glob pattern,
reports only the HEAD ref, verifies that a specific ref exists, or emits
only a count.

Output (JSON, default)::

    {
      "refs": [
        {"ref": "refs/heads/dev",  "commit_id": "<sha256>"},
        {"ref": "refs/heads/main", "commit_id": "<sha256>"}
      ],
      "head": {
        "ref":       "refs/heads/main",
        "branch":    "main",
        "commit_id": "<sha256>"
      },
      "count":      2,
      "duration_ms": 1.3,
      "exit_code":  0
    }

Text output (``--format text``)::

    <sha256>  refs/heads/dev
  * <sha256>  refs/heads/main  (HEAD)

Error output (``--json``, always to stdout so agents can parse failures)::

    {
      "error":      "io_error",
      "message":    "<detail>",
      "duration_ms": 0.4,
      "exit_code":  3
    }

Output contract
---------------

- Exit 0: refs enumerated successfully (list may be empty).
- Exit 0: verify mode and ref exists.
- Exit 1: bad ``--format`` value; verify mode and ref does not exist.
- Exit 3: I/O error reading refs directory.
- All JSON responses carry ``duration_ms`` (wall-clock ms) and ``exit_code``
  so agent pipelines can parse timing and success uniformly.

Agent use
---------

Check whether a branch exists before starting work::

    muse show-ref --verify refs/heads/feat/my-task --json
    # → {"ref": "refs/heads/feat/my-task", "exists": true}

Count branches for capacity planning::

    muse show-ref --count
    # → {"count": 42}

Filter to a lane::

    muse show-ref --pattern 'refs/heads/task/*' --json

Read HEAD without a round-trip to status::

    muse show-ref --head --json
    # → {"head": {"ref": "refs/heads/main", "branch": "main", "commit_id": "<sha256>"}}
"""

import argparse
import fnmatch
import json
import logging
import pathlib
import sys
from typing import TypedDict

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.paths import muse_dir as _muse_dir
from muse.core.errors import ExitCode
from muse.core.refs import iter_branch_refs
from muse.core.repo import require_repo
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.validation import sanitize_display, validate_object_id
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

_SHA256_HEX_LEN = 64

class _RefEntry(TypedDict):
    ref: str
    commit_id: str

class _HeadInfo(TypedDict):
    ref: str
    branch: str
    commit_id: str

class _ShowRefResult(EnvelopeJson):
    refs: list[_RefEntry]
    head: _HeadInfo | None
    count: int

def _list_branch_refs(root: pathlib.Path) -> list[_RefEntry]:
    """Return every branch ref under ``.muse/refs/heads/``, sorted by name.

    Symlinks and empty ref files are skipped by :func:`iter_branch_refs`.
    Ref files whose content is not a valid 64-char hex SHA-256 are also
    skipped with a debug log — guards against corrupt or adversarially
    crafted ref files injecting invalid commit IDs into consumer pipelines.
    """
    refs: list[_RefEntry] = []
    for branch, commit_id in sorted(iter_branch_refs(root)):
        try:
            validate_object_id(commit_id)
        except ValueError:
            logger.debug(
                "show-ref: skipping ref %r — invalid commit ID %r",
                branch, commit_id,
            )
            continue
        refs.append({"ref": f"refs/heads/{branch}", "commit_id": commit_id})
    return refs

def _head_info(root: pathlib.Path) -> _HeadInfo | None:
    """Return metadata about what HEAD currently points to, or ``None``."""
    try:
        muse_dir = _muse_dir(root)
        branch = read_current_branch(root)
    except Exception:
        return None
    commit_id = get_head_commit_id(root, branch)
    if commit_id is None:
        return None
    return {
        "ref": f"refs/heads/{branch}",
        "branch": branch,
        "commit_id": commit_id,
    }

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the show-ref subcommand."""
    parser = subparsers.add_parser(
        "show-ref",
        help="List all branch refs and their commit IDs.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--pattern", "-p",
        default=None,
        dest="pattern",
        metavar="GLOB",
        help="fnmatch glob filter applied to the full ref name (e.g. 'refs/heads/feat/*').",
    )
    parser.add_argument(
        "--head", "-H",
        action="store_true",
        dest="head_only",
        help="Print only the HEAD ref and its commit ID.",
    )
    parser.add_argument(
        "--verify", "-v",
        default=None,
        dest="verify_ref",
        metavar="REF",
        help=(
            "Check whether the given ref exists. "
            "Exits 0 if found, 1 if not. "
            "With --json, emits {\"ref\": ..., \"exists\": bool} to stdout."
        ),
    )
    parser.add_argument(
        "--count",
        action="store_true",
        dest="count_only",
        help=(
            "Emit only the branch count. "
            "With --json, emits {\"count\": N}. "
            "With --pattern, counts matching refs. "
            "Useful for capacity planning in agent pipelines."
        ),
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON.",
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """List all refs known to this repository.

    Reads every branch pointer from ``.muse/refs/heads/`` and reports their
    commit IDs, sorted lexicographically.  Ref files that are symlinks or
    contain non-hex content are silently skipped to guard against corrupt
    or adversarially crafted ref stores.

    Agent quickstart::

        muse show-ref --json
        muse show-ref --verify refs/heads/feat/my-task --json
        muse show-ref --pattern 'refs/heads/task/*' --json
        muse show-ref --head --json

    JSON fields::

        refs            list        All refs: [{ref, commit_id}, ...]
        head            obj|null    HEAD info: {ref, branch, commit_id}
        count           int         Number of refs returned

    Exit codes::

        0  Success (empty list is valid).
        1  Bad --format, or --verify ref not found.
        3  I/O error reading refs directory.
    """
    json_out: bool = args.json_out
    pattern: str | None = args.pattern
    head_only: bool = args.head_only
    verify_ref: str | None = args.verify_ref
    count_only: bool = args.count_only

    elapsed = start_timer()

    def _emit_error(msg: str, code: int, error_key: str = "error") -> None:
        """Emit a structured error to stdout (JSON) or stderr (text) then exit."""
        if json_out:
            print(json.dumps({
                **make_envelope(elapsed, exit_code=code),
                "error": error_key,
                "message": msg,
            }))
        else:
            print(f"❌ Error: {msg}", file=sys.stderr)
        raise SystemExit(code)

    root = require_repo()

    # --verify mode: existence check.
    if verify_ref is not None:
        try:
            all_refs = _list_branch_refs(root)
        except Exception as exc:
            logger.debug("show-ref I/O error: %s", exc)
            _emit_error(str(exc), ExitCode.INTERNAL_ERROR, "io_error")
        exists = any(r["ref"] == verify_ref for r in all_refs)
        code = 0 if exists else ExitCode.USER_ERROR
        if json_out:
            print(json.dumps({
                **make_envelope(elapsed, exit_code=code),
                "ref": verify_ref,
                "exists": exists,
            }))
        raise SystemExit(code)

    # --head mode: only HEAD.
    if head_only:
        info = _head_info(root)
        if info is None:
            if not json_out:
                print("(no HEAD commit)")
            else:
                print(json.dumps({
                    **make_envelope(elapsed),
                    "head": None,
                }))
            return

        if not json_out:
            print(
                f"{sanitize_display(info['commit_id'])}  "
                f"{sanitize_display(info['ref'])}  (HEAD)"
            )
        else:
            print(json.dumps({
                **make_envelope(elapsed),
                "head": dict(info),
            }))
        return

    # Collect refs, applying optional glob filter.
    try:
        refs = _list_branch_refs(root)
    except Exception as exc:
        logger.debug("show-ref I/O error: %s", exc)
        _emit_error(str(exc), ExitCode.INTERNAL_ERROR, "io_error")

    if pattern is not None:
        refs = [r for r in refs if fnmatch.fnmatch(r["ref"], pattern)]

    # --count mode: emit count only.
    if count_only:
        if not json_out:
            print(str(len(refs)))
        else:
            print(json.dumps({
                **make_envelope(elapsed),
                "count": len(refs),
            }))
        return

    head = _head_info(root)

    if not json_out:
        head_ref = head["ref"] if head else None
        for r in refs:
            is_head = r["ref"] == head_ref
            marker = "* " if is_head else "  "
            suffix = "  (HEAD)" if is_head else ""
            print(
                f"{sanitize_display(r['commit_id'])}  "
                f"{marker}{sanitize_display(r['ref'])}{suffix}"
            )
        return

    result = _ShowRefResult(
        **make_envelope(elapsed),
        refs=refs,
        head=head,
        count=len(refs),
    )
    print(json.dumps(result))
