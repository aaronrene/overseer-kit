"""``muse bundle`` — pack and unpack commits for single-file transport.

A bundle is a self-contained msgpack binary file carrying commits, snapshots,
and objects.  It wraps ``muse pack-objects`` / ``unpack-objects`` with friendlier
names and the key value-add of auto-updating local branch refs after ``unbundle``.

Use bundles to transfer a repository slice between machines without a network
connection — copy the file over SSH, USB, or email.

Bundle format: binary msgpack encoding of the ``MPack`` TypedDict.
Objects are stored as raw bytes (no base64 overhead).

Subcommands::

    muse bundle create   <file> [<ref>...] [--have <id>...] [--json]
    muse bundle unbundle <file> [--no-update-refs] [--json]
    muse bundle verify   <file> [-q] [--json]
    muse bundle list-heads <file> [--json]

Security model::

    Symlinks inside ``.muse/refs/heads/`` are silently skipped during branch
    enumeration.  A crafted symlink could otherwise expose external path content.

    Ref files are read at most 65 bytes; oversized files are treated as invalid
    refs rather than read entirely into memory.

    Bundle file parsing is limited by ``MAX_PACK_MSGPACK_BYTES``; both the file
    size and the msgpack payload are checked before any deserialization occurs.

JSON output schemas::

    bundle create --json:
        {"file": str, "commits": int, "blobs": int,
         "size_bytes": int, "branches": [str, ...]}

    bundle unbundle --json:
        {"commits_written": int, "snapshots_written": int,
         "blobs_written": int, "blobs_skipped": int,
         "refs_updated": [str, ...], "verified": bool}

    bundle verify --json:
        {"blobs_checked": int, "snapshots_checked": int,
         "all_ok": bool, "failures": [str, ...]}

    bundle list-heads --json:
        {"<branch>": "<commit_id>", ...}

Exit codes::

    0 — success
    1 — bundle not found, integrity failure, bad arguments
    3 — I/O error
"""

import argparse
import json
import logging
import os
import pathlib
import sys
import tempfile
from typing import TypedDict, TypeGuard

import msgpack

from muse.core.types import blob_id, short_id
from muse.core.paths import heads_dir as _heads_dir
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.timing import start_timer
from muse.core.errors import ExitCode
from muse.core.object_store import has_object, write_object
from muse.core.mpack import MPack, apply_mpack, build_mpack
from muse.core.repo import require_repo
from muse.core.io import (
    MAX_PACK_MSGPACK_BYTES,
    safe_unpackb,
)
from muse.core.types import (
    BranchHeads,
    MsgpackValue,
)
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
    write_branch_ref,
)
from muse.core.commits import (
    CommitDict,
    CommitRecord,
    read_commit,
    resolve_commit_ref,
    write_commit,
)
from muse.core.snapshots import (
    SnapshotDict,
    SnapshotRecord,
    write_snapshot,
)
from muse.core.validation import sanitize_display, validate_branch_name

logger = logging.getLogger(__name__)

# Maximum bytes read from a branch ref file.  A valid canonical commit ID is
# "sha256:" (7 chars) + 64 hex chars + optional newline = 72 bytes.  Anything
# larger is treated as corrupt.
_MAX_REF_BYTES = 72

# Maximum number of distinct failures collected during ``muse bundle verify``.
# Caps memory and output size when a crafted bundle has many corrupted objects.
_MAX_VERIFY_FAILURES = 100

# ---------------------------------------------------------------------------
# JSON wire-format TypedDicts
# ---------------------------------------------------------------------------

class _BundleCreateJson(EnvelopeJson):
    """JSON output for ``muse bundle create --json``."""

    file: str
    commits: int
    objects: int
    size_bytes: int
    branches: list[str]

class _BundleUnbundleJson(EnvelopeJson):
    """JSON output for ``muse bundle unbundle --json``."""

    commits_written: int
    snapshots_written: int
    blobs_written: int
    blobs_skipped: int
    refs_updated: list[str]
    verified: bool

class _BundleVerifyJson(EnvelopeJson):
    """JSON output for ``muse bundle verify --json``."""

    blobs_checked: int
    snapshots_checked: int
    all_ok: bool
    failures: list[str]

class _BundleInspectCommit(TypedDict):
    """Per-commit entry in ``muse bundle inspect --json`` output."""

    commit_id: str
    message: str
    committed_at: str
    agent_id: str
    branches: list[str]

class _BundleInspectJson(EnvelopeJson):
    """JSON output for ``muse bundle inspect --json``."""

    total_commits: int
    total_objects: int
    branches: dict[str, str]  # branch_name → commit_id (sha256:<64hex>)
    commits: list[_BundleInspectCommit]

class _BundleDiffCommit(TypedDict):
    """Per-commit entry in ``muse bundle diff --json`` output."""

    commit_id: str
    message: str
    committed_at: str

class _BundleDiffJson(EnvelopeJson):
    """JSON output for ``muse bundle diff --json``."""

    new_commits: int
    known_commits: int
    refs_to_advance: list[str]   # branch names that would move forward
    commits: list[_BundleDiffCommit]  # new commits not yet in local repo

class _BundleListHeadsJson(EnvelopeJson):
    """JSON output for ``muse bundle list-heads --json``."""

    heads: dict[str, str]  # branch_name → commit_id

# ---------------------------------------------------------------------------
# TypeGuards for wire-boundary narrowing
# ---------------------------------------------------------------------------

def _is_commit_dict(v: MsgpackValue) -> TypeGuard[CommitDict]:
    """TypeGuard for narrowing MsgpackValue → CommitDict at the wire boundary."""
    return isinstance(v, dict)

def _is_snapshot_dict(v: MsgpackValue) -> TypeGuard[SnapshotDict]:
    """TypeGuard for narrowing MsgpackValue → SnapshotDict at the wire boundary."""
    return isinstance(v, dict)

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _resolve_refs(
    root: pathlib.Path,
    branch: str,
    refs: list[str],
) -> list[str]:
    """Resolve a list of ref strings to commit IDs.  Expands ``HEAD``."""
    ids: list[str] = []
    for ref in refs:
        if ref.upper() == "HEAD":
            cid = get_head_commit_id(root, branch)
            if cid:
                ids.append(cid)
        else:
            rec = resolve_commit_ref(root, branch, ref)
            if rec:
                ids.append(rec.commit_id)
            else:
                print(f"❌ Ref '{sanitize_display(ref)}' not found.", file=sys.stderr)
                raise SystemExit(ExitCode.USER_ERROR)
    return ids

def _load_bundle(file_path: pathlib.Path) -> MPack:
    """Read a msgpack bundle file and return a :class:`~muse.core.mpack.MPack`.

    Security:
        The file size is checked before reading.  The raw bytes are then
        passed through :func:`~muse.core.store.safe_unpackb` which enforces
        an upper bound on the deserialized payload as well.  This double-check
        prevents OOM from crafted size-bomb bundles.

        Exceptions are narrowed to :class:`(OSError, ValueError,
        msgpack.UnpackException)` — the precise types raised by the I/O and
        parse path — so genuine programming errors are not silently swallowed.
    """
    try:
        size = file_path.stat().st_size
        if size > MAX_PACK_MSGPACK_BYTES:
            raise OSError(
                f"Bundle file is {size:,} bytes — exceeds the "
                f"{MAX_PACK_MSGPACK_BYTES // (1024 * 1024)} MiB safety cap."
            )
        raw_bytes = file_path.read_bytes()
        parsed = safe_unpackb(
            raw_bytes,
            context="bundle file",
            max_bytes=MAX_PACK_MSGPACK_BYTES,
            allow_binary=True,
        )
    except FileNotFoundError:
        print(
            f"❌ Bundle file not found: {sanitize_display(str(file_path))}",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)
    except (OSError, ValueError, msgpack.UnpackException) as exc:
        print(f"❌ Bundle is not valid msgpack: {sanitize_display(str(exc))}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    if not isinstance(parsed, dict):
        print("❌ Bundle has unexpected structure.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    from muse.core.mpack import BlobPayload

    bundle: MPack = {}
    raw_commits = parsed.get("commits")
    if isinstance(raw_commits, list):
        bundle["commits"] = [r for r in raw_commits if _is_commit_dict(r)]
    raw_snapshots = parsed.get("snapshots")
    if isinstance(raw_snapshots, list):
        bundle["snapshots"] = [r for r in raw_snapshots if _is_snapshot_dict(r)]
    if "blobs" in parsed and isinstance(parsed["blobs"], list):
        blobs: list[BlobPayload] = []
        for item in parsed["blobs"]:
            if isinstance(item, dict):
                oid = item.get("object_id")
                content = item.get("content")
                if isinstance(oid, str) and isinstance(content, (bytes, bytearray)):
                    blobs.append(BlobPayload(object_id=oid, content=bytes(content)))
        bundle["blobs"] = blobs
    if "branch_heads" in parsed and isinstance(parsed["branch_heads"], dict):
        bundle["branch_heads"] = {
            k: v
            for k, v in parsed["branch_heads"].items()
            if isinstance(k, str) and isinstance(v, str)
        }
    return bundle

def _iter_branches(root: pathlib.Path) -> list[tuple[str, str]]:
    """Return ``[(branch_name, commit_id)]`` for all branch ref files.

    Security:
        Symlinks inside ``.muse/refs/heads/`` are silently skipped.
        Ref files are capped at ``_MAX_REF_BYTES`` (65 bytes) before
        decoding — oversized content is decoded but will fail hex
        validation downstream.
    """
    heads_dir = _heads_dir(root)
    if not heads_dir.exists():
        return []
    result: list[tuple[str, str]] = []
    for ref_file in sorted(heads_dir.rglob("*")):
        if ref_file.is_symlink():
            logger.warning("⚠️ bundle: skipping symlink ref: %s", ref_file)
            continue
        if not ref_file.is_file():
            continue
        raw_bytes = ref_file.read_bytes()[:_MAX_REF_BYTES]
        cid = raw_bytes.decode("utf-8", errors="replace").strip()
        if cid:
            branch_name = str(ref_file.relative_to(heads_dir).as_posix())
            result.append((branch_name, cid))
    return result

def _reachable_from(root: pathlib.Path, tip_ids: list[str]) -> set[str]:
    """Return all commit IDs reachable from *tip_ids*."""
    from muse.core.graph import ancestor_ids
    return ancestor_ids(root, tip_ids)

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the bundle subcommand."""
    parser = subparsers.add_parser(
        "bundle",
        help="Pack and unpack commits into a single portable bundle file.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subs = parser.add_subparsers(dest="subcommand", metavar="SUBCOMMAND")
    subs.required = True

    # create
    create_p = subs.add_parser(
        "create",
        help="Create a bundle file containing commits reachable from <refs>.",
        description=(
            "Pack commits, snapshots, and objects reachable from <refs> into a\n"
            "single self-contained msgpack binary file.  Transfer it over SSH,\n"
            "USB, or email and apply it with ``muse bundle unbundle``.\n\n"
            "Use --have to prune commits the receiver already has, producing a\n"
            "smaller incremental bundle.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse bundle create repo.bundle --json\n"
            "  muse bundle create out.bundle feat/audio --json\n"
            "  muse bundle create out.bundle HEAD --have <old-sha> --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"file": "<path>", "commits": <int>, "blobs": <int>,\n'
            '   "size_bytes": <int>, "branches": ["<branch>", ...]}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — bundle created successfully\n"
            "  1 — unknown ref, no commits to bundle, or bad --have ref\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    create_p.add_argument("file", help="Output bundle file path.")
    create_p.add_argument(
        "refs", nargs="*", default=None,
        help="Refs to include (default: HEAD).",
    )
    create_p.add_argument(
        "--have", "-H", nargs="*", default=None, dest="have",
        help="Commits the receiver already has (exclude from bundle).",
    )
    create_p.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit a machine-readable JSON summary.",
    )
    create_p.set_defaults(func=run_create)

    # list-heads
    list_heads_p = subs.add_parser(
        "list-heads",
        help="List the branch heads recorded in a bundle file.",
        description=(
            "Print the branch → commit_id map embedded in a bundle file.\n"
            "Does NOT require a Muse repository — runs against any bundle\n"
            "file in isolation.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse bundle list-heads repo.bundle --json\n"
            "  muse bundle list-heads repo.bundle --json | jq 'keys'\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"<branch>": "sha256:<64hex>", ...}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — always (empty object when no heads are recorded)\n"
            "  1 — bundle file not found or not valid msgpack\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    list_heads_p.add_argument("file", help="Bundle file to inspect.")
    list_heads_p.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit a machine-readable JSON map of branch → commit_id.",
    )
    list_heads_p.set_defaults(func=run_list_heads)

    # unbundle
    unbundle_p = subs.add_parser(
        "unbundle",
        help="Apply a bundle to the local store and optionally advance branch refs.",
        description=(
            "Write all commits, snapshots, and objects from a bundle file into\n"
            "the local repository, then advance local branch refs to match the\n"
            "bundle's recorded heads.  All writes are idempotent — objects\n"
            "already present are counted as 'skipped', not errors.\n\n"
            "Use --no-update-refs to import objects without moving any branches\n"
            "(useful for inspection or partial imports).\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse bundle unbundle repo.bundle --json\n"
            "  muse bundle unbundle repo.bundle --no-update-refs --json\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"commits_written": <int>, "snapshots_written": <int>,\n'
            '   "blobs_written": <int>, "blobs_skipped": <int>,\n'
            '   "refs_updated": ["<branch>", ...]}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — bundle applied (even if all objects were already present)\n"
            "  1 — bundle file not found or not valid msgpack\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    unbundle_p.add_argument("file", help="Bundle file to apply.")
    unbundle_p.add_argument(
        "--no-update-refs", action="store_false", dest="update_refs",
        help="Do not update local branch refs from the bundle's branch_heads.",
    )
    unbundle_p.add_argument(
        "--verify", action="store_true", dest="verify_first",
        help=(
            "Verify bundle integrity before applying.  Exits 1 without writing "
            "anything if the bundle is corrupt."
        ),
    )
    unbundle_p.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit a machine-readable JSON summary.",
    )
    unbundle_p.set_defaults(func=run_unbundle, update_refs=True, verify_first=False)

    # inspect
    inspect_p = subs.add_parser(
        "inspect",
        help="Show the commit log and branch state recorded in a bundle file.",
        description=(
            "Read and display commits, branch heads, and agent provenance from\n"
            "a bundle file without applying it.  No Muse repository required —\n"
            "safe to run before deciding whether to unbundle.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse bundle inspect repo.bundle --json\n"
            "  # → total_commits, branches map, per-commit message + agent_id\n\n"
            "Typical agent workflow\n"
            "----------------------\n"
            "  muse bundle inspect bundle.muse --json   # what's in it?\n"
            "  muse bundle verify  bundle.muse -q       # is it clean?\n"
            "  muse bundle diff    bundle.muse --json   # what's new?\n"
            "  muse bundle unbundle bundle.muse --verify # apply safely\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"total_commits": int, "total_objects": int,\n'
            '   "branches": {"<name>": "sha256:<64hex>"},\n'
            '   "commits": [{"commit_id": str, "message": str,\n'
            '                "committed_at": str, "agent_id": str,\n'
            '                "branches": [str]}, ...]}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — bundle read successfully (even if empty)\n"
            "  1 — bundle file not found or not valid msgpack\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    inspect_p.add_argument("file", help="Bundle file to inspect.")
    inspect_p.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit a machine-readable JSON summary.",
    )
    inspect_p.set_defaults(func=run_inspect)

    # diff
    diff_p = subs.add_parser(
        "diff",
        help="Show which commits in a bundle are not yet in the local repository.",
        description=(
            "Compare a bundle's commits against the local repository and report\n"
            "which ones are new (not yet present).  Agents use this to answer\n"
            "\"what would this bundle add?\" before deciding to apply it.\n\n"
            "Requires a Muse repository (unlike inspect, verify, list-heads).\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse bundle diff repo.bundle --json\n"
            "  # → new_commits, known_commits, refs_to_advance, commit list\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"new_commits": int, "known_commits": int,\n'
            '   "refs_to_advance": ["<branch>", ...],\n'
            '   "commits": [{"commit_id": str, "message": str,\n'
            '                "committed_at": str}, ...]}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — diff computed (even if new_commits == 0)\n"
            "  1 — bundle file not found or not valid msgpack\n"
            "  2 — not inside a Muse repository\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    diff_p.add_argument("file", help="Bundle file to diff against the local repo.")
    diff_p.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit a machine-readable JSON report.",
    )
    diff_p.set_defaults(func=run_diff)

    # verify
    verify_p = subs.add_parser(
        "verify",
        help="Verify the integrity of a bundle file.",
        description=(
            "Check every object's SHA-256 against its declared object_id\n"
            "(detects corruption), and confirm every snapshot's objects are\n"
            "present in the bundle (detects truncation).  Does NOT require a\n"
            "Muse repository — runs against any bundle file in isolation.\n\n"
            "Use --quiet for scripting: no output, just the exit code.\n\n"
            "Agent quickstart\n"
            "----------------\n"
            "  muse bundle verify repo.bundle --json\n"
            "  muse bundle verify repo.bundle -q && muse bundle unbundle repo.bundle\n\n"
            "JSON output schema\n"
            "------------------\n"
            '  {"blobs_checked": <int>, "snapshots_checked": <int>,\n'
            '   "all_ok": true|false, "failures": ["<description>", ...]}\n\n'
            "Exit codes\n"
            "----------\n"
            "  0 — bundle is clean\n"
            "  1 — integrity failures, or bundle file not found / not valid\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    verify_p.add_argument("file", help="Bundle file to verify.")
    verify_p.add_argument(
        "--quiet", "-q", action="store_true", dest="quiet",
        help="No output — exit 0 if clean, 1 on failure.",
    )
    verify_p.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit a machine-readable JSON report.",
    )
    verify_p.set_defaults(func=run_verify)

# ---------------------------------------------------------------------------
# Subcommand handlers
# ---------------------------------------------------------------------------

def run_create(args: argparse.Namespace) -> None:
    """Pack commits reachable from <refs> into a portable bundle file.

    A bundle is a self-contained msgpack binary carrying commits, snapshots,
    and objects.  Copy the file over SSH, USB, or email, then apply it with
    ``muse bundle unbundle``.  Use ``--have`` to produce an incremental bundle
    by pruning commits the receiver already has.  The output file is written
    atomically — a kill signal never leaves a partial bundle at the target path.

    Agent quickstart
    ----------------
    ::

        muse bundle create repo.bundle --json
        muse bundle create out.bundle feat/audio --json
        muse bundle create out.bundle HEAD --have <old-sha> --json

    JSON fields
    -----------
    file         Absolute path to the bundle file written.
    commits      Number of commits packed.
    objects      Number of content objects packed.
    size_bytes   Final file size in bytes.
    branches     List of branch names whose tip is included in the bundle.

    Exit codes
    ----------
    0  Bundle created successfully.
    1  Unknown ref, no commits to bundle, or bad ``--have`` ref.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    file: str = args.file
    refs: list[str] | None = args.refs
    have: list[str] | None = args.have
    json_out: bool = args.json_out

    root = require_repo()
    branch = read_current_branch(root)

    want_refs: list[str] = refs or ["HEAD"]
    commit_ids = _resolve_refs(root, branch, want_refs)

    if not commit_ids:
        print("❌ No commits to bundle.", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    have_ids: list[str] = have or []
    bundle = build_mpack(root, commit_ids, have=have_ids)

    # Pre-compute the reachable set once (O(commits)) so the branch-head
    # filter below is O(branches) rather than O(branches × commits).
    reachable: set[str] = _reachable_from(root, commit_ids)
    heads: BranchHeads = {}
    for br_name, cid in _iter_branches(root):
        if cid in commit_ids or cid in reachable:
            heads[br_name] = cid
    if heads:
        bundle["branch_heads"] = heads

    out_path = pathlib.Path(file)
    packed = msgpack.packb(bundle, use_bin_type=True)

    # Atomic write: temp file in same directory → os.replace().
    # Ensures a kill signal never leaves a partial bundle at out_path.
    tmp_dir = out_path.parent if out_path.parent != pathlib.Path("") else pathlib.Path(".")
    tmp_fd, tmp_str = tempfile.mkstemp(dir=tmp_dir, prefix=".bundle-tmp-")
    tmp_path_obj = pathlib.Path(tmp_str)
    try:
        with os.fdopen(tmp_fd, "wb") as fh:
            fh.write(packed)
        os.replace(tmp_path_obj, out_path)
    except Exception:
        tmp_path_obj.unlink(missing_ok=True)
        raise

    n_commits = len(bundle.get("commits", []))
    n_blobs = len(bundle.get("blobs", []))
    size_bytes = out_path.stat().st_size

    if json_out:
        print(json.dumps(_BundleCreateJson(
            **make_envelope(elapsed),
            file=str(out_path),
            commits=n_commits,
            blobs=n_blobs,
            size_bytes=size_bytes,
            branches=sorted(heads.keys()),
        )))
    else:
        size_kb = size_bytes / 1024
        print(
            f"✅ Bundle: {sanitize_display(str(out_path))}  "
            f"({n_commits} commits, {n_blobs} blobs, {size_kb:.1f} KiB)"
        )

def _verify_bundle_integrity(bundle: "MPack") -> list[str]:
    """Run integrity checks on *bundle* and return a list of failure strings.

    Returns an empty list when the bundle is clean.  This is the shared core
    used by both ``run_verify`` and the ``--verify`` flag on ``run_unbundle``.
    """
    failures: list[str] = []

    bundle_obj_ids: set[str] = set()
    for obj in bundle.get("blobs", []):
        obj_id = obj.get("object_id", "")
        raw = obj.get("content", b"")
        if not obj_id:
            failures.append("blobs list: entry has missing object_id")
            continue
        # NOTE: raw may be b"" for empty files — that is valid.
        actual = blob_id(raw)
        if actual != obj_id:
            failures.append(f"blob {obj_id}: hash mismatch (corruption)")
        else:
            bundle_obj_ids.add(obj_id)

    for snap_dict in bundle.get("snapshots", []):
        snap_id = snap_dict.get("snapshot_id", "")
        # Bundles use delta_upsert since feat(pack): delta-encode snapshots (1a6566e77).
        # Only new objects introduced by this delta need to be present in the bundle;
        # objects from parent snapshots live on the receiver's side.
        delta_upsert: dict[str, str] = snap_dict.get("delta_upsert") or {}
        for rel_path, obj_id in delta_upsert.items():
            if obj_id not in bundle_obj_ids:
                failures.append(
                    f"snapshot {snap_id}: "
                    f"missing object {obj_id} for {rel_path}"
                )
    return failures

def run_inspect(args: argparse.Namespace) -> None:
    """Show the commit log and branch state recorded in a bundle file.

    Reads all commits, branch heads, and agent provenance from a bundle file
    without writing anything to the local repository.  Does NOT require a Muse
    repository — safe to run against any bundle file in isolation.  Commits are
    sorted newest-first by ``committed_at``.

    Agent quickstart
    ----------------
    ::

        muse bundle inspect repo.bundle --json
        muse bundle inspect repo.bundle --json | jq '.commits[].message'

    JSON fields
    -----------
    total_commits  Number of commits in the bundle.
    total_objects  Number of content objects in the bundle.
    branches       Map of branch name → ``sha256:<64hex>`` commit ID.
    commits        List of commit objects, each with: ``commit_id``,
                   ``message`` (first line, max 72 chars), ``committed_at``
                   (ISO-8601), ``agent_id``, and ``branches`` (list of branch
                   names whose tip is this commit).

    Exit codes
    ----------
    0  Bundle read successfully (``total_commits=0`` for an empty bundle).
    1  Bundle file not found or not valid msgpack.
    """
    elapsed = start_timer()
    file: str = args.file
    json_out: bool = args.json_out

    bundle = _load_bundle(pathlib.Path(file))

    # Branch heads map: branch_name → commit_id (sha256: prefixed).
    raw_heads: "BranchHeads" = bundle.get("branch_heads") or {}
    # Invert for annotation: commit_id → [branch_name, ...]
    cid_to_branches: dict[str, list[str]] = {}
    for br, cid in raw_heads.items():
        cid_to_branches.setdefault(cid, []).append(br)

    # Build commit entries from the bundle's commits list.
    commit_entries: list["_BundleInspectCommit"] = []
    for c in bundle.get("commits", []):
        cid = c.get("commit_id", "")
        message_raw = c.get("message", "")
        message = sanitize_display(message_raw.splitlines()[0][:72]) if message_raw else ""
        committed_at = c.get("committed_at", "")
        agent_id = sanitize_display(c.get("agent_id", "") or "")
        branches = sorted(sanitize_display(b) for b in cid_to_branches.get(cid, []))
        commit_entries.append(_BundleInspectCommit(
            commit_id=cid,
            message=message,
            committed_at=committed_at,
            agent_id=agent_id,
            branches=branches,
        ))

    # Sort newest-first by committed_at (ISO-8601 sorts lexicographically).
    commit_entries.sort(key=lambda e: e["committed_at"], reverse=True)

    total_commits = len(commit_entries)
    total_blobs = len(bundle.get("blobs", []))
    branches_out = {
        sanitize_display(k): sanitize_display(v)
        for k, v in raw_heads.items()
    }

    if json_out:
        print(json.dumps(_BundleInspectJson(
            **make_envelope(elapsed),
            total_commits=total_commits,
            total_objects=total_blobs,
            branches=branches_out,
            commits=commit_entries,
        )))
    else:
        print(f"Commits: {total_commits}")
        print(f"Blobs:   {total_blobs}")
        if branches_out:
            print(f"Branches: {', '.join(sorted(branches_out))}")
        else:
            print("Branches: (none)")
        print()
        for entry in commit_entries:
            short = short_id(entry["commit_id"])
            ts = entry["committed_at"][:19] if entry["committed_at"] else "unknown"
            agent = f"  [{entry['agent_id']}]" if entry["agent_id"] else ""
            br_str = f"  ({', '.join(entry['branches'])})" if entry["branches"] else ""
            print(f"{short}  {ts}{agent}{br_str}")
            print(f"  {entry['message']}")

def run_diff(args: argparse.Namespace) -> None:
    """Show which commits in a bundle are not yet in the local repository.

    Compares each bundle commit against the local store and reports which are
    new.  Also reports which branch refs would advance if the bundle were
    applied.  ``new_commits=0`` means the repo is already up-to-date.  Requires
    a Muse repository (unlike ``inspect``, ``verify``, ``list-heads``).

    Agent quickstart
    ----------------
    ::

        muse bundle diff repo.bundle --json
        muse bundle diff repo.bundle --json | jq '.new_commits'

    JSON fields
    -----------
    new_commits     Number of commits in the bundle not yet in the local store.
    known_commits   Number of commits already present locally.
    refs_to_advance Branch names whose local tip differs from the bundle tip.
    commits         List of new commit objects, each with: ``commit_id``,
                    ``message`` (first line, max 72 chars), ``committed_at``
                    (ISO-8601). Sorted newest-first.

    Exit codes
    ----------
    0  Diff computed (even when ``new_commits == 0``).
    1  Bundle file not found or not valid msgpack.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    file: str = args.file
    json_out: bool = args.json_out

    root = require_repo()
    bundle = _load_bundle(pathlib.Path(file))

    new_entries: list[_BundleDiffCommit] = []
    known_count = 0

    for c in bundle.get("commits", []):
        cid = c.get("commit_id", "")
        if not cid:
            continue
        local_rec = read_commit(root, cid)
        if local_rec is None:
            message_raw = c.get("message", "")
            message = sanitize_display(message_raw.splitlines()[0][:72]) if message_raw else ""
            new_entries.append(_BundleDiffCommit(
                commit_id=cid,
                message=message,
                committed_at=c.get("committed_at", ""),
            ))
        else:
            known_count += 1

    # Sort new commits newest-first.
    new_entries.sort(key=lambda e: e["committed_at"], reverse=True)

    # Determine which branch refs would advance.
    branch_heads: "BranchHeads" = bundle.get("branch_heads") or {}
    refs_to_advance: list[str] = []
    for br, bundle_cid in sorted(branch_heads.items()):
        local_cid = get_head_commit_id(root, br)
        if local_cid != bundle_cid:
            refs_to_advance.append(sanitize_display(br))

    if json_out:
        print(json.dumps(_BundleDiffJson(
            **make_envelope(elapsed),
            new_commits=len(new_entries),
            known_commits=known_count,
            refs_to_advance=refs_to_advance,
            commits=new_entries,
        )))
    else:
        if not new_entries:
            print(f"Already up-to-date. 0 new commits.")
        else:
            print(f"{len(new_entries)} new commit(s), {known_count} already known.")
            if refs_to_advance:
                print(f"Refs to advance: {', '.join(refs_to_advance)}")
            for entry in new_entries:
                short = short_id(entry["commit_id"])
                ts = entry["committed_at"][:19] if entry["committed_at"] else "unknown"
                print(f"  {short}  {ts}  {entry['message']}")

def run_unbundle(args: argparse.Namespace) -> None:
    """Apply a bundle to the local store and optionally advance branch refs.

    Writes all commits, snapshots, and objects from a bundle into the local
    repository, then advances local branch refs to match the bundle's recorded
    heads.  All writes are idempotent — objects already present are counted as
    skipped, not errors.  Use ``--verify`` to abort before any write if the
    bundle fails an integrity check.

    Agent quickstart
    ----------------
    ::

        muse bundle unbundle repo.bundle --verify --json
        muse bundle unbundle repo.bundle --no-update-refs --json

    JSON fields
    -----------
    commits_written    Number of commit records written to the local store.
    snapshots_written  Number of snapshot records written.
    blobs_written      Number of blobs written.
    blobs_skipped      Number of blobs already present (skipped).
    refs_updated       Branch names whose local tip was advanced.
    verified           ``true`` if ``--verify`` was set and integrity passed.

    Exit codes
    ----------
    0  Bundle applied (all objects skipped = already up-to-date, also 0).
    1  Bundle not found, not valid msgpack, or ``--verify`` integrity failure.
    2  Not inside a Muse repository.
    """
    elapsed = start_timer()
    file: str = args.file
    update_refs: bool = args.update_refs
    verify_first: bool = args.verify_first
    json_out: bool = args.json_out

    root = require_repo()
    bundle = _load_bundle(pathlib.Path(file))

    if verify_first:
        failures = _verify_bundle_integrity(bundle)
        if failures:
            if json_out:
                print(json.dumps({
                    "error": "integrity_failure",
                    "failures": [sanitize_display(f) for f in failures[:10]],
                }))
            else:
                print(
                    f"❌ Bundle integrity check failed ({len(failures)} failure(s)) — "
                    "no changes written.",
                    file=sys.stderr,
                )
                for f in failures[:10]:
                    print(f"  {sanitize_display(f)}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

    result = apply_mpack(root, bundle)

    updated: list[str] = []
    if update_refs:
        import re as _re
        branch_heads: BranchHeads = bundle.get("branch_heads") or {}
        for br, cid in branch_heads.items():
            try:
                validate_branch_name(br)
            except ValueError:
                logger.warning("⚠️ bundle: skipping invalid branch name %r", br)
                continue
            if not _re.fullmatch(r"sha256:[0-9a-f]{64}", cid):
                logger.warning("⚠️ bundle: skipping invalid commit ID for %r", br)
                continue
            write_branch_ref(root, br, cid)
            updated.append(br)

    if json_out:
        print(json.dumps(_BundleUnbundleJson(
            **make_envelope(elapsed),
            commits_written=result["commits_written"],
            snapshots_written=result["snapshots_written"],
            blobs_written=result["blobs_written"],
            blobs_skipped=result["blobs_skipped"],
            refs_updated=sorted(updated),
            verified=verify_first,
        )))
    else:
        print(
            f"Unpacked {result['commits_written']} commit(s), "
            f"{result['snapshots_written']} snapshot(s), "
            f"{result['blobs_written']} blob(s)  "
            f"({result['blobs_skipped']} skipped)"
        )
        if updated:
            print(
                f"Updated refs: {', '.join(sanitize_display(b) for b in updated)}"
            )
        print("✅ Bundle applied.")

def run_verify(args: argparse.Namespace) -> None:
    """Verify the integrity of a bundle file.

    Checks every object's SHA-256 against its declared ``object_id`` (hash
    mismatch means corruption) and confirms every snapshot's objects are present
    in the bundle (missing object means truncation).  Does NOT require a Muse
    repository.  At most 100 distinct failures are collected; beyond that a
    trailing "... and N more" entry is appended.

    Agent quickstart
    ----------------
    ::

        muse bundle verify repo.bundle --json
        muse bundle verify repo.bundle -q && muse bundle unbundle repo.bundle

    JSON fields
    -----------
    blobs_checked      Number of blobs whose hash was verified.
    snapshots_checked  Number of snapshots whose blob references were checked.
    all_ok             ``true`` when no integrity failures were found.
    failures           List of human-readable failure descriptions (capped at 100).

    Exit codes
    ----------
    0  Bundle is clean.
    1  Integrity failures found, or bundle file not found / not valid msgpack.
    """
    elapsed = start_timer()
    file: str = args.file
    quiet: bool = args.quiet
    json_out: bool = args.json_out

    bundle = _load_bundle(pathlib.Path(file))

    failures: list[str] = []
    blobs_checked = 0
    snapshots_checked = 0
    _total_failures = 0  # tracks raw count before the cap kicks in

    def _add_failure(msg: str) -> None:
        nonlocal _total_failures
        _total_failures += 1
        if len(failures) < _MAX_VERIFY_FAILURES:
            failures.append(msg)

    # Build set of blob IDs in the bundle and verify each hash.
    # Blob IDs use canonical "sha256:<64hex>" format; compare accordingly.
    bundle_obj_ids: set[str] = set()
    for obj in bundle.get("blobs", []):
        obj_id = obj["object_id"]
        raw = obj["content"]
        if not obj_id:
            _add_failure("blobs list: entry has missing object_id")
            continue
        # NOTE: raw may be b"" for empty files — that is valid.
        actual = blob_id(raw)
        if actual != obj_id:
            _add_failure(f"blob {obj_id}: hash mismatch (corruption)")
        else:
            bundle_obj_ids.add(obj_id)
        blobs_checked += 1

    # Check snapshots reference objects present in the bundle.
    for snap_dict in bundle.get("snapshots", []):
        snap_id = snap_dict.get("snapshot_id", "")
        delta_upsert: dict[str, str] = snap_dict.get("delta_upsert") or {}
        snapshots_checked += 1
        for rel_path, obj_id in delta_upsert.items():
            if obj_id not in bundle_obj_ids:
                _add_failure(
                    f"snapshot {snap_id}: "
                    f"missing object {obj_id} for {rel_path}"
                )

    overflow = _total_failures - len(failures)
    if overflow > 0:
        failures.append(f"... and {overflow} more failure(s) (cap: {_MAX_VERIFY_FAILURES})")

    all_ok = _total_failures == 0

    if quiet:
        raise SystemExit(0 if all_ok else ExitCode.USER_ERROR)

    if json_out:
        print(json.dumps(_BundleVerifyJson(
            **make_envelope(elapsed),
            blobs_checked=blobs_checked,
            snapshots_checked=snapshots_checked,
            all_ok=all_ok,
            failures=[sanitize_display(f) for f in failures],
        )))
    else:
        print(f"Blobs checked:     {blobs_checked}")
        print(f"Snapshots checked: {snapshots_checked}")
        if all_ok:
            print("✅ Bundle is clean.")
        else:
            print(f"❌ {_total_failures} failure(s):")
            for f in failures:
                print(f"  {sanitize_display(str(f))}")

    raise SystemExit(0 if all_ok else ExitCode.USER_ERROR)

def run_list_heads(args: argparse.Namespace) -> None:
    """List the branch heads recorded in a bundle file.

    Reads the ``branch_heads`` map embedded in the bundle and prints it.  Does
    NOT require a Muse repository — runs against any bundle file in isolation.
    Both branch names and commit IDs are sanitized before output to prevent
    ANSI injection from crafted bundles.

    Agent quickstart
    ----------------
    ::

        muse bundle list-heads repo.bundle --json
        muse bundle list-heads repo.bundle --json | jq 'keys'

    JSON fields
    -----------
    <branch>  Each key is a branch name; value is ``sha256:<64hex>`` commit ID.
              Top level is a flat map — no wrapper key.

    Exit codes
    ----------
    0  Always (empty object when no heads are recorded in the bundle).
    1  Bundle file not found or not valid msgpack.
    """
    elapsed = start_timer()
    file: str = args.file
    json_out: bool = args.json_out

    bundle = _load_bundle(pathlib.Path(file))
    heads: BranchHeads = bundle.get("branch_heads") or {}

    if json_out:
        safe_heads = {
            sanitize_display(k): sanitize_display(v)
            for k, v in heads.items()
        }
        print(json.dumps({
            **make_envelope(elapsed),
            **_BundleListHeadsJson(heads=safe_heads),
        }))
    else:
        if not heads:
            print("No branch heads in bundle.")
            return
        for branch, cid in sorted(heads.items()):
            print(f"{sanitize_display(cid[:len('sha256:') + 12])}  {sanitize_display(branch)}")
