"""muse update-ref — move a branch HEAD to a specific commit.

Directly writes a branch reference file under ``.muse/refs/heads/``.  This is
the lowest-level way to advance or rewind a branch without any merge logic.

Commands (``muse commit``, ``muse merge``, ``muse reset``) call this internally
after computing the new commit ID.

Output — create/update::

    {
      "branch":     "main",
      "commit_id":  "sha256:<64-hex>",
      "previous":   "sha256:<64-hex>" | null,
      "duration_ms": 1.234,
      "exit_code":  0
    }

Output — delete::

    {
      "branch":     "main",
      "deleted":    true,
      "duration_ms": 0.812,
      "exit_code":  0
    }

Output contract
---------------

- Exit 0: ref updated or deleted.
- Exit 1: commit not found in the store, invalid commit ID format,
  ``--delete`` on a non-existent ref, CAS mismatch, or invalid args.
- Exit 3: file write failure (``OSError``).

JSON error contract
-------------------

When ``--json`` (or ``--format json``) is active, **all** errors are emitted
to **stdout** so agents always receive a parseable response::

    {"error": "<key>", "message": "<text>", "duration_ms": 0.3, "exit_code": 1}

CAS errors also include ``current`` and ``expected`` fields::

    {
      "error":      "cas_mismatch",
      "message":    "CAS mismatch: ...",
      "current":    "sha256:...",
      "expected":   "sha256:...",
      "duration_ms": 0.5,
      "exit_code":  1
    }

Agent use — compare-and-swap (CAS)
-----------------------------------

In a multi-agent environment multiple agents may try to advance the same branch
concurrently.  Use ``--old-value`` to make the update conditional: it succeeds
only if the current ref value matches the expected value.  This turns update-ref
into an atomic compare-and-swap and prevents silent overwrites::

    muse update-ref main <new_id> --old-value <expected_current_id>
"""

import argparse
import json
import logging
import sys
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.paths import ref_path as _ref_path
from muse.core.errors import ExitCode
from muse.core.refs import read_ref
from muse.core.repo import require_repo
from muse.core.refs import get_head_commit_id, write_branch_ref
from muse.core.commits import read_commit
from muse.core.validation import validate_branch_name, validate_object_id
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

class _UpdateRefJson(EnvelopeJson):
    """JSON schema for a successful create/update response."""
    branch: str
    commit_id: str
    previous: str | None

class _DeleteRefJson(EnvelopeJson):
    """JSON schema for a successful delete response."""
    branch: str
    deleted: bool

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the update-ref subcommand."""
    parser = subparsers.add_parser(
        "update-ref",
        help="Move a branch HEAD to a specific commit ID.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "branch",
        help="Branch name to update.",
    )
    parser.add_argument(
        "commit_id",
        nargs="?",
        default=None,
        help="Commit ID to point the branch at. Omit with --delete to remove the branch.",
    )
    parser.add_argument(
        "--delete", "-d",
        action="store_true",
        help="Delete the branch ref entirely.",
    )
    parser.add_argument(
        "--no-verify",
        dest="verify",
        action="store_false",
        help="Skip verifying the commit exists before updating.",
    )
    parser.add_argument(
        "--old-value",
        dest="old_value",
        default=None,
        metavar="COMMIT_ID",
        help=(
            "Compare-and-swap guard: update only if the current ref matches this commit ID. "
            "Use 'null' to require that the ref does not currently exist. "
            "Essential for safe concurrent updates in multi-agent environments."
        ),
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON on stdout.",
    )
    parser.set_defaults(func=run, verify=True, json_out=False)

def run(args: argparse.Namespace) -> None:
    """Move a branch HEAD to a specific commit ID.

    Directly writes (or deletes) a branch ref file under ``.muse/refs/heads/``.
    Supports compare-and-swap via ``--old-value`` for safe concurrent updates in
    multi-agent environments.  With ``--no-verify``, skips confirming the commit
    exists in the store (useful after ``muse unpack-objects``).

    Agent quickstart::

        muse update-ref main sha256:<id> --json
        muse update-ref main sha256:<new> --old-value sha256:<expected> --json
        muse update-ref feat/x --delete --json

    JSON fields::

        branch       Branch name that was updated or deleted.
        commit_id    New commit ID the branch points at (create/update only).
        previous     Previous commit ID before update, or null (create/update only).
        deleted      true (delete mode only).
        muse_version Muse release that produced this output.
        schema       Envelope schema version (int).
        exit_code    0 on success, 1 on user error, 3 on write failure.
        duration_ms  Wall-clock milliseconds for the command.
        timestamp    ISO-8601 UTC timestamp of command completion.
        warnings     List of non-fatal advisory messages.

    Exit codes::

        0  Ref updated or deleted successfully.
        1  User error (invalid args, commit not found, CAS mismatch).
        3  Write failure (OSError from write_branch_ref).
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    branch: str = args.branch
    commit_id: str | None = args.commit_id
    delete: bool = args.delete
    verify: bool = args.verify
    old_value: str | None = args.old_value

    def _emit_error(msg: str, code: int, error_key: str = "error", **extra: str) -> None:
        if json_out:
            payload = {**make_envelope(elapsed, exit_code=code), "error": error_key, "message": msg}
            payload.update(extra)
            print(json.dumps(payload))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(code)

    root = require_repo()

    try:
        validate_branch_name(branch)
    except ValueError as exc:
        _emit_error(f"Invalid branch name: {exc}", ExitCode.USER_ERROR, "invalid_branch")

    ref_path = _ref_path(root, branch)

    # Validate --old-value before any write.
    if old_value is not None and old_value != "null":
        try:
            validate_object_id(old_value)
        except ValueError as exc:
            _emit_error(f"Invalid --old-value: {exc}", ExitCode.USER_ERROR, "invalid_old_value")

    if delete:
        if not ref_path.exists():
            _emit_error(
                f"Branch ref does not exist: {branch}",
                ExitCode.USER_ERROR,
                "ref_not_found",
            )
        if old_value is not None:
            current = read_ref(ref_path) or ""
            if old_value != current:
                _emit_error(
                    "CAS mismatch: ref does not match --old-value",
                    ExitCode.USER_ERROR,
                    "cas_mismatch",
                    current=current,
                    expected=old_value,
                )
        ref_path.unlink()
        if json_out:
            print(json.dumps(_DeleteRefJson(**make_envelope(elapsed), branch=branch, deleted=True)))
        return

    if commit_id is None:
        _emit_error(
            "commit_id is required unless --delete is used.",
            ExitCode.USER_ERROR,
            "missing_commit_id",
        )

    # Always validate the format — writing a malformed ID to a ref file would
    # silently corrupt the repository regardless of the --verify flag.
    try:
        validate_object_id(commit_id)
    except ValueError as exc:
        _emit_error(f"Invalid commit ID: {exc}", ExitCode.USER_ERROR, "invalid_commit_id")

    if verify and read_commit(root, commit_id) is None:
        _emit_error(
            f"Commit not found in store: {commit_id}",
            ExitCode.USER_ERROR,
            "commit_not_found",
        )

    previous = get_head_commit_id(root, branch)

    # CAS check — must happen after reading `previous` and before the write.
    if old_value is not None:
        if old_value == "null":
            if previous is not None:
                _emit_error(
                    "CAS mismatch: ref already exists (--old-value null requires no ref)",
                    ExitCode.USER_ERROR,
                    "cas_mismatch",
                    current=previous,
                )
        elif old_value != previous:
            _emit_error(
                "CAS mismatch: ref does not match --old-value",
                ExitCode.USER_ERROR,
                "cas_mismatch",
                current=previous,
                expected=old_value,
            )

    try:
        write_branch_ref(root, branch, commit_id)
    except (OSError, ValueError) as exc:
        _emit_error(str(exc), ExitCode.INTERNAL_ERROR, "write_error")

    if json_out:
        print(json.dumps(_UpdateRefJson(
            **make_envelope(elapsed),
            branch=branch,
            commit_id=commit_id,
            previous=previous,
        )))
