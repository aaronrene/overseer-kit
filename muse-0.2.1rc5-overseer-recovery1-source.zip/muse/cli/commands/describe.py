"""``muse describe`` — describe a commit relative to the nearest version tag.

Walks backward from a commit (default: HEAD) through the ancestry graph and
finds the nearest semantic version tag.

Without ``--pre`` only stable version tags are considered.  With ``--pre``
pre-release tags (rc, beta, alpha) are also eligible.

When no eligible tag is found the command exits 1 with ``tag: null``,
``distance: null``, and ``description: null`` in JSON output.

Usage::

    muse describe                      # describe HEAD (stable tags only)
    muse describe --pre                # include pre-release tags
    muse describe feat/audio           # describe tip of a branch
    muse describe sha256:<id>          # describe a specific commit
    muse describe --abbrev 12          # 12-char hex suffix in description
    muse describe --first-parent       # follow main-line ancestry only
    muse describe --json               # machine-readable output

JSON output schema::

    {
      "commit_id":    "<sha256:hex>",
      "tag":          "<nearest version tag>" | null,
      "distance":     <int> | null,
      "short_sha":    "<abbrev hex chars>",
      "description":  "<describe string>" | null,
      "exact":        true | false,
      "repo_id":      "<sha256:...>",
      "branch":       "<current branch>",
      "duration_ms":  <float>,
      "exit_code":    0 | 1
    }

Exit codes::

    0 — tag found and description produced
    1 — no eligible version tags in the ancestry
    2 — not a Muse repository
"""

import argparse
import json
import logging
import sys
from typing import TypedDict

from muse.core.describe import describe_commit
from muse.core.errors import ExitCode
from muse.core.repo import read_repo_id, require_repo
from muse.core.refs import get_head_commit_id, read_current_branch
from muse.core.commits import resolve_commit_ref
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)


class _DescribeJson(EnvelopeJson):
    """JSON output for ``muse describe --json``."""

    commit_id: str
    tag: str | None
    distance: int | None
    short_sha: str
    description: str | None
    exact: bool
    repo_id: str
    branch: str


def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse describe`` subcommand."""
    parser = subparsers.add_parser(
        "describe",
        help="Describe a commit relative to the nearest version tag.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "ref",
        nargs="?",
        default=None,
        help="Branch name or commit ID to describe (default: HEAD).",
    )
    parser.add_argument(
        "--pre",
        action="store_true",
        dest="include_pre",
        help="Include pre-release version tags (rc, beta, alpha) as reference points.",
    )
    parser.add_argument(
        "--first-parent",
        action="store_true",
        dest="first_parent",
        help="Follow only the first-parent chain (skip merge second-parents).",
    )
    parser.add_argument(
        "--abbrev",
        type=int,
        default=8,
        dest="abbrev",
        metavar="N",
        help="Length of the hex suffix in the description string (default: 8).",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON on stdout.",
    )
    parser.set_defaults(func=run)


def run(args: argparse.Namespace) -> None:
    """Describe a commit relative to the nearest semantic version tag."""
    elapsed = start_timer()
    ref: str | None = args.ref
    include_pre: bool = args.include_pre
    first_parent: bool = args.first_parent
    abbrev: int = args.abbrev
    json_out: bool = args.json_out

    if abbrev < 4 or abbrev > 64:
        print(
            f"❌ --abbrev must be between 4 and 64 (got {abbrev}).",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()
    repo_id = read_repo_id(root)
    branch = read_current_branch(root)

    if ref is None:
        commit_id = get_head_commit_id(root, branch)
        if commit_id is None:
            print("❌ No commits on current branch.", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
    else:
        commit_rec = resolve_commit_ref(root, branch, ref)
        if commit_rec is None:
            print(f"❌ Ref '{ref}' not found.", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        commit_id = commit_rec.commit_id

    result = describe_commit(
        root,
        repo_id,
        commit_id,
        include_pre=include_pre,
        first_parent=first_parent,
        abbrev=abbrev,
    )

    found = result["tag"] is not None
    exit_code = 0 if found else ExitCode.USER_ERROR

    if json_out:
        print(json.dumps(_DescribeJson(
            **make_envelope(elapsed, exit_code=exit_code),
            commit_id=result["commit_id"],
            tag=result["tag"],
            distance=result["distance"],
            short_sha=result["short_sha"],
            description=result["description"],
            exact=result["exact"],
            repo_id=repo_id,
            branch=branch,
        )))
        raise SystemExit(exit_code)
    else:
        if not found:
            print(f"❌ No version tags found in the ancestry of {commit_id[:abbrev]}.", file=sys.stderr)
            raise SystemExit(exit_code)
        print(result["description"])
