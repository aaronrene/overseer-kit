"""``muse mv`` — move a tracked file or directory, staging the rename atomically.

Moves *source* to *dest* on disk and records the change in the stage.
For files: source tombstoned as ``"D"``, destination staged as ``"A"``
with the same object ID.  For directories: all contained files are
restaged under the new path; empty-directory sentinels are relocated.

Special cases
-------------
- **Directory source**: detected automatically when the source path is a
  tracked directory (has committed files under it, or is a committed empty
  directory, or is a staged-as-new empty directory).
- **Move into directory**: if *dest* ends with ``/`` or is an existing
  directory on disk, the source name is appended (``muse mv a.py lib/`` →
  ``lib/a.py``; ``muse mv src/ lib/`` → ``lib/src/``).
- **Staged-only source**: a file staged as ``"A"`` but never committed is
  moved by replacing its stage entry rather than creating a ``"D"`` tombstone.
- **``--force``**: bypasses the "destination exists on disk" safety check.

JSON schema (``--json``)::

    {
      "status":      "moved" | "dry_run",
      "source":      "old/path.py"  | "old/dir/",
      "dest":        "new/path.py"  | "new/dir/",
      "object_id":   "sha256:<64-char hex>" | "",
      "dry_run":     true | false,
      "duration_ms": 1.2,
      "exit_code":   0
    }

Exit codes::

    0 — success (file/dir moved or would be moved in dry-run)
    1 — user error: source not tracked, dest exists, path outside repo
    2 — not a Muse repository
    3 — I/O error during rename

Examples::

    muse mv old.py new.py                  # rename file in-place
    muse mv src/ lib/src/                  # rename directory
    muse mv utils.py lib/                  # move file into existing directory
    muse mv old.py new.py --dry-run --json # preview in JSON
"""

import argparse
import json as _json
import logging
import pathlib
import shutil
import sys
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.types import Manifest
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import read_commit
from muse.core.snapshots import read_snapshot
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.validation import sanitize_display, assert_write_inside_repo
from muse.core.timing import start_timer
from muse.core.object_store import write_object
from muse.plugins.code.stage import EMPTY_DIR_OID, StagedFileMap, make_entry, read_stage, read_stage_dir_renames, write_stage

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Wire-format TypedDicts
# ---------------------------------------------------------------------------

class _MvResultJson(EnvelopeJson):
    """Stable JSON envelope for a successful (or dry-run) mv operation."""
    status: str       # "moved" | "dry_run"
    source: str
    dest: str
    object_id: str    # sha256:… object ID
    dry_run: bool

class _MvErrorJson(EnvelopeJson):
    """Error payload for usage/internal errors in --json mode."""
    status: str       # "error"
    error: str

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _emit_error(json_out: bool, msg: str, code: ExitCode, elapsed: float) -> None:
    """Print an error and raise SystemExit.  Never returns.

    In ``--json`` mode the error goes to stdout as a JSON payload so agents
    always get parseable output.  In text mode it goes to stderr.
    """
    if json_out:
        print(_json.dumps(_MvErrorJson(
            **make_envelope(elapsed, exit_code=int(code)),
            status="error",
            error=msg,
        )))
    else:
        print(f"❌ {msg}", file=sys.stderr)
    raise SystemExit(code)

_DIR_SENTINEL = EMPTY_DIR_OID

def _head_manifest(root: pathlib.Path) -> Manifest:
    """Return the manifest from HEAD, or ``{}`` on an empty repo."""
    try:
        branch = read_current_branch(root)
        commit_id = get_head_commit_id(root, branch)
        if not commit_id:
            return {}
        commit = read_commit(root, commit_id)
        if commit is None:
            return {}
        snap = read_snapshot(root, commit.snapshot_id)
        return dict(snap.manifest) if snap else {}
    except Exception:
        return {}

def _head_snapshot_dirs(root: pathlib.Path) -> list[str]:
    """Return the ``directories`` list from the current HEAD snapshot."""
    try:
        branch = read_current_branch(root)
        commit_id = get_head_commit_id(root, branch)
        if not commit_id:
            return []
        commit = read_commit(root, commit_id)
        if commit is None:
            return []
        snap = read_snapshot(root, commit.snapshot_id)
        return list(snap.directories) if snap else []
    except Exception:
        return []

def _resolve_path(root: pathlib.Path, raw: str) -> str:
    """Resolve *raw* to a repo-relative POSIX path.

    Rejects anything that escapes the repository root (path traversal).

    Args:
        root: Absolute repository root.
        raw:  Raw path string from the user.

    Returns:
        POSIX-style path relative to *root* (e.g. ``"src/auth.py"``).

    Raises:
        SystemExit(USER_ERROR): path is outside the repository.
    """
    p = pathlib.Path(raw)
    if not p.is_absolute():
        cwd_candidate = (pathlib.Path.cwd() / p).resolve()
        try:
            cwd_candidate.relative_to(root.resolve())
            abs_target = cwd_candidate
        except ValueError:
            abs_target = (root / p).resolve()
    else:
        abs_target = p.resolve()

    try:
        rel = abs_target.relative_to(root.resolve())
    except ValueError:
        print(
            f"❌ fatal: '{sanitize_display(raw)}' is outside the repository root.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    return rel.as_posix()

def _get_source_object_id(
    src_rel: str,
    head_manifest: Manifest,
    stage: StagedFileMap,
) -> str:
    """Return the object_id for *src_rel*, preferring the stage over HEAD.

    Args:
        src_rel:       Repo-relative POSIX path of the source file.
        head_manifest: Manifest of the current HEAD commit.
        stage:         Current stage index.

    Returns:
        sha256:… object_id.
    """
    staged = stage.get(src_rel)
    if staged is not None and staged["mode"] != "D":
        return staged["object_id"]
    return head_manifest[src_rel]

def _resolve_dest(
    root: pathlib.Path,
    raw_dest: str,
    src_rel: str,
) -> str:
    """Compute the final destination relative path.

    If *raw_dest* ends with ``/`` or is an existing directory, appends the
    source filename to produce the full destination path.

    Args:
        root:     Absolute repository root.
        raw_dest: Destination argument as given by the user.
        src_rel:  Resolved source path (repo-relative POSIX).

    Returns:
        Repo-relative POSIX destination path.
    """
    # Strip trailing slash — purely cosmetic, no semantic meaning.
    dest_path = pathlib.Path(raw_dest.rstrip("/"))

    abs_dest: pathlib.Path
    if not dest_path.is_absolute():
        cwd_candidate = (pathlib.Path.cwd() / dest_path).resolve()
        try:
            cwd_candidate.relative_to(root.resolve())
            abs_dest = cwd_candidate
        except ValueError:
            abs_dest = (root / dest_path).resolve()
    else:
        abs_dest = dest_path.resolve()

    # If the destination exists as a directory on disk, move source inside it.
    # Trailing slash is cosmetic — only actual directory existence matters.
    # Matches git mv semantics: `muse mv a b/` where b doesn't exist → rename to b.
    if abs_dest.is_dir():
        src_filename = pathlib.Path(src_rel).name
        abs_dest = abs_dest / src_filename

    # Validate it stays inside the repo.
    try:
        rel = abs_dest.relative_to(root.resolve())
    except ValueError:
        print(
            f"❌ fatal: destination '{sanitize_display(raw_dest)}' is outside "
            f"the repository root.",
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    return rel.as_posix()

# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``muse mv`` subcommand."""
    parser = subparsers.add_parser(
        "mv",
        help="Move or rename a tracked file, staging the change.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "source",
        metavar="SOURCE",
        help="File to move (must be tracked).",
    )
    parser.add_argument(
        "dest",
        metavar="DEST",
        help=(
            "Destination path or directory.  If DEST ends with '/' or is an "
            "existing directory, SOURCE's filename is appended."
        ),
    )
    parser.add_argument(
        "-f", "--force",
        action="store_true",
        help=(
            "Override safety checks — allow moving onto an already-tracked or "
            "on-disk destination."
        ),
    )
    parser.add_argument(
        "-n", "--dry-run",
        action="store_true",
        dest="dry_run",
        help="Preview what would be moved without writing anything.",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON on stdout.",
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Move a tracked file or directory, updating both the working tree and the stage.

    Validates that the source is tracked and the destination is safe, then
    performs the on-disk rename atomically and updates the stage.

    For files: source is tombstoned as ``"D"``; destination staged as ``"A"``
    with the same object ID — content is unchanged.

    For directories: all contained files are restaged under the new path;
    empty-directory sentinels are relocated.

    Agent quickstart
    ----------------
    ::

        muse mv src/old.py src/new.py --json
        muse mv src/olddir/ src/newdir/ --json
        muse mv src/old.py src/new.py --dry-run --json

    Exit codes
    ----------
    0  Success (or would-succeed in dry-run).
    1  User error — source not tracked, destination exists, path traversal.
    2  Not inside a Muse repository.
    3  I/O error during rename.
    """
    import os

    elapsed = start_timer()

    force: bool = args.force
    dry_run: bool = args.dry_run
    json_out: bool = args.json_out

    root = require_repo()

    # ------------------------------------------------------------------ #
    # 1. Resolve source path
    # ------------------------------------------------------------------ #
    src_rel = _resolve_path(root, args.source)
    src_abs = root / src_rel

    head_manifest = _head_manifest(root)
    stage = read_stage(root)

    # ------------------------------------------------------------------ #
    # 2. Detect whether source is a tracked directory
    # ------------------------------------------------------------------ #
    files_in_dir: dict[str, str] = {
        p: oid for p, oid in head_manifest.items()
        if p.startswith(src_rel + "/")
    }
    head_dirs = _head_snapshot_dirs(root)
    is_committed_empty_dir = src_rel in head_dirs and not files_in_dir
    staged_dir_entry = stage.get(src_rel)
    is_staged_empty_dir = (
        staged_dir_entry is not None
        and staged_dir_entry.get("object_id") == _DIR_SENTINEL
        and staged_dir_entry.get("mode") == "A"
        and src_rel not in head_dirs
    )
    is_dir_source = bool(files_in_dir) or is_committed_empty_dir or is_staged_empty_dir

    if is_dir_source:
        # ---------------------------------------------------------------- #
        # DIRECTORY BRANCH
        # ---------------------------------------------------------------- #
        if not src_abs.exists():
            _emit_error(
                json_out,
                f"source directory '{sanitize_display(src_rel)}' does not exist on disk.",
                ExitCode.USER_ERROR,
                elapsed,
            )

        dest_rel = _resolve_dest(root, args.dest, src_rel)
        dest_abs = root / dest_rel
        assert_write_inside_repo(root, dest_abs)

        if dest_abs.exists() and not force:
            _emit_error(
                json_out,
                f"destination '{sanitize_display(dest_rel)}' already exists on disk. "
                f"Use --force to overwrite.",
                ExitCode.USER_ERROR,
                elapsed,
            )

        if dry_run:
            if json_out:
                print(_json.dumps(_MvResultJson(
                    **make_envelope(elapsed),
                    status="dry_run",
                    source=src_rel + "/",
                    dest=dest_rel + "/",
                    object_id="",
                    dry_run=True,
                )))
            else:
                print(f"[dry-run] Would rename: {sanitize_display(src_rel)}/ → {sanitize_display(dest_rel)}/")
            return

        try:
            shutil.move(str(src_abs), str(dest_abs))
        except OSError as exc:
            _emit_error(
                json_out,
                f"could not rename '{sanitize_display(src_rel)}/' → "
                f"'{sanitize_display(dest_rel)}/': {exc}",
                ExitCode.INTERNAL_ERROR,
                elapsed,
            )

        new_stage: StagedFileMap = dict(stage)
        files_moved = 0

        # Restage committed files under new path.
        for old_path, oid in files_in_dir.items():
            suffix = old_path[len(src_rel):]   # "/sub/file.py"
            new_path = dest_rel + suffix
            new_stage[old_path] = make_entry(object_id=oid, mode="D")
            new_stage[new_path] = make_entry(object_id=oid, mode="A")
            files_moved += 1

        # Restage staged-only files (not yet committed) under new path.
        for old_path, entry in list(stage.items()):
            if (old_path.startswith(src_rel + "/")
                    and entry.get("object_id") != _DIR_SENTINEL
                    and old_path not in head_manifest
                    and entry["mode"] == "A"):
                suffix = old_path[len(src_rel):]
                new_path = dest_rel + suffix
                new_stage.pop(old_path, None)
                new_stage[new_path] = make_entry(object_id=entry["object_id"], mode="A")
                files_moved += 1

        # Ensure zero-byte object exists in the store for all dir A entries.
        write_object(root, EMPTY_DIR_OID, b"")

        # Relocate empty-directory sentinel.
        if is_committed_empty_dir:
            new_stage.pop(src_rel, None)
            new_stage[src_rel] = make_entry(object_id=_DIR_SENTINEL, mode="D")
            new_stage[dest_rel] = make_entry(object_id=_DIR_SENTINEL, mode="A")
        elif is_staged_empty_dir:
            new_stage.pop(src_rel, None)
            new_stage[dest_rel] = make_entry(object_id=_DIR_SENTINEL, mode="A")

        # Record the rename so status/diff can display "renamed: old/ → new/"
        # rather than separate delete + add entries.
        existing_renames = read_stage_dir_renames(root)
        # If src_rel was itself the destination of a previous rename, collapse
        # the chain: old_orig → dest_rel (drop the intermediate src_rel step).
        collapsed: dict[str, str] = {}
        for old, new in existing_renames.items():
            if new == src_rel:
                collapsed[old] = dest_rel  # A→B then B→C becomes A→C
            elif old != src_rel:
                collapsed[old] = new       # unrelated rename — keep
        collapsed[src_rel] = dest_rel
        write_stage(root, new_stage, dir_renames=collapsed)

        src_disp = sanitize_display(src_rel)
        dst_disp = sanitize_display(dest_rel)
        if json_out:
            print(_json.dumps(_MvResultJson(
                **make_envelope(elapsed),
                status="moved",
                source=src_rel + "/",
                dest=dest_rel + "/",
                object_id="",
                dry_run=False,
            )))
        else:
            suffix_msg = f" ({files_moved} file{'s' if files_moved != 1 else ''})" if files_moved else ""
            print(f"mv: {src_disp}/ → {dst_disp}/{suffix_msg}")
        return

    # ------------------------------------------------------------------ #
    # FILE BRANCH (original logic)
    # ------------------------------------------------------------------ #
    in_head = src_rel in head_manifest
    staged_entry = stage.get(src_rel)
    staged_only = (
        staged_entry is not None
        and staged_entry["mode"] == "A"
        and not in_head
    )
    is_tracked = in_head or (
        staged_entry is not None and staged_entry["mode"] != "D"
    )

    if not is_tracked:
        _emit_error(
            json_out,
            f"'{sanitize_display(src_rel)}' is not tracked. "
            f"Stage it with 'muse code add' first.",
            ExitCode.USER_ERROR,
            elapsed,
        )

    if not src_abs.exists():
        _emit_error(
            json_out,
            f"source file '{sanitize_display(src_rel)}' does not exist on disk.",
            ExitCode.USER_ERROR,
            elapsed,
        )

    # ------------------------------------------------------------------ #
    # Resolve destination path
    # ------------------------------------------------------------------ #
    dest_rel = _resolve_dest(root, args.dest, src_rel)
    dest_abs = root / dest_rel

    assert_write_inside_repo(root, dest_abs)

    dest_in_head = dest_rel in head_manifest
    dest_staged = stage.get(dest_rel)
    dest_is_tracked = dest_in_head or (
        dest_staged is not None and dest_staged["mode"] != "D"
    )

    if dest_is_tracked and not force:
        _emit_error(
            json_out,
            f"destination '{sanitize_display(dest_rel)}' is already tracked. "
            f"Use --force to overwrite.",
            ExitCode.USER_ERROR,
            elapsed,
        )

    if dest_abs.exists() and not force:
        _emit_error(
            json_out,
            f"destination '{sanitize_display(dest_rel)}' already exists on disk. "
            f"Use --force to overwrite.",
            ExitCode.USER_ERROR,
            elapsed,
        )

    # ------------------------------------------------------------------ #
    # Resolve object_id (stays the same — content is unchanged)
    # ------------------------------------------------------------------ #
    object_id = _get_source_object_id(src_rel, head_manifest, stage)

    # ------------------------------------------------------------------ #
    # Dry-run — report and exit
    # ------------------------------------------------------------------ #
    if dry_run:
        if json_out:
            print(_json.dumps(_MvResultJson(
                **make_envelope(elapsed),
                status="dry_run",
                source=src_rel,
                dest=dest_rel,
                object_id=object_id,
                dry_run=True,
            )))
        else:
            src_disp = sanitize_display(src_rel)
            dst_disp = sanitize_display(dest_rel)
            print(f"[dry-run] Would rename: {src_disp} → {dst_disp}")
        return

    # ------------------------------------------------------------------ #
    # On-disk rename
    # ------------------------------------------------------------------ #
    dest_abs.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.replace(src_abs, dest_abs)
    except OSError as exc:
        _emit_error(
            json_out,
            f"could not rename '{sanitize_display(src_rel)}' → "
            f"'{sanitize_display(dest_rel)}': {exc}",
            ExitCode.INTERNAL_ERROR,
            elapsed,
        )

    # ------------------------------------------------------------------ #
    # Update the stage
    # ------------------------------------------------------------------ #
    new_stage_f: StagedFileMap = dict(stage)

    if staged_only:
        new_stage_f.pop(src_rel, None)
    else:
        new_stage_f[src_rel] = make_entry(object_id="", mode="D")

    new_stage_f[dest_rel] = make_entry(object_id=object_id, mode="A")

    write_stage(root, new_stage_f)

    # ------------------------------------------------------------------ #
    # Output
    # ------------------------------------------------------------------ #
    src_disp = sanitize_display(src_rel)
    dst_disp = sanitize_display(dest_rel)

    if json_out:
        print(_json.dumps(_MvResultJson(
            **make_envelope(elapsed),
            status="moved",
            source=src_rel,
            dest=dest_rel,
            object_id=object_id,
            dry_run=False,
        )))
    else:
        print(f"mv: {src_disp} → {dst_disp}")
