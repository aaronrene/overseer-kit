"""muse rev-parse — resolve a ref to a full commit ID.

Resolves a branch name, ``HEAD``, or an abbreviated SHA prefix to the full
64-character SHA-256 commit ID.

Output (JSON, default)::

    {"ref": "main", "commit_id": "<sha256>", "duration_ms": 0.9, "exit_code": 0}

With ``--abbrev-ref``::

    {"ref": "HEAD", "branch": "main", "duration_ms": 0.4, "exit_code": 0}  # JSON
    main                                                                    # text

Output (--format text)::

    <sha256>

Error output (all error paths, always JSON to stdout)::

    {"ref": "...", "commit_id": null, "error": "not found",
     "duration_ms": 0.3, "exit_code": 1}

Output contract
---------------

- Exit 0: ref resolved successfully.
- Exit 1: ref not found, ambiguous, empty, or unknown --format value.
- All JSON (success and error) carries ``duration_ms`` and ``exit_code``.
- Errors always land on **stdout** as JSON — never on stderr — so agents
  can parse failures without stderr redirection.

Agent use
---------

Canonical "what branch am I on?" query::

    muse rev-parse --abbrev-ref HEAD --json
    # → {"ref": "HEAD", "branch": "main", "duration_ms": 0.4, "exit_code": 0}

Canonical "what is HEAD?" query::

    muse rev-parse HEAD --format text
    # → sha256:<64 hex chars>
"""

import argparse
import json
import logging
import re
import sys

from muse.core.types import long_id
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.timing import start_timer
from muse.core.refs import (
    get_head_commit_id,
    read_current_branch,
)
from muse.core.commits import (
    find_commits_by_prefix,
    read_commit,
)

logger = logging.getLogger(__name__)

type _ErrorPayload = dict[str, str | int | float | None]

class _RevParseJson(EnvelopeJson, total=False):
    """JSON output for normal ref resolution."""

    ref: str
    commit_id: str | None

class _RevParseAbbrevJson(EnvelopeJson):
    """JSON output for --abbrev-ref mode."""

    ref: str
    branch: str

_SHA256_FULL_RE = re.compile(r"^sha256:[0-9a-f]{64}$")
_SHA256_PREFIX_RE = re.compile(r"^sha256:[0-9a-f]{1,63}$")
_BARE_HEX_RE = re.compile(r"^[0-9a-f]+$", re.IGNORECASE)

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the rev-parse subcommand."""
    parser = subparsers.add_parser(
        "rev-parse",
        help="Resolve branch/HEAD/SHA prefix → full commit_id.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "ref",
        help="Ref to resolve: branch name, 'HEAD', or commit ID prefix.",
    )
    parser.add_argument(
        "--abbrev-ref",
        action="store_true",
        dest="abbrev_ref",
        help=(
            "Resolve HEAD (or a commit_id) to the branch name rather than "
            "the commit ID. Canonical agent query: "
            "`muse rev-parse --abbrev-ref HEAD`."
        ),
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON (default: plain text commit_id).",
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Resolve a branch name, HEAD, or SHA prefix to a full commit ID.

    Useful for canonicalising refs in scripts and agent pipelines before
    passing them to other commands.  With ``--abbrev-ref``: return the
    symbolic branch name — the idiomatic "what branch am I on?" query.
    Error responses always land on **stdout** as JSON, never on stderr.

    Agent quickstart::

        muse rev-parse HEAD --json
        muse rev-parse main --json
        muse rev-parse --abbrev-ref HEAD --json
        muse rev-parse sha256:abc123 --json

    JSON fields (normal mode)::

        ref         str       Ref as passed by the caller
        commit_id   str|null  Full sha256:<hex> commit ID

    JSON fields (--abbrev-ref mode)::

        ref         str   Ref as passed by the caller (usually "HEAD")
        branch      str   Symbolic branch name

    Exit codes::

        0  Success.
        1  Ref not found, ambiguous, empty, or unknown --format value.
    """
    json_out: bool = args.json_out
    ref: str = args.ref
    abbrev_ref: bool = args.abbrev_ref

    elapsed = start_timer()

    def _emit_error(payload: _ErrorPayload, code: int) -> None:
        """Emit a structured JSON error to stdout and exit.

        Always writes to stdout (never stderr) so agents can parse errors
        without stderr redirection.
        """
        payload.update(make_envelope(elapsed, exit_code=code))
        print(json.dumps(payload))
        raise SystemExit(code)

    if not ref:
        _emit_error(
            {"ref": ref, "commit_id": None, "error": "ref must not be empty"},
            ExitCode.USER_ERROR,
        )

    root = require_repo()

    # ── --abbrev-ref: resolve HEAD → branch name ─────────────────────────────
    if abbrev_ref:
        branch = read_current_branch(root)
        if json_out:
            print(json.dumps(_RevParseAbbrevJson(**make_envelope(elapsed), ref=ref, branch=branch)))
        else:
            print(branch)
        return

    # ── normal ref resolution ─────────────────────────────────────────────────
    commit_id: str | None = None

    if ref.upper() == "HEAD":
        branch = read_current_branch(root)
        commit_id = get_head_commit_id(root, branch)
        if commit_id is None:
            _emit_error(
                {"ref": ref, "commit_id": None, "error": "HEAD has no commits"},
                ExitCode.USER_ERROR,
            )
    else:
        # @{N} / branch@{N} — check reflog before any other resolution so
        # out-of-range produces a useful error rather than a silent "not found".
        from muse.core.reflog import resolve_reflog_ref as _resolve_reflog_ref
        try:
            reflog_id = _resolve_reflog_ref(ref, root)
            if reflog_id is not None:
                commit_id = reflog_id
        except FileNotFoundError:
            _emit_error(
                {"ref": ref, "commit_id": None, "error": "no reflog for this ref"},
                ExitCode.USER_ERROR,
            )
        except IndexError as exc:
            idx, total = exc.args
            max_idx = total - 1
            _emit_error(
                {
                    "ref": ref,
                    "commit_id": None,
                    "error": f"@{{{idx}}} out of range; valid range: 0–{max_idx}",
                },
                ExitCode.USER_ERROR,
            )

        if commit_id is None:
            # Try as branch name first.  validate_branch_name (called inside
            # get_head_commit_id) raises ValueError for refs containing control
            # characters, ANSI escapes, or other forbidden sequences — treat
            # these as "not found" rather than letting the exception escape.
            try:
                candidate = get_head_commit_id(root, ref)
            except ValueError:
                candidate = None
            if candidate is not None:
                commit_id = candidate
            else:
                # Try as a canonical content-addressed ID.
                if _SHA256_FULL_RE.match(ref):
                    record = read_commit(root, ref)
                    if record is not None:
                        commit_id = record.commit_id
                elif _SHA256_PREFIX_RE.match(ref):
                    bare_prefix = long_id(ref, strip=True)
                    matches = find_commits_by_prefix(root, bare_prefix)
                    if len(matches) == 1:
                        commit_id = matches[0].commit_id
                    elif len(matches) > 1:
                        _emit_error(
                            {
                                "ref": ref,
                                "commit_id": None,
                                "error": "ambiguous",
                                "candidates": [m.commit_id for m in matches],
                            },
                            ExitCode.USER_ERROR,
                        )
                elif _BARE_HEX_RE.match(ref):
                    _emit_error(
                        {
                            "ref": ref,
                            "commit_id": None,
                            "error": (
                                f"bare hex ID not accepted; "
                                f"use the canonical 'sha256:{ref.lower()}' form"
                            ),
                        },
                        ExitCode.USER_ERROR,
                    )

    if commit_id is None:
        _emit_error(
            {"ref": ref, "commit_id": None, "error": "not found"},
            ExitCode.USER_ERROR,
        )

    if json_out:
        print(json.dumps(_RevParseJson(**make_envelope(elapsed), ref=ref, commit_id=commit_id)))
    else:
        print(commit_id)
