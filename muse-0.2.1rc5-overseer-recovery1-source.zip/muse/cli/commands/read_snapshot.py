"""muse read-snapshot — emit full snapshot metadata as JSON.

Reads a snapshot record by its SHA-256 ID and emits the complete JSON
representation including the file manifest.

Output::

    {
      "snapshot_id": "<sha256>",
      "created_at": "2026-03-18T12:00:00+00:00",
      "file_count": 3,
      "manifest": {
        "tracks/drums.mid": "<sha256>",
        "tracks/bass.mid":  "<sha256>",
        "tracks/piano.mid": "<sha256>"
      }
    }

Output contract
---------------

- Exit 0: snapshot found and printed.
- Exit 1: snapshot not found or invalid snapshot ID format.

Agent use
---------

Skip the manifest when you only need metadata::

    muse read-snapshot <id> --no-manifest
    # → {"snapshot_id": "...", "created_at": "...", "file_count": 3}

Filter to a path prefix to avoid pulling the full manifest::

    muse read-snapshot <id> --path-prefix src/
"""

import argparse
import json
import logging
import sys
from typing import TypedDict

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.snapshots import read_snapshot
from muse.core.validation import validate_object_id
from muse.core.types import Manifest
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

class _SnapshotOutput(EnvelopeJson, total=False):
    """JSON output schema for ``muse read-snapshot``.

    Always present: envelope fields + ``snapshot_id``, ``created_at``,
    ``file_count``.

    Optional: ``manifest`` (omitted with ``--no-manifest``).

    ``file_count`` reflects the number of entries actually returned — i.e.
    the filtered count when ``--path-prefix`` is used.
    """
    snapshot_id: str
    created_at: str
    file_count: int
    manifest: Manifest

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the read-snapshot subcommand."""
    parser = subparsers.add_parser(
        "read-snapshot",
        help="Emit full snapshot metadata and manifest as JSON.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "snapshot_id",
        help="SHA-256 snapshot ID (64 hex chars).",
    )
    parser.add_argument(
        "--no-manifest",
        action="store_true",
        dest="no_manifest",
        help=(
            "Omit the file manifest from JSON output. "
            "Returns only snapshot_id, created_at, and file_count — "
            "ideal for agents doing metadata-only queries."
        ),
    )
    parser.add_argument(
        "--path-prefix", "-p",
        default=None,
        dest="path_prefix",
        metavar="PREFIX",
        help="Filter manifest to paths starting with PREFIX.",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON.",
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Emit full snapshot metadata as JSON (default) or a compact text summary.

    A snapshot holds the complete file manifest (path → object_id mapping)
    for a point in time.  Every commit references exactly one snapshot.
    Use ``muse ls-files --commit <id>`` if you want to look up a snapshot from
    a commit ID rather than the snapshot ID directly.

    Use ``--no-manifest`` for lightweight metadata queries (returns only
    ``snapshot_id``, ``created_at``, ``file_count``, ``elapsed()``,
    ``exit_code``).

    Use ``--path-prefix`` to scope the manifest to a subtree.  ``file_count``
    in the response reflects the filtered count, not the total snapshot size.

    ``--no-manifest`` and ``--path-prefix`` may be combined: useful for
    counting files under a path without downloading any object IDs::

        muse read-snapshot <id> --no-manifest --path-prefix src/
        # → {"snapshot_id": "...", "created_at": "...", "file_count": 5,
        #    "duration_ms": 1.2, "exit_code": 0}

    Text format (``--format text``)::

        <sha256:12-hex>  <file_count> files  <created_at>
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    snapshot_id: str = args.snapshot_id
    no_manifest: bool = args.no_manifest
    path_prefix: str | None = args.path_prefix

    if no_manifest and not json_out:
        print(
            json.dumps({"error": "--no-manifest is only valid with --json"}),
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    if path_prefix is not None and not json_out:
        print(
            json.dumps({"error": "--path-prefix is only valid with --json"}),
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    try:
        validate_object_id(snapshot_id)
    except ValueError as exc:
        print(json.dumps({"error": f"Invalid snapshot ID: {exc}"}), file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()

    record = read_snapshot(root, snapshot_id)
    if record is None:
        print(json.dumps({"error": f"Snapshot not found: {snapshot_id}"}), file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    if not json_out:
        print(
            f"{record.snapshot_id}  {len(record.manifest)} files  "
            f"{record.created_at.isoformat()}"
        )
        return

    manifest = record.manifest
    if path_prefix is not None:
        manifest = {p: oid for p, oid in manifest.items() if p.startswith(path_prefix)}

    output = _SnapshotOutput(
        **make_envelope(elapsed),
        snapshot_id=record.snapshot_id,
        created_at=record.created_at.isoformat(),
        file_count=len(manifest),
    )
    if not no_manifest:
        output["manifest"] = manifest
    print(json.dumps(output))
