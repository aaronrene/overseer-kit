"""muse symbolic-ref — read or write HEAD's symbolic reference.

In Muse, HEAD is a symbolic reference that points to a branch (normal mode)
or directly to a commit (detached HEAD state).  This command reads which
branch HEAD currently tracks, handles detached HEAD gracefully, or — with
``--set`` — updates HEAD to point to a different branch.

Read mode output (JSON, default — normal branch HEAD)::

    {
      "ref":             "HEAD",
      "symbolic_target": "refs/heads/main",
      "branch":          "main",
      "commit_id":       "<sha256>",
      "detached":        false,
      "duration_ms":      1.234,
      "exit_code":       0
    }

Read mode output (JSON — detached HEAD)::

    {
      "ref":             "HEAD",
      "symbolic_target": null,
      "branch":          null,
      "commit_id":       "<sha256>",
      "detached":        true,
      "duration_ms":      0.8,
      "exit_code":       0
    }

When a branch has no commits yet, ``commit_id`` is ``null``.

Write mode (``--set <branch>``)::

    muse symbolic-ref HEAD --set main

Output after a successful write::

    {
      "ref":             "HEAD",
      "symbolic_target": "refs/heads/main",
      "branch":          "main",
      "commit_id":       "<sha256> | null",
      "detached":        false,
      "duration_ms":      2.1,
      "exit_code":       0
    }

JSON error output (always to stdout so agents can parse failures)::

    {
      "error":      "<error_key>",
      "message":    "<human-readable description>",
      "duration_ms": 0.3,
      "exit_code":  1
    }

Text output (``--format text``, read mode)::

    refs/heads/main

With ``--short``::

    main

Output contract
---------------

- Exit 0: ref read or updated successfully.
- Exit 1: ``--set`` target branch does not exist (unless ``--create-branch``);
          bad ``--format``; unsupported ref name; invalid branch name.
- Exit 3: I/O error reading or writing HEAD.

Agent use
---------

Read the current branch from any pipeline step::

    muse symbolic-ref HEAD --short --format text
    # → main

Check whether HEAD is detached::

    muse symbolic-ref HEAD --json | python3 -c "import sys,json; print(json.load(sys.stdin)['detached'])"

Point HEAD at a new empty branch (orphan-style)::

    muse symbolic-ref HEAD --set feat/new --create-branch --json

Switch HEAD to an existing branch::

    muse symbolic-ref HEAD --set main --json

Agents should always pass ``--json`` and parse ``exit_code`` from the
response rather than relying on the process exit code alone.  Every
response — success and error alike — includes ``duration_ms`` (float,
milliseconds) for latency monitoring.
"""

import argparse
import json
import logging
import pathlib
import sys
from typing import TypedDict

from muse.core.paths import ref_path as _ref_path
from muse.core.errors import ExitCode
from muse.core.repo import require_repo
from muse.core.refs import (
    get_head_commit_id,
    read_head,
    write_head_branch,
)
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.validation import sanitize_display, validate_branch_name
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

type _RefData = dict[str, str | bool | None]

class _SymbolicRefResult(EnvelopeJson):
    ref: str
    symbolic_target: str | None
    branch: str | None
    commit_id: str | None
    detached: bool

def _read_symbolic_ref(root: pathlib.Path) -> _RefData:
    """Return the current HEAD symbolic-ref data (no envelope fields).

    Handles both the normal (branch) and detached (commit) HEAD states
    without raising — detached HEAD is represented as a structured result
    with ``detached=True`` and ``branch=None``.

    Uses :func:`muse.core.store.read_head` directly so both states are
    covered, rather than :func:`read_current_branch` which raises on
    detached HEAD.

    The returned dict does **not** include envelope fields — those are
    added by :func:`run` via ``make_envelope`` once overall timing is known.
    """
    state = read_head(root)
    if state["kind"] == "branch":
        branch = state["branch"]
        commit_id = get_head_commit_id(root, branch)
        return {
            "ref": "HEAD",
            "symbolic_target": f"refs/heads/{branch}",
            "branch": branch,
            "commit_id": commit_id,
            "detached": False,
        }
    # Detached HEAD — HEAD points directly to a commit.
    return {
        "ref": "HEAD",
        "symbolic_target": None,
        "branch": None,
        "commit_id": state["commit_id"],
        "detached": True,
    }

def _branch_exists(root: pathlib.Path, branch: str) -> bool:
    """Return True if the branch ref file exists and is not a symlink.

    Symlinks are rejected for consistency with the object store and ref
    listing — a symlink at ``.muse/refs/heads/<branch>`` could point
    anywhere outside the repository.
    """
    rp = _ref_path(root, branch)
    return rp.is_file() and not rp.is_symlink()

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse symbolic-ref`` subcommand and its flags."""
    parser = subparsers.add_parser(
        "symbolic-ref",
        help="Read or write HEAD's symbolic branch reference.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "ref",
        nargs="?",
        default="HEAD",
        help=(
            "The symbolic ref to query or update.  "
            "Currently only HEAD is supported."
        ),
    )
    parser.add_argument(
        "--set", "-s",
        default=None,
        dest="set_branch",
        metavar="BRANCH",
        help="Branch name to point HEAD at (write mode).",
    )
    parser.add_argument(
        "--create-branch",
        action="store_true",
        dest="create_branch",
        help=(
            "With ``--set``, create the branch pointer even if the branch has "
            "no commits yet (orphan-style).  Without this flag, ``--set`` "
            "requires the branch to already exist."
        ),
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON on stdout.",
    )
    parser.add_argument(
        "--short", "-S",
        action="store_true",
        help=(
            "In text mode, emit only the branch name rather than the full "
            "``refs/heads/<branch>`` path.  Ignored in detached HEAD state."
        ),
    )
    parser.set_defaults(func=run, json_out=False)

def run(args: argparse.Namespace) -> None:
    """Read or write HEAD's symbolic reference.

    With no ``--set`` flag, reads which branch HEAD points to and the commit
    ID at that tip.  Detached HEAD is a structured result (``detached=true``),
    not an error.  With ``--set <branch>``, updates HEAD to point to that
    branch; use ``--create-branch`` for orphan mode.

    Agent quickstart::

        muse symbolic-ref HEAD --json
        muse symbolic-ref HEAD --set main --json
        muse symbolic-ref HEAD --set feat/x --create-branch --json
        muse symbolic-ref HEAD --short --format text

    JSON fields::

        ref              Always ``"HEAD"``.
        symbolic_target  Full ref path e.g. ``"refs/heads/main"``; ``null`` when detached.
        branch           Branch name; ``null`` when detached.
        commit_id        SHA-256 commit ID at the branch tip; ``null`` when no commits yet.
        detached         ``true`` when HEAD points directly to a commit.
        muse_version     Muse release that produced this output.
        schema           Envelope schema version (int).
        exit_code        ``0`` on success, ``1`` on user error, ``3`` on I/O error.
        duration_ms      Wall-clock milliseconds for the command.
        timestamp        ISO-8601 UTC timestamp of command completion.
        warnings         List of non-fatal advisory messages.

    Exit codes::

        0  Ref read or updated successfully.
        1  User error (bad format, unsupported ref, branch not found, invalid name).
        3  I/O error reading or writing HEAD.
    """
    elapsed = start_timer()

    json_out: bool = args.json_out
    ref: str = args.ref
    set_branch: str | None = args.set_branch
    create_branch: bool = args.create_branch
    short: bool = args.short

    def _emit_error(
        msg: str,
        code: int,
        error_key: str = "error",
        **extra: str,
    ) -> None:
        if json_out:
            payload = {
                **make_envelope(elapsed, exit_code=code),
                "error": error_key,
                "message": msg,
            }
            payload.update(extra)
            print(json.dumps(payload))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(code)

    ref_upper = ref.upper()
    if ref_upper != "HEAD":
        _emit_error(
            f"Unsupported ref {sanitize_display(ref)!r}. Only HEAD is supported.",
            ExitCode.USER_ERROR,
            "unsupported_ref",
        )

    root = require_repo()

    # ── Write mode ────────────────────────────────────────────────────────────
    if set_branch is not None:
        try:
            validate_branch_name(set_branch)
        except ValueError as exc:
            _emit_error(
                sanitize_display(str(exc)),
                ExitCode.USER_ERROR,
                "invalid_branch_name",
            )

        if not create_branch and not _branch_exists(root, set_branch):
            _emit_error(
                f"Branch {sanitize_display(set_branch)!r} does not exist. "
                "Use --create-branch to point HEAD at a new empty branch.",
                ExitCode.USER_ERROR,
                "branch_not_found",
            )

        try:
            write_head_branch(root, set_branch)
        except OSError as exc:
            logger.debug("symbolic-ref write error: %s", exc)
            _emit_error(
                sanitize_display(str(exc)),
                ExitCode.INTERNAL_ERROR,
                "io_error",
            )

        commit_id = get_head_commit_id(root, set_branch)
        if not json_out:
            if short:
                print(sanitize_display(set_branch))
            else:
                print(sanitize_display(f"refs/heads/{set_branch}"))
            return
        print(json.dumps(_SymbolicRefResult(
            **make_envelope(elapsed),
            ref="HEAD",
            symbolic_target=f"refs/heads/{set_branch}",
            branch=set_branch,
            commit_id=commit_id,
            detached=False,
        )))
        return

    # ── Read mode ─────────────────────────────────────────────────────────────
    try:
        result = _read_symbolic_ref(root)
    except (OSError, ValueError) as exc:
        logger.debug("symbolic-ref read error: %s", exc)
        _emit_error(
            sanitize_display(str(exc)),
            ExitCode.INTERNAL_ERROR,
            "io_error",
        )

    if not json_out:
        if result["detached"]:
            commit = result["commit_id"] or "(no commit)"
            print(sanitize_display(f"(HEAD detached at {commit})"))
        elif short:
            print(sanitize_display(str(result["branch"] or "")))
        else:
            print(sanitize_display(str(result["symbolic_target"] or "")))
        return

    print(json.dumps(_SymbolicRefResult(
        **make_envelope(elapsed),
        ref=str(result["ref"]),
        symbolic_target=result["symbolic_target"],  # type: ignore[arg-type]
        branch=result["branch"],  # type: ignore[arg-type]
        commit_id=result["commit_id"],  # type: ignore[arg-type]
        detached=bool(result["detached"]),
    )))
