"""muse migrate — identity and data migration tooling.

Subcommands::

    muse migrate domain-integers    Re-derive keys at new hash-derived HD paths.
    muse migrate hub-scoping        Re-derive keys with a per-hub HD path level.

``muse migrate domain-integers`` is the Phase 4 companion to the hash-derived
domain constant migration (Phase 1 of issue #3).  Users who generated their
keys before Phase 1 have credentials derived at old sequential domain integers
(0–6).  This command detects those entries in ``~/.muse/identity.toml``,
re-derives the correct keys at the new paths, and re-registers each fingerprint
with its hub.

Usage::

    # Inspect — see what would be migrated (safe, no writes)
    muse migrate domain-integers --dry-run --json

    # Migrate all legacy entries (re-derives keys + re-registers with each hub)
    muse migrate domain-integers --json

JSON schema (``--dry-run``)::

    {
      "dry_run":         true,
      "entries_found":   1,
      "entries_migrated": 0,
      "results": [
        {
          "hub_key":        "localhost:1337",
          "domain_name":    "muse/identity",
          "old_domain_int": 0,
          "new_domain_int": 1660078172,
          "old_hd_path":    "m/1075233755'/0'/0'/0'/0'/0'",
          "new_hd_path":    "m/1075233755'/1660078172'/0'/0'/0'/0'",
          "old_fingerprint": "sha256:...",
          "new_fingerprint": "sha256:...",
          "hub_registered":  false
        }
      ]
    }

``muse migrate hub-scoping`` is the Phase 2 companion to musehub#221.  Prior
to Phase 2, the identity key at rotation index 0 was bit-for-bit identical
regardless of which hub it was registered with — this command detects
six-level identity-domain entries in ``~/.muse/identity.toml`` (no hub
segment), re-derives each at a new hub-scoped path, and re-registers with
that specific hub. Non-identity domains never had hub scoping and are not
touched.

Usage::

    # Inspect — see what would be migrated (safe, no writes)
    muse migrate hub-scoping --dry-run --json

    # Migrate all pre-Phase-2 entries (re-derives keys + re-registers with each hub)
    muse migrate hub-scoping --json

JSON schema (``--dry-run``)::

    {
      "dry_run":         true,
      "entries_found":   1,
      "entries_migrated": 0,
      "results": [
        {
          "hub_key":        "localhost:1337",
          "old_hd_path":    "m/1075233755'/1660078172'/0'/0'/0'/0'",
          "new_hd_path":    "m/1075233755'/1660078172'/0'/0'/0'/1604397778'/0'",
          "old_fingerprint": "sha256:...",
          "new_fingerprint": "sha256:...",
          "hub_registered":  false
        }
      ]
    }

Exit codes
----------
0  Success (including the case where nothing needed migration).
1  No mnemonic found in keychain — run ``muse auth keygen`` first.
3  Unexpected error during key derivation or identity file write.
"""

import argparse
import json
import logging
import sys
from collections.abc import Callable, Mapping

from muse.core.envelope import EnvelopeJson, make_envelope
from muse.core.errors import ExitCode
from muse.core.timing import start_timer

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Hub registration shim — wraps the auth challenge-response flow
# ---------------------------------------------------------------------------

def _make_hub_register_fn(seed: bytes, json_out: bool) -> Callable[[str, str, str, Mapping[str, object]], bool]:
    """Return a hub_register_fn that rotates to the new hub-scoped key.

    This is a key *rotation* for an existing, already-registered handle — not
    a fresh registration. ``POST /api/auth/verify`` (the fresh-registration
    endpoint) correctly rejects it with 409 ("handle already taken"), as
    discovered running this for real against a live hub. The actual endpoint
    is ``POST /api/auth/keys``, MSign-authenticated with the *old* key to
    prove account ownership, with a challenge-response for the *new* key in
    the body to prove its ownership too — mirrors ``muse auth rotate``
    (auth.py's ``run_rotate``, lines ~1414-1514) exactly, including its
    best-effort deregistration of the old key afterward.

    Any hub HTTP error is converted to a return of ``False`` rather than
    left to propagate — ``_json_post_raw`` raises ``SystemExit`` (not a
    plain ``Exception``) on HTTP failure, which would otherwise abort the
    entire multi-hub migration instead of just marking this one hub failed.
    """

    def _register(hub_key: str, new_fingerprint: str, new_hd_path: str, entry: Mapping[str, object]) -> bool:
        import urllib.parse
        from muse.core.keypair import public_key_to_b64url, sign_bytes
        from muse.core.slip010 import derive_path, to_ed25519_private_key
        from muse.core.types import DEFAULT_SIGN_ALGO
        from muse.core.msign import build_msign_header
        from muse.core.transport import SigningIdentity
        from muse.cli.commands.auth import (
            _post_challenge, _hub_base_url, _json_post_raw, _hub_delete, _hub_get,
        )

        hub_url = f"https://{hub_key}" if not hub_key.startswith("http") else hub_key
        base_url = _hub_base_url(hub_url)
        handle = str(entry.get("handle", ""))
        old_hd_path = str(entry.get("hd_path", ""))
        old_fingerprint = str(entry.get("fingerprint", ""))

        if not json_out:
            print(f"  registering {hub_key} …", file=sys.stderr)

        old_dk = derive_path(seed, old_hd_path)
        try:
            old_private_key = to_ed25519_private_key(old_dk)
        finally:
            old_dk.zero()

        new_dk = derive_path(seed, new_hd_path)
        try:
            new_private_key = to_ed25519_private_key(new_dk)
        finally:
            new_dk.zero()

        try:
            new_pub_b64 = public_key_to_b64url(new_private_key.public_key())

            challenge_resp = _post_challenge(base_url, {
                "fingerprint": new_fingerprint,
                "algorithm": DEFAULT_SIGN_ALGO,
            })
            challenge_token = challenge_resp.get("challenge_token") or ""
            if not challenge_token:
                raise RuntimeError("hub returned no challenge_token")

            try:
                nonce_bytes = bytes.fromhex(challenge_token)
            except ValueError:
                nonce_bytes = challenge_token.encode("utf-8")
            new_key_sig = sign_bytes(new_private_key, nonce_bytes)

            add_key_path = "/api/auth/keys"
            add_key_url = f"{base_url}{add_key_path}"
            add_key_payload = {
                "challenge_token": challenge_token,
                "public_key_b64": new_pub_b64,
                "signature_b64": new_key_sig,
                "label": "hub-scoping-migration",
            }
            add_key_body = json.dumps(add_key_payload).encode("utf-8")

            old_signing = SigningIdentity(handle=handle, private_key=old_private_key)
            add_key_auth = build_msign_header(old_signing, "POST", add_key_url, add_key_body)

            _json_post_raw(
                base_url, add_key_path, add_key_payload,
                extra_headers={"Authorization": add_key_auth},
            )

            # Best-effort: deregister the old (pre-hub-scoping) key. Non-fatal --
            # the new key is already registered even if this fails.
            #
            # The old key's key_id is looked up via GET /api/auth/keys/{handle}
            # and matched by fingerprint, rather than recomputed locally from
            # sha256(identity_id, public_key_b64) -- recomputing depends on
            # reproducing the exact public_key_b64 *encoding* the account's
            # original registration used, which can predate conventions the
            # current client uses (e.g. an unprefixed vs. canonically-prefixed
            # base64url string). A stale/legacy account with a key_id computed
            # under an older encoding would make the recomputed key_id wrong
            # and silently 404 on delete -- looking it up by the fingerprint we
            # already know (authoritative, hub-assigned) sidesteps that
            # entirely regardless of encoding history.
            ssl_ctx = None
            parsed = urllib.parse.urlparse(base_url)
            if parsed.scheme == "https" and parsed.hostname in ("localhost", "127.0.0.1"):
                import ssl as _ssl
                from muse.core.transport import _mkcert_ca
                ca = _mkcert_ca()
                if ca is not None:
                    ssl_ctx = _ssl.create_default_context(cafile=str(ca))
            try:
                list_path = f"/api/auth/keys/{urllib.parse.quote(handle)}"
                list_url = f"{base_url}{list_path}"
                list_auth = build_msign_header(old_signing, "GET", list_url, None)
                keys_resp = _hub_get(list_url, list_auth, ssl_ctx)
                old_key_id = next(
                    (k["key_id"] for k in keys_resp.get("keys", []) if k.get("fingerprint") == old_fingerprint),
                    None,
                )
                if old_key_id is None:
                    raise RuntimeError(f"old key (fingerprint={old_fingerprint}) not found in hub key list")

                delete_path = f"/api/auth/keys/{urllib.parse.quote(handle)}/{urllib.parse.quote(old_key_id)}"
                delete_url = f"{base_url}{delete_path}"
                delete_auth = build_msign_header(old_signing, "DELETE", delete_url, None)
                _hub_delete(delete_url, delete_auth, ssl_ctx)
            except Exception as exc:
                logger.warning("could not deregister old key for %s: %s", hub_key, exc)

            return True
        except (Exception, SystemExit) as exc:
            logger.warning("re-registration failed for %s: %s", hub_key, exc)
            if not json_out:
                print(f"  ⚠ registration failed for {hub_key}: {exc}", file=sys.stderr)
            return False

    return _register

# ---------------------------------------------------------------------------
# Subcommand: domain-integers
# ---------------------------------------------------------------------------

def _run_domain_integers(args: argparse.Namespace) -> None:
    elapsed = start_timer()
    dry_run: bool = args.dry_run
    json_out: bool = args.json_out
    skip_register: bool = args.no_register

    # ── Load mnemonic from keychain ─────────────────────────────────────
    from muse.core import keychain as kc
    mnemonic = kc.load()
    if mnemonic is None:
        msg = (
            "No mnemonic found in keychain.\n"
            "Run 'muse auth keygen' to generate your identity first."
        )
        if json_out:
            print(json.dumps({"error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    # ── Derive seed ─────────────────────────────────────────────────────
    try:
        from muse.core.bip39 import mnemonic_to_seed
        seed = mnemonic_to_seed(mnemonic)
    except Exception as exc:
        msg = f"Failed to derive seed from mnemonic: {exc}"
        if json_out:
            print(json.dumps({"error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR) from exc

    # ── Load identity map ───────────────────────────────────────────────
    try:
        from muse.core.identity import list_all_identities
        identity_map = dict(list_all_identities())
    except Exception as exc:
        msg = f"Failed to read identity file: {exc}"
        if json_out:
            print(json.dumps({"error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR) from exc

    # ── Build hub_register_fn ────────────────────────────────────────────
    if dry_run or skip_register:
        from unittest.mock import MagicMock
        hub_register_fn = MagicMock()  # never called: guarded by dry_run/skip_register below
    else:
        hub_register_fn = _make_hub_register_fn(seed, json_out)

    # ── Run migration ────────────────────────────────────────────────────
    from muse.core.domain_migration import build_plans, run_migration

    try:
        results = run_migration(
            identity_map=identity_map,
            seed=seed,
            hub_register_fn=hub_register_fn,
            dry_run=dry_run,
            skip_register=skip_register,
        )
    except Exception as exc:
        msg = f"Migration failed: {exc}"
        if json_out:
            print(json.dumps({"error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR) from exc

    # ── Persist updated identity map (live run only) ─────────────────────
    if not dry_run and results:
        try:
            from muse.core.identity import save_identity
            for r in results:
                entry = identity_map[r.hub_key]
                hub_url = f"https://{r.hub_key}" if not r.hub_key.startswith("http") else r.hub_key
                save_identity(hub_url, entry)
        except Exception as exc:
            logger.warning("Failed to persist updated identity: %s", exc)
            if not json_out:
                print(f"⚠ Could not persist identity: {exc}", file=sys.stderr)

    # ── Output ────────────────────────────────────────────────────────────
    entries_migrated = sum(1 for r in results if r.hub_registered) if not dry_run else 0

    result_dicts = [
        {
            "hub_key": r.hub_key,
            "old_hd_path": r.old_hd_path,
            "new_hd_path": r.new_hd_path,
            "old_fingerprint": r.old_fingerprint,
            "new_fingerprint": r.new_fingerprint,
            "hub_registered": r.hub_registered,
        }
        for r in results
    ]

    if json_out:
        print(json.dumps({
            **make_envelope(elapsed),
            "dry_run": dry_run,
            "entries_found": len(results),
            "entries_migrated": entries_migrated,
            "results": result_dicts,
        }))
        return

    if not results:
        print("✅ No legacy entries found — identity is already up to date.")
        return

    prefix = "[dry-run] " if dry_run else ""
    for r in results:
        status = "would migrate" if dry_run else ("✅ migrated" if r.hub_registered else "⚠ key re-derived (hub registration failed)")
        print(f"{prefix}{r.hub_key}: {status}")
        print(f"  old path: {r.old_hd_path}")
        print(f"  new path: {r.new_hd_path}")

    if dry_run:
        print(f"\n{len(results)} entry/entries would be migrated. Run without --dry-run to apply.")
    else:
        ok = sum(1 for r in results if r.hub_registered)
        print(f"\n{ok}/{len(results)} entries migrated and re-registered.")

# ---------------------------------------------------------------------------
# Subcommand: hub-scoping
# ---------------------------------------------------------------------------

def _run_hub_scoping(args: argparse.Namespace) -> None:
    elapsed = start_timer()
    dry_run: bool = args.dry_run
    json_out: bool = args.json_out
    skip_register: bool = args.no_register

    # ── Load mnemonic from keychain ─────────────────────────────────────
    from muse.core import keychain as kc
    mnemonic = kc.load()
    if mnemonic is None:
        msg = (
            "No mnemonic found in keychain.\n"
            "Run 'muse auth keygen' to generate your identity first."
        )
        if json_out:
            print(json.dumps({"error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    # ── Derive seed ─────────────────────────────────────────────────────
    try:
        from muse.core.bip39 import mnemonic_to_seed
        seed = mnemonic_to_seed(mnemonic)
    except Exception as exc:
        msg = f"Failed to derive seed from mnemonic: {exc}"
        if json_out:
            print(json.dumps({"error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR) from exc

    # ── Load identity map ───────────────────────────────────────────────
    try:
        from muse.core.identity import list_all_identities
        identity_map = dict(list_all_identities())
    except Exception as exc:
        msg = f"Failed to read identity file: {exc}"
        if json_out:
            print(json.dumps({"error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR) from exc

    # ── Restrict to a single hub, if requested ────────────────────────────
    hub_filter: str | None = getattr(args, "hub", None)
    if hub_filter:
        from muse.core.identity import hostname_from_url
        target_key = hostname_from_url(hub_filter)
        if target_key not in identity_map:
            msg = f"No local identity entry for hub {target_key!r}."
            if json_out:
                print(json.dumps({"error": msg}))
            else:
                print(f"❌ {msg}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        identity_map = {target_key: identity_map[target_key]}

    # ── Build hub_register_fn ────────────────────────────────────────────
    if dry_run or skip_register:
        from unittest.mock import MagicMock
        hub_register_fn = MagicMock()  # never called: guarded by dry_run/skip_register below
    else:
        hub_register_fn = _make_hub_register_fn(seed, json_out)

    # ── Run migration ────────────────────────────────────────────────────
    from muse.core.hub_scoping_migration import run_migration as run_hub_scoping_migration

    try:
        results = run_hub_scoping_migration(
            identity_map=identity_map,
            seed=seed,
            hub_register_fn=hub_register_fn,
            dry_run=dry_run,
            skip_register=skip_register,
        )
    except Exception as exc:
        msg = f"Migration failed: {exc}"
        if json_out:
            print(json.dumps({"error": msg}))
        else:
            print(f"❌ {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR) from exc

    # ── Persist updated identity map (live run only) ─────────────────────
    if not dry_run and results:
        try:
            from muse.core.identity import save_identity
            for r in results:
                entry = identity_map[r.hub_key]
                hub_url = f"https://{r.hub_key}" if not r.hub_key.startswith("http") else r.hub_key
                save_identity(hub_url, entry)
        except Exception as exc:
            logger.warning("Failed to persist updated identity: %s", exc)
            if not json_out:
                print(f"⚠ Could not persist identity: {exc}", file=sys.stderr)

    # ── Output ────────────────────────────────────────────────────────────
    entries_migrated = sum(1 for r in results if r.hub_registered) if not dry_run else 0

    result_dicts = [
        {
            "hub_key": r.hub_key,
            "old_hd_path": r.old_hd_path,
            "new_hd_path": r.new_hd_path,
            "old_fingerprint": r.old_fingerprint,
            "new_fingerprint": r.new_fingerprint,
            "hub_registered": r.hub_registered,
        }
        for r in results
    ]

    if json_out:
        print(json.dumps({
            **make_envelope(elapsed),
            "dry_run": dry_run,
            "entries_found": len(results),
            "entries_migrated": entries_migrated,
            "results": result_dicts,
        }))
        return

    if not results:
        print("✅ No pre-hub-scoping entries found — identity is already up to date.")
        return

    prefix = "[dry-run] " if dry_run else ""
    for r in results:
        status = "would migrate" if dry_run else ("✅ migrated" if r.hub_registered else "⚠ key re-derived (hub registration failed)")
        print(f"{prefix}{r.hub_key}: {status}")
        print(f"  old path: {r.old_hd_path}")
        print(f"  new path: {r.new_hd_path}")

    if dry_run:
        print(f"\n{len(results)} entry/entries would be migrated. Run without --dry-run to apply.")
    else:
        ok = sum(1 for r in results if r.hub_registered)
        print(f"\n{ok}/{len(results)} entries migrated and re-registered.")

# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the ``muse migrate`` namespace."""
    parser = subparsers.add_parser(
        "migrate",
        help="Identity and data migration tooling.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    migrate_subs = parser.add_subparsers(dest="migrate_subcmd", metavar="SUBCMD")
    migrate_subs.required = True

    # ── domain-integers ────────────────────────────────────────────────
    p_di = migrate_subs.add_parser(
        "domain-integers",
        help=(
            "Re-derive identity keys at new hash-derived HD paths "
            "and re-register with each hub."
        ),
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_di.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Detect legacy entries and compute new keys — no writes, no hub calls.",
    )
    p_di.add_argument(
        "--no-register",
        action="store_true",
        default=False,
        dest="no_register",
        help="Re-derive keys and update identity.toml but skip hub re-registration.",
    )
    p_di.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON.",
    )
    p_di.set_defaults(func=_run_domain_integers)

    # ── hub-scoping ────────────────────────────────────────────────────
    p_hs = migrate_subs.add_parser(
        "hub-scoping",
        help=(
            "Re-derive identity keys with a per-hub HD path level "
            "and re-register with each hub (musehub#221)."
        ),
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_hs.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Detect pre-hub-scoping entries and compute new keys — no writes, no hub calls.",
    )
    p_hs.add_argument(
        "--no-register",
        action="store_true",
        default=False,
        dest="no_register",
        help="Re-derive keys and update identity.toml but skip hub re-registration.",
    )
    p_hs.add_argument(
        "--hub",
        default=None,
        help="Restrict migration to a single hub (e.g. https://localhost:1337). "
             "Default: migrate every pre-hub-scoping entry in identity.toml at once.",
    )
    p_hs.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_out",
        help="Emit machine-readable JSON.",
    )
    p_hs.set_defaults(func=_run_hub_scoping)
