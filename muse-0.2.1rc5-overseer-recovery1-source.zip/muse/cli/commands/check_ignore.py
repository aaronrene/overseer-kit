"""muse check-ignore — test whether paths are ignored by ``.museignore``.

Reads the ``.museignore`` file (if present), resolves patterns for the active
domain, and evaluates each supplied path against the compiled rule list.
Reports whether each path is ignored and — when in verbose text mode — which
pattern matched it.  JSON output always includes the matching pattern.

Output (JSON, default)::

    {
      "domain": "midi",
      "patterns_loaded": 4,
      "summary": {
        "total":       2,
        "ignored":     1,
        "not_ignored": 1
      },
      "results": [
        {
          "path":             "build/output.bin",
          "ignored":          true,
          "matching_pattern": "build/"
        },
        {
          "path":             "tracks/drums.mid",
          "ignored":          false,
          "matching_pattern": null
        }
      ],
      "duration_ms": 0.000087,
      "exit_code": 0
    }

Text output (``--format text``)::

    ignored   build/output.bin    [build/]
    ok        tracks/drums.mid

With ``--quiet`` (exits 0 if *all* paths are ignored, exits 1 otherwise, no
other output)::

    (empty stdout)

With ``--patterns-only`` (emit the active pattern list, no paths needed)::

    {
      "domain": "midi",
      "patterns_loaded": 3,
      "patterns": ["build/", "*.bin", "!tracks/*.mid"],
      "duration_ms": 0.000031,
      "exit_code": 0
    }

Output contract
---------------

- Exit 0: all evaluated paths are ignored (success for ``--quiet`` mode), or
          all results emitted normally.
- Exit 1: one or more paths are not ignored (``--quiet`` mode only); bad args
          or bad ``--format``; ``--ignored-only`` combined with ``--patterns-only``
          or ``--quiet``.
- Exit 3: I/O or TOML parse error reading ``.museignore``.

JSON fields present in every successful response
------------------------------------------------

``duration_ms``
    Wall-clock time in seconds from argument parsing to output.
``exit_code``
    Always ``0`` on success.  Lets agents parse a single JSON payload instead
    of inspecting the process exit code separately.
``summary`` *(default mode only)*
    ``total`` — number of results emitted (after ``--ignored-only`` filter).
    ``ignored`` — paths that matched an ignore pattern.
    ``not_ignored`` — paths that did not match any ignore pattern.
``patterns_loaded`` *(both modes)*
    Count of patterns resolved for the active domain.

Matching engine
---------------

The matching logic (last-match-wins, negation rules, directory patterns,
anchored patterns) lives exclusively in :func:`muse.core.ignore.check_path_with_pattern`.
This command is a thin consumer of that function — it never reimplements the
matching rules, ensuring it always agrees with ``muse code add`` and the
snapshot engine.

Agent use
---------

Inspect active patterns before staging::

    muse check-ignore --patterns-only --json

Audit which staged files will be excluded from the snapshot::

    muse check-ignore --ignored-only --stdin < staged_paths.txt --json

Pipe a list of paths from another command::

    muse code symbols --kind import | awk '{print $NF}' | \\
      muse check-ignore --stdin

Check a batch of paths non-interactively::

    muse check-ignore build/render.bin tmp/*.log --json

Quiet mode for scripting::

    muse check-ignore dist/ && echo "dist is ignored"

Summary-only audit (no per-path detail needed)::

    muse check-ignore foo.py bar.py baz.py --json | \\
      python3 -c "import sys,json; s=json.load(sys.stdin)['summary']; print(s)"
"""

import argparse
import json
import logging
import sys
from typing import TypedDict

from muse.core.errors import ExitCode
from muse.core.ignore import check_path_with_pattern, load_ignore_config, resolve_patterns
from muse.core.repo import require_repo
from muse.core.validation import sanitize_display, validate_workspace_path
from muse.core.timing import start_timer
from muse.core.envelope import EnvelopeJson, make_envelope
from muse.plugins.registry import read_domain

logger = logging.getLogger(__name__)

class _PathResult(TypedDict):
    path: str
    ignored: bool
    matching_pattern: str | None

class _SummaryDict(TypedDict):
    total: int
    ignored: int
    not_ignored: int

class _PatternsOnlyJson(EnvelopeJson):
    """Wire shape for --patterns-only --json."""

    domain: str
    patterns_loaded: int
    patterns: list[str]

class _CheckIgnoreJson(EnvelopeJson):
    """Wire shape for default path-check --json output."""

    domain: str
    patterns_loaded: int
    summary: _SummaryDict
    results: list[dict]

def register(subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]") -> None:
    """Register the check-ignore subcommand."""
    parser = subparsers.add_parser(
        "check-ignore",
        help="Test paths against .museignore rules.",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "paths",
        nargs="*",
        help=(
            "Workspace-relative paths to test.  "
            "At least one path is required unless --stdin or --patterns-only is used."
        ),
    )
    parser.add_argument(
        "--stdin",
        action="store_true",
        dest="from_stdin",
        help=(
            "Read additional paths from stdin, one per line.  "
            "Blank lines and lines starting with '#' are skipped.  "
            "Combines with positional path arguments."
        ),
    )
    parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="No output. Exit 0 if all paths are ignored, exit 1 otherwise.",
    )
    parser.add_argument(
        "--verbose", "-V",
        action="store_true",
        help="Include the matching pattern in text output (JSON always includes it).",
    )
    parser.add_argument(
        "--patterns-only",
        action="store_true",
        dest="patterns_only",
        help=(
            "Emit the resolved pattern list for this domain and exit.  "
            "No path arguments needed.  "
            "Useful for agents inspecting active ignore rules before staging."
        ),
    )
    parser.add_argument(
        "--json", "-j", action="store_true", dest="json_out",
        help="Emit machine-readable JSON.",
    )
    parser.add_argument(
        "--ignored-only",
        action="store_true",
        dest="ignored_only",
        help=(
            "Show only paths that are ignored.  "
            "Useful for auditing which staged files will be excluded from the snapshot."
        ),
    )
    parser.set_defaults(func=run)

def run(args: argparse.Namespace) -> None:
    """Test whether paths are excluded by ``.museignore`` rules.

    Evaluates each supplied path against the global and domain-specific
    patterns loaded from ``.museignore``.  Uses the same matching engine as the
    snapshot engine so results are always consistent with ``muse commit``.  Use
    ``--patterns-only`` to inspect the loaded rules without providing paths;
    ``--ignored-only`` to filter output to only excluded paths.

    Agent quickstart
    ----------------
    ::

        muse check-ignore tracks/drums.mid build/ --json
        muse check-ignore --patterns-only --json
        muse check-ignore --stdin --json < staged_paths.txt

    JSON fields
    -----------
    domain           Repository domain (e.g. ``"code"``).
    patterns_loaded  Number of patterns loaded.
    summary          ``total``, ``ignored``, ``not_ignored`` counts.
    results          List of per-path objects: ``path``, ``ignored`` (bool),
                     ``matching_pattern`` (first matching rule or ``null``).
    patterns         List of loaded patterns (only with ``--patterns-only``).

    Exit codes
    ----------
    0  Query completed (paths may or may not be ignored).
    1  Conflicting flags, missing paths, or path validation error.
    2  Not inside a Muse repository.
    3  Internal error reading ``.museignore``.
    """
    elapsed = start_timer()
    json_out: bool = args.json_out
    cli_paths: list[str] = args.paths or []
    from_stdin: bool = args.from_stdin
    quiet: bool = args.quiet
    verbose: bool = args.verbose
    patterns_only: bool = args.patterns_only
    ignored_only: bool = getattr(args, "ignored_only", False)

    if ignored_only and patterns_only:
        print(
            json.dumps({"error": "--ignored-only and --patterns-only are mutually exclusive."}),
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    if ignored_only and quiet:
        print(
            json.dumps({"error": "--ignored-only and --quiet are mutually exclusive."}),
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    root = require_repo()
    domain = read_domain(root)

    try:
        config = load_ignore_config(root)
    except ValueError as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        raise SystemExit(ExitCode.INTERNAL_ERROR)

    patterns = resolve_patterns(config, domain)

    # --patterns-only: emit the resolved pattern list and exit — no paths needed.
    if patterns_only:
        if not json_out:
            for pat in patterns:
                print(pat)
        else:
            print(json.dumps(_PatternsOnlyJson(
                **make_envelope(elapsed),
                domain=domain,
                patterns_loaded=len(patterns),
                patterns=patterns,
            )))
        return

    # Collect paths: positional args + optional stdin.
    # Strip \r\n (not just \n) — CRLF-terminated input would embed \r in path
    # strings, which silently corrupts pattern matching and text output.
    all_paths: list[str] = list(cli_paths)
    if from_stdin:
        for line in sys.stdin:
            stripped = line.rstrip("\r\n")
            if stripped and not stripped.startswith("#"):
                all_paths.append(stripped)

    if not all_paths:
        print(
            json.dumps({"error": "At least one path argument is required."}),
            file=sys.stderr,
        )
        raise SystemExit(ExitCode.USER_ERROR)

    # Validate paths: reject traversal sequences, null bytes, absolute paths,
    # control characters, and excessively long values.
    for p in all_paths:
        try:
            validate_workspace_path(p)
        except ValueError as exc:
            print(
                json.dumps({"error": f"Invalid path {p!r}: {exc}"}),
                file=sys.stderr,
            )
            raise SystemExit(ExitCode.USER_ERROR)

    # Evaluate every path using the single authoritative engine in core/ignore.py.
    results: list[_PathResult] = []
    for p in all_paths:
        ignored, matching = check_path_with_pattern(p, patterns)
        results.append({"path": p, "ignored": ignored, "matching_pattern": matching})

    if quiet:
        all_ignored = all(r["ignored"] for r in results)
        raise SystemExit(0 if all_ignored else ExitCode.USER_ERROR)

    # --ignored-only: retain only paths that matched an ignore pattern.
    if ignored_only:
        results = [r for r in results if r["ignored"]]

    # Build summary over the (possibly filtered) result set.
    summary: _SummaryDict = {
        "total": len(results),
        "ignored": sum(1 for r in results if r["ignored"]),
        "not_ignored": sum(1 for r in results if not r["ignored"]),
    }

    if not json_out:
        for r in results:
            status = "ignored" if r["ignored"] else "ok     "
            if verbose and r["matching_pattern"]:
                print(
                    f"{status}  {sanitize_display(r['path'])}    "
                    f"[{sanitize_display(r['matching_pattern'])}]"
                )
            else:
                print(f"{status}  {sanitize_display(r['path'])}")
        return

    print(json.dumps(_CheckIgnoreJson(
        **make_envelope(elapsed),
        domain=domain,
        patterns_loaded=len(patterns),
        summary=summary,
        results=[dict(r) for r in results],
    )))
