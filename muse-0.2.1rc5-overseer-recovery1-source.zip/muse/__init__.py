"""Muse — domain-agnostic version control for multidimensional state."""

import pathlib as _pathlib
import re as _re

def _read_version() -> str:
    # Editable install: pyproject.toml lives two levels up from this file.
    # Reading it directly means bumping pyproject.toml is instantly reflected
    # without reinstalling. Packaged installs have no pyproject.toml alongside
    # the source, so they fall through to importlib.metadata.
    _toml = _pathlib.Path(__file__).parent.parent / "pyproject.toml"
    if _toml.is_file():
        _m = _re.search(r'^version\s*=\s*"([^"]+)"', _toml.read_text(), _re.MULTILINE)
        if _m:
            return _m.group(1)
    from importlib.metadata import PackageNotFoundError, version as _meta_version
    try:
        return _meta_version("muse")
    except PackageNotFoundError:
        return "0.0.0+dev"

__version__: str = _read_version()
