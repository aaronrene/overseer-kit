"""Hub-scoping migration — re-derive identity keys with a per-hub HD path level.

Pre-Phase-2 Muse derived the identity (MSign auth) key with no hub-specific
level in the HD path — the key at rotation index 0 was bit-for-bit identical
regardless of which hub it was registered with (musehub#221). Phase 2 inserts
a hardened ``hub'`` level (see :func:`muse.core.hdkeys.hub_index`) between
``role'`` and ``index'``. Users who registered identities before Phase 2 must
re-derive at the new, hub-scoped path and re-register with the affected hub.

Public API
----------

``is_pre_hub_scoping_hd_path(hd_path)``
    Returns True if *hd_path* is a six-level identity-domain path with no
    hub segment.

``new_path_for_pre_hub_scoping(hd_path, hub_key)``
    Returns the equivalent path with the hub segment inserted, scoped to
    *hub_key*. Raises ``ValueError`` for unknown or already-scoped paths.

``scan_for_pre_hub_scoping(identity_map)``
    Returns the list of hub keys in *identity_map* whose ``hd_path`` predates
    hub scoping.

``build_plans(identity_map)``
    Returns one :class:`MigrationPlan` per pre-Phase-2 entry.

``run_migration(identity_map, seed, hub_register_fn, dry_run)``
    Drives the full migration, optionally calling *hub_register_fn* for each
    entry, and mutating *identity_map* in place on a live run. Returns a
    list of :class:`MigrationResult`.
"""

import logging
import re
from collections.abc import Mapping
from dataclasses import dataclass

from muse.core.hdkeys import DOMAIN_IDENTITY, hub_index, muse_path
from muse.core.identity import hostname_from_url
from muse.core.slip010 import MUSE_PURPOSE

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Path parsing
# ---------------------------------------------------------------------------

# Six-level path (no hub segment): m/purpose'/domain'/entity_type'/entity_id'/role'/index'
_SIX_LEVEL_RE = re.compile(
    r"^m/(\d+)'"
    r"/(\d+)'"
    r"/(\d+)'"
    r"/(\d+)'"
    r"/(\d+)'"
    r"/(\d+)'$"
)

def _parse_six_level(hd_path: str) -> tuple[int, int, int, int, int, int] | None:
    """Parse *hd_path* as a six-level path, or return None if it doesn't match."""
    m = _SIX_LEVEL_RE.match(hd_path.strip())
    if not m:
        return None
    return tuple(int(m.group(i)) for i in range(1, 7))  # type: ignore[return-value]

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def is_pre_hub_scoping_hd_path(hd_path: str) -> bool:
    """Return True if *hd_path* is a pre-Phase-2 identity path with no hub segment.

    Only six-level paths with the Muse purpose index and the
    :data:`~muse.core.hdkeys.DOMAIN_IDENTITY` domain are considered —
    non-identity domains (code, music, payments, ...) never had hub scoping
    and are not part of this migration.
    """
    parsed = _parse_six_level(hd_path)
    if parsed is None:
        return False
    purpose, domain, *_ = parsed
    return purpose == MUSE_PURPOSE and domain == DOMAIN_IDENTITY

def new_path_for_pre_hub_scoping(hd_path: str, hub_key: str) -> str:
    """Return the equivalent HD path with a hub segment scoped to *hub_key*.

    Parameters
    ----------
    hd_path:
        A pre-Phase-2 six-level identity path.
    hub_key:
        Canonical hostname (as stored as the ``identity.toml`` section key,
        e.g. ``"musehub.ai"``, ``"localhost:1337"``) — hashed via
        :func:`~muse.core.hdkeys.hub_index` to compute the hub segment.

    Raises
    ------
    ValueError
        If *hd_path* is not a recognised pre-Phase-2 identity path.
    """
    parsed = _parse_six_level(hd_path)
    if parsed is None:
        raise ValueError(f"Cannot parse HD path: {hd_path!r}")
    purpose, domain, entity_type, entity_id, role, index = parsed
    if purpose != MUSE_PURPOSE:
        raise ValueError(f"Not a Muse HD path (wrong purpose {purpose}): {hd_path!r}")
    if domain != DOMAIN_IDENTITY:
        raise ValueError(f"Not an identity-domain path (domain {domain}): {hd_path!r}")
    hub = hub_index(hostname_from_url(hub_key))
    return muse_path(domain, entity_type, entity_id, role, index, hub=hub)

# Seven-level path with a hub segment: .../role'/hub'/index'
_SEVEN_LEVEL_RE = re.compile(
    r"^m/(\d+)'"
    r"/(\d+)'"
    r"/(\d+)'"
    r"/(\d+)'"
    r"/(\d+)'"
    r"/(\d+)'"
    r"/(\d+)'$"
)

def derive_fingerprint_at_hub_scoped_path(seed: bytes, hd_path: str) -> str:
    """Derive the Ed25519 public-key fingerprint at a hub-scoped (7-level) HD path.

    Unlike :func:`muse.core.domain_migration.derive_fingerprint_at_path`, this
    accepts the seven-level ``.../role'/hub'/index'`` shape produced by
    :func:`new_path_for_pre_hub_scoping` — that module's validator only
    recognises the pre-Phase-2 six-level shape.

    Returns a canonical ``sha256:<64-hex>`` string. The private key bytes
    are zeroed immediately after use.
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

    from muse.core.slip010 import derive_path
    from muse.core.types import public_key_fingerprint

    if not _SEVEN_LEVEL_RE.match(hd_path.strip()):
        raise ValueError(f"Cannot parse hub-scoped HD path for derivation: {hd_path!r}")

    dk = derive_path(seed, hd_path)
    try:
        private_key = Ed25519PrivateKey.from_private_bytes(dk.private_bytes)
    finally:
        dk.zero()

    public_key = private_key.public_key()
    raw = public_key.public_bytes(Encoding.Raw, PublicFormat.Raw)
    return public_key_fingerprint(raw)

# ---------------------------------------------------------------------------
# Scanning
# ---------------------------------------------------------------------------

def scan_for_pre_hub_scoping(identity_map: Mapping[str, Mapping[str, object]]) -> list[str]:
    """Return hub keys in *identity_map* whose ``hd_path`` predates hub scoping.

    Entries without an ``hd_path`` field are silently skipped.
    """
    result = []
    for hub_key, entry in identity_map.items():
        hd_path = entry.get("hd_path", "")
        if hd_path and is_pre_hub_scoping_hd_path(hd_path):
            result.append(hub_key)
    return result

# ---------------------------------------------------------------------------
# Plan and Result
# ---------------------------------------------------------------------------

@dataclass
class MigrationPlan:
    """Describes a single identity entry that needs hub-scoping migration."""

    hub_key: str
    old_hd_path: str
    new_hd_path: str

@dataclass
class MigrationResult:
    """Outcome of migrating a single identity entry."""

    hub_key: str
    old_fingerprint: str
    new_fingerprint: str
    old_hd_path: str
    new_hd_path: str
    hub_registered: bool

def build_plans(identity_map: Mapping[str, Mapping[str, object]]) -> list[MigrationPlan]:
    """Return one :class:`MigrationPlan` per pre-Phase-2 entry in *identity_map*."""
    plans = []
    for hub_key in scan_for_pre_hub_scoping(identity_map):
        entry = identity_map[hub_key]
        old_path = entry["hd_path"]
        plans.append(MigrationPlan(
            hub_key=hub_key,
            old_hd_path=old_path,
            new_hd_path=new_path_for_pre_hub_scoping(old_path, hub_key),
        ))
    return plans

# ---------------------------------------------------------------------------
# Migration runner
# ---------------------------------------------------------------------------

def run_migration(
    identity_map: dict[str, dict],
    seed: bytes,
    hub_register_fn: "Any",  # noqa: F821
    dry_run: bool = True,
    skip_register: bool = False,
) -> list[MigrationResult]:
    """Drive the full hub-scoping migration.

    For each pre-Phase-2 entry in *identity_map*:

    1. Derive the new fingerprint at the hub-scoped HD path.
    2. If not dry-run and not skip-register, call
       ``hub_register_fn(hub_key, new_fingerprint, new_hd_path, entry)``.
    3. Update *identity_map* in place — but only when the hub actually has
       the new key (``hub_registered``), or the caller explicitly asked to
       skip hub registration (``skip_register``). A *failed* registration
       attempt must never mutate local state: doing so would leave
       identity.toml claiming a key the hub never received, permanently
       desyncing local from remote with no way for a future run to detect
       it (the entry would no longer look pre-scoping). ``skip_register``
       is a deliberate, different case — the caller knows no hub call was
       made and still wants local state updated (e.g. `--no-register`).
    4. Append a :class:`MigrationResult` to the return list.

    Parameters
    ----------
    identity_map:
        The full identity map (hub key → entry dict). Mutated in place on a
        live run when registration succeeds (or is explicitly skipped);
        untouched during dry-run or on a failed registration attempt.
    seed:
        64-byte BIP39 root seed.
    hub_register_fn:
        Callable ``(hub_key, new_fingerprint, new_hd_path, entry) -> bool``.
        Should return True on success, raise or return False on failure.
        Not called during dry-run or when *skip_register* is set.
    dry_run:
        When True, compute results but make no writes and skip hub calls.
    skip_register:
        When True (and not dry-run), re-derive keys and update
        *identity_map* but never call *hub_register_fn* — the resulting
        :class:`MigrationResult.hub_registered` is ``False`` since no hub
        call was made, but local state is still updated because the
        caller explicitly asked for this, not because anything failed.

    Returns
    -------
    list[MigrationResult]
        One entry per pre-Phase-2 identity found. Empty list when nothing
        needed migration.
    """
    plans = build_plans(identity_map)
    results: list[MigrationResult] = []

    for plan in plans:
        entry = identity_map[plan.hub_key]
        old_fp = entry.get("fingerprint", "")
        new_fp = derive_fingerprint_at_hub_scoped_path(seed, plan.new_hd_path)

        hub_registered = False
        if not dry_run:
            if not skip_register:
                try:
                    outcome = hub_register_fn(plan.hub_key, new_fp, plan.new_hd_path, entry)
                    hub_registered = bool(outcome)
                except Exception as exc:
                    logger.warning("hub_register_fn failed for %s: %s", plan.hub_key, exc)
                    hub_registered = False
            # Only mutate local state once the hub actually has the new key, or
            # the caller explicitly asked to skip hub registration entirely.
            # Updating identity.toml on a *failed* registration would leave
            # local state claiming a key the hub never received — every
            # subsequent authenticated call to that hub would then fail, and
            # nothing about this migration command would show it as still
            # needing migration (the six-level pre-scoping check would no
            # longer match). Leaving the entry untouched on failure keeps
            # local and remote state from ever diverging, and keeps the entry
            # visible to a re-run.
            if hub_registered or skip_register:
                entry["fingerprint"] = new_fp
                entry["hd_path"] = plan.new_hd_path

        results.append(MigrationResult(
            hub_key=plan.hub_key,
            old_fingerprint=old_fp,
            new_fingerprint=new_fp,
            old_hd_path=plan.old_hd_path,
            new_hd_path=plan.new_hd_path,
            hub_registered=hub_registered,
        ))

    return results
