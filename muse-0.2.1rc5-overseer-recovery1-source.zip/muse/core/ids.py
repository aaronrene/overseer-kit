"""Canonical ID derivation for all Muse object types."""

import hashlib
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from muse.core.types import Manifest

DEFAULT_HASH_ALGO: str = "sha256"


def long_id(hex_digest: str, algo: str = DEFAULT_HASH_ALGO, *, strip: bool = False) -> str:
    """Canonical long-form of an algorithm-prefixed object ID."""
    prefix = f"{algo}:"
    if hex_digest.startswith(prefix):
        return hex_digest[len(prefix):] if strip else hex_digest
    return hex_digest if strip else f"{prefix}{hex_digest}"


def hash_blob(data: bytes, hash_algo: str = DEFAULT_HASH_ALGO) -> str:
    """Return the canonical content-addressed ID for raw bytes.

    The type is baked into the hash: ``sha256("blob <size>\\0<data>")``.

    Args:
        data:      Raw bytes to hash.
        hash_algo: Hash algorithm name (default :data:`DEFAULT_HASH_ALGO`).

    Returns:
        A ``<hash_algo>:<hex>`` content-addressed ID string.
    """
    header = f"blob {len(data)}\0".encode()
    return long_id(hashlib.new(hash_algo, header + data).hexdigest(), hash_algo)


_SEP: str = "\x00"


def hash_snapshot(
    manifest: "Manifest",
    directories: list[str] | None = None,
    hash_algo: str = DEFAULT_HASH_ALGO,
) -> str:
    """Return the canonical content-addressed ID for a snapshot manifest.

    The type is baked into the hash: ``sha256("snapshot <size>\\0<canonical>")``.
    """
    from muse.core.types import split_id
    parts = sorted(
        f"{path}{_SEP}{split_id(oid)[1]}" for path, oid in manifest.items()
    )
    if directories:
        parts.extend(f"dir{_SEP}{d}" for d in sorted(directories))
    canonical = _SEP.join(parts).encode()
    header = f"snapshot {len(canonical)}\0".encode()
    return long_id(hashlib.new(hash_algo, header + canonical).hexdigest(), hash_algo)


def hash_commit(
    parent_ids: list[str],
    snapshot_id: str,
    message: str,
    committed_at_iso: str,
    author: str = "",
    signer_public_key: str = "",
    hash_algo: str = DEFAULT_HASH_ALGO,
) -> str:
    """Return the canonical content-addressed ID for a commit.

    The type is baked into the hash: ``sha256("commit <size>\\0<canonical>")``.
    """
    from muse.core.types import split_id
    parts = [
        _SEP.join(sorted(split_id(p)[1] for p in parent_ids)),
        split_id(snapshot_id)[1] if snapshot_id else "",
        message,
        committed_at_iso,
        author,
        signer_public_key,
    ]
    canonical = _SEP.join(parts).encode()
    header = f"commit {len(canonical)}\0".encode()
    return long_id(hashlib.new(hash_algo, header + canonical).hexdigest(), hash_algo)


def commit_identity_bytes(
    parent_ids: list[str],
    snapshot_id: str,
    message: str,
    committed_at_iso: str,
    author: str = "",
    signer_public_key: str = "",
) -> bytes:
    """Return the canonical bytes that are hashed to produce a commit ID.

    Used by signature verification — the signed payload is these bytes.
    """
    from muse.core.types import split_id
    parts = [
        _SEP.join(sorted(split_id(p)[1] for p in parent_ids)),
        split_id(snapshot_id)[1] if snapshot_id else "",
        message,
        committed_at_iso,
        author,
        signer_public_key,
    ]
    canonical = _SEP.join(parts).encode()
    header = f"commit {len(canonical)}\0".encode()
    return header + canonical
