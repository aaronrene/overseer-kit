"""Muse VCS merge engine — fast-forward, 3-way, op-level, and CRDT merge.

Public API
----------
Pure functions (no I/O):

- :func:`diff_snapshots` — paths that changed between two snapshot manifests.
- :func:`detect_conflicts` — paths where both branches made DIVERGENT changes.
- :func:`apply_merge` — build merged manifest for a conflict-free 3-way merge.
- :func:`crdt_join_snapshots` — convergent CRDT join; always succeeds.

Address-keyed Map merge (operation-level):

- :mod:`muse.core.op_merge` — ``ops_commute``, ``adjust_sequence_positions``,
  ``merge_op_lists``, ``merge_structured``, and
  :class:`~muse.core.op_merge.MergeOpsResult`.
  Plugins that implement :class:`~muse.domain.AddressedMergePlugin` use these
  functions to auto-merge non-conflicting ``DomainOp`` lists.  Operations on
  different addresses commute automatically; same-address conflicts route to
  Harmony.

CRDT convergent merge:

- :func:`crdt_join_snapshots` — detects :class:`~muse.domain.CRDTPlugin` at
  runtime and delegates to ``plugin.join(a, b)``.  Returns a
  :class:`~muse.domain.MergeResult` with an empty ``conflicts`` list; CRDT
  joins never fail.

File-based helpers:

- :func:`find_merge_base` — lowest common ancestor (LCA) of two commits.
- :func:`read_merge_state` — detect and load an in-progress merge.
- :func:`write_merge_state` — persist conflict state before exiting.
- :func:`clear_merge_state` — remove MERGE_STATE.json after resolution.
- :func:`resolve_path` — clear all conflict entries for a file path (Phase 1, issue #8).
- :func:`resolve_symbol` — clear one conflict entry by full symbol address (Phase 1, issue #8).
- :func:`apply_resolution` — restore a specific object version to state/.

``MERGE_STATE.json`` schema
---------------------------

.. code-block:: json

    {
        "base_commit": "abc123...",
        "ours_commit": "def456...",
        "theirs_commit": "789abc...",
        "conflict_paths": ["beat.mid", "lead.mp3"],
        "other_branch": "feature/experiment"
    }

``other_branch`` is optional; all other fields are required when conflicts exist.
"""

import json
import logging
import pathlib
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, TypedDict

from muse._version import __version__
from muse.core.types import MUSE_DIR, Manifest, load_json_file, short_id
from muse.core.paths import merge_state_path as _merge_state_path
from muse.core.io import write_text_atomic
from muse.core.validation import contain_path, validate_object_id, validate_ref_id

if TYPE_CHECKING:
    from muse.domain import MergeResult, MuseDomainPlugin

logger = logging.getLogger(__name__)

type VectorClock = dict[str, int]    # agent_id → logical clock count
type CRDTState = dict[str, str]      # path → blob hash for CRDT metadata

_MERGE_STATE_FILENAME = "MERGE_STATE.json"

# ---------------------------------------------------------------------------
# Wire-format TypedDict
# ---------------------------------------------------------------------------

class MergeStatePayload(TypedDict, total=False):
    """JSON-serialisable form of an in-progress merge state."""

    base_commit: str
    ours_commit: str
    theirs_commit: str
    conflict_paths: list[str]
    original_conflict_paths: list[str]
    manually_resolved: list[str]
    other_branch: str

# ---------------------------------------------------------------------------
# MergeState dataclass
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class MergeState:
    """Describes an in-progress merge with unresolved conflicts.

    ``conflict_paths`` — paths still unresolved; shrinks as the user runs
    ``muse checkout --ours/--theirs`` or ``muse resolve`` for each conflict.

    ``original_conflict_paths`` — full list of paths that conflicted when the
    merge was first written.  Never modified after initial write.  Used by
    ``muse commit`` to pass the complete conflict set to harmony even when all
    individual conflicts have been cleared.

    ``manually_resolved`` — subset of original_conflict_paths that the user
    explicitly marked resolved via ``muse resolve`` (i.e. edited manually and
    confirmed).  Harmony uses this to assign ``confidence=1.0,
    human_verified=True`` to these paths and lower confidence to side-picked
    resolutions (``checkout --ours/--theirs``).
    """

    conflict_paths: list[str] = field(default_factory=list)
    original_conflict_paths: list[str] = field(default_factory=list)
    manually_resolved: list[str] = field(default_factory=list)
    base_commit: str | None = None
    ours_commit: str | None = None
    theirs_commit: str | None = None
    other_branch: str | None = None

# ---------------------------------------------------------------------------
# Filesystem helpers
# ---------------------------------------------------------------------------

def read_merge_state(root: pathlib.Path) -> MergeState | None:
    """Return :class:`MergeState` if a merge is in progress, otherwise ``None``."""
    merge_state_path = root / MUSE_DIR / _MERGE_STATE_FILENAME
    if not merge_state_path.exists():
        return None
    data = load_json_file(merge_state_path)
    if data is None:
        logger.warning("⚠️ Failed to read %s", _MERGE_STATE_FILENAME)
        return None

    def _safe_conflict_list(key: str) -> list[str]:
        raw = data.get(key, [])
        out: list[str] = []
        if isinstance(raw, list):
            for c in raw:
                try:
                    contained = contain_path(root, str(c))
                    out.append(contained.relative_to(root.resolve()).as_posix())
                except ValueError:
                    logger.warning(
                        "⚠️ Skipping unsafe conflict path %r from MERGE_STATE.json", c
                    )
        return out

    safe_conflict_paths = _safe_conflict_list("conflict_paths")
    safe_original_paths = _safe_conflict_list("original_conflict_paths")

    # manually_resolved entries are already validated conflict paths — read as plain strings.
    raw_manually = data.get("manually_resolved", [])
    safe_manually: list[str] = [str(s) for s in raw_manually if isinstance(s, str)] if isinstance(raw_manually, list) else []

    def _validated_ref(key: str) -> str | None:
        val = data.get(key)
        if val is None:
            return None
        s = str(val)
        try:
            validate_ref_id(s)
            return s
        except ValueError:
            logger.warning(
                "⚠️ Invalid %s %r in MERGE_STATE.json — ignoring", key, s
            )
            return None

    def _str_or_none(key: str) -> str | None:
        val = data.get(key)
        return str(val) if val is not None else None

    return MergeState(
        conflict_paths=safe_conflict_paths,
        original_conflict_paths=safe_original_paths or safe_conflict_paths,
        manually_resolved=safe_manually,
        base_commit=_validated_ref("base_commit"),
        ours_commit=_validated_ref("ours_commit"),
        theirs_commit=_validated_ref("theirs_commit"),
        other_branch=_str_or_none("other_branch"),
    )

def write_merge_state(
    root: pathlib.Path,
    *,
    base_commit: str,
    ours_commit: str,
    theirs_commit: str,
    conflict_paths: list[str],
    other_branch: str | None = None,
) -> None:
    """Write ``.muse/MERGE_STATE.json`` to signal an in-progress conflicted merge.

    Called by the ``muse merge`` command when the merge produces at least one
    conflict that cannot be auto-resolved.  The file is read back by
    :func:`read_merge_state` on subsequent ``muse status`` and ``muse commit``
    invocations to surface conflict state to the user.

    Args:
        root:           Repository root (parent of ``.muse/``).
        base_commit:    Commit ID of the merge base (common ancestor).
        ours_commit:    Commit ID of the current branch (HEAD) at merge time.
        theirs_commit:  Commit ID of the branch being merged in.
        conflict_paths: Sorted list of workspace-relative POSIX paths with
                        unresolvable conflicts.
        other_branch:   Name of the branch being merged in; stored for
                        informational display but not required for resolution.
    """
    merge_state_path = root / MUSE_DIR / _MERGE_STATE_FILENAME

    # Preserve original_conflict_paths from the first write so that commit
    # can pass the full set to harmony even after checkout --ours/--theirs
    # has cleared individual paths from conflict_paths.
    existing = read_merge_state(root)
    if existing is not None and existing.original_conflict_paths:
        original = existing.original_conflict_paths
    else:
        original = sorted(conflict_paths)

    payload: MergeStatePayload = {
        "base_commit": base_commit,
        "ours_commit": ours_commit,
        "theirs_commit": theirs_commit,
        "conflict_paths": sorted(conflict_paths),
        "original_conflict_paths": original,
    }
    if other_branch is not None:
        payload["other_branch"] = other_branch
    write_text_atomic(merge_state_path, json.dumps(payload, indent=2))
    logger.info("✅ Wrote MERGE_STATE.json with %d conflict(s)", len(conflict_paths))

def clear_merge_state(root: pathlib.Path) -> None:
    """Remove ``.muse/MERGE_STATE.json`` after a successful merge or resolution."""
    merge_state_path = root / MUSE_DIR / _MERGE_STATE_FILENAME
    if merge_state_path.exists():
        merge_state_path.unlink()
        logger.debug("✅ Cleared MERGE_STATE.json")

def _write_conflict_paths(
    root: pathlib.Path,
    state: MergeState,
    new_paths: list[str],
    manually_resolved: list[str] | None = None,
) -> None:
    """Atomically persist *new_paths* as ``conflict_paths`` in MERGE_STATE.json.

    All other fields (``original_conflict_paths``, commit refs, branch name) are
    preserved verbatim.  ``original_conflict_paths`` is intentionally never
    mutated here — Harmony reads it at commit time.

    *manually_resolved* — if provided, replaces ``state.manually_resolved``
    (used by resolve_path / resolve_symbol to accumulate the set of explicitly
    confirmed resolutions).  When ``None`` the existing value is preserved.
    """
    merge_state_path = root / MUSE_DIR / _MERGE_STATE_FILENAME
    new_manually = manually_resolved if manually_resolved is not None else state.manually_resolved
    payload: MergeStatePayload = {
        "conflict_paths": sorted(new_paths),
        "original_conflict_paths": state.original_conflict_paths,
        "manually_resolved": sorted(new_manually),
    }
    if state.base_commit is not None:
        payload["base_commit"] = state.base_commit
    if state.ours_commit is not None:
        payload["ours_commit"] = state.ours_commit
    if state.theirs_commit is not None:
        payload["theirs_commit"] = state.theirs_commit
    if state.other_branch is not None:
        payload["other_branch"] = state.other_branch
    write_text_atomic(merge_state_path, json.dumps(payload, indent=2))


def resolve_path(root: pathlib.Path, path: str) -> list[str]:
    """Remove all conflict entries whose file portion matches *path*.

    The file portion of a conflict entry is everything before the first ``::``
    (or the whole string if no ``::`` is present).  For example, calling
    ``resolve_path(root, "hello.md")`` clears both ``"hello.md"`` and
    ``"hello.md::Hello World"`` in one call.

    ``original_conflict_paths`` is **never mutated** — Harmony reads it at
    commit time to know what was learned from this merge.

    Args:
        root: Repository root (parent of ``.muse/``).
        path: Workspace-relative POSIX path of the file to mark resolved.

    Returns:
        List of conflict entries that were removed (may be empty if none matched).

    Raises:
        ValueError: If no merge is in progress.
    """
    state = read_merge_state(root)
    if state is None:
        raise ValueError("No merge in progress — nothing to resolve.")
    cleared: list[str] = []
    remaining: list[str] = []
    for entry in state.conflict_paths:
        file_part = entry.split("::")[0] if "::" in entry else entry
        if file_part == path:
            cleared.append(entry)
        else:
            remaining.append(entry)
    if cleared:
        new_manually = sorted(set(state.manually_resolved) | set(cleared))
        _write_conflict_paths(root, state, remaining, manually_resolved=new_manually)
        logger.info("✅ resolve_path: cleared %d conflict(s) for %r", len(cleared), path)
    return cleared


def resolve_symbol(root: pathlib.Path, symbol_address: str) -> bool:
    """Remove exactly one entry matching *symbol_address* from ``conflict_paths``.

    Idempotent — if the address is not in ``conflict_paths`` the function
    returns ``False`` without raising.  ``original_conflict_paths`` is never
    mutated.

    Args:
        root:           Repository root (parent of ``.muse/``).
        symbol_address: Full conflict address, e.g. ``"hello.md"`` or
                        ``"hello.md::Hello World"``.

    Returns:
        ``True`` if the entry was found and removed, ``False`` if not present.

    Raises:
        ValueError: If no merge is in progress.
    """
    state = read_merge_state(root)
    if state is None:
        raise ValueError("No merge in progress — nothing to resolve.")
    if symbol_address not in state.conflict_paths:
        return False
    remaining = [e for e in state.conflict_paths if e != symbol_address]
    new_manually = sorted(set(state.manually_resolved) | {symbol_address})
    _write_conflict_paths(root, state, remaining, manually_resolved=new_manually)
    logger.info("✅ resolve_symbol: cleared %r", symbol_address)
    return True


def apply_resolution(
    root: pathlib.Path,
    rel_path: str,
    object_id: str,
) -> None:
    """Restore a specific object version to the working tree at ``<rel_path>``.

    Used by the ``muse merge --resolve`` workflow: after a user has chosen
    which version of a conflicting file to keep, this function writes that
    version into the working tree so ``muse commit`` can snapshot it.

    Args:
        root:      Repository root (parent of ``.muse/``).
        rel_path:  Workspace-relative POSIX path of the conflicting file.
        object_id: SHA-256 of the chosen resolution content in the object store.

    Raises:
        FileNotFoundError: When *object_id* is not present in the local store.
    """
    from muse.core.object_store import read_object

    validate_object_id(object_id)
    dest = contain_path(root, rel_path)

    content = read_object(root, object_id)
    if content is None:
        raise FileNotFoundError(
            f"Object {object_id} for '{rel_path}' not found in local store."
        )
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(content)
    logger.debug("✅ Restored '%s' from object %s", rel_path, short_id(object_id))

# ---------------------------------------------------------------------------
# Pure merge functions (no I/O)
# ---------------------------------------------------------------------------

def diff_snapshots(
    base_manifest: Manifest,
    other_manifest: Manifest,
) -> set[str]:
    """Return the set of paths that differ between *base_manifest* and *other_manifest*.

    A path is "different" if it was added (in *other* but not *base*), deleted
    (in *base* but not *other*), or modified (present in both with different
    content hashes).

    Args:
        base_manifest:  Path → content-hash map for the ancestor snapshot.
        other_manifest: Path → content-hash map for the other snapshot.

    Returns:
        Set of workspace-relative POSIX paths that differ.
    """
    base_paths = set(base_manifest.keys())
    other_paths = set(other_manifest.keys())
    added = other_paths - base_paths
    deleted = base_paths - other_paths
    common = base_paths & other_paths
    modified = {p for p in common if base_manifest[p] != other_manifest[p]}
    return added | deleted | modified

def detect_conflicts(
    ours_changed: set[str],
    theirs_changed: set[str],
    ours_manifest: Manifest,
    theirs_manifest: Manifest,
) -> set[str]:
    """Return paths where both branches made DIVERGENT changes since the merge base.

    Two branches conflict on a path only when they both changed it AND arrived at
    DIFFERENT results.  Convergent changes — both deleted the same file, or both
    added/modified it to the same content hash — are auto-resolved and are NOT
    returned as conflicts.

    Examples of convergent (non-conflict) changes:
    - Both branches deleted the same file  →  agreed on deletion, not a conflict.
    - Both branches independently added the same file with identical content  →
      agreed on the new content, not a conflict.

    Args:
        ours_changed:    Paths changed by our branch (from :func:`diff_snapshots`).
        theirs_changed:  Paths changed by their branch.
        ours_manifest:   Path → content-hash for our branch's snapshot.
        theirs_manifest: Path → content-hash for their branch's snapshot.

    Returns:
        Set of paths where both branches made changes that disagree on the result.
    """
    return {
        path
        for path in ours_changed & theirs_changed
        if ours_manifest.get(path) != theirs_manifest.get(path)
    }

def apply_merge(
    base_manifest: Manifest,
    ours_manifest: Manifest,
    theirs_manifest: Manifest,
    ours_changed: set[str],
    theirs_changed: set[str],
    conflict_paths: set[str],
) -> Manifest:
    """Build the merged snapshot manifest for a conflict-free 3-way merge.

    Starts from *base_manifest* and applies non-conflicting changes from both
    branches:

    - Ours-only changes (in *ours_changed* but not *conflict_paths*) are taken
      from *ours_manifest*.  Deletions are handled by the absence of the path
      in *ours_manifest*.
    - Theirs-only changes (in *theirs_changed* but not *conflict_paths*) are
      taken from *theirs_manifest* by the same logic.
    - Paths in *conflict_paths* are excluded — callers must resolve them
      separately before producing a final merged snapshot.

    Args:
        base_manifest:  Path → content-hash for the common ancestor.
        ours_manifest:  Path → content-hash for our branch.
        theirs_manifest: Path → content-hash for their branch.
        ours_changed:   Paths changed by our branch (from :func:`diff_snapshots`).
        theirs_changed: Paths changed by their branch.
        conflict_paths: Paths with concurrent changes — excluded from output.

    Returns:
        Merged path → content-hash mapping; conflict paths are absent.
    """
    merged: Manifest = dict(base_manifest)
    for path in ours_changed - conflict_paths:
        if path in ours_manifest:
            merged[path] = ours_manifest[path]
        else:
            merged.pop(path, None)
    for path in theirs_changed - conflict_paths:
        if path in theirs_manifest:
            merged[path] = theirs_manifest[path]
        else:
            merged.pop(path, None)
    return merged

# ---------------------------------------------------------------------------
# CRDT convergent join
# ---------------------------------------------------------------------------

def crdt_join_snapshots(
    plugin: MuseDomainPlugin,
    a_snapshot: Manifest,
    b_snapshot: Manifest,
    a_vclock: VectorClock,
    b_vclock: VectorClock,
    a_crdt_state: CRDTState,
    b_crdt_state: CRDTState,
    domain: str,
) -> MergeResult:
    """Convergent CRDT merge — always succeeds, no conflicts possible.

    Detects :class:`~muse.domain.CRDTPlugin` support via ``isinstance`` and
    delegates to ``plugin.join(a, b)``.  The returned :class:`~muse.domain.MergeResult`
    always has an empty ``conflicts`` list — the defining property of CRDT joins.

    This function is the CRDT entry point for the ``muse merge`` command.
    It is only called when ``DomainSchema.merge_mode == "crdt"`` AND the plugin
    passes the ``isinstance(plugin, CRDTPlugin)`` check.

    Args:
        plugin:       The loaded domain plugin instance.
        a_snapshot:   ``files`` mapping (path → content hash) for replica A.
        b_snapshot:   ``files`` mapping (path → content hash) for replica B.
        a_vclock:     Vector clock ``{agent_id: count}`` for replica A.
        b_vclock:     Vector clock ``{agent_id: count}`` for replica B.
        a_crdt_state: CRDT metadata hashes (path → blob hash) for replica A.
        b_crdt_state: CRDT metadata hashes (path → blob hash) for replica B.
        domain:       Domain name string (e.g. ``"midi"``).

    Returns:
        A :class:`~muse.domain.MergeResult` with the joined snapshot and an
        empty ``conflicts`` list.

    Raises:
        TypeError: When *plugin* does not implement the
                   :class:`~muse.domain.CRDTPlugin` protocol.
    """
    from muse.domain import CRDTPlugin, CRDTSnapshotManifest, MergeResult, StateSnapshot

    if not isinstance(plugin, CRDTPlugin):
        raise TypeError(
            f"crdt_join_snapshots: plugin {type(plugin).__name__!r} does not "
            "implement CRDTPlugin — cannot use CRDT join path."
        )

    a_crdt: CRDTSnapshotManifest = {
        "files": a_snapshot,
        "domain": domain,
        "vclock": a_vclock,
        "crdt_state": a_crdt_state,
        "schema_version": __version__,
    }
    b_crdt: CRDTSnapshotManifest = {
        "files": b_snapshot,
        "domain": domain,
        "vclock": b_vclock,
        "crdt_state": b_crdt_state,
        "schema_version": __version__,
    }

    result_crdt = plugin.join(a_crdt, b_crdt)
    plain_snapshot: StateSnapshot = plugin.from_crdt_state(result_crdt)

    return MergeResult(
        merged=plain_snapshot,
        conflicts=[],
        applied_strategies={},
    )

# ---------------------------------------------------------------------------
# File-based merge base finder
# ---------------------------------------------------------------------------

def find_merge_base(
    repo_root: pathlib.Path,
    commit_id_a: str,
    commit_id_b: str,
) -> str | None:
    """Find the Lowest Common Ancestor (LCA) of two commits.

    Delegates to :func:`muse.core.graph.find_merge_base` with the
    repo-configured ancestor cap, converting the generic :class:`ValueError`
    into a user-facing :class:`~muse.core.errors.MuseCLIError`.
    """
    from muse.cli.config import get_limit
    from muse.core.errors import MuseCLIError
    from muse.core.graph import find_merge_base as _graph_find_merge_base

    max_ancestors = get_limit("max_ancestors", repo_root)
    try:
        return _graph_find_merge_base(repo_root, commit_id_a, commit_id_b, max_ancestors=max_ancestors)
    except ValueError:
        raise MuseCLIError(
            f"Ancestor graph exceeds {max_ancestors:,} commits during "
            "merge-base search — the repository history is too deep or "
            "the DAG may be malformed. "
            f"Raise [limits] max_ancestors in .muse/config.toml "
            f"(current cap: {max_ancestors:,})."
        )

# ---------------------------------------------------------------------------
# MergeEngine — strategy vocabulary
# ---------------------------------------------------------------------------

_VALID_DIFF_UNITS = frozenset({"three_way", "snapshot", "replay_ours", "replay_theirs"})
_VALID_RESOLUTIONS = frozenset({"escalate", "prefer_ours", "prefer_theirs"})


@dataclass(frozen=True)
class MergeEngine:
    """Canonical description of a merge strategy as two orthogonal axes.

    ``diff_unit`` — how the two sides are compared:
      - ``three_way``:    combine(delta(base→ours), delta(base→theirs))
      - ``snapshot``:     compare(ours_state, theirs_state) — no base
      - ``replay_ours``:  apply delta(base→ours) onto theirs_state
      - ``replay_theirs``: apply delta(base→theirs) onto ours_state

    ``resolution`` — what to do when a unit conflicts:
      - ``escalate``:      surface it for human / Harmony resolution
      - ``prefer_ours``:   auto-resolve keeping ours
      - ``prefer_theirs``: auto-resolve keeping theirs
    """

    diff_unit: str
    resolution: str

    def __post_init__(self) -> None:
        if self.diff_unit not in _VALID_DIFF_UNITS:
            raise ValueError(
                f"Invalid diff_unit {self.diff_unit!r}. "
                f"Valid values: {sorted(_VALID_DIFF_UNITS)}"
            )
        if self.resolution not in _VALID_RESOLUTIONS:
            raise ValueError(
                f"Invalid resolution {self.resolution!r}. "
                f"Valid values: {sorted(_VALID_RESOLUTIONS)}"
            )


STRATEGY_MAP: dict[str, MergeEngine] = {
    "recursive": MergeEngine(diff_unit="three_way",    resolution="escalate"),
    "overlay":   MergeEngine(diff_unit="snapshot",     resolution="prefer_theirs"),
    "snapshot":  MergeEngine(diff_unit="snapshot",     resolution="escalate"),
    "replay":    MergeEngine(diff_unit="replay_ours",  resolution="escalate"),
    "ours":      MergeEngine(diff_unit="three_way",    resolution="prefer_ours"),
    "theirs":    MergeEngine(diff_unit="three_way",    resolution="prefer_theirs"),
}


def run_merge(
    base_manifest: Manifest,
    ours_manifest: Manifest,
    theirs_manifest: Manifest,
    engine: MergeEngine,
    *,
    plugin: MuseDomainPlugin | None = None,
    repo_root: pathlib.Path | None = None,
    domain: str = "",
) -> MergeResult:
    """Execute a merge using the given engine configuration.

    This is the single shared implementation used by both :command:`muse merge`
    (local CLI) and :command:`muse hub proposal merge` (server).  Callers are
    responsible for all I/O: loading snapshots before calling, writing commits
    and MERGE_STATE after.

    Execution paths by ``diff_unit``:

    - ``three_way``:    standard three-way diff relative to the common ancestor.
      When *plugin* is supplied the merge is symbol-level (via
      ``plugin.merge_ops`` or ``plugin.merge``).  Without a plugin the merge
      falls back to manifest-level using :func:`detect_conflicts` +
      :func:`apply_merge`.
    - ``snapshot``:     compare *ours* and *theirs* directly — no ancestor.
      Implemented as ``three_way`` with ``base_manifest = {}``.
    - ``replay_ours``:  apply ``base→ours`` delta onto ``theirs`` state.
    - ``replay_theirs``: apply ``base→theirs`` delta onto ``ours`` state.

    When ``engine.resolution`` is ``prefer_ours`` or ``prefer_theirs``, all
    conflicts are auto-resolved to the nominated side and the returned
    ``conflicts`` list is empty.

    Args:
        base_manifest:   Path → content-hash for the common ancestor.
                         Pass ``{}`` when no ancestor is available (e.g. fresh
                         repos) — this is equivalent to ``snapshot`` diff.
        ours_manifest:   Path → content-hash for the current branch (HEAD).
        theirs_manifest: Path → content-hash for the incoming branch.
        engine:          Strategy configuration from :data:`STRATEGY_MAP`.
        plugin:          Optional domain plugin for symbol-level merge.
                         When ``None`` the merge is manifest-level only.
        repo_root:       Repository root passed to the plugin.  May be ``None``
                         on the server (the plugin degrades gracefully).
        domain:          Domain name placed in the returned snapshot manifest.

    Returns:
        :class:`~muse.domain.MergeResult` with the reconciled snapshot and any
        remaining conflict paths.  ``conflicts`` is empty when the merge is
        clean or when the resolution policy auto-resolved everything.
    """
    from muse.domain import AddressedMergePlugin, MergeResult, SnapshotManifest
    from muse.core.snapshot import directories_from_manifest

    def _snap(manifest: Manifest) -> SnapshotManifest:
        return SnapshotManifest(
            files=manifest,
            domain=domain,
            directories=directories_from_manifest(manifest),
        )

    def _make_result(merged_files: Manifest, conflicts: list[str]) -> MergeResult:
        return MergeResult(
            merged=_snap(merged_files),
            conflicts=conflicts,
        )

    # ── snapshot diff_unit: treat as three_way with empty base ──────────────
    effective_base = {} if engine.diff_unit == "snapshot" else base_manifest

    # ── replay paths: apply one side's delta onto the other's state ─────────
    if engine.diff_unit in ("replay_ours", "replay_theirs"):
        ours_changed  = diff_snapshots(base_manifest, ours_manifest)
        theirs_changed = diff_snapshots(base_manifest, theirs_manifest)
        conflict_paths = detect_conflicts(
            ours_changed, theirs_changed, ours_manifest, theirs_manifest
        )
        if engine.diff_unit == "replay_ours":
            # Apply ours' delta (base→ours) onto theirs' state.
            merged: Manifest = dict(theirs_manifest)
            for path in ours_changed:
                if path in ours_manifest:
                    merged[path] = ours_manifest[path]
                else:
                    merged.pop(path, None)
        else:
            # Apply theirs' delta (base→theirs) onto ours' state.
            merged = dict(ours_manifest)
            for path in theirs_changed:
                if path in theirs_manifest:
                    merged[path] = theirs_manifest[path]
                else:
                    merged.pop(path, None)
        if engine.resolution == "prefer_ours":
            for path in conflict_paths:
                if path in ours_manifest:
                    merged[path] = ours_manifest[path]
                else:
                    merged.pop(path, None)
            return _make_result(merged, [])
        elif engine.resolution == "prefer_theirs":
            for path in conflict_paths:
                if path in theirs_manifest:
                    merged[path] = theirs_manifest[path]
                else:
                    merged.pop(path, None)
            return _make_result(merged, [])
        return _make_result(merged, sorted(conflict_paths))

    # ── three_way (or snapshot as three_way with empty base) ────────────────
    if plugin is not None:
        # Symbol-level merge via domain plugin.  The plugin always receives the
        # real base — the snapshot empty-base concept applies only to
        # manifest-level comparisons; plugins do their own internal diffing.
        base_snap   = _snap(base_manifest)
        ours_snap   = _snap(ours_manifest)
        theirs_snap = _snap(theirs_manifest)

        if isinstance(plugin, AddressedMergePlugin):
            ours_delta   = plugin.diff(base_snap, ours_snap,   repo_root=repo_root)
            theirs_delta = plugin.diff(base_snap, theirs_snap, repo_root=repo_root)
            result = plugin.merge_ops(
                base_snap, ours_snap, theirs_snap,
                ours_delta["ops"], theirs_delta["ops"],
                repo_root=repo_root,
            )
        else:
            result = plugin.merge(base_snap, ours_snap, theirs_snap, repo_root=repo_root)

        if not result.conflicts or engine.resolution == "escalate":
            return result

        # Auto-resolve plugin conflicts via the nominated side.
        side = ours_manifest if engine.resolution == "prefer_ours" else theirs_manifest
        merged_files = dict(result.merged["files"])
        for addr in result.conflicts:
            file_path = addr.split("::")[0] if "::" in addr else addr
            if file_path in side:
                merged_files[file_path] = side[file_path]
            else:
                merged_files.pop(file_path, None)
        return _make_result(merged_files, [])

    # ── manifest-level three_way (no plugin) ────────────────────────────────
    ours_changed   = diff_snapshots(effective_base, ours_manifest)
    theirs_changed = diff_snapshots(effective_base, theirs_manifest)
    conflict_paths = detect_conflicts(
        ours_changed, theirs_changed, ours_manifest, theirs_manifest
    )
    merged_m = apply_merge(
        effective_base, ours_manifest, theirs_manifest,
        ours_changed, theirs_changed, conflict_paths,
    )
    if engine.resolution == "prefer_ours":
        for path in conflict_paths:
            if path in ours_manifest:
                merged_m[path] = ours_manifest[path]
            else:
                merged_m.pop(path, None)
        return _make_result(merged_m, [])
    elif engine.resolution == "prefer_theirs":
        for path in conflict_paths:
            if path in theirs_manifest:
                merged_m[path] = theirs_manifest[path]
            else:
                merged_m.pop(path, None)
        return _make_result(merged_m, [])
    # escalate: put ours placeholder for conflict paths so manifest is complete
    for path in conflict_paths:
        if path in ours_manifest:
            merged_m[path] = ours_manifest[path]
    return _make_result(merged_m, sorted(conflict_paths))
