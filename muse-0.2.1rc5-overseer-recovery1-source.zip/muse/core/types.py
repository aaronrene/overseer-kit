"""Primitive type aliases shared across muse.core.

This module has **no imports from the muse package** so that it can be
safely imported by any module without risk of circular imports.
"""

import base64
import hashlib
import json
import pathlib
import datetime

from typing import Literal

# ---------------------------------------------------------------------------
# Semver
# ---------------------------------------------------------------------------

SemVerBump = Literal["major", "minor", "patch", "none"]
"""Semver bump level.  Defined here (not in ``muse.domain``) so that core
modules (semver, store, transport) can import it without pulling in the full
domain graph."""

# ---------------------------------------------------------------------------
# Msgpack / JSON value types
# ---------------------------------------------------------------------------

type MsgpackValue = (
    str | int | float | bool | bytes | None
    | list["MsgpackValue"]
    | dict[str, "MsgpackValue"]
)

type JsonValue = (
    str | int | float | bool | None
    | list["JsonValue"]
    | dict[str, "JsonValue"]
)

# A JSON object — string keys, JSON values. The audit-clean named form for any
# dict[str, JsonValue] at a boundary (param, return, or mutable local): a named
# alias never matches the literal `dict[str,` the typing audit forbids.
type JsonObject = dict[str, JsonValue]

type MsgpackDict = dict[str, MsgpackValue]

# ---------------------------------------------------------------------------
# Repository manifest / metadata aliases
# ---------------------------------------------------------------------------

type Manifest = dict[str, str]      # filename → sha256 hex
type Metadata = dict[str, str]      # arbitrary string key→value labels
type BranchHeads = dict[str, str]   # branch name → commit_id

# ---------------------------------------------------------------------------
# Object store layout constants
#
# Defined early so that DEFAULT_HASH_ALGO can be used as a default argument value
# in the ID and hashing functions below.  object_store.py imports these from
# here — never the other way around.
# ---------------------------------------------------------------------------

MUSE_DIR: str = ".muse"
OBJECTS_DIR: str = "objects"
DEFAULT_HASH_ALGO: str = "sha256"
DEFAULT_SIGN_ALGO: str = "ed25519"
# Null/sentinel commit ID — 64 zero hex digits, used to represent "no prior commit"
# (initial commit, empty reflog entry, etc.). NULL_LONG_ID is the prefixed form.
NULL_COMMIT_ID: str = "0" * 64
NULL_LONG_ID: str = f"{DEFAULT_HASH_ALGO}:{NULL_COMMIT_ID}"

# ---------------------------------------------------------------------------
# ID display
# ---------------------------------------------------------------------------

def short_id(full_id: str, algo: str = DEFAULT_HASH_ALGO, *, strip: bool = False) -> str:
    """Canonical short-form of an algorithm-prefixed object ID.

    By default returns ``<algo>:<first-12-hex-chars>`` — the prefix is kept
    because the algorithm is part of the identity.  Pass ``strip=True`` to
    get the bare 12-character hex without the prefix (e.g. for embedding in
    a format string that already carries context).

    Args:
        full_id: The full ``<algo>:<hex>`` object ID (or a bare hex string).
        algo:    Hash algorithm name (default :data:`DEFAULT_HASH_ALGO`).
        strip:   If ``True``, return bare hex without the ``<algo>:`` prefix.

    Examples::

        short_id("sha256:abcdef1234567890...")           →  "sha256:abcdef123456"
        short_id("sha256:abcdef1234567890...", strip=True)  →  "abcdef123456"
        short_id("blake3:abcdef...", "blake3")           →  "blake3:abcdef123456"

    Falls back to the first 12 characters of the raw string for IDs that
    predate the prefix convention.
    """
    prefix = f"{algo}:"
    if full_id.startswith(prefix):
        hex_part = full_id[len(prefix):len(prefix) + 12]
        return hex_part if strip else f"{prefix}{hex_part}"
    return full_id[:12]

def long_id(hex_digest: str, algo: str = DEFAULT_HASH_ALGO, *, strip: bool = False) -> str:
    """Canonical long-form of an algorithm-prefixed object ID.

    By default returns ``<algo>:<full-hex>`` — the prefix is part of the
    identity and must never be omitted in display, JSON, or log output.
    Pass ``strip=True`` to remove the prefix (e.g. at the storage boundary
    where the raw digest is written to disk without the prefix).

    Args:
        hex_digest: A bare hex digest, or an already-prefixed ``<algo>:<hex>`` ID.
        algo:       Hash algorithm name (default :data:`DEFAULT_HASH_ALGO`).
        strip:      If ``True``, return bare hex without the ``<algo>:`` prefix.

    Examples::

        long_id("abcdef..." * 4)                   →  "sha256:abcdef..."
        long_id("sha256:abcdef...", strip=True)     →  "abcdef..."
        long_id("abcdef...", "blake3")              →  "blake3:abcdef..."

    Idempotent when adding — already-prefixed IDs are returned unchanged.
    """
    prefix = f"{algo}:"
    if hex_digest.startswith(prefix):
        return hex_digest[len(prefix):] if strip else hex_digest
    return hex_digest if strip else f"{prefix}{hex_digest}"

def blob_id(data: bytes, hash_algo: str = DEFAULT_HASH_ALGO) -> str:
    """Return the canonical content-addressed ID for raw bytes.

    Thin wrapper over :func:`muse.core.ids.hash_blob` — the Git-idiomatic
    formula: ``sha256("blob <size>\\0" + data)``.

    Args:
        data:      Raw bytes to hash.
        hash_algo: Hash algorithm name (default :data:`DEFAULT_HASH_ALGO`).

    Returns:
        A ``<hash_algo>:<hex>`` content-addressed ID string.
    """
    from muse.core.ids import hash_blob
    return hash_blob(data, hash_algo)

def content_hash(obj: "JsonValue", hash_algo: str = DEFAULT_HASH_ALGO) -> str:
    """Return the canonical content-addressed ID for a JSON object.

    This is the single canonical content-addressing primitive for all stored
    entities in Muse.  Every ``compute_*_id`` function delegates here.

    Canonical form
    --------------
    - ``json.dumps`` with ``sort_keys=True`` for key-order independence
    - Compact separators ``(",", ":")`` — no whitespace
    - ``ensure_ascii=True`` — consistent byte output regardless of locale
    - UTF-8 encoded before hashing

    Args:
        obj:       Any JSON-serialisable value (dict, list, str, int, float, bool, None).
        hash_algo: Hash algorithm name (default :data:`DEFAULT_HASH_ALGO`).

    Returns:
        A ``<hash_algo>:<hex>`` content-addressed ID string.

    Examples::

        content_hash({"actor": "gabriel", "ts": 42})   →  "sha256:..."
        content_hash({"ts": 42, "actor": "gabriel"})   →  same ID (key-order invariant)
    """
    canonical = json.dumps(
        obj,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode()
    return blob_id(canonical, hash_algo)

def public_key_fingerprint(raw: bytes, hash_algo: str = DEFAULT_HASH_ALGO) -> str:
    """Return the canonical ``<hash_algo>:<hex>`` fingerprint of raw public key bytes.

    Deliberately NOT routed through :func:`blob_id`. Key fingerprints are
    authentication identifiers — plain ``sha256(raw_bytes)`` — not content-
    addressed storage objects. The blob prefix (``"blob <size>\\0"``) belongs
    in the object store; mixing it into auth fingerprints would be a category
    error and would break compatibility with registered keys.

    All auth fingerprint code routes through here; never hash inline.

    Args:
        raw:       Raw public key bytes.
        hash_algo: Hash algorithm name (default :data:`DEFAULT_HASH_ALGO`).
    """
    import hashlib as _hashlib
    digest = _hashlib.new(hash_algo, raw).hexdigest()
    return f"{hash_algo}:{digest}"

def hash_file(path: pathlib.Path, hash_algo: str = DEFAULT_HASH_ALGO, *, chunk_size: int = 65536) -> str:
    """Return the canonical content-addressed ID for a file.

    Produces the same ID as ``blob_id(path.read_bytes())`` — the muse blob
    object format ``sha256("blob <size>\\0<content>")`` — but streams content
    in chunks so memory stays bounded for large files.

    The file size is read via ``stat()`` first (one extra syscall) to build
    the ``"blob <size>\\0"`` header without buffering the full content.

    Args:
        path:       Path to the file to hash.
        hash_algo:  Hash algorithm name (default :data:`DEFAULT_HASH_ALGO`).
        chunk_size: Read chunk size in bytes (default 65 536 = 64 KiB).

    Returns:
        A ``<hash_algo>:<hex>`` content-addressed ID string.

    Examples::

        hash_file(pathlib.Path("song.mid"))               →  "sha256:..."
        hash_file(pathlib.Path("song.mid"), "blake3")     →  "blake3:..."
        hash_file(src)  ==  blob_id(src.read_bytes())     # always true for same algo
    """
    size = path.stat().st_size
    header = f"blob {size}\0".encode()
    h = hashlib.new(hash_algo, header)
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(chunk_size), b""):
            h.update(chunk)
    return long_id(h.hexdigest(), hash_algo)

def split_id(object_id: str) -> tuple[str, str]:
    """Parse an algorithm-prefixed object ID into ``(algo, hex)``.

    This is the single canonical entry point for decomposing any content-
    addressed ID at the storage boundary.  Every path-construction helper
    (``commit_path``, ``snapshot_path``, ``tag_path``, ``release_path``,
    ``pattern_dir``, ``resolution_path``) delegates here so the algorithm is
    always derived from the ID itself — never assumed.

    Accepted forms
    --------------
    - ``"sha256:<64-hex>"``  →  ``("sha256", "<64-hex>")``
    - ``"blake3:<64-hex>"``  →  ``("blake3", "<64-hex>")``
    - ``"<64-hex>"``         →  ``("sha256", "<64-hex>")``  (legacy bare-hex)

    The bare-hex fallback exists only for IDs that predate the prefix
    convention.  All new IDs must carry the algorithm prefix.

    Args:
        object_id: A ``<algo>:<hex>`` string, or bare 64-char hex.

    Returns:
        A ``(algo, hex_id)`` tuple where *algo* is the algorithm name and
        *hex_id* is the 64-character lowercase hex digest.

    Raises:
        ValueError: If the hex portion is not exactly 64 lowercase hex chars,
                    or if the string is empty or contains path-unsafe chars.

    Examples::

        split_id("sha256:abcd..." * 16)    →  ("sha256", "abcd..." * 16)
        split_id("blake3:ef01..." * 16)    →  ("blake3", "ef01..." * 16)
        split_id("abcd..." * 16)           →  ("sha256", "abcd..." * 16)
    """
    if not object_id:
        raise ValueError("object_id must not be empty.")
    if "/" in object_id or "\\" in object_id or ".." in object_id:
        raise ValueError(
            f"object_id {object_id!r} contains path-unsafe characters."
        )
    if ":" in object_id:
        algo, _, hex_id = object_id.partition(":")
        if not algo:
            raise ValueError(
                f"object_id {object_id!r} has an empty algorithm prefix."
            )
    else:
        algo = DEFAULT_HASH_ALGO
        hex_id = object_id
    if len(hex_id) != 64 or not all(c in "0123456789abcdef" for c in hex_id):
        raise ValueError(
            f"object_id {object_id!r} hex portion must be exactly 64 lowercase "
            f"hex characters; got {len(hex_id)} chars."
        )
    return algo, hex_id

def fake_id(seed: str) -> str:
    """Return a deterministic ``sha256:`` ID from an arbitrary string seed.

    Intended **only for tests** that need a well-formed content-addressed ID
    without storing actual content.  Using a named function here ensures every
    test file imports the same canonical helper instead of rolling its own bare
    ``hashlib.sha256(seed.encode()).hexdigest()`` — which produces a legacy
    bare-hex string that violates the ``sha256:`` prefix invariant.

    Args:
        seed: Any string — used as-is to derive a deterministic hash.

    Returns:
        A ``sha256:<64-hex>`` ID (length 71).

    Examples::

        fake_id("pattern-1")   →  "sha256:..."
        fake_id("resolution")  →  "sha256:..."  (different from above)
    """
    return blob_id(seed.encode())

def now_utc_iso() -> str:
    """Return the current UTC time as an ISO 8601 string.

    Uses :func:`datetime.datetime.now` with ``datetime.timezone.utc`` to
    produce a timezone-aware timestamp.

    Returns:
        ISO 8601 string with UTC timezone offset, e.g.
        ``"2026-04-17T15:30:00.123456+00:00"``.
    """
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def load_json_file(path: pathlib.Path) -> JsonValue | None:
    """Read and parse a JSON file, returning ``None`` on any error.

    Canonical replacement for the repeated pattern::

        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, ValueError):
            ...

    Args:
        path: Path to the JSON file to read.

    Returns:
        The parsed JSON value, or ``None`` when the file cannot be read or
        its contents are not valid JSON.
    """
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, ValueError):
        return None

# ---------------------------------------------------------------------------
# Cryptographic signature / public-key codec
#
# Mirrors the sha256:-prefixed object ID convention: every stored cryptographic
# value embeds its algorithm in the value itself, making it self-describing for
# humans, agents, and future verifiers that may support multiple algorithms.
#
# Wire format: "<algorithm>:<base64url-no-padding>"
#   ed25519:AAAA…   — Ed25519 signature (64 bytes → 86 base64url chars)
#   ed25519:BBBB…   — Ed25519 public key (32 bytes → 43 base64url chars)
#   mldsa65:CCCC…   — future post-quantum signature (hypothetical)
#
# encode_sig / encode_pubkey are intentionally separate functions despite
# identical implementation — a signature and a public key are semantically
# distinct and callers should not accidentally pass one where the other is
# expected.
# ---------------------------------------------------------------------------

def encode_sig(algorithm: str, raw: bytes) -> str:
    """Encode raw signature bytes with an algorithm prefix.

    Args:
        algorithm: Algorithm name, e.g. ``"ed25519"`` or ``"mldsa65"``.
        raw:       Raw signature bytes.

    Returns:
        ``"<algorithm>:<base64url>"`` with no padding characters.

    Examples::

        encode_sig("ed25519", sig_bytes)   →  "ed25519:AAAA…"
    """
    b64 = base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")
    return f"{algorithm}:{b64}"

def encode_pubkey(algorithm: str, raw: bytes) -> str:
    """Encode raw public key bytes with an algorithm prefix.

    Identical wire format to :func:`encode_sig` — kept separate so that
    callers cannot accidentally pass a signature where a public key is expected.

    Args:
        algorithm: Algorithm name, e.g. ``"ed25519"``.
        raw:       Raw public key bytes.

    Returns:
        ``"<algorithm>:<base64url>"`` with no padding characters.

    Examples::

        encode_pubkey("ed25519", pub_bytes)   →  "ed25519:BBBB…"
    """
    b64 = base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")
    return f"{algorithm}:{b64}"

def decode_sig(value: str) -> tuple[str, bytes]:
    """Decode a prefixed signature string into ``(algorithm, raw_bytes)``.

    Args:
        value: ``"<algorithm>:<base64url>"`` string from :func:`encode_sig`.

    Returns:
        ``(algorithm, raw_bytes)`` tuple.

    Raises:
        ValueError: If *value* is missing an algorithm prefix or the base64
            portion is malformed.

    Examples::

        algo, raw = decode_sig("ed25519:AAAA…")
        # algo == "ed25519", raw == b"\\x00…"
    """
    if ":" not in value:
        raise ValueError(
            f"signature value missing algorithm prefix — expected 'algo:<base64url>', got {value!r}"
        )
    algo, _, b64 = value.partition(":")
    padded = f"{b64}{'=' * (-len(b64) % 4)}"
    try:
        raw = base64.urlsafe_b64decode(padded)
    except Exception as exc:
        raise ValueError(f"malformed base64 in signature value {value!r}: {exc}") from exc
    return algo, raw

def decode_pubkey(value: str) -> tuple[str, bytes]:
    """Decode a prefixed public key string into ``(algorithm, raw_bytes)``.

    Identical logic to :func:`decode_sig` — kept separate so that callers
    cannot accidentally pass a signature where a public key is expected.

    Args:
        value: ``"<algorithm>:<base64url>"`` string from :func:`encode_pubkey`.

    Returns:
        ``(algorithm, raw_bytes)`` tuple.

    Raises:
        ValueError: If *value* is missing an algorithm prefix or the base64
            portion is malformed.
    """
    if ":" not in value:
        raise ValueError(
            f"public key value missing algorithm prefix — expected 'algo:<base64url>', got {value!r}"
        )
    algo, _, b64 = value.partition(":")
    padded = f"{b64}{'=' * (-len(b64) % 4)}"
    try:
        raw = base64.urlsafe_b64decode(padded)
    except Exception as exc:
        raise ValueError(f"malformed base64 in public key value {value!r}: {exc}") from exc
    return algo, raw

def sig_algo(value: str) -> str:
    """Return the algorithm prefix of a cryptographic value, or ``""`` if absent.

    Does not decode the base64 portion — use this for dispatch checks before
    calling :func:`decode_sig` or :func:`decode_pubkey`.

    Args:
        value: Potentially prefixed string, e.g. ``"ed25519:AAAA…"`` or ``""``.

    Returns:
        The algorithm name (``"ed25519"``, ``"mldsa65"``, …) or ``""`` when
        the value has no prefix.

    Examples::

        sig_algo("ed25519:AAAA…")   →  "ed25519"
        sig_algo("barevalue")       →  ""
        sig_algo("")                →  ""
    """
    if ":" not in value:
        return ""
    return value.partition(":")[0]

def split_sig(value: str) -> tuple[str, str]:
    """Parse a prefixed signature string into ``(algo, b64_string)``.

    The string analog of :func:`split_id` for cryptographic signatures.
    Returns the base64url portion as a string without decoding to bytes —
    use :func:`decode_sig` when you need the raw bytes.

    Args:
        value: ``"<algorithm>:<base64url>"`` string from :func:`encode_sig`.

    Returns:
        ``(algorithm, b64_string)`` tuple, e.g. ``("ed25519", "AAAA…")``.

    Raises:
        ValueError: If *value* has no algorithm prefix.

    Examples::

        split_sig("ed25519:AAAA…")   →  ("ed25519", "AAAA…")
        split_sig("mldsa65:CCCC…")   →  ("mldsa65", "CCCC…")
    """
    if ":" not in value:
        raise ValueError(
            f"signature value missing algorithm prefix — expected 'algo:<base64url>', got {value!r}"
        )
    algo, _, b64 = value.partition(":")
    return algo, b64

def split_pubkey(value: str) -> tuple[str, str]:
    """Parse a prefixed public key string into ``(algo, b64_string)``.

    The string analog of :func:`split_id` for public keys.
    Returns the base64url portion as a string without decoding to bytes —
    use :func:`decode_pubkey` when you need the raw bytes.

    Args:
        value: ``"<algorithm>:<base64url>"`` string from :func:`encode_pubkey`.

    Returns:
        ``(algorithm, b64_string)`` tuple, e.g. ``("ed25519", "BBBB…")``.

    Raises:
        ValueError: If *value* has no algorithm prefix.

    Examples::

        split_pubkey("ed25519:BBBB…")   →  ("ed25519", "BBBB…")
    """
    if ":" not in value:
        raise ValueError(
            f"public key value missing algorithm prefix — expected 'algo:<base64url>', got {value!r}"
        )
    algo, _, b64 = value.partition(":")
    return algo, b64

# ---------------------------------------------------------------------------
# Base64url utilities
# ---------------------------------------------------------------------------

import base64 as _base64

def b64url_encode(b: bytes) -> str:
    """Encode bytes as URL-safe base64 without padding."""
    return _base64.urlsafe_b64encode(b).rstrip(b"=").decode()

def b64url_decode(s: str) -> bytes:
    """Decode a bare base64url string to raw bytes.

    For values that are explicitly bare by protocol design — specifically the
    ``sig=`` field in the MSign Authorization header, where the algorithm is
    already carried by the adjacent ``alg=`` field.

    For canonical prefixed values (public keys, stored signatures) use
    ``decode_pubkey`` or ``decode_sig`` instead.
    """
    pad = 4 - len(s) % 4
    if pad != 4:
        s += "=" * pad
    return _base64.urlsafe_b64decode(s)
