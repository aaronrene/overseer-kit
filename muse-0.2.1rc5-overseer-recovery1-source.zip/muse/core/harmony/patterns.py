"""Harmony pattern persistence — record, load, list, forget, clear.

Single responsibility: CRUD for ConflictPattern objects in the harmony store,
plus the shared _write_atomic helper used by all harmony persistence modules.
"""

from __future__ import annotations

import json
import logging
import os
import pathlib
import tempfile
from collections.abc import Mapping

from muse.core.types import JsonValue, load_json_file, long_id, short_id

from .fingerprint import _parse_dt
from .paths import (
    _BARE_HEX64_RE,
    _PATTERN_FILE,
    _RESOLUTIONS,
    _pattern_entry_dir,
    _resolutions_dir,
    patterns_dir,
    _validate_id,
)
from .types import ConflictPattern, ConflictType, _PatternDict

logger = logging.getLogger(__name__)

#: Maximum bytes read from ``pattern.json``.
_MAX_PATTERN_BYTES: int = 32_768  # 32 KiB

#: Maximum patterns scanned by :func:`list_patterns` to protect degenerate repos.
_MAX_SCAN: int = 100_000

# ---------------------------------------------------------------------------
# Shared atomic write helper
# ---------------------------------------------------------------------------

def _write_atomic(dest: pathlib.Path, content: str) -> None:
    """Write *content* to *dest* atomically via a temp file and ``os.replace``.

    Creates parent directories as needed.  On failure the temp file is removed
    and the exception re-raised, leaving *dest* unchanged.

    Args:
        dest:    Target path for the final file.
        content: UTF-8 string content to write.
    """
    dest.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_str = tempfile.mkstemp(dir=dest.parent, prefix=".harmony-tmp-")
    tmp = pathlib.Path(tmp_str)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(content)
        os.replace(tmp, dest)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise

# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------

def _pattern_to_dict(pattern: ConflictPattern) -> _PatternDict:
    return _PatternDict(
        pattern_id=pattern.pattern_id,
        path=pattern.path,
        domain=pattern.domain,
        conflict_type=pattern.conflict_type,
        blob_fingerprint=pattern.blob_fingerprint,
        semantic_fingerprint=pattern.semantic_fingerprint,
        ours_id=pattern.ours_id,
        theirs_id=pattern.theirs_id,
        description=pattern.description,
        recorded_at=pattern.recorded_at.isoformat(),
        recorded_by=pattern.recorded_by,
    )

def _dict_to_pattern(data: Mapping[str, JsonValue]) -> ConflictPattern | None:
    """Deserialise a JSON dict to :class:`ConflictPattern`, returning ``None`` on error."""
    try:
        return ConflictPattern(
            pattern_id=str(data["pattern_id"]),
            path=str(data.get("path", "")),
            domain=str(data.get("domain", "")),
            conflict_type=str(data.get("conflict_type", ConflictType.UNKNOWN)),
            blob_fingerprint=str(data.get("blob_fingerprint", "")),
            semantic_fingerprint=str(data.get("semantic_fingerprint", "")),
            ours_id=str(data.get("ours_id", "")),
            theirs_id=str(data.get("theirs_id", "")),
            description=data.get("description") or {},
            recorded_at=_parse_dt(data.get("recorded_at")),
            recorded_by=str(data.get("recorded_by", "unknown")),
        )
    except (KeyError, TypeError, ValueError) as exc:
        logger.warning("⚠️ harmony: failed to deserialise pattern: %s", exc)
        return None

# ---------------------------------------------------------------------------
# Pattern CRUD
# ---------------------------------------------------------------------------

def record_pattern(root: pathlib.Path, pattern: ConflictPattern) -> str:
    """Persist a :class:`ConflictPattern` to the harmony store.

    **Idempotent** — if *pattern.pattern_id* already exists in the store the
    existing ``pattern.json`` is left unchanged and the pattern_id is returned.

    Args:
        root:    Repository root.
        pattern: Pattern to record.

    Returns:
        The ``sha256:<hex>`` ``pattern_id`` identifying this conflict.

    Raises:
        ValueError: If ``pattern.pattern_id`` is not a valid content-addressed ID.
    """
    _validate_id(pattern.pattern_id, "pattern_id")
    meta_p = _pattern_entry_dir(root, pattern.pattern_id) / _PATTERN_FILE
    if meta_p.exists():
        logger.debug(
            "harmony: pattern %s already recorded for '%s'",
            short_id(pattern.pattern_id),
            pattern.path,
        )
        return pattern.pattern_id

    _write_atomic(meta_p, json.dumps(_pattern_to_dict(pattern), indent=2))
    logger.debug(
        "harmony: recorded pattern %s for '%s' (type=%s, domain=%s)",
        short_id(pattern.pattern_id),
        pattern.path,
        pattern.conflict_type,
        pattern.domain,
    )
    return pattern.pattern_id

def load_pattern(root: pathlib.Path, pattern_id: str) -> ConflictPattern | None:
    """Load a :class:`ConflictPattern` from the harmony store.

    Returns ``None`` when:

    - *pattern_id* is not a valid content-addressed ID.
    - No entry exists for *pattern_id*.
    - The ``pattern.json`` file exceeds :data:`_MAX_PATTERN_BYTES`.
    - The JSON cannot be parsed or is missing required fields.

    Args:
        root:       Repository root.
        pattern_id: ``sha256:<hex>`` pattern ID.
    """
    try:
        _validate_id(pattern_id, "pattern_id")
    except ValueError:
        return None

    meta_p = _pattern_entry_dir(root, pattern_id) / _PATTERN_FILE
    if not meta_p.exists():
        return None

    try:
        size = meta_p.stat().st_size
    except OSError as exc:
        logger.warning("⚠️ harmony: failed to read pattern %s: %s", pattern_id, exc)
        return None
    if size > _MAX_PATTERN_BYTES:
        logger.warning(
            "⚠️ harmony: pattern.json for %s is %d bytes — exceeds %d cap; skipping",
            pattern_id,
            size,
            _MAX_PATTERN_BYTES,
        )
        return None
    data = load_json_file(meta_p)
    if data is None:
        logger.warning(
            "⚠️ harmony: failed to read pattern %s: unreadable or invalid JSON", pattern_id
        )
        return None

    return _dict_to_pattern(data)

def list_patterns(root: pathlib.Path) -> list[ConflictPattern]:
    """Return all :class:`ConflictPattern` entries in the harmony store.

    Scans ``.muse/harmony/patterns/``.  Skips symlinks, directories whose
    names are not valid 64-char hex strings, and entries that fail to load.
    Capped at :data:`_MAX_SCAN` entries to protect degenerate repos.

    Returns patterns sorted by ``recorded_at`` descending (most recent first).

    Args:
        root: Repository root.
    """
    pdir = patterns_dir(root)
    if not pdir.exists():
        return []

    results: list[ConflictPattern] = []
    count = 0

    for algo_dir in pdir.iterdir():
        if algo_dir.is_symlink() or not algo_dir.is_dir():
            continue
        for entry in algo_dir.iterdir():
            if count >= _MAX_SCAN:
                logger.warning(
                    "⚠️ harmony: patterns dir has >%d entries — scan truncated",
                    _MAX_SCAN,
                )
                break
            count += 1

            if entry.is_symlink():
                logger.debug("harmony: skipping symlink %s in patterns dir", entry.name)
                continue
            if not entry.is_dir():
                continue
            if not _BARE_HEX64_RE.match(entry.name):
                continue

            p = load_pattern(root, long_id(entry.name, algo_dir.name))
            if p is not None:
                results.append(p)

    results.sort(key=lambda p: p.recorded_at, reverse=True)
    return results

def forget_pattern(root: pathlib.Path, pattern_id: str) -> bool:
    """Remove a conflict pattern and all its resolutions from the harmony store.

    Deletes ``pattern.json``, all resolution files under ``resolutions/``,
    and the entry directory itself.  Returns ``False`` if the pattern does not
    exist or *pattern_id* is not a valid content-addressed ID.

    Args:
        root:       Repository root.
        pattern_id: ``sha256:`` content-addressed pattern ID.
    """
    try:
        entry = _pattern_entry_dir(root, pattern_id)
    except ValueError:
        logger.warning(
            "⚠️ harmony: invalid pattern_id in forget_pattern: %r", pattern_id
        )
        return False

    if not entry.exists():
        return False

    res_dir = entry / _RESOLUTIONS
    if res_dir.exists() and not res_dir.is_symlink():
        for algo_dir in res_dir.iterdir():
            if algo_dir.is_symlink():
                continue
            if algo_dir.is_dir():
                for f in algo_dir.iterdir():
                    if not f.is_symlink():
                        f.unlink(missing_ok=True)
                try:
                    algo_dir.rmdir()
                except OSError:
                    pass
            else:
                algo_dir.unlink(missing_ok=True)
        try:
            res_dir.rmdir()
        except OSError:
            pass

    for child in entry.iterdir():
        if not child.is_symlink():
            child.unlink(missing_ok=True)
    try:
        entry.rmdir()
    except OSError:
        pass  # not empty — leave; caller may retry

    logger.debug("harmony: forgot pattern %s", short_id(pattern_id))
    return True

def clear_all(root: pathlib.Path) -> int:
    """Remove every conflict pattern and all its resolutions from the store.

    Symlinks in the patterns directory are skipped (only real subdirectories
    are cleared).

    Args:
        root: Repository root.

    Returns:
        Number of patterns removed.
    """
    pdir = patterns_dir(root)
    if not pdir.exists():
        return 0

    removed = 0
    for algo_dir in pdir.iterdir():
        if algo_dir.is_symlink() or not algo_dir.is_dir():
            continue
        for entry in algo_dir.iterdir():
            if entry.is_symlink() or not entry.is_dir():
                continue
            if forget_pattern(root, long_id(entry.name, algo_dir.name)):
                removed += 1

    logger.debug("harmony: clear_all removed %d patterns", removed)
    return removed
