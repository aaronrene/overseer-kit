"""Harmony audit log — append and list the tamper-evident action log.

Single responsibility: write and read the append-only audit log under
.muse/harmony/audit/.  Entries are never modified after writing.
"""

from __future__ import annotations

import json
import logging
import pathlib

from muse.core.types import content_hash, load_json_file

from .fingerprint import _now_utc
from .paths import audit_dir
from .patterns import _write_atomic
from .types import (
    AgentProvenance,
    AuditEvent,
    _AuditMetadata,
)

logger = logging.getLogger(__name__)

#: Maximum bytes read from a single audit log entry.
_MAX_AUDIT_BYTES: int = 4_096  # 4 KiB

#: Maximum audit entries returned by :func:`list_audit`.
_MAX_AUDIT_ENTRIES: int = 10_000

# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------

def append_audit(
    root: pathlib.Path,
    event_type: str,
    acted_by: AgentProvenance,
    *,
    pattern_id: str | None = None,
    resolution_id: str | None = None,
    policy_id: str | None = None,
    metadata: _AuditMetadata | None = None,
) -> None:
    """Append a single entry to the harmony audit log.

    Each entry is an independent JSON file named
    ``<YYYYMMDD>-<sha256-hex-slice>.json`` in ``.muse/harmony/audit/``.  The
    append-only design means audit entries are never modified after writing —
    they form a tamper-evident record of all harmony engine actions.

    Args:
        root:          Repository root.
        event_type:    :class:`AuditEventType` constant describing what happened.
        acted_by:      Attribution for the actor.
        pattern_id:    Involved pattern (if applicable).
        resolution_id: Involved resolution (if applicable).
        policy_id:     Involved policy (if applicable).
        metadata:      Additional event-specific fields (arbitrary JSON-safe dict).
    """
    now = _now_utc()
    payload: _AuditMetadata = {
        "event_type": event_type,
        "pattern_id": pattern_id,
        "resolution_id": resolution_id,
        "policy_id": policy_id,
        "acted_by": acted_by.to_dict(),
        "occurred_at": now.isoformat(),
        "metadata": metadata or {},
    }
    audit_id = content_hash(payload)
    filename = f"{now.strftime('%Y%m%d')}-{audit_id[7:19]}.json"

    entry: AuditEvent = {"audit_id": audit_id, **payload}  # type: ignore[misc]
    _write_atomic(audit_dir(root) / filename, json.dumps(entry, indent=2))

def list_audit(root: pathlib.Path, limit: int = 100) -> list[AuditEvent]:
    """Return up to *limit* recent audit log entries, newest first.

    Entries are sorted by filename (``<YYYYMMDD>-<sha256-hex-slice>``), which gives
    chronological order.  Skips entries exceeding :data:`_MAX_AUDIT_BYTES`
    or that fail JSON parsing.

    Args:
        root:  Repository root.
        limit: Maximum entries to return (default 100).
    """
    adir = audit_dir(root)
    if not adir.exists():
        return []

    entries: list[tuple[str, AuditEvent]] = []
    count = 0

    for f in adir.iterdir():
        if count >= _MAX_AUDIT_ENTRIES:
            break
        count += 1
        if f.is_symlink() or not f.is_file():
            continue
        if not f.name.endswith(".json"):
            continue
        try:
            size = f.stat().st_size
        except OSError:
            continue
        if size > _MAX_AUDIT_BYTES:
            logger.warning(
                "⚠️ harmony: audit entry %s is too large (%d bytes); skipping",
                f.name,
                size,
            )
            continue
        data: AuditEvent | None = load_json_file(f)
        if data is None:
            continue
        entries.append((f.name, data))

    entries.sort(key=lambda t: t[0], reverse=True)
    return [e for _, e in entries[:limit]]
