"""Harmony domain types — dataclasses, TypedDicts, and open constant namespaces.

Single responsibility: define every data shape used by the harmony subsystem.
No I/O, no filesystem access, no business logic.
"""

from __future__ import annotations

import datetime
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Literal, TypedDict

from muse.core.types import JsonValue

# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------

# Domain-specific conflict description metadata: arbitrary JSON-safe dict.
type _ConflictDescription = dict[str, JsonValue]

# Audit event metadata: event-specific extra fields.
type _AuditMetadata = dict[str, JsonValue]

# AgentProvenance.to_dict() output shape.
type _ProvenanceDict = dict[str, str | None]

# ---------------------------------------------------------------------------
# Open string-constant namespaces (extensible by domain plugins)
# ---------------------------------------------------------------------------

class ConflictType:
    """Semantic category of a conflict.

    Domain plugins may define additional types beyond these built-in constants.
    All values are plain strings so plugin-defined types are always valid in
    :class:`PolicyCondition` and :class:`ConflictPattern` without modifying
    this module.

    Built-in types
    --------------
    ``STRUCTURAL``  — schema, time signature, file structure.
    ``CONTENT``     — notes, function bodies, actual payload data.
    ``METADATA``    — tempo, tags, BPM, author annotations.
    ``RELATIONAL``  — cross-dimensional or cross-file dependencies.
    ``UNKNOWN``     — conflict type could not be determined.
    """

    STRUCTURAL = "structural"
    CONTENT = "content"
    METADATA = "metadata"
    RELATIONAL = "relational"
    UNKNOWN = "unknown"

class ResolutionStrategy:
    """How a :class:`Resolution` was produced.

    ``POLICY``            — a declarative :class:`Policy` fired automatically.
    ``EXACT_REPLAY``      — blob fingerprint matched an existing resolution exactly.
    ``SEMANTIC_PROPOSAL`` — domain plugin similarity score exceeded threshold.
    ``MANUAL``            — a human or agent resolved the conflict interactively.
    """

    POLICY = "policy"
    EXACT_REPLAY = "exact-replay"
    SEMANTIC_PROPOSAL = "semantic-proposal"
    MANUAL = "manual"

class PolicyAction:
    """What a matching :class:`Policy` does when it fires.

    ``PREFER_OURS``    — adopt the "ours" version of the conflicting content.
    ``PREFER_THEIRS``  — adopt the "theirs" version of the conflicting content.
    ``ESCALATE``       — create a hub issue or notify; see ``Policy.escalate_to``.
    ``REQUIRE_HUMAN``  — block until a human explicitly resolves.
    ``DELEGATE``       — route to a specialist agent; see ``Policy.delegate_to``.
    """

    PREFER_OURS = "prefer-ours"
    PREFER_THEIRS = "prefer-theirs"
    ESCALATE = "escalate"
    REQUIRE_HUMAN = "require-human"
    DELEGATE = "delegate"

class PolicyScope:
    """Scope hierarchy for :class:`Policy` evaluation.

    Policies are evaluated in this order — higher scope takes precedence:
    ``WORKSPACE`` → ``REPO`` → ``DOMAIN`` → ``FILE``.

    A workspace-level policy fires for all repos in the workspace; a
    file-level policy fires only for paths matching its ``path_pattern``.
    """

    WORKSPACE = "workspace"
    REPO = "repo"
    DOMAIN = "domain"
    FILE = "file"

class AuditEventType:
    """Event types written to the harmony audit log.

    The audit log is append-only — entries are never modified after writing,
    creating a tamper-evident record of all harmony engine actions.
    """

    PATTERN_RECORDED = "pattern_recorded"
    RESOLUTION_SAVED = "resolution_saved"
    RESOLUTION_APPLIED = "resolution_applied"
    ESCALATION_RECORDED = "escalation_recorded"
    ESCALATION_RESOLVED = "escalation_resolved"
    PATTERN_FORGOTTEN = "pattern_forgotten"
    POLICY_SAVED = "policy_saved"
    POLICY_REMOVED = "policy_removed"
    GC_RUN = "gc_run"
    CLEAR_RUN = "clear_run"

class EscalationStatus:
    """Status of an :class:`EscalationRecord`.

    ``OPEN``     — the conflict is unresolved; waiting for human or agent.
    ``RESOLVED`` — a resolution was applied and the escalation was closed.
    """

    OPEN = "open"
    RESOLVED = "resolved"

# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class AgentProvenance:
    """Attribution for a resolution or policy action.

    ``type`` is always ``"agent"`` or ``"human"``.  Agent actions carry
    ``agent_id`` and optionally ``model_id``; human actions leave both ``None``.

    Use the convenience constructors :meth:`human` and :meth:`agent` rather
    than calling the dataclass directly.
    """

    type: Literal["agent", "human"]
    agent_id: str | None = None
    model_id: str | None = None

    @classmethod
    def human(cls) -> "AgentProvenance":
        """Return provenance for a direct human action."""
        return cls(type="human")

    @classmethod
    def agent(cls, agent_id: str, model_id: str | None = None) -> "AgentProvenance":
        """Return provenance for an agent action.

        Args:
            agent_id:  Identifies the agent type, e.g. ``"claude-code"``.
            model_id:  Specific model, e.g. ``"claude-sonnet-4-6"``.
        """
        return cls(type="agent", agent_id=agent_id, model_id=model_id)

    def to_dict(self) -> _ProvenanceDict:
        """Serialise to a JSON-compatible dict."""
        return {"type": self.type, "agent_id": self.agent_id, "model_id": self.model_id}

    @classmethod
    def from_dict(cls, data: Mapping[str, JsonValue]) -> "AgentProvenance":
        """Deserialise from a JSON dict, tolerating missing keys."""
        return cls(
            type=str(data.get("type", "human")),  # type: ignore[arg-type]
            agent_id=data.get("agent_id") or None,
            model_id=data.get("model_id") or None,
        )

@dataclass(frozen=True)
class PolicyCondition:
    """Predicate evaluated against a :class:`ConflictPattern`.

    ``None`` fields are wildcards — they match any value.  All non-``None``
    fields must match for the condition to be satisfied.  ``path_pattern``
    uses :func:`fnmatch.fnmatch` glob semantics.

    ``min_confidence`` is a proposal-time filter evaluated by the harmony
    engine against the resolution proposal's confidence score, not against
    any field of the static pattern.
    """

    conflict_type: str | None = None    # None = any ConflictType value
    domain: str | None = None           # None = any domain
    path_pattern: str | None = None     # fnmatch glob; None = any path
    min_confidence: float | None = None  # minimum confidence for auto-acceptance

@dataclass(frozen=True)
class ConflictPattern:
    """The semantic identity of a merge conflict.

    Two fingerprints
    ~~~~~~~~~~~~~~~~
    ``blob_fingerprint`` — SHA-256 of the lexicographically sorted pair of
    ``(ours_id, theirs_id)``.  Enables exact replay regardless of domain —
    enables exact blob-level replay.

    ``semantic_fingerprint`` — provided by a domain's ``HarmonyPlugin`` when
    one is active.  For repos without a plugin, falls back to
    ``blob_fingerprint``.  Enables fuzzy matching across structurally similar
    conflicts even when blob IDs differ.

    ``pattern_id`` — SHA-256 of ``(path + ":" + blob_fingerprint + ":" +
    semantic_fingerprint)``.  Uniquely identifies a conflict for a specific
    file, so two files with identical content conflicts produce distinct
    pattern IDs.

    ``description`` — domain-specific structured metadata populated by the
    active plugin.  The schema is domain-defined; generic code should treat
    it as opaque.
    """

    pattern_id: str                      # 64 hex chars — SHA-256 of (path:blob_fp:semantic_fp)
    path: str                            # workspace-relative POSIX path
    domain: str                          # domain name, e.g. "midi", "code"
    conflict_type: str                   # ConflictType constant or plugin-defined string
    blob_fingerprint: str                # 64 hex SHA-256(sorted ours_id + ":" + theirs_id)
    semantic_fingerprint: str            # 64 hex — domain-provided or == blob_fingerprint
    ours_id: str                         # SHA-256 object ID of the "ours" version
    theirs_id: str                       # SHA-256 object ID of the "theirs" version
    description: _ConflictDescription     # domain-specific structured conflict metadata
    recorded_at: datetime.datetime       # UTC-aware timestamp
    recorded_by: str                     # agent_id or "human"

@dataclass(frozen=True)
class Resolution:
    """A committed decision for a specific :class:`ConflictPattern`.

    ``applied_count`` starts at 0 and is incremented each time this resolution
    is replayed by the harmony engine.  Use :func:`increment_applied_count` to
    update it atomically — do not modify the dataclass directly.

    ``human_verified`` starts ``False`` and is set ``True`` when a human has
    explicitly confirmed the resolution is correct.  The engine prefers
    human-verified resolutions over unverified ones at equal confidence.
    """

    resolution_id: str                   # 64 hex chars — content-addressed
    pattern_id: str                      # which ConflictPattern this resolves
    strategy: str                        # ResolutionStrategy constant
    policy_id: str | None                # set when strategy == POLICY
    outcome_blob: str                    # SHA-256 object ID of the resolved state
    resolved_by: AgentProvenance
    human_verified: bool
    confidence: float                    # 0.0–1.0
    rationale: str                       # human-readable reasoning
    resolved_at: datetime.datetime       # UTC-aware timestamp
    applied_count: int = 0               # incremented on each replay

@dataclass(frozen=True)
class Policy:
    """A declarative resolution rule evaluated against incoming conflict patterns.

    Policies are matched in scope order (workspace → repo → domain → file).
    The first matching policy fires; subsequent policies are not evaluated.

    For ``action == PolicyAction.ESCALATE``, ``escalate_to`` specifies the
    target — ``"human"`` or an agent ID.  For ``action == PolicyAction.DELEGATE``,
    ``delegate_to`` specifies the agent to route the conflict to.  Both fields
    are ``None`` for other actions.

    ``confidence`` is the confidence score assigned to resolutions produced by
    this policy.  It affects :func:`best_resolution` ranking and is compared
    against ``PolicyCondition.min_confidence`` by the harmony engine.
    """

    policy_id: str                       # URL-safe alphanumeric, 1–128 chars
    description: str                     # human-readable explanation
    when: PolicyCondition                # conditions that must all match
    action: str                          # PolicyAction constant
    confidence: float                    # 0.0–1.0; used for ranking and min_confidence checks
    escalate_to: str | None              # "human" | agent_id, for ESCALATE action
    delegate_to: str | None              # agent_id, for DELEGATE action
    scope: str                           # PolicyScope constant
    created_at: datetime.datetime        # UTC-aware timestamp
    created_by: str                      # agent_id or "human"

@dataclass(frozen=True)
class ResolutionProposal:
    """A candidate resolution produced by the harmony engine.

    Proposals are returned when the engine finds a match (semantic or policy)
    but cannot apply automatically — for example because ``confidence`` is
    below the auto-accept threshold or ``requires_confirmation`` is ``True``.

    Agents should auto-accept proposals above their configured threshold and
    escalate the rest for human or specialist-agent review.

    ``similar_pattern_id`` and ``similarity`` are populated for semantic
    proposals; ``policy_id`` is populated for policy-driven proposals.
    """

    pattern_id: str
    strategy: str                         # ResolutionStrategy constant
    proposed_action: str                  # PolicyAction constant
    confidence: float                     # 0.0–1.0
    rationale: str
    policy_id: str | None = None          # set for policy-driven proposals
    similar_pattern_id: str | None = None  # set for semantic proposals
    similarity: float | None = None       # 0.0–1.0 domain similarity score
    requires_confirmation: bool = False

@dataclass(frozen=True)
class EscalationRecord:
    """A persistent record of a conflict pattern escalated for human attention.

    Created when the resolution engine cannot auto-resolve a conflict (Tier 4).
    Transitions from ``status=OPEN`` to ``status=RESOLVED`` when a human or
    specialist agent applies a resolution and calls :func:`resolve_escalation`.

    ``escalation_id``  — deterministic hex64 from ``(pattern_id, reason)``.
    ``pattern_id``     — the pattern that could not be resolved.
    ``reason``         — human-readable explanation of why escalation occurred.
    ``escalated_at``   — UTC-aware timestamp of when escalation was created.
    ``escalated_by``   — agent or human that triggered the escalation.
    ``resolved_at``    — UTC-aware timestamp of resolution (``None`` if open).
    ``resolved_by``    — who resolved the escalation (``None`` if open).
    ``resolution_id``  — which resolution closed this escalation (``None`` if open).
    ``status``         — :class:`EscalationStatus` constant.
    """

    escalation_id: str
    pattern_id: str
    reason: str
    escalated_at: datetime.datetime
    escalated_by: "AgentProvenance"
    resolved_at: datetime.datetime | None = None
    resolved_by: "AgentProvenance | None" = None
    resolution_id: str | None = None
    status: str = EscalationStatus.OPEN

# ---------------------------------------------------------------------------
# Wire-format TypedDicts for JSON serialisation
# ---------------------------------------------------------------------------

class _PatternDict(TypedDict):
    pattern_id: str
    path: str
    domain: str
    conflict_type: str
    blob_fingerprint: str
    semantic_fingerprint: str
    ours_id: str
    theirs_id: str
    description: _ConflictDescription
    recorded_at: str    # ISO 8601
    recorded_by: str

class _ResolutionDict(TypedDict):
    resolution_id: str
    pattern_id: str
    strategy: str
    policy_id: str | None
    outcome_blob: str
    resolved_by: dict[str, str | None]
    human_verified: bool
    confidence: float
    rationale: str
    resolved_at: str    # ISO 8601
    applied_count: int

class _PolicyConditionDict(TypedDict):
    conflict_type: str | None
    domain: str | None
    path_pattern: str | None
    min_confidence: float | None

class _PolicyDict(TypedDict):
    policy_id: str
    description: str
    when: _PolicyConditionDict
    action: str
    confidence: float
    escalate_to: str | None
    delegate_to: str | None
    scope: str
    created_at: str    # ISO 8601
    created_by: str

class AuditEvent(TypedDict):
    """One entry in the harmony audit log — never modified after writing."""

    audit_id: str                       # sha256:<hex> content-addressed ID
    event_type: str                     # AuditEventType constant
    pattern_id: str | None
    resolution_id: str | None
    policy_id: str | None
    acted_by: dict[str, str | None]     # AgentProvenance.to_dict()
    occurred_at: str                    # ISO 8601
    metadata: _AuditMetadata           # event-specific extra fields

class _EscalationDict(TypedDict):
    escalation_id: str
    pattern_id: str
    reason: str
    escalated_at: str               # ISO 8601
    escalated_by: dict[str, str | None]
    resolved_at: str | None         # ISO 8601 or null
    resolved_by: dict[str, str | None] | None
    resolution_id: str | None
    status: str                     # EscalationStatus constant
