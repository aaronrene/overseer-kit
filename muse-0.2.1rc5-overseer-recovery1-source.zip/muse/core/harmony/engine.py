"""muse harmony engine — three-tier resolution intelligence pipeline.

The engine evaluates incoming :class:`~muse.core.harmony.ConflictPattern`
instances against the harmony store and produces an :class:`EngineResult`
indicating what action to take.  The four tiers are evaluated in order and
the first matching tier wins:

Tier 1 — **Policy match**
    Load all :class:`~muse.core.harmony.Policy` entries (scope-sorted:
    workspace → repo → domain → file) and evaluate each condition against
    the pattern.  The first matching policy determines the action:

    - ``PREFER_OURS`` / ``PREFER_THEIRS`` at or above
      :attr:`EngineConfig.auto_apply_threshold` → ``status="applied"``.
    - Same actions *below* threshold → ``status="proposed"`` with
      ``requires_confirmation=True``.
    - ``ESCALATE`` / ``REQUIRE_HUMAN`` / ``DELEGATE`` → ``status="escalated"``.

Tier 2 — **Exact replay**
    Look up the best :class:`~muse.core.harmony.Resolution` for the pattern
    (ranked by ``human_verified`` > ``confidence`` > ``applied_count``):

    - ``human_verified=True`` OR ``confidence`` ≥ threshold → ``status="applied"``,
      :func:`~muse.core.harmony.increment_applied_count` called atomically.
    - Below threshold → ``status="proposed"`` (``requires_confirmation=True``).

Tier 3 — **Semantic match**
    Call :func:`find_similar` to discover patterns with semantically similar
    fingerprints.  The :class:`HarmonyPlugin` ``similarity()`` method scores
    each pair; matches at or above :attr:`EngineConfig.semantic_threshold`
    are returned as proposals with ``requires_confirmation=True``.  Semantic
    matches are always proposed — never auto-applied — because they are
    structural analogies, not exact replays.

Tier 4 — **Escalate**
    No match found in any tier.  Returns ``status="escalated"`` with a
    human-readable reason string.  An audit entry of type
    :attr:`~muse.core.harmony.AuditEventType.ESCALATION_RECORDED` is written.

Plugin protocol
---------------

:class:`HarmonyPlugin` is a structural :class:`typing.Protocol` — any class
with a ``similarity(fp_a, fp_b) -> float`` method satisfies it without
explicit inheritance.  :class:`DefaultPlugin` is the no-op baseline: it
returns ``1.0`` for identical fingerprints and ``0.0`` for all others,
which degrades cleanly to exact-fingerprint semantic matching.

Plugin errors (exceptions from ``similarity()``) are caught and logged;
the engine falls back to :class:`DefaultPlugin` behaviour for that pair.
Plugin-returned similarity values outside ``[0.0, 1.0]`` are clamped before
comparison.

Audit
-----

The engine writes an audit entry for every resolution applied or escalated.
The :data:`~muse.core.harmony.AuditEventType.RESOLUTION_APPLIED` event
records which resolution was replayed; the
:data:`~muse.core.harmony.AuditEventType.ESCALATION_RECORDED` event records
why no automatic resolution was possible.

Thread safety
-------------

All writes delegate to :mod:`muse.core.harmony` functions which use atomic
``os.replace`` — safe for concurrent engine calls on the same repo.
"""

import logging
import pathlib
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from muse.core.types import JsonObject, JsonValue, Manifest, short_id
from muse.core.validation import validate_object_id

from .audit import append_audit
from .fingerprint import (
    _now_utc,
    blob_fingerprint,
    compute_pattern_id,
    compute_resolution_id,
    compute_semantic_fingerprint,
)
from .patterns import list_patterns, load_pattern, record_pattern
from .policies import list_policies, match_policy
from .resolutions import best_resolution, increment_applied_count, list_resolutions, save_resolution
from .types import (
    AgentProvenance,
    AuditEventType,
    ConflictPattern,
    ConflictType,
    PolicyAction,
    Resolution,
    ResolutionProposal,
    ResolutionStrategy,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Open string-constant namespace
# ---------------------------------------------------------------------------

class EngineStatus:
    """Possible outcomes of a :func:`resolve` call.

    ``APPLIED``   — a resolution was auto-applied (confidence ≥ threshold or
                    human_verified, or policy fired at or above threshold).
    ``PROPOSED``  — a candidate was found but requires confirmation before
                    applying (confidence below threshold, or semantic match).
    ``ESCALATED`` — no match found in any tier; human or specialist-agent
                    intervention is required.
    """

    APPLIED = "applied"
    PROPOSED = "proposed"
    ESCALATED = "escalated"

# ---------------------------------------------------------------------------
# Plugin protocol
# ---------------------------------------------------------------------------

@runtime_checkable
class HarmonyPlugin(Protocol):
    """Structural protocol for domain-specific similarity scoring.

    Any class implementing ``similarity(fp_a, fp_b) -> float`` satisfies this
    protocol without explicit inheritance.  The method must return a value in
    ``[0.0, 1.0]``; values outside this range are clamped by the engine.

    Domain plugins (MIDI, code, …) override ``similarity`` to implement
    richer comparisons — e.g. structural graph edit distance on AST
    fingerprints, or pitch-class vector cosine similarity for MIDI tracks.
    """

    def similarity(self, fp_a: str, fp_b: str) -> float:
        """Return a similarity score in ``[0.0, 1.0]`` between two fingerprints."""
        ...

class DefaultPlugin:
    """No-op plugin — exact fingerprint match only.

    Returns ``1.0`` when the two fingerprints are identical (same semantic
    content), ``0.0`` otherwise.  This degrades semantic matching to exact
    fingerprint replay, which is always safe.
    """

    def similarity(self, fp_a: str, fp_b: str) -> float:
        """Return 1.0 for identical fingerprints, 0.0 for all others."""
        return 1.0 if fp_a == fp_b else 0.0

# ---------------------------------------------------------------------------
# Engine configuration
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class EngineConfig:
    """Thresholds and limits that govern engine behaviour.

    ``auto_apply_threshold``
        Minimum confidence required to auto-apply a resolution without
        confirmation.  Resolutions below this threshold are *proposed*.
        Human-verified resolutions bypass this check and are always applied.

    ``semantic_threshold``
        Minimum :class:`HarmonyPlugin` similarity score for a pattern to be
        considered a semantic match.  Pairs below this threshold are ignored.

    ``max_proposals``
        Maximum number of semantic proposals returned by :func:`find_similar`.
        Higher values increase recall at the cost of latency on large stores.
    """

    auto_apply_threshold: float = 0.85
    semantic_threshold: float = 0.70
    max_proposals: int = 5

# ---------------------------------------------------------------------------
# Engine result
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class EngineResult:
    """Outcome of a single :func:`resolve` call.

    ``status``
        One of :class:`EngineStatus` constants — ``"applied"``, ``"proposed"``,
        or ``"escalated"``.

    ``pattern_id``
        The ``pattern_id`` of the :class:`~muse.core.harmony.ConflictPattern`
        that was evaluated.

    ``proposal``
        Populated for ``"applied"`` and ``"proposed"`` statuses.  Contains the
        :class:`~muse.core.harmony.ResolutionProposal` that the engine produced.
        ``None`` for ``"escalated"``.

    ``applied_resolution_id``
        Set when an existing :class:`~muse.core.harmony.Resolution` was replayed
        exactly (exact-replay tier).  ``None`` for policy-driven applications
        (no pre-existing resolution) and all other statuses.

    ``escalation_reason``
        Human-readable explanation populated for ``"escalated"`` results.
        ``None`` for other statuses.
    """

    status: str
    pattern_id: str
    proposal: ResolutionProposal | None = None
    applied_resolution_id: str | None = None
    escalation_reason: str | None = None

# ---------------------------------------------------------------------------
# find_similar
# ---------------------------------------------------------------------------

def find_similar(
    root: pathlib.Path,
    pattern: ConflictPattern,
    *,
    plugin: HarmonyPlugin | None = None,
    config: EngineConfig | None = None,
) -> list[ResolutionProposal]:
    """Search the harmony store for patterns semantically similar to *pattern*.

    Iterates all stored patterns, calls *plugin*``similarity()`` on each pair
    of semantic fingerprints, and returns proposals for patterns whose
    similarity score meets :attr:`EngineConfig.semantic_threshold` and that
    have at least one saved resolution.

    Results are sorted by ``confidence`` descending (best proposal first) and
    capped at :attr:`EngineConfig.max_proposals`.

    Args:
        root:    Repository root.
        pattern: The incoming conflict pattern to match against.
        plugin:  Domain plugin for similarity scoring.  Defaults to
                 :class:`DefaultPlugin`.
        config:  Engine configuration.  Defaults to :class:`EngineConfig`.

    Returns:
        List of :class:`~muse.core.harmony.ResolutionProposal` instances,
        sorted by confidence descending.  Empty if no matches exceed the
        threshold.
    """
    cfg = config or EngineConfig()
    plug = plugin or DefaultPlugin()

    try:
        all_patterns = list_patterns(root)
    except Exception:
        return []

    proposals: list[ResolutionProposal] = []

    for p in all_patterns:
        if p.pattern_id == pattern.pattern_id:
            continue  # skip self

        try:
            raw_sim = plug.similarity(pattern.semantic_fingerprint, p.semantic_fingerprint)
            sim = max(0.0, min(1.0, float(raw_sim)))
        except Exception as exc:
            logger.warning("⚠️ harmony engine: plugin.similarity() raised %s — skipping", exc)
            sim = 0.0

        if sim < cfg.semantic_threshold:
            continue

        best = best_resolution(root, p.pattern_id)
        if best is None:
            continue

        proposals.append(
            ResolutionProposal(
                pattern_id=pattern.pattern_id,
                strategy=ResolutionStrategy.SEMANTIC_PROPOSAL,
                proposed_action=PolicyAction.PREFER_OURS,
                confidence=round(best.confidence * sim, 4),
                rationale=(
                    f"Semantically similar to pattern {p.pattern_id} "
                    f"(similarity={sim:.2f}): {best.rationale}"
                ),
                similar_pattern_id=p.pattern_id,
                similarity=sim,
                requires_confirmation=True,
            )
        )

    proposals.sort(key=lambda pr: pr.confidence, reverse=True)
    return proposals[: cfg.max_proposals]

# ---------------------------------------------------------------------------
# Core engine
# ---------------------------------------------------------------------------

def resolve(
    root: pathlib.Path,
    pattern: ConflictPattern,
    config: EngineConfig | None = None,
    *,
    plugin: HarmonyPlugin | None = None,
    actor: AgentProvenance | None = None,
) -> EngineResult:
    """Run the three-tier resolution pipeline for *pattern*.

    Evaluates tiers in order — policy → exact replay → semantic → escalate —
    and returns the first successful outcome.

    Args:
        root:    Repository root (need not contain the pattern — the engine
                 escalates gracefully if the store is absent or empty).
        pattern: Incoming conflict pattern to resolve.
        config:  Engine configuration overrides.  Defaults to
                 :class:`EngineConfig`.
        plugin:  Domain plugin for semantic similarity.  Defaults to
                 :class:`DefaultPlugin`.
        actor:   Attribution for audit entries.  Defaults to
                 :func:`~muse.core.harmony.AgentProvenance.human`.

    Returns:
        :class:`EngineResult` with ``status``, ``proposal``, and optional
        ``applied_resolution_id`` / ``escalation_reason``.
    """
    cfg = config or EngineConfig()
    plug = plugin or DefaultPlugin()
    act = actor or AgentProvenance.human()

    # ------------------------------------------------------------------
    # Tier 1 — Policy
    # ------------------------------------------------------------------
    try:
        policies = list_policies(root)
        matched = match_policy(policies, pattern)
    except Exception as exc:
        logger.warning("⚠️ harmony engine: policy load failed (%s) — skipping tier 1", exc)
        matched = None

    if matched is not None:
        action = matched.action
        confidence = matched.confidence

        if action in (PolicyAction.PREFER_OURS, PolicyAction.PREFER_THEIRS):
            proposal = ResolutionProposal(
                pattern_id=pattern.pattern_id,
                strategy=ResolutionStrategy.POLICY,
                proposed_action=action,
                confidence=confidence,
                rationale=(
                    f"Policy '{matched.policy_id}' fired: {matched.description}"
                ),
                policy_id=matched.policy_id,
                requires_confirmation=confidence < cfg.auto_apply_threshold,
            )
            if confidence >= cfg.auto_apply_threshold:
                _write_applied_audit(root, pattern.pattern_id, None, act)
                return EngineResult(
                    status=EngineStatus.APPLIED,
                    pattern_id=pattern.pattern_id,
                    proposal=proposal,
                )
            else:
                return EngineResult(
                    status=EngineStatus.PROPOSED,
                    pattern_id=pattern.pattern_id,
                    proposal=proposal,
                )

        # ESCALATE / REQUIRE_HUMAN / DELEGATE → escalate
        if action == PolicyAction.DELEGATE:
            reason = (
                f"Policy '{matched.policy_id}' delegates to agent "
                f"'{matched.delegate_to or 'unknown'}'"
            )
        elif action == PolicyAction.REQUIRE_HUMAN:
            reason = f"Policy '{matched.policy_id}' requires human resolution"
        else:
            target = matched.escalate_to or "unspecified"
            reason = (
                f"Policy '{matched.policy_id}' requires escalation to {target}"
            )
        _write_escalation_audit(root, pattern.pattern_id, act, reason)
        return EngineResult(
            status=EngineStatus.ESCALATED,
            pattern_id=pattern.pattern_id,
            escalation_reason=reason,
        )

    # ------------------------------------------------------------------
    # Tier 2 — Exact replay
    # ------------------------------------------------------------------
    try:
        best = best_resolution(root, pattern.pattern_id)
    except Exception as exc:
        logger.warning("⚠️ harmony engine: exact-replay lookup failed (%s)", exc)
        best = None

    if best is not None:
        proposal = ResolutionProposal(
            pattern_id=pattern.pattern_id,
            strategy=ResolutionStrategy.EXACT_REPLAY,
            proposed_action=PolicyAction.PREFER_OURS,
            confidence=best.confidence,
            rationale=f"Exact replay of resolution {best.resolution_id}",
            requires_confirmation=not (
                best.human_verified or best.confidence >= cfg.auto_apply_threshold
            ),
        )
        if best.human_verified or best.confidence >= cfg.auto_apply_threshold:
            try:
                increment_applied_count(root, pattern.pattern_id, best.resolution_id)
            except Exception as exc:
                logger.warning("⚠️ harmony engine: increment_applied_count failed: %s", exc)
            _write_applied_audit(root, pattern.pattern_id, best.resolution_id, act)
            return EngineResult(
                status=EngineStatus.APPLIED,
                pattern_id=pattern.pattern_id,
                proposal=proposal,
                applied_resolution_id=best.resolution_id,
            )
        else:
            return EngineResult(
                status=EngineStatus.PROPOSED,
                pattern_id=pattern.pattern_id,
                proposal=proposal,
            )

    # ------------------------------------------------------------------
    # Tier 3 — Semantic match
    # ------------------------------------------------------------------
    try:
        similar = find_similar(root, pattern, plugin=plug, config=cfg)
    except Exception as exc:
        logger.warning("⚠️ harmony engine: semantic search failed (%s)", exc)
        similar = []

    if similar:
        best_proposal = similar[0]
        return EngineResult(
            status=EngineStatus.PROPOSED,
            pattern_id=pattern.pattern_id,
            proposal=best_proposal,
        )

    # ------------------------------------------------------------------
    # Tier 4 — Escalate
    # ------------------------------------------------------------------
    reason = (
        f"No policy, exact resolution, or semantic match found for "
        f"pattern {pattern.pattern_id} "
        f"(path='{pattern.path}', domain='{pattern.domain}')"
    )
    _write_escalation_audit(root, pattern.pattern_id, act, reason)
    return EngineResult(
        status=EngineStatus.ESCALATED,
        pattern_id=pattern.pattern_id,
        escalation_reason=reason,
    )

# ---------------------------------------------------------------------------
# Audit helpers
# ---------------------------------------------------------------------------

def _write_applied_audit(
    root: pathlib.Path,
    pattern_id: str,
    resolution_id: str | None,
    actor: AgentProvenance,
) -> None:
    """Write a RESOLUTION_APPLIED audit entry, swallowing any IO errors."""
    try:
        append_audit(
            root,
            AuditEventType.RESOLUTION_APPLIED,
            actor,
            pattern_id=pattern_id,
            resolution_id=resolution_id,
        )
    except Exception as exc:
        logger.warning("⚠️ harmony engine: audit write (applied) failed: %s", exc)

def _write_escalation_audit(
    root: pathlib.Path,
    pattern_id: str,
    actor: AgentProvenance,
    reason: str,
) -> None:
    """Write an ESCALATION_RECORDED audit entry, swallowing any IO errors."""
    try:
        append_audit(
            root,
            AuditEventType.ESCALATION_RECORDED,
            actor,
            pattern_id=pattern_id,
            metadata={"reason": reason},
        )
    except Exception as exc:
        logger.warning("⚠️ harmony engine: audit write (escalation) failed: %s", exc)

# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def _read_config_float(root: pathlib.Path, key: str, default: float) -> float:
    """Read a float from .muse/config.toml by dotted key; return *default* if absent.

    Traverses nested TOML tables using dot-separated *key* components.
    Silently returns *default* on any parse or type error.
    """
    config_path = root / ".muse" / "config.toml"
    if not config_path.is_file():
        return default
    try:
        import tomllib
        with config_path.open("rb") as fh:
            raw = tomllib.load(fh)
        val: JsonValue = raw
        for part in key.split("."):
            if not isinstance(val, dict):
                return default
            val = val.get(part, ...)  # type: ignore[union-attr]
            if val is ...:
                return default
        return float(val) if isinstance(val, (int, float)) else default  # type: ignore[arg-type]
    except Exception:
        return default


# ---------------------------------------------------------------------------
# High-level integration helpers (merge and commit integration)
# ---------------------------------------------------------------------------

def auto_apply(
    root: pathlib.Path,
    conflict_paths: list[str],
    ours_manifest: Manifest,
    theirs_manifest: Manifest,
    domain: str,
    plugin: "MuseDomainPlugin",
    *,
    explain_decisions: JsonObject | None = None,
) -> tuple[Manifest, list[str]]:
    """Attempt to auto-resolve conflicts using saved harmony resolutions.

    For each path in *conflict_paths*:

    1. Validate the path stays within the repository root (path traversal guard).
    2. Compute blob and semantic fingerprints from the ours/theirs object IDs.
    3. Look up the best :class:`~muse.core.harmony.Resolution` for the computed
       pattern ID.
    4. If found: restore the resolution blob to the working tree and collect
       the ``{path: outcome_blob}`` mapping.
    5. If not found: record the pattern for future learning and leave the path
       for manual resolution.

    Args:
        root:            Repository root.
        conflict_paths:  Workspace-relative POSIX paths that conflicted.
        ours_manifest:   ``{path: object_id}`` for the "ours" snapshot.
        theirs_manifest: ``{path: object_id}`` for the "theirs" snapshot.
        domain:          Active domain name string.
        plugin:          Active domain plugin instance.

    Returns:
        ``(resolved, remaining)`` where:

        - ``resolved`` maps path → outcome_blob for auto-resolved paths.
        - ``remaining`` is the list of paths still requiring manual resolution.
    """
    from muse.core.object_store import restore_object

    resolved: dict[str, str] = {}
    remaining: list[str] = []

    for path in conflict_paths:
        # Conflict paths from the code domain are symbol addresses of the form
        # "file.py::SymbolName".  Manifests are keyed by file path, so extract
        # the file portion for all manifest lookups.  The full address is kept
        # as the canonical path for pattern storage and fingerprinting so that
        # two different symbols in the same file produce distinct patterns.
        file_path = path.split("::")[0]

        # Guard against path traversal from a tampered MERGE_STATE.json.
        # Use the file portion for the filesystem check.
        # resolve() normalises any ".." components and symlinks before the
        # relative_to() check, so "../traversal.py" is caught correctly.
        try:
            (root / file_path).resolve().relative_to(root.resolve())
        except ValueError:
            logger.warning(
                "⚠️ harmony: path traversal attempt in auto_apply — skipping %r",
                path,
            )
            remaining.append(path)
            continue

        ours_id = ours_manifest.get(file_path, "")
        theirs_id = theirs_manifest.get(file_path, "")

        if not ours_id or not theirs_id:
            # One side deleted the file — cannot fingerprint, leave for manual.
            remaining.append(path)
            continue

        blob_fp = blob_fingerprint(ours_id, theirs_id)
        semantic_fp = compute_semantic_fingerprint(path, ours_id, theirs_id, plugin, root)
        pattern_id = compute_pattern_id(path, blob_fp, semantic_fp)

        best = best_resolution(root, pattern_id)
        if best is not None:
            min_confidence = _read_config_float(
                root, "harmony.min_auto_apply_confidence", default=0.85
            )
            if best.confidence < min_confidence:
                logger.info(
                    "⚠️ harmony: skipping auto-apply for '%s' — "
                    "confidence %.2f < threshold %.2f",
                    path, best.confidence, min_confidence,
                )
                if explain_decisions is not None:
                    explain_decisions[file_path] = {
                        "result": "below_confidence_threshold",
                        "pattern_id": pattern_id,
                    }
                remaining.append(path)
                continue

            dest = root / file_path
            dest.parent.mkdir(parents=True, exist_ok=True)
            ok = restore_object(root, best.outcome_blob, dest)
            if ok:
                resolved[path] = best.outcome_blob
                logger.info("✅ harmony: auto-resolved '%s'", path)
                if explain_decisions is not None:
                    explain_decisions[file_path] = {
                        "result": "auto_resolved",
                        "pattern_id": pattern_id,
                    }
                try:
                    increment_applied_count(root, pattern_id, best.resolution_id)
                except Exception as exc:
                    logger.warning(
                        "⚠️ harmony: increment_applied_count failed for '%s': %s",
                        path, exc,
                    )
            else:
                logger.warning(
                    "⚠️ harmony: resolution blob %s for '%s' not in local store",
                    best.outcome_blob, path,
                )
                if explain_decisions is not None:
                    explain_decisions[file_path] = {
                        "result": "no_pattern",
                        "pattern_id": pattern_id,
                    }
                remaining.append(path)
        else:
            # No saved resolution — record the pattern for future learning.
            now = _now_utc()
            pattern = ConflictPattern(
                pattern_id=pattern_id,
                path=path,
                domain=domain,
                conflict_type=ConflictType.CONTENT,
                blob_fingerprint=blob_fp,
                semantic_fingerprint=semantic_fp,
                ours_id=ours_id,
                theirs_id=theirs_id,
                description={},
                recorded_at=now,
                recorded_by="auto_apply",
            )
            record_pattern(root, pattern)
            if explain_decisions is not None:
                explain_decisions[file_path] = {
                    "result": "no_pattern",
                    "pattern_id": None,
                }
            remaining.append(path)

    return resolved, remaining


def record_resolutions(
    root: pathlib.Path,
    conflict_paths: list[str],
    ours_manifest: Manifest,
    theirs_manifest: Manifest,
    new_manifest: Manifest,
    domain: str,
    plugin: "MuseDomainPlugin",
    manually_resolved: set[str] | None = None,
) -> list[str]:
    """Record how the user resolved each conflict after a merge commit.

    Called by ``muse commit`` immediately after writing a merge commit that
    resolves a conflicted merge.  For each previously conflicting path the
    function reads the resolution object ID from the new snapshot manifest and
    saves it to the harmony store as a :class:`~muse.core.harmony.Resolution`.

    Paths present in *manually_resolved* (those explicitly confirmed via
    ``muse resolve`` after manual editing) are recorded with
    ``confidence=1.0, human_verified=True``.  All other paths (resolved by
    accepting one side with ``muse checkout --ours/--theirs``) are recorded
    with ``confidence=0.8, human_verified=False`` — a deliberate choice, but
    not a careful manual merge.

    When *manually_resolved* is ``None`` (legacy callers / no MERGE_STATE
    tracking) every path is recorded with ``confidence=1.0,
    human_verified=True`` to preserve the pre-Phase-4 behaviour.

    Args:
        root:              Repository root.
        conflict_paths:    Paths that were listed as conflicts in MERGE_STATE.
        ours_manifest:     ``{path: object_id}`` for the "ours" snapshot.
        theirs_manifest:   ``{path: object_id}`` for the "theirs" snapshot.
        new_manifest:      ``{path: object_id}`` from the committed merge snapshot.
        domain:            Active domain name string.
        plugin:            Active domain plugin instance.
        manually_resolved: Set of conflict addresses explicitly confirmed via
                           ``muse resolve``.  ``None`` → treat all as manual.

    Returns:
        List of paths for which a resolution was successfully saved.
    """
    saved: list[str] = []

    for path in conflict_paths:
        # Conflict paths from the code domain are symbol addresses of the form
        # "file.py::SymbolName".  Extract the file portion for manifest lookups;
        # keep the full address as the canonical path in the harmony store.
        file_path = path.split("::")[0]

        ours_id = ours_manifest.get(file_path, "")
        theirs_id = theirs_manifest.get(file_path, "")
        outcome_blob = new_manifest.get(file_path, "")

        if not ours_id or not theirs_id or not outcome_blob:
            continue

        try:
            validate_object_id(outcome_blob)
        except ValueError:
            continue

        blob_fp = blob_fingerprint(ours_id, theirs_id)
        semantic_fp = compute_semantic_fingerprint(path, ours_id, theirs_id, plugin, root)
        pattern_id = compute_pattern_id(path, blob_fp, semantic_fp)
        now = _now_utc()

        # Ensure the pattern exists in the harmony store.
        if load_pattern(root, pattern_id) is None:
            pattern = ConflictPattern(
                pattern_id=pattern_id,
                path=path,
                domain=domain,
                conflict_type=ConflictType.CONTENT,
                blob_fingerprint=blob_fp,
                semantic_fingerprint=semantic_fp,
                ours_id=ours_id,
                theirs_id=theirs_id,
                description={},
                recorded_at=now,
                recorded_by="record_resolutions",
            )
            record_pattern(root, pattern)

        # Idempotency: skip if a resolution with this outcome_blob already exists.
        existing = list_resolutions(root, pattern_id)
        if any(r.outcome_blob == outcome_blob for r in existing):
            logger.debug(
                "harmony: resolution for '%s' (pattern %s) already recorded — skipping",
                path, short_id(pattern_id),
            )
            saved.append(path)
            continue

        # Paths in manually_resolved were carefully edited by the user via
        # `muse resolve` — high confidence, human-verified.  Paths resolved via
        # `muse checkout --ours/--theirs` (side-pick) get lower confidence and
        # human_verified=False.  When manually_resolved is None (legacy callers)
        # treat everything as human-verified to preserve pre-Phase-4 behaviour.
        is_manual = manually_resolved is None or path in manually_resolved
        confidence = 1.0 if is_manual else 0.8
        resolution_id = compute_resolution_id(
            pattern_id,
            outcome_blob,
            ResolutionStrategy.MANUAL,
            AgentProvenance.human(),
            now,
        )
        resolution = Resolution(
            resolution_id=resolution_id,
            pattern_id=pattern_id,
            strategy=ResolutionStrategy.MANUAL,
            policy_id=None,
            outcome_blob=outcome_blob,
            rationale=(
                f"User manually resolved conflict in '{path}' via muse resolve"
                if is_manual
                else f"Conflict in '{path}' resolved by accepting one side (checkout --ours/--theirs)"
            ),
            confidence=confidence,
            applied_count=0,
            human_verified=is_manual,
            resolved_at=now,
            resolved_by=AgentProvenance.human(),
        )
        try:
            save_resolution(root, resolution)
            saved.append(path)
            logger.info(
                "✅ harmony: recorded resolution for '%s' (pattern %s)",
                path,
                pattern_id,
            )
        except Exception as exc:
            logger.warning(
                "⚠️ harmony: failed to save resolution for '%s': %s",
                path, exc,
            )

    return saved
