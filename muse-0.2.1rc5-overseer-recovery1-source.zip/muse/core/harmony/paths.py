"""Harmony path helpers and path-level validation.

Single responsibility: compute filesystem paths for harmony storage and
validate ID strings before they touch the filesystem.  No I/O beyond
path construction.
"""

from __future__ import annotations

import pathlib
import re

from muse.core.paths import harmony_dir as _harmony_dir
from muse.core.types import split_id

# ---------------------------------------------------------------------------
# String constants — harmony storage layout
# ---------------------------------------------------------------------------

_HARMONY = "harmony"
_PATTERNS = "patterns"
_POLICIES = "policies"
_AUDIT = "audit"
_ESCALATIONS = "escalations"
_RESOLUTIONS = "resolutions"
_PATTERN_FILE = "pattern.json"

# ---------------------------------------------------------------------------
# Size and format constants used by validation
# ---------------------------------------------------------------------------

#: Maximum bytes for a semantic fingerprint string.
#: Fingerprints may be rich token-bag strings (code plugin) rather than hex64.
_MAX_FINGERPRINT_BYTES: int = 4_096  # 4 KiB

#: Regex matching a canonical content-addressed ID: ``sha256:`` + 64 lowercase hex chars.
_SHA256_ID_RE: re.Pattern[str] = re.compile(r"^sha256:[0-9a-f]{64}$")

#: Regex matching a bare 64-char lowercase hex string (used for filesystem dir names).
_BARE_HEX64_RE: re.Pattern[str] = re.compile(r"^[0-9a-f]{64}$")

#: Regex matching a valid policy ID: alphanumeric + hyphen + underscore, 1–128 chars.
_POLICY_ID_RE: re.Pattern[str] = re.compile(r"^[A-Za-z0-9_-]{1,128}$")

# _id_hex is retired — use split_id() from muse.core.types directly.

# ---------------------------------------------------------------------------
# Directory helpers
# ---------------------------------------------------------------------------

def patterns_dir(root: pathlib.Path) -> pathlib.Path:
    """Return ``.muse/harmony/patterns/`` (may not yet exist)."""
    return _harmony_dir(root) / _PATTERNS

def policies_dir(root: pathlib.Path) -> pathlib.Path:
    """Return ``.muse/harmony/policies/`` (may not yet exist)."""
    return _harmony_dir(root) / _POLICIES

def audit_dir(root: pathlib.Path) -> pathlib.Path:
    """Return ``.muse/harmony/audit/`` (may not yet exist)."""
    return _harmony_dir(root) / _AUDIT

def escalations_dir(root: pathlib.Path) -> pathlib.Path:
    """Return ``.muse/harmony/escalations/`` (may not yet exist)."""
    return _harmony_dir(root) / _ESCALATIONS

def escalation_path(root: pathlib.Path, escalation_id: str) -> pathlib.Path:
    """Return the JSON file path for an escalation record.

    Path shape: ``.muse/harmony/escalations/<algo>/<hex>.json``

    Args:
        root:           Repository root.
        escalation_id:  A ``<algo>:<hex>`` escalation ID, or bare 64-char hex.
    """
    algo, hex_id = split_id(escalation_id)
    return escalations_dir(root) / algo / f"{hex_id}.json"

def pattern_dir(root: pathlib.Path, pattern_id: str) -> pathlib.Path:
    """Return the entry directory for *pattern_id*.

    Path shape: ``.muse/harmony/patterns/<algo>/<hex>/``

    The algorithm is derived from *pattern_id* itself via :func:`split_id`,
    so the directory reflects the actual hash algorithm used — no colon ever
    appears in a path segment.

    Args:
        root:       Repository root.
        pattern_id: A ``<algo>:<hex>`` pattern ID, or bare 64-char hex.

    Raises:
        ValueError: If *pattern_id* is malformed or contains path-unsafe chars.
    """
    algo, hex_id = split_id(pattern_id)
    return patterns_dir(root) / algo / hex_id

# Keep old name as an alias so internal callers migrate gradually.
_pattern_entry_dir = pattern_dir

def _resolutions_dir(root: pathlib.Path, pattern_id: str) -> pathlib.Path:
    """Return the resolutions subdirectory for *pattern_id*."""
    return pattern_dir(root, pattern_id) / _RESOLUTIONS

def resolution_path(root: pathlib.Path, pattern_id: str, resolution_id: str) -> pathlib.Path:
    """Return the JSON file path for a resolution record.

    Path shape: ``.muse/harmony/patterns/<p-algo>/<p-hex>/resolutions/<r-algo>/<r-hex>.json``

    Both the pattern and the resolution carry independent algorithm segments —
    they may differ if patterns and resolutions are created at different points
    in the system's lifecycle.  No colon ever appears in a path segment.

    Args:
        root:          Repository root.
        pattern_id:    A ``<algo>:<hex>`` pattern ID, or bare 64-char hex.
        resolution_id: A ``<algo>:<hex>`` resolution ID, or bare 64-char hex.

    Raises:
        ValueError: If either ID is malformed or contains path-unsafe chars.
    """
    r_algo, r_hex = split_id(resolution_id)
    return _resolutions_dir(root, pattern_id) / r_algo / f"{r_hex}.json"

# Keep old name as an alias.
_resolution_path = resolution_path

# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def _validate_id(value: str, label: str = "id") -> None:
    """Raise :exc:`ValueError` if *value* is not a valid content-addressed ID.

    Prevents path-traversal attacks: a crafted value like ``"../traversal"`` cannot
    match ``sha256:[0-9a-f]{64}``, so it is rejected before any filesystem path
    is constructed from it.

    Args:
        value: The string to validate — must be ``sha256:<64-hex>``.
        label: Field name used in the error message.

    Raises:
        ValueError: When *value* does not match ``sha256:[0-9a-f]{64}``.
    """
    if not _SHA256_ID_RE.match(value):
        raise ValueError(
            f"Invalid {label} {value!r} — expected sha256:<64-hex> (length 71)."
        )

def _validate_fingerprint(value: str, label: str = "semantic_fingerprint") -> None:
    """Raise :exc:`ValueError` if *value* is not a valid semantic fingerprint.

    Unlike :func:`_validate_id`, this does not require hex64 format — domain
    plugins may use richer representations such as normalized token-bag
    strings produced by ``code_fingerprint()``.

    Constraints:
    - Must be non-empty.
    - Must not contain null bytes (``\\x00``).
    - Must not exceed :data:`_MAX_FINGERPRINT_BYTES` bytes (UTF-8 encoded).

    Args:
        value: The fingerprint string to validate.
        label: Field name used in the error message.

    Raises:
        ValueError: When *value* is empty, contains a null byte, or is too large.
    """
    if not value:
        raise ValueError(f"Invalid {label}: must not be empty.")
    if "\x00" in value:
        raise ValueError(f"Invalid {label}: must not contain null bytes.")
    if len(value.encode()) > _MAX_FINGERPRINT_BYTES:
        raise ValueError(
            f"Invalid {label}: exceeds {_MAX_FINGERPRINT_BYTES}-byte limit "
            f"({len(value.encode())} bytes)."
        )

def _validate_policy_id(policy_id: str) -> None:
    """Raise :exc:`ValueError` if *policy_id* is not URL-safe.

    Policy IDs are used directly as filenames.  This rejects slashes, spaces,
    dots, and control characters that could cause path traversal or injection.

    Args:
        policy_id: The policy identifier to validate.

    Raises:
        ValueError: When *policy_id* does not match ``[A-Za-z0-9_-]{1,128}``.
    """
    if not _POLICY_ID_RE.match(policy_id):
        raise ValueError(
            f"Invalid policy_id {policy_id!r} — "
            "only alphanumeric characters, hyphens, and underscores are allowed "
            "(1–128 characters)."
        )
