"""Harmony fingerprinting and time helpers — pure computation, no I/O.

Single responsibility: compute content-addressed IDs and fingerprints for
conflict patterns, resolutions, and escalations.  All functions are
deterministic and side-effect-free except for the current-time helpers
(_now_utc, _parse_dt) and the plugin-dispatch in compute_semantic_fingerprint.
"""

from __future__ import annotations

import datetime
import logging
import pathlib

from muse.core.types import JsonValue, content_hash

from .paths import _SHA256_ID_RE
from .types import AgentProvenance

logger = logging.getLogger(__name__)


def _now_utc() -> datetime.datetime:
    """Return the current UTC time as a timezone-aware datetime."""
    return datetime.datetime.now(datetime.timezone.utc)


def _parse_dt(value: JsonValue | None) -> datetime.datetime:
    """Parse *value* as an ISO 8601 datetime, defaulting to now on failure.

    Always returns a UTC-aware datetime regardless of the timezone embedded
    in *value* — naive datetimes are assumed to be UTC.
    """
    try:
        dt = datetime.datetime.fromisoformat(str(value))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=datetime.timezone.utc)
        return dt
    except (ValueError, TypeError):
        return _now_utc()


def blob_fingerprint(ours_id: str, theirs_id: str) -> str:
    """Return the content fingerprint for a pair of conflicting object IDs.

    Sorts the pair lexicographically before hashing so the result is
    commutative — resolving A-vs-B produces the same fingerprint as B-vs-A.

    Args:
        ours_id:   ``sha256:`` object ID of the "ours" version.
        theirs_id: ``sha256:`` object ID of the "theirs" version.

    Returns:
        ``sha256:`` content-addressed fingerprint (length 71).
    """
    lo, hi = sorted((ours_id, theirs_id))
    return content_hash({"ids": [lo, hi]})


def compute_pattern_id(path: str, blob_fp: str, semantic_fp: str) -> str:
    """Compute the canonical pattern ID for a conflict.

    Incorporates *path* so that two different files with the same conflicting
    content produce distinct pattern IDs — the resolution for ``track.mid``
    and ``drums.mid`` are stored and retrieved independently.

    When a domain plugin provides a richer semantic fingerprint (``semantic_fp
    != blob_fp``), the semantic fingerprint alone determines the pattern
    identity.  This is the mechanism that enables cross-content replay: two
    merge conflicts with different blob IDs but the same semantic shape
    (e.g. same musical phrase transposed by a semitone) map to the same
    pattern and therefore replay the same saved resolution.

    When no semantic plugin is active, ``semantic_fp == blob_fp``, so the
    formula degenerates to the classic exact-replay model where two conflicts
    must have identical blob content to share a pattern.

    Args:
        path:        Workspace-relative POSIX path of the conflicting file.
        blob_fp:     ``sha256:`` blob fingerprint from :func:`blob_fingerprint`.
        semantic_fp: ``sha256:`` semantic fingerprint (from plugin or == blob_fp).

    Returns:
        ``sha256:`` content-addressed pattern ID (length 71).
    """
    if semantic_fp != blob_fp:
        # Domain plugin provided a richer fingerprint — use it alone so that
        # conflicts with different blob IDs but the same semantic shape share
        # a single pattern and replay the same resolution.
        return content_hash({"path": path, "semantic_fp": semantic_fp})
    # No plugin (or plugin deferred to blob fingerprint) — include both so
    # exact-replay is commutative (blob_fp already is) and stable.
    return content_hash({"blob_fp": blob_fp, "path": path, "semantic_fp": semantic_fp})


def compute_resolution_id(
    pattern_id: str,
    outcome_blob: str,
    strategy: str,
    resolved_by: AgentProvenance,
    resolved_at: datetime.datetime,
) -> str:
    """Compute a stable content-addressed ID for a resolution.

    The ID is deterministic for the same inputs so duplicate saves are
    idempotent — calling :func:`save_resolution` twice with the same parameters
    produces the same file and is a no-op.

    Args:
        pattern_id:   ``sha256:`` pattern ID this resolution belongs to.
        outcome_blob: ``sha256:`` object ID of the resolved content.
        strategy:     :class:`ResolutionStrategy` constant.
        resolved_by:  Attribution for the resolution.
        resolved_at:  UTC-aware timestamp of the resolution.

    Returns:
        ``sha256:`` content-addressed resolution ID (length 71).
    """
    return content_hash({
        "actor": resolved_by.agent_id or "human",
        "outcome_blob": outcome_blob,
        "pattern_id": pattern_id,
        "resolved_at": resolved_at.isoformat(),
        "strategy": strategy,
    })


def compute_escalation_id(pattern_id: str, reason: str) -> str:
    """Return a deterministic ``sha256:`` escalation ID.

    The same (pattern_id, reason) pair always produces the same escalation_id,
    enabling idempotent :func:`record_escalation` calls — recording the same
    escalation twice returns ``False`` without creating a duplicate file.

    Args:
        pattern_id: ``sha256:`` ID of the pattern that was escalated.
        reason:     The human-readable escalation reason string.

    Returns:
        ``sha256:`` content-addressed escalation ID (length 71).
    """
    return content_hash({"pattern_id": pattern_id, "reason": reason})


def compute_semantic_fingerprint(
    path: str,
    ours_id: str,
    theirs_id: str,
    plugin: "MuseDomainPlugin",
    repo_root: pathlib.Path,
) -> str:
    """Return the semantic fingerprint for a conflict.

    Uses the plugin's ``conflict_fingerprint()`` method if it implements the
    :class:`~muse.domain.HarmonyPlugin` sub-protocol; falls back to
    :func:`blob_fingerprint` otherwise.

    Args:
        path:      Workspace-relative POSIX path of the conflicting file.
        ours_id:   SHA-256 object ID of the "ours" blob.
        theirs_id: SHA-256 object ID of the "theirs" blob.
        plugin:    Active domain plugin instance.
        repo_root: Repository root for plugin context.

    Returns:
        sha256: content-addressed fingerprint.
    """
    from muse.domain import HarmonyPlugin as _HarmonyPlugin

    if isinstance(plugin, _HarmonyPlugin):
        try:
            fp = plugin.conflict_fingerprint(path, ours_id, theirs_id, repo_root)
            if fp and _SHA256_ID_RE.match(fp):
                return fp
            logger.warning(
                "⚠️ harmony: plugin conflict_fingerprint returned invalid value %r — "
                "falling back to blob fingerprint",
                fp,
            )
        except Exception as exc:
            logger.warning(
                "⚠️ harmony: plugin conflict_fingerprint raised %s — "
                "falling back to blob fingerprint",
                exc,
            )
    return blob_fingerprint(ours_id, theirs_id)
