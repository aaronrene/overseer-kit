"""Harmony escalation persistence — record, load, list, resolve escalations.

Single responsibility: CRUD for EscalationRecord objects in the harmony store.
Uses the raw os.replace write pattern (like the original) because escalation
records carry fsync for durability.
"""

from __future__ import annotations

import datetime
import json
import logging
import os
import pathlib
import tempfile
from collections.abc import Mapping
from dataclasses import replace as dc_replace

from muse.core.types import JsonValue, short_id

from .paths import (
    escalation_path,
    escalations_dir,
    _validate_id,
)
from .types import (
    AgentProvenance,
    EscalationRecord,
    EscalationStatus,
    _EscalationDict,
)

logger = logging.getLogger(__name__)

#: Maximum bytes read from a single escalation record file.
_MAX_ESCALATION_BYTES: int = 16_384  # 16 KiB

# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------

def _escalation_to_dict(rec: EscalationRecord) -> _EscalationDict:
    return _EscalationDict(
        escalation_id=rec.escalation_id,
        pattern_id=rec.pattern_id,
        reason=rec.reason,
        escalated_at=rec.escalated_at.isoformat(),
        escalated_by=rec.escalated_by.to_dict(),
        resolved_at=rec.resolved_at.isoformat() if rec.resolved_at is not None else None,
        resolved_by=rec.resolved_by.to_dict() if rec.resolved_by is not None else None,
        resolution_id=rec.resolution_id,
        status=rec.status,
    )

def _dict_to_escalation(data: Mapping[str, JsonValue]) -> EscalationRecord:
    escalated_by_raw = data["escalated_by"]
    escalated_by = AgentProvenance(
        type=escalated_by_raw.get("type", "human"),
        agent_id=escalated_by_raw.get("agent_id"),
        model_id=escalated_by_raw.get("model_id"),
    )

    resolved_at = (
        datetime.datetime.fromisoformat(data["resolved_at"])
        if data.get("resolved_at") is not None
        else None
    )
    resolved_by: AgentProvenance | None = None
    if data.get("resolved_by") is not None:
        rb = data["resolved_by"]
        resolved_by = AgentProvenance(
            type=rb.get("type", "human"),
            agent_id=rb.get("agent_id"),
            model_id=rb.get("model_id"),
        )

    return EscalationRecord(
        escalation_id=data["escalation_id"],
        pattern_id=data["pattern_id"],
        reason=data["reason"],
        escalated_at=datetime.datetime.fromisoformat(data["escalated_at"]),
        escalated_by=escalated_by,
        resolved_at=resolved_at,
        resolved_by=resolved_by,
        resolution_id=data.get("resolution_id"),
        status=data.get("status", EscalationStatus.OPEN),
    )

# ---------------------------------------------------------------------------
# Escalation CRUD
# ---------------------------------------------------------------------------

def record_escalation(root: pathlib.Path, record: EscalationRecord) -> bool:
    """Persist an :class:`EscalationRecord` to the harmony store.

    The file is written atomically with ``os.replace``.  If the escalation
    already exists (same ``escalation_id``), the call is a no-op and returns
    ``False``.  Returns ``True`` on first write.

    Args:
        root:   Repository root.
        record: The escalation record to persist.

    Returns:
        ``True`` if the record was newly written; ``False`` if it already
        existed.
    """
    esc_dir = escalations_dir(root)
    dest = escalation_path(root, record.escalation_id)
    dest.parent.mkdir(parents=True, exist_ok=True)

    if dest.exists() and not dest.is_symlink():
        return False

    payload = json.dumps(_escalation_to_dict(record), indent=2).encode()
    fd, tmp = tempfile.mkstemp(dir=esc_dir, suffix=".tmp")
    try:
        os.write(fd, payload)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(tmp, dest)
    logger.debug(
        "harmony: recorded escalation %s for pattern %s",
        short_id(record.escalation_id),
        short_id(record.pattern_id),
    )
    return True

def load_escalation(root: pathlib.Path, escalation_id: str) -> EscalationRecord | None:
    """Load an :class:`EscalationRecord` by ID.

    Args:
        root:           Repository root.
        escalation_id:  ``sha256:`` content-addressed escalation ID.

    Returns:
        The :class:`EscalationRecord`, or ``None`` if not found.

    Raises:
        ValueError: If ``escalation_id`` is not a valid content-addressed ID.
    """
    _validate_id(escalation_id, "escalation_id")
    dest = escalation_path(root, escalation_id)

    if not dest.exists() or dest.is_symlink():
        return None

    raw = dest.read_bytes()
    if len(raw) > _MAX_ESCALATION_BYTES:
        logger.warning(
            "harmony: escalation %s exceeds size cap — skipping", escalation_id
        )
        return None

    try:
        data = json.loads(raw)
        return _dict_to_escalation(data)
    except Exception as exc:
        logger.warning(
            "harmony: failed to parse escalation %s: %s", escalation_id, exc
        )
        return None

def list_escalations(
    root: pathlib.Path,
    status: str | None = None,
) -> list[EscalationRecord]:
    """Return all escalation records, optionally filtered by status.

    Results are sorted newest-first by ``escalated_at``.  Symlinks and files
    that exceed :data:`_MAX_ESCALATION_BYTES` are silently skipped.

    Args:
        root:   Repository root.
        status: If given, only records with this :class:`EscalationStatus`
                value are returned.  ``None`` returns all records.

    Returns:
        List of :class:`EscalationRecord` instances, newest-first.
    """
    esc_dir = escalations_dir(root)
    if not esc_dir.exists():
        return []

    records: list[EscalationRecord] = []
    for algo_dir in esc_dir.iterdir():
        if algo_dir.is_symlink() or not algo_dir.is_dir():
            continue
        for entry in algo_dir.iterdir():
            if entry.is_symlink() or not entry.is_file():
                continue
            if not entry.name.endswith(".json"):
                continue

            raw = entry.read_bytes()
            if len(raw) > _MAX_ESCALATION_BYTES:
                logger.warning(
                    "harmony: escalation file %s exceeds size cap — skipping",
                    entry.name,
                )
                continue

            try:
                data = json.loads(raw)
                rec = _dict_to_escalation(data)
            except Exception as exc:
                logger.warning(
                    "harmony: failed to parse escalation %s: %s", entry.name, exc
                )
                continue

            if status is not None and rec.status != status:
                continue
            records.append(rec)

    records.sort(key=lambda r: r.escalated_at, reverse=True)
    return records

def resolve_escalation(
    root: pathlib.Path,
    escalation_id: str,
    resolution_id: str,
    resolved_by: AgentProvenance,
    resolved_at: datetime.datetime,
) -> bool:
    """Transition an :class:`EscalationRecord` from OPEN to RESOLVED.

    Reads the existing record, updates status + resolution fields, and writes
    atomically.  If the escalation does not exist, returns ``False``.

    Args:
        root:           Repository root.
        escalation_id:  ``sha256:`` content-addressed ID of the escalation.
        resolution_id:  ``sha256:`` content-addressed ID of the resolution.
        resolved_by:    :class:`AgentProvenance` of who resolved it.
        resolved_at:    UTC-aware timestamp of the resolution.

    Returns:
        ``True`` if the record was found and updated; ``False`` if not found.

    Raises:
        ValueError: If ``escalation_id`` is not a valid content-addressed ID.
    """
    _validate_id(escalation_id, "escalation_id")
    existing = load_escalation(root, escalation_id)
    if existing is None:
        return False

    updated = dc_replace(
        existing,
        status=EscalationStatus.RESOLVED,
        resolution_id=resolution_id,
        resolved_by=resolved_by,
        resolved_at=resolved_at,
    )

    dest = escalation_path(root, escalation_id)
    payload = json.dumps(_escalation_to_dict(updated), indent=2).encode()
    fd, tmp = tempfile.mkstemp(dir=dest.parent, suffix=".tmp")
    try:
        os.write(fd, payload)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(tmp, dest)
    logger.debug("harmony: resolved escalation %s", short_id(escalation_id))
    return True
