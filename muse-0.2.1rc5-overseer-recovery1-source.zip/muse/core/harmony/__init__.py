"""muse harmony — Resolution Intelligence for domain-agnostic conflict resolution.

Harmony is a three-tier resolution intelligence layer built from the ground up
for an agent-first, multi-dimensional VCS.

Core concepts
-------------

ConflictPattern
    The semantic identity of a divergence between two branches.  Every pattern
    carries both a *blob fingerprint* (SHA-256 of sorted object-ID pair, for
    exact matching) and a *semantic fingerprint* (domain-provided, for fuzzy
    matching across structurally similar conflicts).  The two fingerprints
    allow exact replay as a degenerate case of the richer semantic model.

Resolution
    A committed decision: what the resolved state is, who made it, which
    strategy was applied, and a human-readable rationale.  ``applied_count``
    tracks replay frequency and informs confidence ranking.

Policy
    A declarative rule that fires automatically when a conflict pattern matches
    its condition.  Conditions constrain ``conflict_type``, ``domain``, path
    glob, and minimum confidence.  Policies are evaluated in scope order:
    workspace → repo → domain → file.  The first matching policy wins.

ResolutionProposal
    A candidate resolution returned by the harmony engine when no exact match
    exists but a semantic or policy match is available.  Always carries a
    ``confidence`` score so agents can decide whether to auto-accept or escalate.

Resolution engine (Phase 3)
    The engine evaluates conflicts in this order:
    1. Policy match  — declarative rule fires automatically.
    2. Exact replay  — blob fingerprint matches a saved resolution.
    3. Semantic match — domain plugin similarity score ≥ threshold.
    4. Escalate      — create hub issue, flag for human or specialist agent.

Storage layout
--------------

::

    .muse/harmony/
      policies/
        <policy_id>.json     ← one file per policy (Phase 2 migrates to TOML)
      patterns/
        <pattern_id>/
          pattern.json       ← ConflictPattern metadata
          resolutions/
            <resolution_id>.json   ← one Resolution per file
      audit/
        <YYYYMMDD>-<sha256-hex-slice>.json    ← append-only audit log

Security model
--------------

Pattern and resolution IDs are validated as exactly 64 lowercase hex characters
before any filesystem path is constructed — preventing ``../`` path-traversal.
Policy IDs are validated as URL-safe alphanumeric strings.  All directory
iteration skips symlinks.  File reads are capped at :data:`_MAX_PATTERN_BYTES`,
:data:`_MAX_RESOLUTION_BYTES`, and :data:`_MAX_POLICY_BYTES` to prevent OOM
from maliciously large entries.  All writes are atomic (temp file + ``os.replace``).

Thread safety
-------------

All writes use ``os.replace`` (POSIX rename), which is atomic on all supported
platforms.  Concurrent readers always see either a complete or absent file —
never a partial write.

Extensibility
-------------

:class:`ConflictType`, :class:`ResolutionStrategy`, :class:`PolicyAction`, and
:class:`PolicyScope` are open string-constant namespaces rather than closed
enums.  Domain plugins may define additional constants (e.g. ``"note_collision"``,
``"tempo_divergence"``) without modifying this module.

Package structure
-----------------

:mod:`muse.core.harmony.types`        — dataclasses, TypedDicts, enums
:mod:`muse.core.harmony.paths`        — path helpers and path-level validation
:mod:`muse.core.harmony.fingerprint`  — blob / semantic fingerprint computation
:mod:`muse.core.harmony.patterns`     — ConflictPattern CRUD
:mod:`muse.core.harmony.resolutions`  — Resolution CRUD and GC
:mod:`muse.core.harmony.audit`        — append-only audit log
:mod:`muse.core.harmony.policies`     — Policy CRUD and matching
:mod:`muse.core.harmony.escalations`  — EscalationRecord CRUD
:mod:`muse.core.harmony.engine`       — three-tier resolution engine

This ``__init__.py`` re-exports the full public API so all existing
``from muse.core.harmony import X`` statements continue to work unchanged.
"""

from __future__ import annotations

from .fingerprint import (
    _now_utc,
    _parse_dt,
    blob_fingerprint,
    compute_pattern_id,
    compute_resolution_id,
    compute_escalation_id,
    compute_semantic_fingerprint,
)
from .patterns import (
    _MAX_PATTERN_BYTES,
    _MAX_SCAN,
    _write_atomic,
    _pattern_to_dict,
    _dict_to_pattern,
    record_pattern,
    load_pattern,
    list_patterns,
    forget_pattern,
    clear_all,
)
from .resolutions import (
    _MAX_RESOLUTION_BYTES,
    _resolution_to_dict,
    _dict_to_resolution,
    save_resolution,
    load_resolution,
    list_resolutions,
    increment_applied_count,
    best_resolution,
    gc_stale,
)
from .audit import (
    _MAX_AUDIT_BYTES,
    _MAX_AUDIT_ENTRIES,
    append_audit,
    list_audit,
)
from .policies import (
    _MAX_POLICY_BYTES,
    _MAX_POLICIES,
    _policy_condition_to_dict,
    _policy_to_dict,
    _dict_to_policy,
    save_policy,
    load_policy,
    list_policies,
    remove_policy,
    _condition_matches,
    match_policy,
)
from .escalations import (
    _MAX_ESCALATION_BYTES,
    _escalation_to_dict,
    _dict_to_escalation,
    record_escalation,
    load_escalation,
    list_escalations,
    resolve_escalation,
)
from .paths import (
    _HARMONY,
    _PATTERNS,
    _POLICIES,
    _AUDIT,
    _ESCALATIONS,
    _RESOLUTIONS,
    _PATTERN_FILE,
    _MAX_FINGERPRINT_BYTES,
    _SHA256_ID_RE,
    _BARE_HEX64_RE,
    _POLICY_ID_RE,
    patterns_dir,
    policies_dir,
    audit_dir,
    escalations_dir,
    escalation_path,
    pattern_dir,
    _pattern_entry_dir,
    _resolutions_dir,
    resolution_path,
    _resolution_path,
    _validate_id,
    _validate_fingerprint,
    _validate_policy_id,
)
from .types import (
    _ConflictDescription,
    _AuditMetadata,
    _ProvenanceDict,
    ConflictType,
    ResolutionStrategy,
    PolicyAction,
    PolicyScope,
    AuditEventType,
    EscalationStatus,
    AgentProvenance,
    PolicyCondition,
    ConflictPattern,
    Resolution,
    Policy,
    ResolutionProposal,
    EscalationRecord,
    _PatternDict,
    _ResolutionDict,
    _PolicyConditionDict,
    _PolicyDict,
    AuditEvent,
    _EscalationDict,
)
from .engine import (
    EngineStatus,
    HarmonyPlugin,
    DefaultPlugin,
    EngineConfig,
    EngineResult,
    find_similar,
    resolve,
    auto_apply,
    record_resolutions,
)
