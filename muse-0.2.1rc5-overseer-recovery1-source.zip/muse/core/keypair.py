"""Ed25519 keypair utilities for Muse CLI authentication.

Keys are derived in memory from the OS keychain mnemonic via SLIP-0010 HD
derivation.  No private key material is ever written to disk.

Public key encoding
--------------------
Public keys are transmitted as URL-safe base64 (no padding) of the raw 32-byte
Ed25519 public key material — identical to the format expected by MuseHub's
``/api/auth/challenge`` and ``/api/auth/verify`` endpoints.

Fingerprint
-----------
``sha256:<64-hex>`` of the raw 32 public key bytes — the canonical prefixed
format used throughout the Muse ecosystem and stored by MuseHub.
"""

import base64
import logging

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    PublicFormat,
)

from muse.core.paths import user_keys_dir as _user_keys_dir

logger = logging.getLogger(__name__)

_KEYS_DIR = _user_keys_dir()

# _KEYS_DIR is exported for use by cleanup-keys and security-check commands.

# ---------------------------------------------------------------------------
# Public key encoding helpers
# ---------------------------------------------------------------------------

def public_key_to_b64url(public_key: Ed25519PublicKey) -> str:
    """Return the canonically prefixed encoding of the raw public key bytes.

    Returns ``"ed25519:<base64url>"`` — the same self-describing format used
    for all cryptographic values in the Muse ecosystem.
    """
    from muse.core.types import encode_pubkey, DEFAULT_SIGN_ALGO
    raw: bytes = public_key.public_bytes(Encoding.Raw, PublicFormat.Raw)
    return encode_pubkey(DEFAULT_SIGN_ALGO, raw)

def public_key_fingerprint(public_key: Ed25519PublicKey) -> str:
    """Return the canonical ``sha256:<64-hex>`` fingerprint of the raw public key bytes."""
    from muse.core.types import public_key_fingerprint as _fp  # noqa: PLC0415
    raw: bytes = public_key.public_bytes(Encoding.Raw, PublicFormat.Raw)
    return _fp(raw)

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def sign_bytes(private_key: Ed25519PrivateKey, data: bytes) -> str:
    """Sign *data* with *private_key* and return a canonically prefixed signature.

    Args:
        private_key: Ed25519 private key.
        data:        Raw bytes to sign (the nonce bytes from the challenge token).

    Returns:
        ``"ed25519:<base64url>"`` of the 64-byte signature — self-describing,
        consistent with all other cryptographic values in the Muse ecosystem.
    """
    from muse.core.types import encode_sig, DEFAULT_SIGN_ALGO
    signature: bytes = private_key.sign(data)
    return encode_sig(DEFAULT_SIGN_ALGO, signature)

def derive_hd_public_info(
    seed: bytes, rotation_index: int = 0, hub: int | None = None
) -> tuple[str, str]:
    """Derive the Ed25519 public key info from *seed* without writing any file.

    Returns ``(public_key_b64url, fingerprint)`` derived via SLIP-0010 HD path.
    The private key never leaves memory — no PEM is written.

    Args:
        seed: 64-byte BIP39 root seed from :func:`muse.core.bip39.mnemonic_to_seed`.
        rotation_index: Key rotation counter (0 = primary key).
        hub: Hub index from :func:`muse.core.hdkeys.hub_index`, or ``None``
            to omit hub scoping (musehub#221). Callers that register this
            key with a specific hub should always pass a real value.
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey as _Ed25519PrivateKey
    from muse.core.hdkeys import derive_identity_key

    dk = derive_identity_key(seed, index=rotation_index, hub=hub)
    try:
        private_key = _Ed25519PrivateKey.from_private_bytes(dk.private_bytes)
    finally:
        dk.zero()
    public_key = private_key.public_key()
    return public_key_to_b64url(public_key), public_key_fingerprint(public_key)

