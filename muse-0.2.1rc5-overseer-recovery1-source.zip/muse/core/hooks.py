"""Muse hooks — ``.musehooks.toml`` parser and validator.

``.musehooks.toml`` lives in the repository root (next to ``.museignore``,
``.museattributes``, and ``.museagent.md``) and declares commands to run at
specific commit-lifecycle points. Unlike ``.muse/hooks/`` (which would live
inside the object-store directory and therefore could never be committed,
pushed, or survive a clone — ``.muse/`` is unconditionally excluded from
every snapshot, see :mod:`muse.core.paths`), ``.musehooks.toml`` is an
ordinary tracked file: it is shared automatically via clone/push/pull.

Hooks declared here are **never executed automatically**. A human or agent
must explicitly run ``muse hooks install`` in a given clone to activate them
locally (musehub#192 Phase 2) — this mirrors git's own precedent of never
auto-running code from a freshly cloned repository, and keeps a malicious or
compromised repo from gaining code execution merely by being cloned.

MVP scope (musehub#192): exactly one hook point, ``pre-commit``, and a
declarative list of shell commands — no arbitrary hook scripts, no hashbang
files. Each command's exit code determines pass/fail when ``muse commit``
runs installed hooks (Phase 3).

Format
------

.. code-block:: toml

    # .musehooks.toml
    [pre-commit]
    commands = [
        "muse agent-config status --fail-if-out-of-sync",
    ]

Local activation (musehub#192 Phase 2)
---------------------------------------

Whether *this specific clone* runs the declared hooks is tracked in
``.muse/hooks-installed.toml`` — deliberately local-only, unlike
``.musehooks.toml`` itself. This is the one place ``.muse/`` is the
*correct* home for state: installed-or-not must never propagate via
clone/push/pull, or a cloned repo would gain silent code execution the
moment someone ran ``muse commit`` — the same class of risk git avoids by
never auto-installing hooks from a fresh clone.

Public API
----------

- :class:`HooksFile` — parsed representation of ``.musehooks.toml``.
- :class:`HooksStatus` — combined view of declared hooks + local install state.
- :data:`VALID_HOOK_POINTS` — the set of recognised ``[<hook-point>]`` section names.
- :func:`load_hooks` — read ``.musehooks.toml`` from a repo root.
- :func:`install_hooks` — activate declared hooks for this clone.
- :func:`uninstall_hooks` — deactivate hooks for this clone.
- :func:`is_installed` — whether this clone has hooks installed.
- :func:`get_status` — the three-state summary: ``not_defined``,
  ``defined_not_installed``, or ``installed``.
"""

import subprocess
import tomllib
from dataclasses import dataclass, field

from muse.core.paths import hooks_installed_toml_path

_FILENAME = ".musehooks.toml"

# MVP is deliberately scoped to pre-commit only — see musehub#192 "Out of Scope".
VALID_HOOK_POINTS: frozenset[str] = frozenset({"pre-commit"})

# 1 MiB cap — prevents OOM from a crafted or corrupted .musehooks.toml,
# matching the precedent set by .museattributes (muse/core/attributes.py).
_MAX_HOOKS_BYTES: int = 1 * 1024 * 1024


@dataclass(frozen=True)
class HooksFile:
    """Parsed representation of ``.musehooks.toml``.

    Attributes:
        hooks: Mapping of hook point name (e.g. ``"pre-commit"``) to its
            ordered list of shell commands. A hook point with no
            ``commands`` key, or an empty ``commands = []``, maps to an
            empty list — both are valid, meaning "hook point declared but
            nothing to run yet."
    """

    hooks: dict[str, list[str]] = field(default_factory=dict)


def load_hooks(root) -> HooksFile:  # noqa: ANN001 - accepts pathlib.Path
    """Parse ``.musehooks.toml`` from *root* and return a :class:`HooksFile`.

    A missing file is not an error — it means no hooks are defined, and
    returns an empty :class:`HooksFile`. This matches
    :func:`muse.core.attributes.load_attributes`'s precedent: absence is a
    valid, common state, not a failure.

    Args:
        root: Repository root directory (``pathlib.Path``).

    Returns:
        The parsed :class:`HooksFile`. Empty (``hooks={}``) when the file is
        absent, empty, or contains only comments.

    Raises:
        ValueError: If the file exceeds the 1 MiB size cap, contains invalid
            TOML syntax, declares an unknown hook point, or a hook point's
            ``commands`` value is not a list of strings.
    """
    hooks_file = root / _FILENAME
    if not hooks_file.exists():
        return HooksFile(hooks={})

    raw_bytes = hooks_file.read_bytes()
    if len(raw_bytes) > _MAX_HOOKS_BYTES:
        raise ValueError(
            f"{_FILENAME}: file too large ({len(raw_bytes):,} bytes > "
            f"{_MAX_HOOKS_BYTES:,} byte limit)"
        )

    try:
        raw = tomllib.loads(raw_bytes.decode("utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise ValueError(f"{_FILENAME}: TOML parse error — {exc}") from exc

    hooks: dict[str, list[str]] = {}
    for section_name, section_value in raw.items():
        if section_name not in VALID_HOOK_POINTS:
            raise ValueError(
                f"{_FILENAME}: unknown hook point [{section_name}]. "
                f"Valid hook points: {sorted(VALID_HOOK_POINTS)}"
            )
        if not isinstance(section_value, dict):
            raise ValueError(
                f"{_FILENAME}: [{section_name}] must be a table"
            )

        commands_raw = section_value.get("commands", [])
        if not isinstance(commands_raw, list):
            raise ValueError(
                f"{_FILENAME}: [{section_name}].commands must be a list of strings"
            )
        commands: list[str] = []
        for idx, cmd in enumerate(commands_raw):
            if not isinstance(cmd, str):
                raise ValueError(
                    f"{_FILENAME}: [{section_name}].commands[{idx}] must be "
                    f"a string, got {type(cmd).__name__}"
                )
            commands.append(cmd)
        hooks[section_name] = commands

    return HooksFile(hooks=hooks)


@dataclass(frozen=True)
class HooksStatus:
    """Combined view of declared hooks and this clone's local install state.

    Attributes:
        state: One of ``"not_defined"`` (the tracked file is absent, empty,
            or contains no ``[<hook-point>]`` sections at all),
            ``"defined_not_installed"`` (at least one hook point section is
            declared — even with an empty ``commands`` list — but this
            clone hasn't run :func:`install_hooks`), or ``"installed"``
            (declared and activated for this clone). ``"not_defined"``
            always wins even if a stale local install marker is present —
            there's nothing left to run.
        hooks_file: The parsed :class:`HooksFile`.
    """

    state: str
    hooks_file: HooksFile


def install_hooks(root) -> None:  # noqa: ANN001 - accepts pathlib.Path
    """Activate declared hooks for *this clone* by writing a local marker.

    Idempotent — calling this when already installed is a no-op, not an
    error. Does not require ``.musehooks.toml`` to exist or declare any
    commands yet; installing ahead of the file being added is valid; it
    simply means nothing runs until commands are declared.
    """
    marker = hooks_installed_toml_path(root)
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text("installed = true\n", encoding="utf-8")


def uninstall_hooks(root) -> None:  # noqa: ANN001 - accepts pathlib.Path
    """Deactivate hooks for *this clone* by removing the local marker.

    Idempotent — calling this when never installed (or already uninstalled)
    is a no-op, not an error.
    """
    marker = hooks_installed_toml_path(root)
    marker.unlink(missing_ok=True)


def is_installed(root) -> bool:  # noqa: ANN001 - accepts pathlib.Path
    """Return whether this clone has hooks installed (the local marker exists)."""
    return hooks_installed_toml_path(root).exists()


def get_status(root) -> HooksStatus:  # noqa: ANN001 - accepts pathlib.Path
    """Return the combined declared-hooks + local-install-state summary.

    Raises:
        ValueError: Propagated from :func:`load_hooks` if ``.musehooks.toml``
            is malformed.
    """
    hooks_file = load_hooks(root)

    if not hooks_file.hooks:
        state = "not_defined"
    elif is_installed(root):
        state = "installed"
    else:
        state = "defined_not_installed"

    return HooksStatus(state=state, hooks_file=hooks_file)


@dataclass(frozen=True)
class HookRunResult:
    """Outcome of running one hook point's commands for this clone.

    Attributes:
        executed: ``False`` when hooks aren't installed for this clone, or
            no commands are declared for the given hook point — nothing was
            run. ``True`` when at least the first command was attempted.
        passed: ``True`` when every executed command exited 0 (or nothing
            was executed at all). ``False`` on the first non-zero exit.
        failed_command: The exact command string that failed, or ``None``
            when ``passed`` is ``True``.
        output: Combined stdout+stderr of the failed command. Empty when
            ``passed`` is ``True``.
    """

    executed: bool
    passed: bool
    failed_command: str | None = None
    output: str = ""


def run_hook_point(root, hook_point: str) -> HookRunResult:  # noqa: ANN001
    """Run *hook_point*'s declared commands for this clone, in order.

    A no-op (``executed=False, passed=True``) when this clone doesn't have
    hooks installed, or when no commands are declared for *hook_point* —
    callers never need to check :func:`is_installed` separately first.

    Commands run via the shell (``cwd=root``), stopping at the first
    non-zero exit. Subsequent commands never run once one fails, matching
    the fail-fast expectation of a pre-commit gate.

    Args:
        root: Repository root directory.
        hook_point: One of :data:`VALID_HOOK_POINTS`.

    Returns:
        A :class:`HookRunResult` describing what happened.

    Raises:
        ValueError: Propagated from :func:`load_hooks` if ``.musehooks.toml``
            is malformed.
    """
    if not is_installed(root):
        return HookRunResult(executed=False, passed=True)

    hooks_file = load_hooks(root)
    commands = hooks_file.hooks.get(hook_point, [])

    for cmd in commands:
        proc = subprocess.run(
            cmd,
            shell=True,
            cwd=root,
            capture_output=True,
            text=True,
        )
        if proc.returncode != 0:
            combined = (proc.stdout or "") + (proc.stderr or "")
            return HookRunResult(
                executed=True,
                passed=False,
                failed_command=cmd,
                output=combined,
            )

    return HookRunResult(executed=bool(commands), passed=True)


def install_notice(root) -> str | None:  # noqa: ANN001 - accepts pathlib.Path
    """Return a one-line nudge when hooks are declared but not installed here.

    Used at two discoverability points (musehub#192 Phase 4): right after
    ``muse clone`` finishes (the moment a repo's ``.musehooks.toml`` first
    becomes visible to a new clone) and from ``muse status`` (for clones
    that predate this feature, or where install was skipped). Returns
    ``None`` for every other state (``not_defined`` or ``installed``) —
    callers should simply skip printing anything in that case.
    """
    try:
        status = get_status(root)
    except ValueError:
        # Malformed .musehooks.toml is surfaced by `muse hooks status`/
        # `muse hooks list` directly — this nudge is best-effort only.
        return None
    if status.state != "defined_not_installed":
        return None
    return (
        "This repo defines pre-commit hooks — run 'muse hooks install' "
        "to enable them."
    )
