"""Secure credential storage via OS keychain.

BIP39 mnemonics are stored here — never in plaintext TOML files.

One mnemonic per machine. The same BIP39 mnemonic is the root of all identity
keys across every hub (localhost, staging, prod). Cross-hub replay is prevented
by the host field in the MSign canonical message — not by separate mnemonics.

The module wraps the ``keyring`` library, which selects the best available
backend automatically:

  macOS        → Keychain Services (Secure Enclave on Apple Silicon)
  Linux        → SecretService (GNOME Keyring / KWallet)
  Headless     → ``keyrings.alt`` encrypted file (AES + PBKDF2)

Test / CI isolation
-------------------
Set ``MUSE_KEYCHAIN_BACKEND=disabled`` to bypass the keychain entirely.
Under this setting all operations are no-ops and :func:`is_available`
returns ``False``.  Callers must handle mnemonic absence gracefully (the
mnemonic is ephemeral for the lifetime of the process).

Key format
----------
::

    service  = "muse"
    username = "mnemonic"   (single global entry — not per-hub)

Legacy migration
----------------
Older versions stored the mnemonic per-hub as ``"{hostname}/mnemonic"``.
:func:`load` transparently promotes any such legacy entry to the global
``"mnemonic"`` slot on first access and deletes the stale per-hub entry.

Public API
----------
::

    is_available() -> bool
    store(mnemonic) -> bool
    load() -> str | None
    delete() -> bool
"""

import logging
import os
import types

logger = logging.getLogger(__name__)

_SERVICE = "muse"
_USERNAME = "mnemonic"

def is_available() -> bool:
    """Return ``True`` when a functional keychain backend is active.

    Returns ``False`` when:
    - ``MUSE_KEYCHAIN_BACKEND=disabled`` is set (test/CI mode), or
    - no keychain backend with priority > 0 is found, or
    - the ``keyring`` library is not installed.

    Returns:
        ``True`` if credentials can be stored and retrieved.
    """
    if os.environ.get("MUSE_KEYCHAIN_BACKEND") == "disabled":
        return False
    try:
        import keyring
        backend = keyring.get_keyring()
        return getattr(backend, "priority", 0) > 0
    except Exception:
        return False

def store(mnemonic: str) -> bool:
    """Store *mnemonic* in the OS keychain as the global machine identity.

    Args:
        mnemonic: BIP39 mnemonic phrase to store.

    Returns:
        ``True`` on success, ``False`` if the keychain is unavailable or
        the store operation fails.
    """
    if not is_available():
        return False
    try:
        import keyring
        keyring.set_password(_SERVICE, _USERNAME, mnemonic)
        logger.debug("✅ Mnemonic stored in keychain")
        return True
    except Exception as exc:
        logger.warning("⚠️ Could not store mnemonic in keychain: %s", exc)
        return False

def load() -> str | None:
    """Load the global mnemonic from the OS keychain.

    Transparently migrates legacy per-hub entries (``"{hostname}/mnemonic"``)
    to the global ``"mnemonic"`` slot on first call.

    Returns:
        The mnemonic phrase, or ``None`` if not found or keychain unavailable.
    """
    if not is_available():
        return None
    try:
        import keyring
        import keyring.errors

        mnemonic = keyring.get_password(_SERVICE, _USERNAME)
        if mnemonic is not None:
            return mnemonic

        # Legacy migration: scan for per-hub "{hostname}/mnemonic" entries.
        # We can't enumerate all keychain entries via the keyring API, so we
        # rely on callers to tell us which legacy hostnames to look for via
        # the identity file. Fall back to the known common names if identity
        # is unavailable.
        mnemonic = _migrate_legacy_entry(keyring)
        return mnemonic

    except Exception as exc:
        logger.warning("⚠️ Could not load mnemonic from keychain: %s", exc)
        return None

def _migrate_legacy_entry(keyring_mod: types.ModuleType) -> str | None:
    """Promote a legacy per-hub mnemonic entry to the global slot.

    Scans hostnames recorded in ``~/.muse/identity.toml`` for legacy entries
    of the form ``"{hostname}/mnemonic"`` in the keychain. The first one found
    is promoted to ``"mnemonic"`` and all per-hub entries are deleted.

    Returns the migrated mnemonic, or ``None`` if none found.
    """
    import keyring as kr
    import keyring.errors

    # Collect candidate hostnames from identity.toml (best-effort).
    hostnames: list[str] = []
    try:
        from muse.core.identity import list_all_identities
        for key in list_all_identities():
            # Keys are bare hostnames or "hostname#agent_id"
            hostname = key.split("#")[0]
            if hostname and hostname not in hostnames:
                hostnames.append(hostname)
    except Exception:
        pass

    migrated: str | None = None
    legacy_keys_found: list[str] = []

    for hostname in hostnames:
        legacy_username = f"{hostname}/mnemonic"
        value = kr.get_password(_SERVICE, legacy_username)
        if value is not None:
            legacy_keys_found.append(legacy_username)
            if migrated is None:
                migrated = value

    if migrated is None:
        return None

    # Write the global entry.
    try:
        kr.set_password(_SERVICE, _USERNAME, migrated)
        logger.info("✅ Mnemonic migrated from per-hub keychain entry to global slot")
    except Exception as exc:
        logger.warning("⚠️ Could not write global mnemonic during migration: %s", exc)
        return migrated  # still return the value even if we couldn't promote it

    # Delete all legacy per-hub entries.
    for legacy_username in legacy_keys_found:
        try:
            kr.delete_password(_SERVICE, legacy_username)
        except Exception:
            pass

    return migrated

def delete() -> bool:
    """Delete the global mnemonic from the OS keychain.

    Returns:
        ``True`` if the entry was deleted, ``False`` if it was not found or
        the keychain is unavailable.
    """
    if not is_available():
        return False
    try:
        import keyring
        import keyring.errors
        keyring.delete_password(_SERVICE, _USERNAME)
        logger.debug("✅ Mnemonic deleted from keychain")
        return True
    except Exception as exc:
        logger.debug("keychain delete: %s", exc)
        return False
