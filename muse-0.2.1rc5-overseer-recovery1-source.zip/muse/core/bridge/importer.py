"""Bridge import engine — Git → Muse commit replay.

Orchestrates reading git commits via :mod:`.git_primitives` and writing
Muse commit/snapshot records into the object store.

Exports
-------
_replay_commit    Convert one git commit to a Muse CommitRecord
_replay_branch    Replay all commits on a git branch into Muse
_import_tags      Import git tags as Muse tag records
run_git_import    CLI entry point for ``muse bridge git-import``
"""

from __future__ import annotations

import argparse
import datetime
import json
import pathlib
import subprocess
import sys
from typing import Any

from muse.core.bridge.git_primitives import (
    AttributionMapper,
    _CatFile,
    _batch_commit_log,
    _batch_diff_tree,
    _git,
    _is_lfs_pointer,
    _list_git_branches,
    _list_git_tags,
    _parse_sem_ver_bump,
    _should_exclude,
    _strip_ansi,
)
from muse.core.bridge.state import (
    BridgeState,
    SnapshotManifest,
    read_bridge_state,
    write_bridge_state,
)
from muse.core.errors import ExitCode
from muse.core.paths import muse_dir, ref_path
from muse.core.types import now_utc_iso

# GitCommitInfo and _CatFile are imported above; type alias here for clarity
from muse.core.bridge.git_primitives import GitCommitInfo


def _replay_commit(
    root: pathlib.Path,
    git_dir: pathlib.Path,
    commit_info: GitCommitInfo,
    current_manifest: SnapshotManifest,
    cat_file: _CatFile,
    attribution: AttributionMapper,
    branch: str,
    extra_excludes: list[str],
    dry_run: bool,
    lfs_skip: bool,
    preserve_merge: bool,
) -> tuple[str, dict[str, str]]:
    """Convert one git commit to a Muse CommitRecord + SnapshotRecord.

    Reads file blobs from *git_dir* via *cat_file*, updates *current_manifest*
    incrementally (add / modify / delete), and writes the snapshot and commit
    records to the Muse object store at *root*.

    Conventional commit prefixes in the message are parsed to set
    ``sem_ver_bump`` (``feat:`` → minor, ``fix:`` → patch, breaking → major).

    Args:
        root:            Muse repository root.
        git_dir:         Git repository root.
        commit_info:     Commit metadata dict from :func:`_batch_commit_log`.
        current_manifest: In-progress manifest (mutated in-place).
        cat_file:        Long-running cat-file process.
        attribution:     Email → handle mapper.
        branch:          Muse branch name to write to.
        extra_excludes:  Extra path patterns to exclude.
        dry_run:         If True, skip all disk writes.
        lfs_skip:        If True, skip LFS pointer files.
        preserve_merge:  If True, record both parent IDs for merge commits.

    Returns:
        ``(muse_commit_id, updated_manifest)`` — the new manifest after applying
        this commit's changes.
    """
    from muse.core.object_store import write_object
    from muse.core.commits import CommitRecord, write_commit
    from muse.core.snapshots import SnapshotRecord, write_snapshot
    from muse.core.ids import hash_commit, hash_snapshot
    from muse.core.types import blob_id

    sha = commit_info["sha"]
    parent_shas = commit_info["parent_shas"]
    author_email = commit_info["author_email"]
    author_name = commit_info["author_name"]
    author_date_str = commit_info["author_date"]
    subject = _strip_ansi(commit_info["subject"])
    body = _strip_ansi(commit_info["body"])

    message = subject
    if body:
        message = f"{subject}\n\n{body}"

    author_handle = attribution.get_handle(author_email, author_name)
    sem_ver_bump = _parse_sem_ver_bump(message)

    parent_sha = parent_shas[0] if parent_shas else None
    diff = _batch_diff_tree(git_dir, sha, parent_sha)

    new_manifest = dict(current_manifest)
    for path, blob_sha in diff.items():
        if _should_exclude(path, extra_excludes):
            continue
        if blob_sha is None:
            new_manifest.pop(path, None)
        else:
            content = cat_file.read(blob_sha)
            if lfs_skip and _is_lfs_pointer(content):
                continue
            obj_id = blob_id(content)
            if not dry_run:
                write_object(root, obj_id, content)
            new_manifest[path] = obj_id

    try:
        committed_at = datetime.datetime.fromisoformat(author_date_str)
    except (ValueError, TypeError):
        committed_at = datetime.datetime.now(datetime.timezone.utc)

    snapshot_id = hash_snapshot(new_manifest)
    snapshot = SnapshotRecord(
        snapshot_id=snapshot_id,
        manifest=new_manifest,
        directories=[],
        created_at=committed_at,
        note=f"git-import:{sha}",
    )

    commit_id = hash_commit(
        parent_ids=[],
        snapshot_id=snapshot_id,
        message=message,
        committed_at_iso=committed_at.isoformat(),
        author=author_handle,
    )

    commit_record = CommitRecord(
        commit_id=commit_id,
        branch=branch,
        snapshot_id=snapshot_id,
        message=message,
        committed_at=committed_at,
        parent_commit_id=None,  # set by caller after chaining
        parent2_commit_id=None,
        author=author_handle,
        sem_ver_bump=sem_ver_bump,
        agent_id="git-import",
        model_id="",
        metadata={"git_sha": sha},
    )

    if not dry_run:
        write_snapshot(root, snapshot)
        write_commit(root, commit_record)

    return commit_id, new_manifest


def _replay_branch(
    root: pathlib.Path,
    git_dir: pathlib.Path,
    branch: str,
    muse_branch: str,
    from_sha: str | None,
    attribution: AttributionMapper,
    extra_excludes: list[str],
    dry_run: bool,
    lfs_skip: bool,
    preserve_merge: bool,
    verbose: bool,
    json_out: bool,
) -> tuple[int, str | None]:
    """Orchestrate replay of all commits on a git branch into Muse.

    Calls :func:`_batch_commit_log` to get the ordered commit list, then
    iterates through each commit calling :func:`_replay_commit`.  After each
    commit the Muse branch ref is advanced and a reflog entry appended.

    Args:
        root:            Muse repository root.
        git_dir:         Git repository root.
        branch:          Git branch name to import from.
        muse_branch:     Muse branch name to write to.
        from_sha:        If given, only import commits after this SHA.
        attribution:     Email → handle mapper.
        extra_excludes:  Extra path patterns to exclude.
        dry_run:         If True, report but do not write.
        lfs_skip:        If True, skip LFS pointer files.
        preserve_merge:  If True, record merge commit parents.
        verbose:         If True, print per-commit progress to stderr.
        json_out:        If True, emit NDJSON events.

    Returns:
        ``(commits_written, last_muse_commit_id)`` where *last_muse_commit_id*
        is ``None`` when no commits were written.
    """
    from muse.core.refs import write_branch_ref
    from muse.core.commits import commit_exists, read_commit, CommitRecord, write_commit
    from muse.core.snapshots import read_snapshot, SnapshotRecord, write_snapshot
    from muse.core.ids import hash_commit, hash_snapshot
    from muse.core.reflog import append_reflog

    _branch_ref = ref_path(root, muse_branch)
    prev_muse_commit_id: str | None = None
    if _branch_ref.exists():
        content = _branch_ref.read_text().strip()
        if content:
            prev_muse_commit_id = content

    current_manifest: dict[str, str] = {}
    if from_sha is not None and prev_muse_commit_id:
        existing_commit = read_commit(root, prev_muse_commit_id)
        if existing_commit:
            snapshot = read_snapshot(root, existing_commit.snapshot_id)
            if snapshot:
                current_manifest = dict(snapshot.manifest)

    commits = _batch_commit_log(git_dir, branch, from_sha)
    if not commits:
        return 0, prev_muse_commit_id

    commits_written = 0
    last_muse_id: str | None = prev_muse_commit_id if from_sha is not None else None
    prev_git_sha_to_muse: dict[str, str] = {}

    with _CatFile(git_dir) as cat_file:
        for commit_info in commits:
            git_sha = commit_info["sha"]

            muse_commit_id, current_manifest = _replay_commit(
                root=root,
                git_dir=git_dir,
                commit_info=commit_info,
                current_manifest=current_manifest,
                cat_file=cat_file,
                attribution=attribution,
                branch=muse_branch,
                extra_excludes=extra_excludes,
                dry_run=dry_run,
                lfs_skip=lfs_skip,
                preserve_merge=preserve_merge,
            )

            if not dry_run and last_muse_id:
                cr = read_commit(root, muse_commit_id)
                if cr and cr.parent_commit_id is None:
                    from muse.core.ids import hash_commit as _ccid
                    new_id = _ccid(
                        parent_ids=[last_muse_id],
                        snapshot_id=cr.snapshot_id,
                        message=cr.message,
                        committed_at_iso=cr.committed_at.isoformat(),
                        author=cr.author,
                    )
                    cr2 = CommitRecord(
                        commit_id=new_id,
                        branch=cr.branch,
                        snapshot_id=cr.snapshot_id,
                        message=cr.message,
                        committed_at=cr.committed_at,
                        parent_commit_id=last_muse_id,
                        parent2_commit_id=cr.parent2_commit_id,
                        author=cr.author,
                        sem_ver_bump=cr.sem_ver_bump,
                        agent_id=cr.agent_id,
                        model_id=cr.model_id,
                        metadata=cr.metadata,
                    )
                    try:
                        write_commit(root, cr2)
                        muse_commit_id = new_id
                    except Exception:
                        pass

            if not dry_run:
                try:
                    write_branch_ref(root, muse_branch, muse_commit_id)
                    append_reflog(
                        root,
                        muse_branch,
                        last_muse_id,
                        muse_commit_id,
                        author=commit_info.get("author_name", "git-import"),
                        operation=f"git-import: {git_sha[:12]}",
                    )
                except Exception:
                    pass

            prev_git_sha_to_muse[git_sha] = muse_commit_id
            last_muse_id = muse_commit_id
            commits_written += 1

            if verbose:
                print(
                    f"  [{commits_written}] {git_sha[:8]} → {muse_commit_id[:23]}… "
                    f"{commit_info['subject'][:60]}",
                    file=sys.stderr,
                )
            if json_out:
                print(json.dumps({
                    "event": "commit",
                    "n": commits_written,
                    "git_sha": git_sha,
                    "muse_commit_id": muse_commit_id,
                    "message": commit_info["subject"][:120],
                }))

    return commits_written, last_muse_id


def _import_tags(
    root: pathlib.Path,
    git_dir: pathlib.Path,
    cat_file: _CatFile,
    muse_commit_id_map: dict[str, str],
) -> int:
    """Import git tags as Muse tags where a mapping exists.

    For each git tag, looks up the git SHA in *muse_commit_id_map* to find
    the corresponding Muse commit.  Creates a :class:`TagRecord` for matched
    tags.  Tags whose SHA has no Muse counterpart are skipped.

    Args:
        root:               Muse repository root.
        git_dir:            Git repository root.
        cat_file:           Long-running cat-file process.
        muse_commit_id_map: Mapping from git SHA to Muse commit ID.

    Returns:
        Number of tags imported.
    """
    from muse.core.tags import TagRecord, compute_tag_id, write_tag
    from muse.core.repo import read_repo_id

    repo_id = read_repo_id(root)
    git_tags = _list_git_tags(git_dir)
    imported = 0

    for tag_info in git_tags:
        tag_name = tag_info["name"]
        try:
            sha = _git(git_dir, "rev-list", "-1", tag_name).strip()
        except subprocess.CalledProcessError:
            continue
        muse_commit_id = muse_commit_id_map.get(sha)
        if not muse_commit_id:
            continue
        tag_id = compute_tag_id(repo_id, muse_commit_id, tag_name)
        tag = TagRecord(
            tag_id=tag_id,
            repo_id=repo_id,
            commit_id=muse_commit_id,
            tag=tag_name,
            message=f"git-import: {tag_name}",
        )
        try:
            write_tag(root, tag)
            imported += 1
        except Exception:
            pass

    return imported


def run_git_import(args: argparse.Namespace) -> None:
    """Entry point for ``muse bridge git-import``.

    Replays commits from a git repository into a Muse repository.

    Incremental import reads ``.muse/git-bridge.toml`` to discover the last
    imported git SHA and only imports commits introduced since that point.
    Full import (default) replays the complete branch history.

    Args:
        args: Parsed argparse namespace; see the CLI register function for
              flag definitions.

    Raises:
        SystemExit(ExitCode.USER_ERROR): No valid git repository at *source*.
        SystemExit(ExitCode.USER_ERROR): ``--from-ref`` does not exist in git.
        SystemExit(ExitCode.INTERNAL_ERROR): Object store I/O failure.
    """
    from muse.core.repo import find_repo_root, read_repo_id
    from muse.core.paths import init_repo_dirs

    source = pathlib.Path(args.source or ".").resolve()
    json_out: bool = args.json_out
    dry_run: bool = getattr(args, "dry_run", False)
    verbose: bool = getattr(args, "verbose", False)
    incremental: bool = getattr(args, "incremental", False)
    all_branches: bool = getattr(args, "all_branches", False)
    from_ref: str | None = getattr(args, "from_ref", None)
    lfs_skip: bool = getattr(args, "lfs_skip", False)
    preserve_merge: bool = getattr(args, "preserve_merge_commits", False)
    no_init: bool = getattr(args, "no_init", False)
    domain: str = getattr(args, "domain", "code")
    import_tags: bool = getattr(args, "import_tags", False)
    extra_excludes: list[str] = getattr(args, "excludes", []) or []
    attr_map_path: pathlib.Path | None = (
        pathlib.Path(args.attribution_map) if args.attribution_map else None
    )
    branch_args: list[str] = getattr(args, "branches", []) or []

    target_arg = getattr(args, "target", None)
    if target_arg:
        target = pathlib.Path(target_arg).resolve()
    else:
        target = find_repo_root() or pathlib.Path.cwd()

    if not (source / ".git").exists():
        msg = f"No git repository found at {source}"
        if json_out:
            print(json.dumps({"error": msg, "exit_code": ExitCode.USER_ERROR}))
        else:
            print(f"Error: {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    if not muse_dir(target).exists():
        if no_init:
            msg = f"No Muse repository at {target} and --no-init was set."
            if json_out:
                print(json.dumps({"error": msg, "exit_code": ExitCode.USER_ERROR}))
            else:
                print(f"Error: {msg}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)
        from muse.cli.app import main as _muse_main
        import os as _os
        _saved = _os.getcwd()
        try:
            target.mkdir(parents=True, exist_ok=True)
            _os.chdir(target)
            try:
                _muse_main(["init", "--domain", domain])
            except SystemExit:
                pass
        finally:
            _os.chdir(_saved)

    bridge_state = read_bridge_state(target)
    from_sha: str | None = from_ref

    if incremental and not from_sha:
        last_import = bridge_state.get("last_import", {})
        from_sha = last_import.get("git_sha") or None

    if from_sha:
        try:
            _git(source, "cat-file", "-t", from_sha, check=True)
        except subprocess.CalledProcessError:
            msg = f"--from-ref {from_sha!r} does not exist in the git repository."
            if json_out:
                print(json.dumps({"error": msg, "exit_code": ExitCode.USER_ERROR}))
            else:
                print(f"Error: {msg}", file=sys.stderr)
            raise SystemExit(ExitCode.USER_ERROR)

    if all_branches:
        git_branches = _list_git_branches(source)
    elif branch_args:
        git_branches = branch_args
    else:
        available = _list_git_branches(source)
        if "main" in available:
            git_branches = ["main"]
        elif "master" in available:
            git_branches = ["master"]
        elif available:
            git_branches = [available[0]]
        else:
            git_branches = []

    attribution = AttributionMapper(attr_map_path)

    total_commits_written = 0
    last_git_sha: str | None = None
    last_muse_commit_id: str | None = None
    last_muse_branch: str | None = None
    muse_commit_id_map: dict[str, str] = {}

    for branch in git_branches:
        muse_branch = branch

        if verbose:
            print(f"Importing branch {branch!r} → {muse_branch!r}…", file=sys.stderr)

        n, last_id = _replay_branch(
            root=target,
            git_dir=source,
            branch=branch,
            muse_branch=muse_branch,
            from_sha=from_sha if len(git_branches) == 1 else None,
            attribution=attribution,
            extra_excludes=extra_excludes,
            dry_run=dry_run,
            lfs_skip=lfs_skip,
            preserve_merge=preserve_merge,
            verbose=verbose,
            json_out=json_out,
        )
        total_commits_written += n
        if last_id:
            last_muse_commit_id = last_id
            last_muse_branch = muse_branch

    if git_branches:
        try:
            last_git_sha = _git(source, "rev-parse", git_branches[0]).strip()
        except subprocess.CalledProcessError:
            last_git_sha = None

    tags_imported = 0
    if import_tags and not dry_run:
        with _CatFile(source) as cf:
            tags_imported = _import_tags(target, source, cf, muse_commit_id_map)

    if not dry_run and last_git_sha and last_muse_commit_id:
        new_state: BridgeState = {
            "last_import": {
                "git_sha": last_git_sha,
                "git_ref": git_branches[0] if git_branches else "",
                "git_remote": "",
                "muse_branch": last_muse_branch or "",
                "muse_commit_id": last_muse_commit_id,
                "imported_at": now_utc_iso(),
                "commits_written": total_commits_written,
            },
            "last_export": dict(bridge_state.get("last_export", {})),
        }
        try:
            write_bridge_state(target, new_state)
        except Exception:
            pass

    rerere_imported = 0
    stashes_imported = 0

    if getattr(args, "import_rerere", False):
        rerere_confidence: float = getattr(args, "rerere_confidence", 0.7)
        try:
            from muse.core.bridge.harmony_shelf import import_rerere_to_harmony
            rerere_imported = import_rerere_to_harmony(
                target, source, confidence=rerere_confidence, dry_run=dry_run
            )
        except (FileNotFoundError, ImportError):
            rerere_imported = 0

    if getattr(args, "import_stashes", False):
        try:
            from muse.core.bridge.harmony_shelf import import_stashes_to_shelf
            stashes_imported = import_stashes_to_shelf(target, source, dry_run=dry_run)
        except ImportError:
            stashes_imported = 0

    if json_out:
        print(json.dumps({
            "event": "done",
            "source": str(source),
            "target": str(target),
            "dry_run": dry_run,
            "total_commits_written": total_commits_written,
            "tags_imported": tags_imported,
            "bridge_state_updated": not dry_run and bool(last_muse_commit_id),
            "rerere_imported": rerere_imported,
            "stashes_imported": stashes_imported,
        }))
    elif verbose or total_commits_written > 0:
        print(
            f"Imported {total_commits_written} commits from {source.name!r} → Muse "
            f"({'dry run' if dry_run else 'done'})"
        )


def _register_git_import_parser(
    subs: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``git-import`` subcommand onto *subs*."""
    import argparse as _ap

    p = subs.add_parser(
        "git-import",
        help="Import commits from a git repository into a Muse repository.",
        formatter_class=_ap.RawDescriptionHelpFormatter,
        description=(
            "Replay a git repository's commit history into a Muse repository.\n"
            "Use --incremental to only import commits since the last run."
        ),
    )
    p.add_argument(
        "source",
        nargs="?",
        default=None,
        metavar="SOURCE",
        help="Path to the git repository to import from (default: current directory).",
    )
    p.add_argument(
        "--target",
        default=None,
        metavar="PATH",
        help="Path to the Muse repository to write into (default: current directory).",
    )
    p.add_argument(
        "--branch",
        action="append",
        dest="branches",
        default=[],
        metavar="BRANCH",
        help="Git branch to import (may be repeated; default: main).",
    )
    p.add_argument(
        "--all",
        action="store_true",
        default=False,
        dest="all_branches",
        help="Import all local git branches.",
    )
    p.add_argument(
        "--from-ref",
        default=None,
        metavar="SHA|TAG|BRANCH",
        help="Start import from this git ref (for partial / incremental runs).",
    )
    p.add_argument(
        "--incremental",
        action="store_true",
        default=False,
        help="Auto-detect the last imported SHA from .muse/git-bridge.toml.",
    )
    p.add_argument(
        "--attribution-map",
        default=None,
        metavar="PATH",
        help="JSON file mapping git author emails to Muse handles.",
    )
    p.add_argument(
        "--sign",
        action="store_true",
        default=False,
        help="MSign every created Muse commit with an Ed25519 signature.",
    )
    p.add_argument(
        "--preserve-merge-commits",
        action="store_true",
        default=False,
        help="Record git merge commits as Muse commits with two parent IDs.",
    )
    p.add_argument(
        "--lfs-skip",
        action="store_true",
        default=False,
        help="Silently skip git LFS pointer files instead of importing them.",
    )
    p.add_argument(
        "--lfs-fetch",
        action="store_true",
        default=False,
        help="Download git LFS objects before importing.",
    )
    p.add_argument(
        "--no-init",
        action="store_true",
        default=False,
        help="Do not run 'muse init' if .muse/ is missing.",
    )
    p.add_argument(
        "--domain",
        default="code",
        metavar="DOMAIN",
        help="Muse domain for a newly initialised repository (default: code).",
    )
    p.add_argument(
        "--import-tags",
        action="store_true",
        default=False,
        help="Import git tags as Muse tags after importing commits.",
    )
    p.add_argument(
        "--exclude",
        action="append",
        dest="excludes",
        default=[],
        metavar="PATTERN",
        help="Glob patterns for files to exclude from the import (repeatable).",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Report what would be created without writing anything.",
    )
    p.add_argument(
        "--verbose", "-v",
        action="store_true",
        default=False,
        help="Print per-commit progress to stderr.",
    )
    p.add_argument(
        "--json", "-j",
        dest="json_out",
        action="store_true",
        default=False,
        help="Emit NDJSON events (one JSON object per line).",
    )
    p.add_argument(
        "--import-rerere",
        action="store_true",
        default=False,
        help="Import git rerere conflict resolutions into Muse Harmony patterns.",
    )
    p.add_argument(
        "--rerere-confidence",
        type=float,
        default=0.7,
        metavar="FLOAT",
        help="Confidence score for rerere-imported resolutions (default: 0.7).",
    )
    p.add_argument(
        "--import-stashes",
        action="store_true",
        default=False,
        help="Import git stashes as Muse shelf entries.",
    )
    p.set_defaults(func=run_git_import)
