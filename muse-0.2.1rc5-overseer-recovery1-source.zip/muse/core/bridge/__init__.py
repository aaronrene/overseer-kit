"""``muse.core.bridge`` — Bridge domain logic package.

Decomposed from ``muse.cli.commands.bridge`` (issue #14).

Public API
----------
Import from the canonical submodule paths, or from this package directly
for the most commonly used symbols.
"""

from muse.core.bridge.exporter import GitExporter, _watch_loop, run_git_export
from muse.core.bridge.git_primitives import (
    AttributionMapper,
    FileDiffTree,
    _CatFile,
    _batch_commit_log,
    _git,
    _should_exclude,
    _validate_git_branch_name,
    _validate_git_sha,
)
from muse.core.bridge.harmony_shelf import (
    export_harmony_to_rerere,
    export_shelves_to_stash,
    import_rerere_to_harmony,
    import_stashes_to_shelf,
)
from muse.core.bridge.hooks import BridgeHook, BridgeHooks, load_bridge_hooks, run_hook, run_hooks
from muse.core.bridge.importer import _replay_branch, _replay_commit, run_git_import
from muse.core.bridge.state import BridgeState, read_bridge_state, write_bridge_state
from muse.core.bridge.status import run_git_status

__all__ = [
    # exporter
    "GitExporter",
    "_watch_loop",
    "run_git_export",
    # git_primitives
    "AttributionMapper",
    "FileDiffTree",
    "_CatFile",
    "_batch_commit_log",
    "_git",
    "_should_exclude",
    "_validate_git_branch_name",
    "_validate_git_sha",
    # harmony_shelf
    "export_harmony_to_rerere",
    "export_shelves_to_stash",
    "import_rerere_to_harmony",
    "import_stashes_to_shelf",
    # hooks
    "BridgeHook",
    "BridgeHooks",
    "load_bridge_hooks",
    "run_hook",
    "run_hooks",
    # importer
    "_replay_branch",
    "_replay_commit",
    "run_git_import",
    # state
    "BridgeState",
    "read_bridge_state",
    "write_bridge_state",
    # status
    "run_git_status",
]
