"""Bridge git primitives — low-level git subprocess wrappers.

All functions that shell out to ``git`` live here.  Nothing in this module
knows about Muse commits or snapshots — it only translates git wire output
into Python dicts and bytes.

Exports
-------
GitCommitInfo, GitTagInfo          TypedDicts for git log / tag output
_DEFAULT_EXCLUDE_PREFIXES/SUFFIXES Import filter constants
_should_exclude                    Path exclusion helper
AttributionMapper                  email → Muse handle mapper
_validate_git_sha                  40-char hex guard
_validate_git_branch_name          Shell-safe branch name guard
_CatFile                           Long-running git cat-file process
_git                               One-shot git subprocess
_batch_commit_log                  Bulk commit log reader
_batch_diff_tree                   Commit → changed-files map
_is_lfs_pointer                    LFS pointer detector
_strip_ansi, _parse_sem_ver_bump   Message helpers
_list_git_branches, _list_git_tags Remote-ref listers
"""

from __future__ import annotations

import hashlib
import pathlib
import re
import subprocess
from typing import TypedDict

from muse.core.types import load_json_file


# ---------------------------------------------------------------------------
# Git-specific TypedDicts
# ---------------------------------------------------------------------------

FileDiffTree = dict[str, str | None]
"""Mapping from POSIX path to blob SHA-1 (``None`` = deleted)."""


class GitCommitInfo(TypedDict):
    """One commit record returned by ``git log`` via :func:`_batch_commit_log`."""

    sha: str
    parent_shas: list[str]
    author_email: str
    author_name: str
    author_date: str
    subject: str
    body: str
    is_merge: bool


class GitTagInfo(TypedDict):
    """One tag descriptor returned by :func:`_list_git_tags`."""

    name: str
    sha: str
    is_semver: bool


# ---------------------------------------------------------------------------
# Import path exclusion
# ---------------------------------------------------------------------------

_DEFAULT_EXCLUDE_PREFIXES: list[str] = [
    ".git/",
    "node_modules/",
    ".venv/",
    ".env/",
    "__pycache__/",
    ".tox/",
    ".mypy_cache/",
    ".pytest_cache/",
    "dist/",
    "build/",
    ".eggs/",
]

_DEFAULT_EXCLUDE_SUFFIXES: list[str] = [
    ".pyc",
    ".pyo",
    ".DS_Store",
    ".swp",
    ".swo",
    ".orig",
    ".rej",
    ".class",
    ".o",
    ".obj",
    ".so",
    ".dll",
    ".exe",
    ".log",
]


def _should_exclude(path: str, extra_patterns: list[str] | None = None) -> bool:
    """Return True if *path* matches any default or extra exclude pattern.

    Checks against :data:`_DEFAULT_EXCLUDE_PREFIXES` (prefix match),
    :data:`_DEFAULT_EXCLUDE_SUFFIXES` (suffix match), and any caller-supplied
    *extra_patterns* (substring match).  The ``.git/`` prefix is always
    excluded so git metadata never leaks into a Muse import.

    Args:
        path:           POSIX-relative file path to test.
        extra_patterns: Additional patterns (substring match) to exclude.

    Returns:
        ``True`` if the path should be excluded from the import.
    """
    for prefix in _DEFAULT_EXCLUDE_PREFIXES:
        if path.startswith(prefix) or (f"/{prefix}") in path:
            return True
    for suffix in _DEFAULT_EXCLUDE_SUFFIXES:
        if path.endswith(suffix):
            return True
    if extra_patterns:
        for pattern in extra_patterns:
            if pattern in path:
                return True
    return False


# ---------------------------------------------------------------------------
# Security validation
# ---------------------------------------------------------------------------

_BRANCH_SAFE_RE = re.compile(r"^[a-zA-Z0-9_.\-/]+$")

# SHA-1 hex validation — exactly 40 lowercase hex characters.
_GIT_SHA_RE = re.compile(r"^[0-9a-f]{40}$")

# Characters banned in branch names passed to subprocess.
_BRANCH_UNSAFE_CHARS_RE = re.compile(r'[;&|`$()\\s\x00-\x1f\x7f]')


def _validate_git_sha(sha: str) -> bool:
    """Return True only if *sha* is a valid 40-character lowercase hex SHA-1.

    Args:
        sha: String to validate.

    Returns:
        ``True`` for exactly 40 hex digits ``[0-9a-f]``, ``False`` otherwise.
    """
    return bool(_GIT_SHA_RE.match(sha))


def _validate_git_branch_name(branch: str) -> bool:
    """Return True only if *branch* is safe to pass to a git subprocess.

    Rejects any branch name containing shell metacharacters (``;``, ``&``,
    ``|``, backtick, ``$``, ``(``, ``)``, spaces, or ASCII control chars).

    Args:
        branch: Branch name string to validate.

    Returns:
        ``True`` when the name contains no dangerous characters, ``False`` otherwise.
    """
    if not branch:
        return False
    dangerous = set(';& |`$()\\') | {chr(c) for c in range(0x00, 0x20)} | {chr(0x7f)}
    return not any(ch in dangerous for ch in branch)


# ---------------------------------------------------------------------------
# Attribution mapper
# ---------------------------------------------------------------------------

class AttributionMapper:
    """Maps git author emails to Muse handles via a JSON attribution file.

    When no mapping file is provided (or an email is not in the map),
    a synthetic handle of the form ``git-import/<sha256[:8]>`` is generated
    from the email address.  This ensures every imported commit has a
    stable, reproducible author identity without requiring a full mapping.

    Args:
        map_file: Path to a JSON file mapping ``email → handle``.  May be
                  ``None`` when no attribution map is supplied.

    Attributes:
        missed_emails: Set of email addresses that were not found in the map.
    """

    def __init__(self, map_file: pathlib.Path | None) -> None:
        """Load the attribution map from *map_file*, or use an empty map."""
        self._map: dict[str, str] = {}
        self.missed_emails: set[str] = set()

        if map_file is not None:
            raw = load_json_file(map_file)
            if isinstance(raw, dict):
                for email, handle in raw.items():
                    if isinstance(email, str) and isinstance(handle, str):
                        cleaned = "".join(
                            ch for ch in handle
                            if ch >= " " and ch != "\x7f"
                        )
                        self._map[email] = cleaned

    def get_handle(self, email: str, name: str = "") -> str:
        """Return the Muse handle for *email*, or a synthetic fallback.

        If *email* is present in the attribution map, the mapped handle is
        returned.  Otherwise a synthetic ``git-import/<sha256[:8]>`` handle
        is generated and *email* is recorded in :attr:`missed_emails`.

        Args:
            email: Git author email address.
            name:  Git author display name (used in synthetic handle comment).

        Returns:
            A Muse handle string, guaranteed free of control characters.
        """
        if email in self._map:
            return self._map[email]
        self.missed_emails.add(email)
        digest = hashlib.sha256(email.encode()).hexdigest()[:8]
        return f"git-import/{digest}"


# ---------------------------------------------------------------------------
# _CatFile — long-running git cat-file process
# ---------------------------------------------------------------------------

class _CatFile:
    """Long-running ``git cat-file --batch`` process manager.

    Keeps a single ``git cat-file --batch`` subprocess alive for the duration
    of an import run so per-blob subprocess startup overhead is eliminated.
    Each call to :meth:`read` sends one SHA-1 to the process's stdin and reads
    the response header + body.

    The ``git cat-file --batch`` wire protocol::

        ← send:   ``<sha>\\n``
        → receive: ``<sha> <type> <size>\\n``
                   ``<size-bytes-of-content>``
                   ``\\n`` (1-byte separator after content)

    Args:
        git_dir: Path to the git repository root (containing ``.git/``).
    """

    def __init__(self, git_dir: pathlib.Path) -> None:
        """Start the git cat-file process."""
        self._proc = subprocess.Popen(
            ["git", "-C", str(git_dir), "cat-file", "--batch"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
        )

    def read(self, sha: str) -> bytes:
        """Read one git object by SHA-1 and return its raw content bytes.

        Args:
            sha: 40-character git SHA-1 hash (lowercase hex).

        Returns:
            Raw content bytes of the object.

        Raises:
            ValueError:   If *sha* is not a valid 40-character hex string.
            RuntimeError: If the process has died or returns a missing-object header.
        """
        if not _validate_git_sha(sha):
            raise ValueError(
                f"Invalid git SHA-1: {sha!r}. "
                "Must be exactly 40 lowercase hexadecimal characters."
            )
        assert self._proc.stdin is not None and self._proc.stdout is not None
        self._proc.stdin.write(f"{sha}\n".encode())
        self._proc.stdin.flush()
        header = self._proc.stdout.readline().decode("utf-8", errors="replace").strip()
        if not header or header.endswith(" missing"):
            return b""
        parts = header.rsplit(" ", 2)
        if len(parts) < 3:
            return b""
        size = int(parts[2])
        content = b""
        remaining = size
        while remaining > 0:
            chunk = self._proc.stdout.read(min(remaining, 65536))
            if not chunk:
                break
            content += chunk
            remaining -= len(chunk)
        # Consume the trailing newline separator
        self._proc.stdout.read(1)
        return content

    def close(self) -> None:
        """Terminate the git cat-file process."""
        try:
            if self._proc.stdin:
                self._proc.stdin.close()
            self._proc.wait(timeout=5)
        except Exception:  # noqa: BLE001
            self._proc.kill()

    def __enter__(self) -> "_CatFile":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


# ---------------------------------------------------------------------------
# Low-level git wrappers
# ---------------------------------------------------------------------------

def _git(git_dir: pathlib.Path, *args: str, check: bool = True) -> str:
    """Run a git command in *git_dir* and return stdout as a string.

    Args:
        git_dir: Path to the git repository root.
        *args:   Arguments to pass to git.
        check:   If True, raise ``CalledProcessError`` on non-zero exit.

    Returns:
        stdout as a UTF-8 string (errors replaced with '?').
    """
    result = subprocess.run(
        ["git", "-C", str(git_dir), *args],
        capture_output=True,
        check=check,
    )
    return result.stdout.decode("utf-8", errors="replace")


def _batch_commit_log(
    git_dir: pathlib.Path,
    branch: str,
    from_sha: str | None = None,
) -> list[GitCommitInfo]:
    """Return an oldest-first list of commit dicts for *branch*.

    Uses ``git log --format=...`` with NUL / record-separator delimiters so
    commit messages containing newlines or spaces are parsed correctly.

    Each dict contains:
        ``sha``, ``parent_shas`` (list), ``author_email``, ``author_name``,
        ``author_date`` (ISO-8601), ``subject``, ``body``, ``is_merge`` (bool).

    Args:
        git_dir:  Path to the git repository root.
        branch:   Branch name or ref to log.
        from_sha: If given, only return commits reachable from *branch* but
                  not from *from_sha* (exclusive — *from_sha* itself omitted).

    Returns:
        Commits in oldest-first order (ready for replay).
    """
    fmt = "%H%x00%P%x00%ae%x00%an%x00%aI%x00%s%x00%b%x1e"
    rev_range = branch
    if from_sha:
        rev_range = f"{from_sha}..{branch}"

    try:
        raw = _git(git_dir, "log", f"--format={fmt}", "--reverse", rev_range)
    except subprocess.CalledProcessError:
        return []

    records: list[GitCommitInfo] = []
    for record in raw.split("\x1e"):
        record = record.strip()
        if not record:
            continue
        parts = record.split("\x00", 6)
        if len(parts) < 6:
            continue
        sha, parents_str, email, name, date, subject = parts[:6]
        body = parts[6] if len(parts) > 6 else ""
        sha = sha.strip()
        if not sha or len(sha) != 40:
            continue
        parent_shas = [p.strip() for p in parents_str.strip().split() if p.strip()]
        records.append({
            "sha": sha,
            "parent_shas": parent_shas,
            "author_email": email.strip(),
            "author_name": name.strip(),
            "author_date": date.strip(),
            "subject": subject.strip(),
            "body": body.strip(),
            "is_merge": len(parent_shas) > 1,
        })
    return records


def _batch_diff_tree(
    git_dir: pathlib.Path,
    sha: str,
    parent_sha: str | None = None,
) -> FileDiffTree:
    """Return ``{path: blob_sha | None}`` for files changed in commit *sha*.

    When *parent_sha* is ``None`` (genesis commit), returns all files in the
    tree.  ``blob_sha=None`` means the file was deleted in this commit.

    Args:
        git_dir:    Path to the git repository root.
        sha:        Commit SHA-1 to inspect.
        parent_sha: Parent SHA-1, or ``None`` for the root commit.

    Returns:
        A mapping from POSIX path to blob SHA-1 (or ``None`` for deletions).
    """
    if parent_sha is None:
        try:
            raw = _git(git_dir, "ls-tree", "-r", "--format=%(objectname) %(path)", sha)
        except subprocess.CalledProcessError:
            return {}
        result: dict[str, str | None] = {}
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split(" ", 1)
            if len(parts) == 2:
                result[parts[1]] = parts[0]
        return result

    try:
        raw = _git(
            git_dir,
            "diff-tree", "--no-commit-id", "-r", "--name-status", "--diff-filter=ACDMRT",
            parent_sha, sha,
        )
    except subprocess.CalledProcessError:
        return {}

    result = {}
    added_modified: list[str] = []
    deleted: list[str] = []

    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split("\t", 2)
        if len(parts) < 2:
            continue
        status = parts[0][0]
        if status == "D":
            deleted.append(parts[1])
        elif status in ("A", "M", "T"):
            added_modified.append(parts[1])
        elif status in ("R", "C"):
            if len(parts) >= 3:
                deleted.append(parts[1])
                added_modified.append(parts[2])

    for path in deleted:
        result[path] = None

    if added_modified:
        try:
            ls_raw = _git(git_dir, "ls-tree", "-r", "--format=%(objectname) %(path)", sha)
        except subprocess.CalledProcessError:
            ls_raw = ""
        blob_map: dict[str, str] = {}
        for line in ls_raw.splitlines():
            line = line.strip()
            if not line:
                continue
            p = line.split(" ", 1)
            if len(p) == 2:
                blob_map[p[1]] = p[0]
        for path in added_modified:
            if path in blob_map:
                result[path] = blob_map[path]

    return result


# ---------------------------------------------------------------------------
# Miscellaneous helpers
# ---------------------------------------------------------------------------

def _is_lfs_pointer(content: bytes) -> bool:
    """Return True if *content* is a git LFS pointer file.

    LFS pointers always start with the version line:
    ``version https://git-lfs.github.com/spec/``.

    Args:
        content: Raw file bytes to test.

    Returns:
        ``True`` if this is an LFS pointer, ``False`` otherwise.
    """
    return content.startswith(b"version https://git-lfs.github.com/spec/")


_ANSI_ESCAPE_RE = re.compile(r"\x1b\[[0-9;]*[mGKHF]")


def _strip_ansi(s: str) -> str:
    """Strip ANSI escape sequences from *s*."""
    return _ANSI_ESCAPE_RE.sub("", s)


def _parse_sem_ver_bump(message: str) -> str:
    """Parse conventional commit prefix and return the semver bump level.

    Rules (in priority order):
    1. ``BREAKING CHANGE`` in body or ``feat!:`` / ``fix!:`` prefix → ``major``
    2. ``feat:`` prefix → ``minor``
    3. ``fix:`` / ``perf:`` prefix → ``patch``
    4. Anything else → ``none``

    Args:
        message: Full commit message (subject + body).

    Returns:
        One of ``"major"``, ``"minor"``, ``"patch"``, or ``"none"``.
    """
    first_line = message.splitlines()[0] if message else ""

    if "BREAKING CHANGE" in message or re.match(r"^\w+!:", first_line):
        return "major"
    if re.match(r"^feat(\(.+\))?:", first_line):
        return "minor"
    if re.match(r"^(fix|perf)(\(.+\))?:", first_line):
        return "patch"
    return "none"


# ---------------------------------------------------------------------------
# Git ref listers
# ---------------------------------------------------------------------------

def _list_git_branches(git_dir: pathlib.Path) -> list[str]:
    """Return the list of local git branch names in *git_dir*.

    Args:
        git_dir: Path to the git repository root.

    Returns:
        A list of branch name strings (e.g. ``["main", "develop"]``).
    """
    try:
        raw = _git(git_dir, "branch", "--format=%(refname:short)")
        return [b.strip() for b in raw.splitlines() if b.strip()]
    except subprocess.CalledProcessError:
        return []


def _list_git_tags(git_dir: pathlib.Path) -> list[GitTagInfo]:
    """Return a list of tag dicts from *git_dir*.

    Each dict has keys:
        ``name`` (str), ``sha`` (str), ``is_semver`` (bool).

    Args:
        git_dir: Path to the git repository root.

    Returns:
        A list of tag descriptor dicts.
    """
    _SEMVER_RE = re.compile(r"^v?\d+\.\d+\.\d+")
    try:
        raw = _git(git_dir, "tag", "-l", "--format=%(refname:short) %(objectname:short)")
        tags: list[GitTagInfo] = []
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split(" ", 1)
            name = parts[0]
            sha = parts[1] if len(parts) > 1 else ""
            tags.append({
                "name": name,
                "sha": sha,
                "is_semver": bool(_SEMVER_RE.match(name)),
            })
        return tags
    except subprocess.CalledProcessError:
        return []
