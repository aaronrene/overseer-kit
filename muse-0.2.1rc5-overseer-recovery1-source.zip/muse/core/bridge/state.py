"""Bridge state persistence — ``.muse/git-bridge.toml``.

Owns the :class:`BridgeState` TypedDict family, the thread-safe
:func:`read_bridge_state` / :func:`write_bridge_state` pair, and the
minimal TOML serialiser :func:`_dict_to_toml`.

All Muse commit IDs stored in bridge state must carry the canonical
``sha256:`` prefix.  :func:`write_bridge_state` enforces this at the
persistence boundary.
"""

from __future__ import annotations

import pathlib
import threading
from typing import TypedDict

from muse.core.paths import git_bridge_state_path
from muse.core.types import split_id


# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------

SnapshotManifest = dict[str, str]

# ---------------------------------------------------------------------------
# Bridge state — TypedDicts
# ---------------------------------------------------------------------------

class _LastImportState(TypedDict, total=False):
    """State recorded after a successful ``muse bridge git-import`` run.

    Fields
    ------
    git_sha:         40-char SHA-1 of the last git commit imported.
    git_ref:         Git branch or tag that was imported (e.g. ``"main"``).
    git_remote:      Name of the git remote (e.g. ``"origin"``).
    muse_branch:     Muse branch the commits were written to.
    muse_commit_id:  ``sha256:`` prefixed ID of the last Muse commit written.
    imported_at:     ISO-8601 UTC timestamp of the import run.
    commits_written: Number of Muse commits created in the last import run.
    """

    git_sha: str
    git_ref: str
    git_remote: str
    muse_branch: str
    muse_commit_id: str
    imported_at: str
    commits_written: int


class _LastExportState(TypedDict, total=False):
    """State recorded after a successful ``muse bridge git-export`` run.

    Fields
    ------
    muse_branch:     Muse branch that was exported.
    muse_commit_id:  ``sha256:`` prefixed ID of the exported Muse commit.
    git_remote:      Name of the git remote pushed to.
    git_ref:         Git branch written to (e.g. ``"muse-mirror"``).
    git_sha:         40-char SHA-1 of the git commit created by the export.
    exported_at:     ISO-8601 UTC timestamp of the export run.
    """

    muse_branch: str
    muse_commit_id: str
    git_remote: str
    git_ref: str
    git_sha: str
    exported_at: str


class BridgeState(TypedDict):
    """Persisted bridge synchronisation state.

    Written to ``<repo_root>/.muse/git-bridge.toml`` by both ``git-import``
    and ``git-export``.  Never committed to the Muse object store — add the
    path to ``.museignore``.

    Both sub-dicts use :class:`total=False` keys so callers that only perform
    one direction of sync can omit the unused section.

    Fields
    ------
    last_import:  Most recent git-import run details (may be empty dict).
    last_export:  Most recent git-export run details (may be empty dict).
    """

    last_import: _LastImportState
    last_export: _LastExportState


class _SidecarData(TypedDict, total=False):
    """Phase-8 sidecar JSON — tracks imported stashes and exported shelf IDs.

    ``exported_manifest_paths`` additionally tracks the set of relative
    paths written by the most recent successful ``git-export`` run — one
    flat record per Muse repo, matching ``_LastExportState``'s existing
    single-target assumption (not keyed per ``--git-dir``; a repo bridging
    to multiple git targets gets ownership tracking scoped to whichever
    target was exported to most recently). This is the ownership record
    ``GitExporter.sync_to_git``'s delete pass uses to compute delete
    candidates as ``owned_before - owned_now`` — never an unconditional
    sweep of the whole working tree. See issue #65.
    """

    imported_stashes: list[str]
    exported_shelf_ids: list[str]
    exported_manifest_paths: list[str]


class DriftInfo(TypedDict):
    """Commit drift between git and Muse since last bridge sync."""

    git_commits_since_import: int | None
    muse_commits_since_export: int | None


# ---------------------------------------------------------------------------
# Internal lock
# ---------------------------------------------------------------------------

_BRIDGE_STATE_LOCK = threading.Lock()


# ---------------------------------------------------------------------------
# read_bridge_state / write_bridge_state
# ---------------------------------------------------------------------------

def read_bridge_state(repo_root: pathlib.Path) -> BridgeState:
    """Read bridge state from ``<repo_root>/.muse/git-bridge.toml``.

    Returns a :class:`BridgeState` with both ``last_import`` and
    ``last_export`` set to empty dicts when the file does not exist or when
    the corresponding TOML section is absent.  Unknown keys are passed through
    unchanged so that future fields survive a round-trip through older CLI
    versions.

    Args:
        repo_root: Root directory of the Muse repository (must contain ``.muse/``).

    Returns:
        A :class:`BridgeState` dict, always with both top-level keys present.

    Raises:
        Nothing — missing or empty files return an empty default state.
    """
    import tomllib

    path = git_bridge_state_path(repo_root)
    raw = {}
    if path.exists():
        try:
            with _BRIDGE_STATE_LOCK:
                raw = tomllib.loads(path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001 — tolerate malformed TOML
            raw = {}

    state: BridgeState = {
        "last_import": raw.get("last_import", {}),
        "last_export": raw.get("last_export", {}),
    }
    return state


def write_bridge_state(repo_root: pathlib.Path, state: BridgeState) -> None:
    """Write bridge state to ``<repo_root>/.muse/git-bridge.toml``.

    Validates that any ``muse_commit_id`` value in *state* carries the
    canonical ``sha256:`` prefix.  Raises :class:`ValueError` for bare hex
    strings to enforce the prefix invariant at the persistence boundary.

    Thread-safe: uses a module-level lock so concurrent writes do not
    interleave partial TOML output.

    Args:
        repo_root: Root directory of the Muse repository.
        state:     A :class:`BridgeState`-compatible dict to persist.

    Raises:
        ValueError: If any ``muse_commit_id`` value lacks the ``sha256:`` prefix.
    """
    for section_key in ("last_import", "last_export"):
        section = state.get(section_key, {})
        cid = section.get("muse_commit_id", "")
        if cid:
            if not cid.startswith("sha256:"):
                raise ValueError(
                    f"bridge state muse_commit_id {cid!r} in section {section_key!r} "
                    "must carry a 'sha256:' prefix (e.g. sha256:<64-hex>). "
                    "Never store bare hex strings in bridge state."
                )
            try:
                split_id(cid)
            except ValueError as exc:
                raise ValueError(
                    f"bridge state muse_commit_id {cid!r} in section {section_key!r} "
                    "is not a valid sha256: object ID."
                ) from exc

    path = git_bridge_state_path(repo_root)
    path.parent.mkdir(parents=True, exist_ok=True)

    toml_text = _dict_to_toml(state)

    with _BRIDGE_STATE_LOCK:
        tmp = path.with_suffix(".toml.tmp")
        tmp.write_text(toml_text, encoding="utf-8")
        tmp.replace(path)


def _dict_to_toml(d: BridgeState) -> str:
    """Serialise a shallow dict-of-dicts to TOML.

    Handles one level of nesting (``[section]`` headers) and the following
    value types: ``str``, ``int``, ``bool``, ``float``.  Sufficient for the
    :class:`BridgeState` structure.  Not a general-purpose TOML serialiser.
    """
    lines: list[str] = []
    for section, values in d.items():
        if not isinstance(values, dict):
            continue
        lines.append(f"[{section}]")
        for key, val in values.items():
            if isinstance(val, bool):
                lines.append(f"{key} = {str(val).lower()}")
            elif isinstance(val, int):
                lines.append(f"{key} = {val}")
            elif isinstance(val, float):
                lines.append(f"{key} = {val!r}")
            elif isinstance(val, str):
                escaped = val.replace("\\", "\\\\").replace('"', '\\"')
                lines.append(f'{key} = "{escaped}"')
        lines.append("")
    return "\n".join(lines)
