"""Bridge export engine — Muse → Git snapshot sync.

Exports a Muse snapshot into a git working tree by reading objects from
the Muse object store and writing them into a git repository.

Exports
-------
GitExporter       Orchestrates the full export pipeline
_ensure_git_branch  Create or checkout a git branch
_watch_loop       Polling loop for watch mode
run_git_export    CLI entry point for ``muse bridge git-export``
"""

from __future__ import annotations

import argparse
import datetime
import json
import pathlib
import subprocess
import sys

from muse.core.bridge.git_primitives import (
    _BRANCH_SAFE_RE,
    _git,
    _should_exclude,
)
from muse.core.bridge.hooks import load_bridge_hooks, run_hook
from muse.core.bridge.state import (
    BridgeState,
    SnapshotManifest,
    _SidecarData,
    read_bridge_state,
    write_bridge_state,
)
from muse.core.errors import ExitCode
from muse.core.ignore import is_ignored, load_ignore_config, resolve_patterns
from muse.core.paths import git_bridge_sidecar_path, head_path, ref_path
from muse.core.repo import find_repo_root
from muse.core.types import load_json_file, now_utc_iso


class GitExporter:
    """Synchronise a Muse snapshot into a git working tree.

    Export algorithm (delete+replace):

    1. Resolve ``--muse-ref`` to a full commit_id via ``.muse/refs/heads/<branch>``
       or HEAD.
    2. Read the :class:`SnapshotRecord` from the Muse object store.
    3. Verify ``--git-dir`` is a real git repository.
    4. If ``--git-branch`` does not exist in git, create it.
    5. Delete all tracked files in ``--git-dir`` (except ``.git/`` and excluded
       patterns).
    6. Write every file from the Muse snapshot manifest into ``--git-dir``.
    7. Run ``git add -A``.
    8. Check for staged changes (``git diff --cached --quiet``).
    9. If changes exist (or ``--allow-empty``): ``git commit -m <message>``.
    10. If not ``--no-push``: ``git push <remote> <branch>``.
    11. Return the new git SHA (or ``None`` if nothing was committed).

    Args:
        root:       Muse repository root directory.
        git_dir:    Target git repository directory.
        git_branch: Git branch to write to.
        git_remote: Git remote name for push.
        muse_ref:   Muse branch name or full ``sha256:`` commit ID to export.
    """

    def __init__(
        self,
        root: pathlib.Path,
        git_dir: pathlib.Path,
        git_branch: str,
        git_remote: str,
        muse_ref: str | None = None,
    ) -> None:
        self.root = root
        self.git_dir = git_dir
        self.git_branch = git_branch
        self.git_remote = git_remote
        self.muse_ref = muse_ref
        self.muse_commit_id: str = ""
        self.muse_branch: str = ""

    def _user_error(self, msg: str) -> None:
        print(f"Error: {msg}", file=sys.stderr)
        raise SystemExit(ExitCode.USER_ERROR)

    def resolve_muse_ref(self, muse_ref: str | None) -> tuple[str, str]:
        """Resolve *muse_ref* to ``(commit_id, snapshot_id)``."""
        from muse.core.commits import read_commit

        root = self.root

        if muse_ref is None or muse_ref == "HEAD":
            _head_file = head_path(root)
            if not _head_file.exists():
                self._user_error(f"No .muse/HEAD found in {root}")
            head_content = _head_file.read_text().strip()
            if head_content.startswith("ref: refs/heads/"):
                branch = head_content[len("ref: refs/heads/"):]
            else:
                branch = head_content
            muse_ref = branch

        if muse_ref.startswith("sha256:"):
            commit_id = muse_ref
            self.muse_branch = "HEAD"
        else:
            _branch_ref = ref_path(root, muse_ref)
            if not _branch_ref.exists():
                self._user_error(
                    f"Muse ref {muse_ref!r} not found. "
                    f"Run 'muse branch --json' to list available branches."
                )
            commit_id = _branch_ref.read_text().strip()
            self.muse_branch = muse_ref

        self.muse_commit_id = commit_id

        cr = read_commit(root, commit_id)
        if cr is None:
            self._user_error(
                f"Muse commit {commit_id[:23]}… not found in object store."
            )
        assert cr is not None
        return commit_id, cr.snapshot_id

    def read_snapshot(self, snapshot_id: str) -> SnapshotManifest:
        """Return the snapshot manifest ``{relative_path: object_id}`` for *snapshot_id*."""
        from muse.core.snapshots import read_snapshot as _read_snapshot

        snap = _read_snapshot(self.root, snapshot_id)
        if snap is None:
            self._user_error(
                f"Snapshot {snapshot_id[:23]}… not found in object store."
            )
        assert snap is not None
        return dict(snap.manifest)

    def _read_owned_paths(self) -> set[str]:
        """Return the manifest paths written by the previous successful export.

        Empty on the very first export for this repo (no prior sidecar
        entry) — meaning nothing is a delete candidate yet, by design. See
        issue #65.
        """
        sidecar_path = git_bridge_sidecar_path(self.root)
        sidecar: _SidecarData = load_json_file(sidecar_path) or _SidecarData()
        return set(sidecar.get("exported_manifest_paths", []))

    def _write_owned_paths(self, paths: set[str]) -> None:
        """Persist *paths* as the ownership record for the next export run."""
        sidecar_path = git_bridge_sidecar_path(self.root)
        sidecar: _SidecarData = load_json_file(sidecar_path) or _SidecarData()
        sidecar["exported_manifest_paths"] = sorted(paths)
        sidecar_path.parent.mkdir(parents=True, exist_ok=True)
        sidecar_path.write_text(json.dumps(sidecar), encoding="utf-8")

    def _ignored_paths(self, git_dir: pathlib.Path, candidates: set[str]) -> set[str]:
        """Return the subset of *candidates* that are gitignored or museignored.

        Consults ``git check-ignore --stdin`` (a single batched call, not one
        subprocess per path) and ``.museignore``'s global patterns. Never
        raises — a git-dir that isn't a real git repo, or has no
        ``.gitignore``, simply contributes an empty set from that source.

        Known limitation of the ``git check-ignore`` half: git never reports
        a path as ignored while it is still tracked in the git index — a
        tracked file overrides gitignore rules everywhere in git, not just
        here. If a delete candidate was tracked by a prior export commit and
        the caller freshly gitignores that exact path before the next
        export, ``check-ignore`` will not protect it until something
        actually untracks it first (e.g. ``git rm --cached``). ``.museignore``
        has no such limitation — it is Muse's own policy layer, independent
        of git's tracking state — so a caller relying on ignore-based
        protection for a *reused, previously-tracked* path should use
        ``.museignore``, not ``.gitignore``, for that specific case.
        """
        if not candidates:
            return set()

        ignored: set[str] = set()

        try:
            result = subprocess.run(
                ["git", "-C", str(git_dir), "check-ignore", "--stdin"],
                input="\n".join(sorted(candidates)),
                capture_output=True,
                text=True,
            )
            # check-ignore prints only the paths that matched an ignore rule;
            # exit code 1 ("no paths matched") is not an error to us.
            ignored.update(line for line in result.stdout.splitlines() if line)
        except (OSError, subprocess.SubprocessError):
            pass

        try:
            config = load_ignore_config(self.root)
            patterns = resolve_patterns(config, domain="")
            if patterns:
                ignored.update(c for c in candidates if is_ignored(c, patterns))
        except Exception:  # noqa: BLE001 — never let ignore-file parsing block export
            pass

        return ignored

    def sync_to_git(
        self,
        manifest: dict[str, str],
        excludes: list[str],
        strip_muse: bool,
        fix_modes: bool,
        allow_delete_ignored: bool = False,
    ) -> int:
        """Write every file from *manifest* into ``git_dir``, deleting only
        paths this exporter itself wrote in a prior run and no longer wants.

        Delete candidates are computed as ``owned_before - owned_now`` —
        the set of paths recorded in the previous successful export's
        manifest that are absent from *manifest* this run. A path Muse
        never wrote (an ignored secret, an untracked scratch file, anything
        that was never part of any Muse snapshot) can never appear in
        ``owned_before`` and is therefore never a delete candidate, on the
        very first export or any subsequent one. See issue #65.

        Within the delete-candidate set, a path currently matched by
        ``.gitignore`` or ``.museignore`` is additionally skipped unless
        *allow_delete_ignored* is passed — defense in depth for the case
        where a path was legitimately Muse-owned before but has since been
        reused by a gitignored local file.

        Returns:
            Number of files written.
        """
        import fnmatch
        from muse.core.object_store import read_object

        git_dir = self.git_dir

        def _should_skip(rel: str) -> bool:
            if ".git" in rel.split("/") or rel.startswith(".git/") or rel == ".git":
                return True
            if strip_muse and (rel.startswith(".muse/") or rel == ".muse"):
                return True
            for pat in (excludes or []):
                basename = rel.split("/")[-1]
                if fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(basename, pat) or pat in rel:
                    return True
            return _should_exclude(rel, None)

        owned_now = {rel for rel in manifest if not _should_skip(rel)}
        owned_before = self._read_owned_paths()
        delete_candidates = owned_before - owned_now

        if delete_candidates and not allow_delete_ignored:
            ignored = self._ignored_paths(git_dir, delete_candidates)
            delete_candidates -= ignored

        removed_dirs: set[pathlib.Path] = set()
        for rel in delete_candidates:
            p = git_dir / rel
            if p.is_file():
                p.unlink()
                removed_dirs.add(p.parent)

        for d in sorted(removed_dirs, key=lambda p: len(p.parts), reverse=True):
            if d == git_dir:
                continue
            if ".git" in d.relative_to(git_dir).parts:
                continue
            try:
                d.rmdir()
            except OSError:
                pass

        files_written = 0
        for rel_path, object_id in manifest.items():
            if _should_skip(rel_path):
                continue
            content = read_object(self.root, object_id)
            if content is None:
                continue
            dest = git_dir / rel_path
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(content)
            files_written += 1

        if fix_modes:
            self.fix_file_modes(manifest)

        self._write_owned_paths(owned_now)

        return files_written

    def fix_file_modes(self, manifest: SnapshotManifest) -> None:
        """Set file permissions based on shebang detection.

        Files whose first two bytes are ``#!`` get ``0o755``; all others get ``0o644``.
        """
        import stat

        MODE_REGULAR = stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH
        MODE_EXECUTABLE = MODE_REGULAR | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH

        for rel_path in manifest:
            dest = self.git_dir / rel_path
            if dest.exists() and dest.is_file():
                try:
                    dest.resolve().relative_to(self.git_dir.resolve())
                except ValueError:
                    continue
                if ".git" in dest.relative_to(self.git_dir).parts:
                    continue
                dest.chmod(
                    MODE_EXECUTABLE if GitExporter._has_shebang(dest) else MODE_REGULAR
                )

    @staticmethod
    def _has_shebang(dest: "pathlib.Path") -> bool:
        """Return True iff *dest*'s first two bytes are ``#!``."""
        try:
            with dest.open("rb") as f:
                return f.read(2) == b"#!"
        except OSError:
            return False

    def git_commit(
        self,
        commit_id: str,
        message_template: str,
        allow_empty: bool,
        author: str = "muse-bridge",
    ) -> str | None:
        """Stage all changes and create a git commit.

        Returns:
            The new git SHA-1 (40 chars) or ``None`` when nothing was committed.
        """
        subprocess.run(
            ["git", "-C", str(self.git_dir), "add", "-A"],
            check=True,
            capture_output=True,
        )

        diff_result = subprocess.run(
            ["git", "-C", str(self.git_dir), "diff", "--cached", "--quiet"],
            capture_output=True,
        )
        has_changes = diff_result.returncode != 0

        if not has_changes and not allow_empty:
            return None

        now = datetime.datetime.now(datetime.timezone.utc)
        msg = message_template.format(
            commit_id=commit_id,
            commit_id_short=commit_id[7:23] if commit_id.startswith("sha256:") else commit_id[:16],
            branch=self.muse_branch,
            timestamp=now.isoformat(),
            author=author,
        )

        cmd = ["git", "-C", str(self.git_dir), "commit", "-m", msg]
        if allow_empty and not has_changes:
            cmd.append("--allow-empty")
        subprocess.run(cmd, check=True, capture_output=True)

        sha = _git(self.git_dir, "rev-parse", "HEAD").strip()
        return sha

    def git_push(self, remote: str, branch: str, force: bool = False) -> None:
        """Push *branch* to *remote*."""
        cmd = ["git", "-C", str(self.git_dir), "push", remote, branch]
        if force:
            cmd.append("--force")
        subprocess.run(cmd, check=True, capture_output=True)


def _ensure_git_branch(git_dir: pathlib.Path, branch: str) -> None:
    """Ensure *branch* exists in the git repo at *git_dir*, creating it if needed."""
    result = subprocess.run(
        ["git", "-C", str(git_dir), "rev-parse", "--verify", branch],
        capture_output=True,
    )
    branch_exists = result.returncode == 0
    if not branch_exists:
        subprocess.run(
            ["git", "-C", str(git_dir), "checkout", "-b", branch],
            check=True,
            capture_output=True,
        )
    else:
        subprocess.run(
            ["git", "-C", str(git_dir), "checkout", branch],
            check=True,
            capture_output=True,
        )


def _watch_loop(
    args: argparse.Namespace,
    root: pathlib.Path,
    git_dir: pathlib.Path,
    interval: int,
) -> None:
    """Poll Muse HEAD every *interval* seconds and auto-export on new commits."""
    import time

    def _head_commit_id() -> str | None:
        _head_file = head_path(root)
        if not _head_file.exists():
            return None
        content = _head_file.read_text().strip()
        if content.startswith("ref: refs/heads/"):
            branch = content[len("ref: refs/heads/"):]
            _branch_ref = ref_path(root, branch)
            return _branch_ref.read_text().strip() if _branch_ref.exists() else None
        return content

    last_commit_id = _head_commit_id()

    while True:
        time.sleep(interval)
        current_commit_id = _head_commit_id()
        changed = current_commit_id != last_commit_id and current_commit_id is not None

        if args.json_out:
            print(json.dumps({
                "event": "poll",
                "muse_commit_id": current_commit_id or "",
                "changed": changed,
            }), flush=True)

        if changed:
            last_commit_id = current_commit_id
            exporter = GitExporter(
                root=root,
                git_dir=git_dir,
                git_branch=args.git_branch,
                git_remote=args.git_remote,
                muse_ref=args.muse_ref,
            )
            try:
                commit_id, snapshot_id = exporter.resolve_muse_ref(args.muse_ref)
                manifest = exporter.read_snapshot(snapshot_id)
                _ensure_git_branch(git_dir, args.git_branch)
                exporter.sync_to_git(
                    manifest,
                    excludes=getattr(args, "excludes", []) or [],
                    strip_muse=getattr(args, "strip_muse_metadata", True),
                    fix_modes=getattr(args, "fix_modes", False),
                )
                git_sha = exporter.git_commit(
                    commit_id,
                    args.commit_message,
                    allow_empty=getattr(args, "allow_empty", False),
                )
                if git_sha and not getattr(args, "no_push", True):
                    exporter.git_push(
                        args.git_remote,
                        args.git_branch,
                        force=getattr(args, "force_push", False),
                    )
                if args.json_out:
                    print(json.dumps({
                        "event": "exported",
                        "muse_commit_id": commit_id,
                        "git_sha": git_sha or "",
                    }), flush=True)
            except SystemExit:
                pass


def run_git_export(args: argparse.Namespace) -> None:
    """Entry point for ``muse bridge git-export``.

    Syncs a Muse snapshot into a git working tree.

    CI env vars:

    * ``MUSE_AGENT_KEY``    — PEM-encoded Ed25519 private key.
    * ``MUSE_AGENT_HANDLE`` — registered agent handle.
    """
    git_dir_arg = getattr(args, "git_dir", None)
    json_out: bool = args.json_out
    dry_run: bool = getattr(args, "dry_run", False)
    no_push: bool = getattr(args, "no_push", True)
    force_push: bool = getattr(args, "force_push", False)
    git_branch: str = getattr(args, "git_branch", "muse-mirror")
    git_remote: str = getattr(args, "git_remote", "origin")
    muse_ref: str | None = getattr(args, "muse_ref", None)
    excludes: list[str] = getattr(args, "excludes", []) or []
    strip_muse: bool = getattr(args, "strip_muse_metadata", True)
    fix_modes: bool = getattr(args, "fix_modes", False)
    allow_delete_ignored: bool = getattr(args, "allow_delete_ignored", False)
    allow_empty: bool = getattr(args, "allow_empty", False)
    commit_message: str = getattr(args, "commit_message", "mirror: muse {commit_id}")
    watch_interval: int | None = getattr(args, "watch", None)

    def _emit_error(msg: str) -> None:
        if json_out:
            print(json.dumps({"error": msg, "exit_code": ExitCode.USER_ERROR}))
        else:
            print(f"Error: {msg}", file=sys.stderr)

    if not git_dir_arg:
        _emit_error("--git-dir is required for muse bridge git-export")
        raise SystemExit(ExitCode.USER_ERROR)

    git_dir = pathlib.Path(git_dir_arg).resolve()

    if not (git_dir / ".git").exists():
        _emit_error(f"No git repository found at {git_dir}")
        raise SystemExit(ExitCode.USER_ERROR)

    if not _BRANCH_SAFE_RE.match(git_branch):
        _emit_error(
            f"--git-branch {git_branch!r} contains invalid characters. "
            "Only alphanumerics, dots, hyphens, underscores, and slashes are allowed."
        )
        raise SystemExit(ExitCode.USER_ERROR)

    root = find_repo_root()
    if root is None:
        _emit_error("No Muse repository found. Run 'muse init' first.")
        raise SystemExit(ExitCode.USER_ERROR)

    if dry_run:
        if json_out:
            print(json.dumps({
                "event": "done",
                "dry_run": True,
                "git_dir": str(git_dir),
                "git_branch": git_branch,
                "muse_ref": muse_ref,
            }))
        else:
            print(
                f"dry-run: would export muse ref {muse_ref or 'HEAD'!r} "
                f"to {git_dir} branch {git_branch!r}"
            )
        return

    exporter = GitExporter(
        root=root,
        git_dir=git_dir,
        git_branch=git_branch,
        git_remote=git_remote,
        muse_ref=muse_ref,
    )

    commit_id, snapshot_id = exporter.resolve_muse_ref(muse_ref)
    manifest = exporter.read_snapshot(snapshot_id)
    _ensure_git_branch(git_dir, git_branch)

    _hook_env: dict[str, str] = {
        "MUSE_BRIDGE_GIT_DIR": str(git_dir),
        "MUSE_BRIDGE_GIT_BRANCH": git_branch,
        "MUSE_BRIDGE_COMMIT_ID": commit_id,
    }

    _bridge_hooks = load_bridge_hooks(root)
    for _hook in _bridge_hooks.pre_bridge:
        run_hook(_hook, cwd=root, env=_hook_env)

    files_written = exporter.sync_to_git(
        manifest,
        excludes=excludes,
        strip_muse=strip_muse,
        fix_modes=fix_modes,
        allow_delete_ignored=allow_delete_ignored,
    )

    git_sha = exporter.git_commit(commit_id, commit_message, allow_empty=allow_empty)

    for _hook in _bridge_hooks.post_bridge:
        run_hook(_hook, cwd=git_dir, env=_hook_env)

    if git_sha and not no_push:
        exporter.git_push(git_remote, git_branch, force=force_push)

    now_iso = now_utc_iso()
    bridge_state = read_bridge_state(root)
    new_state: BridgeState = {
        "last_import": dict(bridge_state.get("last_import", {})),
        "last_export": {
            "muse_branch": exporter.muse_branch,
            "muse_commit_id": commit_id,
            "git_remote": git_remote,
            "git_ref": git_branch,
            "git_sha": git_sha or "",
            "exported_at": now_iso,
        },
    }
    try:
        write_bridge_state(root, new_state)
    except Exception:
        pass

    rerere_exported = 0
    shelves_exported = 0

    if getattr(args, "export_rerere", False):
        from muse.core.bridge.harmony_shelf import export_harmony_to_rerere
        rerere_exported = export_harmony_to_rerere(root, git_dir, dry_run=dry_run)

    if getattr(args, "export_shelves", False):
        from muse.core.bridge.harmony_shelf import export_shelves_to_stash
        shelves_exported = export_shelves_to_stash(root, git_dir, dry_run=dry_run)

    if json_out:
        print(json.dumps({
            "event": "done",
            "muse_commit_id": commit_id,
            "snapshot_id": snapshot_id,
            "files_written": files_written,
            "git_sha": git_sha or "",
            "git_branch": git_branch,
            "pushed": bool(git_sha and not no_push),
            "dry_run": False,
            "rerere_exported": rerere_exported,
            "shelves_exported": shelves_exported,
        }))
    else:
        status = "committed" if git_sha else "no changes"
        print(
            f"Exported {files_written} files → git {git_branch!r} "
            f"({status}{', pushed' if git_sha and not no_push else ''})"
        )

    if watch_interval:
        _watch_loop(args, root, git_dir, watch_interval)


def _register_git_export_parser(
    subs: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Register the ``git-export`` subcommand onto *subs*."""
    import argparse as _ap

    p = subs.add_parser(
        "git-export",
        help="Sync a Muse snapshot into a git working tree.",
        formatter_class=_ap.RawDescriptionHelpFormatter,
        description=(
            "Export a Muse snapshot to a git repository.\n"
            "Creates a git commit with message 'mirror: muse <commit_id>'."
        ),
    )
    p.add_argument(
        "--muse-ref",
        default=None,
        metavar="BRANCH|COMMIT_ID",
        help="Muse ref to export (default: HEAD).",
    )
    p.add_argument(
        "--git-dir",
        default=None,
        metavar="PATH",
        help="Git repository to sync into (required).",
    )
    p.add_argument(
        "--git-branch",
        default="muse-mirror",
        metavar="BRANCH",
        help="Git branch to commit to (default: muse-mirror).",
    )
    p.add_argument(
        "--git-remote",
        default="origin",
        metavar="REMOTE",
        help="Git remote for push (default: origin).",
    )
    p.add_argument(
        "--no-push",
        action="store_true",
        default=False,
        help="Create the git commit but skip git push.",
    )
    p.add_argument(
        "--force-push",
        action="store_true",
        default=False,
        help="Use git push --force (for mirror branches).",
    )
    p.add_argument(
        "--exclude",
        action="append",
        dest="excludes",
        default=[],
        metavar="PATTERN",
        help="Glob patterns for files to omit from the git export (repeatable).",
    )
    p.add_argument(
        "--strip-muse-metadata",
        action="store_true",
        default=True,
        help="Exclude .muse/ from the git export (default: true).",
    )
    p.add_argument(
        "--allow-delete-ignored",
        action="store_true",
        default=False,
        help=(
            "Allow deleting a previously Muse-owned path even if it is "
            "currently matched by .gitignore or .museignore (default: "
            "protected). Never affects paths Muse never wrote — those are "
            "always protected regardless of this flag."
        ),
    )
    p.add_argument(
        "--commit-message",
        default="mirror: muse {commit_id}",
        metavar="TEMPLATE",
        help="Git commit message template (default: 'mirror: muse {commit_id}').",
    )
    p.add_argument(
        "--allow-empty",
        action="store_true",
        default=False,
        help="Create a git commit even if nothing changed.",
    )
    p.add_argument(
        "--fix-modes",
        action=_ap.BooleanOptionalAction,
        default=True,
        help="chmod files after writing — 0o644 for regular files, 0o755 for files with a POSIX shebang. Disable with --no-fix-modes.",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Print what would happen without writing anything.",
    )
    p.add_argument(
        "--json", "-j",
        dest="json_out",
        action="store_true",
        default=False,
        help="Emit NDJSON events (one JSON object per line).",
    )
    p.add_argument(
        "--watch",
        default=None,
        type=int,
        metavar="SECONDS",
        help="Poll Muse HEAD every N seconds and auto-export on new commits.",
    )
    p.add_argument(
        "--export-rerere",
        action="store_true",
        default=False,
        help="Export Muse Harmony resolutions to git rerere format (.git/rr-cache/).",
    )
    p.add_argument(
        "--export-shelves",
        action="store_true",
        default=False,
        help="Export Muse shelf entries as git stashes.",
    )
    p.set_defaults(func=run_git_export)
