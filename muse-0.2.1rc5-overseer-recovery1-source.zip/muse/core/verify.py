"""Whole-repository integrity verification for ``muse verify``.

Walks every reachable commit from every branch ref (or a single branch when
``branch`` is specified) and performs five tiers of integrity checking:

1. **Ref integrity** — every branch ref file points to an existing commit.
2. **Commit → snapshot integrity** — every commit's ``snapshot_id`` resolves.
3. **Snapshot → object integrity** — every object path in every manifest exists
   locally, is promised by a promisor remote, or is reported as missing.
4. **Object hash integrity** — re-hashes each locally-present object file and
   compares against its declared ID.  Optional; controlled by ``check_objects``.
   Empty files are valid: ``sha256(b"")`` is the correct OID for an empty file.
5. **Signature integrity** — for every commit that carries a non-empty
   ``signature``, the Ed25519 signature is verified against the
   ``signer_public_key`` embedded in the commit record.

Object availability model
-------------------------
Every referenced object is in one of three states:

- **PRESENT** — byte content exists in the local ``.muse/objects/`` store.
  The object is verified (and optionally re-hashed).
- **PROMISED** — absent locally, but at least one promisor remote is
  configured in ``.muse/config.toml``.  Not a failure; counted in
  ``promised_objects``.  Pass ``strict=True`` to treat these as failures.
- **MISSING** — absent locally with no promisor remote.  Reported as a
  ``kind="object"`` failure.

Shallow graft model
-------------------
``.muse/shallow`` lists boundary commit IDs.  The BFS walk includes those
commits but does not descend into their parents — objects beyond the boundary
are not expected locally.  Shallow commits are counted in ``shallow_commits``.

Security model
--------------
Branch ref files are validated before being read:

- Symlinks inside ``.muse/refs/heads/`` are silently skipped.
- Ref file content is capped at ``_MAX_REF_BYTES``; oversized files are
  treated as invalid refs.

Walk budget
-----------
``_MAX_COMMITS = 500_000``.  When the budget is reached the walk stops and
a warning is logged.
"""

import hashlib
import logging
import pathlib
from collections import deque
from typing import Literal, TypedDict

from muse.core.paths import heads_dir as _heads_dir
from muse.core.types import DEFAULT_SIGN_ALGO, decode_pubkey, long_id, sig_algo, split_id
from muse.core.object_availability import ObjectState, load_promisor_remotes, object_state
from muse.core.object_store import iter_stored_objects, object_path
from muse.core.provenance import provenance_payload, verify_commit_ed25519
from muse.core.shallow import is_shallow, read_shallow
from muse.core.commits import (
    CommitRecord,
    read_commit,
)
from muse.core.snapshots import read_snapshot

logger = logging.getLogger(__name__)

_CHUNK_SIZE = 65_536
_MAX_COMMITS = 500_000
# Maximum bytes we'll read from a ref file.  A valid sha256-prefixed commit ID
# is "sha256:" (7) + 64 hex chars + optional newline = 72 bytes.
# Anything larger is treated as corrupt.
_MAX_REF_BYTES = 72

class VerifyFailure(TypedDict):
    """A single integrity failure detected during ``muse verify``.

    ``kind`` is one of:

    - ``"ref"``         — branch ref file is malformed or missing
    - ``"commit"``      — commit file is missing or unreadable
    - ``"snapshot"``    — snapshot file is missing or unreadable
    - ``"object"``      — object file is missing or its hash does not match
    - ``"signature"``   — Ed25519 signature verification failed (tamper detected)
    - ``"key_missing"`` — signer_public_key absent; signature could not be verified
    """

    kind: Literal["ref", "commit", "snapshot", "object", "signature", "key_missing"]
    id: str
    error: str

class VerifyResult(TypedDict):
    """Aggregate result of a full repository integrity walk.

    Shallow / promisor fields
    -------------------------
    ``shallow_commits``
        Number of commits where the BFS walk stopped at a graft boundary.
        Their parents were not enqueued and objects beyond the boundary are
        not expected locally.

    ``promised_objects``
        Objects absent from the local store but covered by at least one
        promisor remote.  These are **not** failures in the default mode.
        Pass ``strict=True`` to ``run_verify`` to treat them as failures.

    ``is_shallow``
        ``True`` when ``.muse/shallow`` exists and contains at least one
        commit ID.

    ``promisor_remotes``
        Names of all configured remotes that acted as promisors during this
        run.  Empty when no remotes are configured or all opted out.
    """

    refs_checked: int
    commits_checked: int
    snapshots_checked: int
    objects_checked: int
    signatures_checked: int
    shallow_commits: int
    promised_objects: int
    is_shallow: bool
    promisor_remotes: list[str]
    all_ok: bool
    nothing_checked: bool
    failures: list[VerifyFailure]

def _branch_refs(
    root: pathlib.Path,
    *,
    branch: str | None = None,
) -> list[tuple[str, str]]:
    """Return ``[(branch_name, commit_id)]`` for branch ref files.

    When *branch* is given only that branch's ref is returned.  Otherwise all
    refs under ``.muse/refs/heads/`` are returned.

    Security:
        Symlinks are silently skipped — a symlink could point outside the
        repository boundary.  Ref file content is capped at ``_MAX_REF_BYTES``
        (65 bytes); oversized files are treated as invalid refs.
    """
    heads_dir = _heads_dir(root)
    if not heads_dir.exists():
        return []

    if branch is not None:
        # Guard against path traversal: reject absolute paths and '..' components.
        branch_path = pathlib.Path(branch)
        if branch_path.is_absolute() or ".." in branch_path.parts:
            return []
        ref_file = heads_dir / branch
        if not ref_file.exists() or ref_file.is_symlink():
            return []
        raw_bytes = ref_file.read_bytes()[:_MAX_REF_BYTES]
        raw = raw_bytes.decode("utf-8", errors="replace").strip()
        return [(branch, raw)] if raw else []

    refs: list[tuple[str, str]] = []
    for ref_file in sorted(heads_dir.rglob("*")):
        if ref_file.is_symlink():
            logger.warning("⚠️ verify: skipping symlink ref: %s", ref_file)
            continue
        if not ref_file.is_file():
            continue
        raw_bytes = ref_file.read_bytes()[:_MAX_REF_BYTES]
        raw = raw_bytes.decode("utf-8", errors="replace").strip()
        if raw:
            br = str(ref_file.relative_to(heads_dir).as_posix())
            refs.append((br, raw))
    return refs

def _rehash_object(path: pathlib.Path) -> str:
    """Re-compute SHA-256 of the object file at *path* using streaming reads.

    Returns a canonical ``sha256:``-prefixed content address so the result
    can be compared directly against stored object IDs.
    """
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(_CHUNK_SIZE), b""):
            h.update(chunk)
    return long_id(h.hexdigest())

def _check_object(
    root: pathlib.Path,
    obj_id: str,
    rel_path: str,
    *,
    check_objects: bool,
    promisor_remotes: list[str],
    strict: bool,
    failures: list[VerifyFailure],
    objects_checked_ref: list[int],
    promised_objects_ref: list[int],
    fail_fast: bool,
    orphan_label: str = "",
) -> bool:
    """Check one object and update counters.  Returns True if walk should stop."""
    state = object_state(root, obj_id, promisor_remotes)

    if state == ObjectState.PRESENT:
        objects_checked_ref[0] += 1
        if check_objects:
            obj_file = object_path(root, obj_id)
            actual = _rehash_object(obj_file)
            if actual != obj_id:
                label = f" ({orphan_label})" if orphan_label else ""
                failures.append(VerifyFailure(
                    kind="object",
                    id=obj_id,
                    error=(
                        f"hash mismatch: expected {obj_id} "
                        f"got {actual} — data corruption detected{label}"
                    ),
                ))
                return fail_fast
        return False

    if state == ObjectState.PROMISED and not strict:
        promised_objects_ref[0] += 1
        return False

    # MISSING or (PROMISED + strict)
    label = f", {orphan_label}" if orphan_label else ""
    failures.append(VerifyFailure(
        kind="object",
        id=obj_id,
        error=f"object file missing (path={rel_path}{label})",
    ))
    return fail_fast

def _collect_ancestor_snapshots(
    root: pathlib.Path,
    graft_commit: CommitRecord,
    *,
    visited: set[str],
    verified_snapshots: set[str],
) -> None:
    """Walk ancestors of *graft_commit* and add their snapshot IDs to *verified_snapshots*.

    This is a commit-only BFS — no objects are read or verified.  Its purpose
    is to ensure the orphan-snapshot sweep skips snapshots that belong to
    commits beyond the shallow graft boundary, so they are not mistakenly
    reported as missing.

    The walk stops at commits already in *visited* (already processed by the
    main BFS).  Delegates to :func:`~muse.core.graph.iter_ancestors` with
    ``exclude=visited``.
    """
    from muse.core.graph import iter_ancestors

    starts = [
        p for p in (graft_commit.parent_commit_id, graft_commit.parent2_commit_id)
        if p and p not in visited
    ]
    if not starts:
        return
    for commit in iter_ancestors(root, starts, exclude=frozenset(visited)):
        verified_snapshots.add(commit.snapshot_id)

def run_verify(
    root: pathlib.Path,
    *,
    check_objects: bool = True,
    branch: str | None = None,
    fail_fast: bool = False,
    strict: bool = False,
) -> VerifyResult:
    """Perform a full repository integrity walk.

    Args:
        root:          Repository root (the directory containing ``.muse/``).
        check_objects: When ``True`` (the default), every locally-present
                       object file is re-hashed and its digest compared
                       against its declared content address.  Pass ``False``
                       for a faster existence-only check.
        branch:        When given, only the named branch is walked.
        fail_fast:     Stop after the first failure.  Useful in CI.
        strict:        When ``True``, treat promised objects (absent locally
                       but covered by a promisor remote) as failures.  By
                       default promised objects are counted in
                       ``promised_objects`` and do not affect ``all_ok``.

    Returns:
        A :class:`VerifyResult` summarising what was checked and any
        failures.  ``all_ok`` is ``True`` when ``failures`` is empty —
        promised objects do not affect this flag unless ``strict=True``.
    """
    failures: list[VerifyFailure] = []
    refs_checked = 0
    commits_checked = 0
    snapshots_checked = 0
    shallow_commits = 0
    signatures_checked = 0
    # Mutable single-element lists so _check_object can update them
    objects_checked_ref = [0]
    promised_objects_ref = [0]

    verified_snapshots: set[str] = set()
    verified_objects: set[str] = set()

    # Load shallow grafts and promisor remotes once at startup.
    shallow_set: frozenset[str] = read_shallow(root)
    promisor_remotes: list[str] = load_promisor_remotes(root)

    # Phase 1: enumerate branch refs and collect tip commit IDs.
    branch_refs = _branch_refs(root, branch=branch)
    tip_commit_ids: list[str] = []

    for br, commit_id in branch_refs:
        refs_checked += 1
        if (
            not commit_id.startswith("sha256:")
            or len(commit_id) != 71
            or not all(c in "0123456789abcdef" for c in split_id(commit_id)[1])
        ):
            failures.append(VerifyFailure(
                kind="ref",
                id=br,
                error=f"invalid commit ID in ref: {commit_id!r}",
            ))
            if fail_fast:
                return _make_result(
                    refs_checked, commits_checked, snapshots_checked,
                    objects_checked_ref[0], signatures_checked, failures,
                    shallow_commits=shallow_commits,
                    promised_objects=promised_objects_ref[0],
                    is_shallow=bool(shallow_set),
                    promisor_remotes=promisor_remotes,
                )
            continue
        tip_commit_ids.append(commit_id)

    # Phase 2: BFS walk of the commit DAG.
    visited: set[str] = set()
    queue: deque[str] = deque(tip_commit_ids)

    while queue:
        cid = queue.popleft()
        if cid in visited:
            continue
        visited.add(cid)

        if len(visited) >= _MAX_COMMITS:
            logger.warning(
                "⚠️ verify: reached %d-commit limit — stopping early", _MAX_COMMITS
            )
            break

        commit = read_commit(root, cid)
        if commit is None:
            failures.append(VerifyFailure(
                kind="commit",
                id=cid,
                error="commit file missing or unreadable",
            ))
            if fail_fast:
                break
            continue

        commits_checked += 1

        # Phase 5: verify Ed25519 signature.
        if commit.signature:
            signatures_checked += 1
            sig = commit.signature
            pub_raw = commit.signer_public_key

            # Dispatch on algorithm prefix — the prefix is the sole discriminator.
            # "ed25519:<base64url>" is the only current algorithm.
            # Unknown prefix → report and keep walking the BFS.
            if sig_algo(sig) != DEFAULT_SIGN_ALGO:
                failures.append(VerifyFailure(
                    kind="signature",
                    id=cid,
                    error=(
                        f"commit {cid} has unrecognised signature algorithm "
                        f"{sig_algo(sig)!r} — upgrade muse or re-sign"
                    ),
                ))
                if fail_fast:
                    break
            elif sig_algo(pub_raw) != DEFAULT_SIGN_ALGO:
                failures.append(VerifyFailure(
                    kind="key_missing",
                    id=cid,
                    error=(
                        f"signed commit {cid} has unrecognised public key "
                        f"algorithm {sig_algo(pub_raw)!r} — re-sign to fix"
                    ),
                ))
                if fail_fast:
                    break
            else:
                try:
                    _, pub_bytes = decode_pubkey(pub_raw)
                except ValueError:
                    pub_bytes = b""
                signed_input = provenance_payload(
                    cid,
                    author=commit.author,
                    agent_id=commit.agent_id,
                    model_id=commit.model_id,
                    toolchain_id=commit.toolchain_id,
                    prompt_hash=commit.prompt_hash,
                    committed_at=commit.committed_at.isoformat(),
                )
                if not pub_bytes or not verify_commit_ed25519(signed_input, sig, pub_bytes):
                    failures.append(VerifyFailure(
                        kind="signature",
                        id=cid,
                        error=(
                            f"Ed25519 signature INVALID for commit {cid} "
                            f"(agent {commit.agent_id!r}, key {commit.signer_key_id!r}) "
                            "— commit record may have been tampered with"
                        ),
                    ))
                    if fail_fast:
                        break

        # Phase 3: check snapshot.
        snap_id = commit.snapshot_id
        if snap_id not in verified_snapshots:
            verified_snapshots.add(snap_id)
            snap = read_snapshot(root, snap_id)
            if snap is None:
                failures.append(VerifyFailure(
                    kind="snapshot",
                    id=snap_id,
                    error=f"snapshot missing (referenced by commit {cid})",
                ))
                if fail_fast:
                    break
            else:
                snapshots_checked += 1

                # Phase 4: check objects referenced by this snapshot.
                for rel_path, obj_id in snap.manifest.items():
                    if obj_id in verified_objects:
                        continue
                    verified_objects.add(obj_id)
                    should_stop = _check_object(
                        root, obj_id, rel_path,
                        check_objects=check_objects,
                        promisor_remotes=promisor_remotes,
                        strict=strict,
                        failures=failures,
                        objects_checked_ref=objects_checked_ref,
                        promised_objects_ref=promised_objects_ref,
                        fail_fast=fail_fast,
                    )
                    if should_stop:
                        break
                if fail_fast and failures:
                    break

        # Enqueue parents — stop at shallow graft boundary.
        # If the current commit is itself a graft, count it and don't descend.
        if cid in shallow_set:
            shallow_commits += 1
            # Walk all ancestors of this graft (commit records only, no object
            # verification) and add their snapshot IDs to verified_snapshots.
            # This prevents the orphan sweep from flagging objects that are
            # legitimately beyond the shallow boundary.
            _collect_ancestor_snapshots(
                root, commit, visited=visited, verified_snapshots=verified_snapshots
            )
        else:
            for parent_id in (commit.parent_commit_id, commit.parent2_commit_id):
                if not parent_id:
                    continue
                queue.append(parent_id)

        if fail_fast and failures:
            break

    # Snapshot store sweep — orphaned snapshots not reachable from branch refs.
    # Snapshots live in the unified object store (same as blobs/commits).
    # Walk every stored object, identify snapshot-typed ones by their header.
    if not (fail_fast and failures):
        import json as _json_mod
        for snap_id, obj_file in iter_stored_objects(root):
            if obj_file.is_symlink():
                continue
            try:
                raw = obj_file.read_bytes()
                null_idx = raw.index(b"\0")
                type_str = raw[:null_idx].decode(errors="replace").split(" ", 1)[0]
            except (ValueError, OSError):
                continue
            if type_str != "snapshot":
                continue
            if snap_id in verified_snapshots:
                continue
            verified_snapshots.add(snap_id)
            snap = read_snapshot(root, snap_id)
            if snap is None:
                failures.append(VerifyFailure(
                    kind="snapshot",
                    id=snap_id,
                    error="orphan snapshot file missing or unreadable",
                ))
                if fail_fast:
                    break
                continue
            snapshots_checked += 1
            for rel_path, obj_id in snap.manifest.items():
                if obj_id in verified_objects:
                    continue
                verified_objects.add(obj_id)
                should_stop = _check_object(
                    root, obj_id, rel_path,
                    check_objects=check_objects,
                    promisor_remotes=promisor_remotes,
                    strict=strict,
                    failures=failures,
                    objects_checked_ref=objects_checked_ref,
                    promised_objects_ref=promised_objects_ref,
                    fail_fast=fail_fast,
                    orphan_label=f"orphan snapshot {snap_id}",
                )
                if should_stop:
                    break
            if fail_fast and failures:
                break

    nothing_checked = (
        refs_checked == 0
        and commits_checked == 0
        and snapshots_checked == 0
        and promised_objects_ref[0] == 0
    )

    return _make_result(
        refs_checked, commits_checked, snapshots_checked,
        objects_checked_ref[0], signatures_checked, failures,
        shallow_commits=shallow_commits,
        promised_objects=promised_objects_ref[0],
        is_shallow=bool(shallow_set),
        promisor_remotes=promisor_remotes,
        nothing_checked=nothing_checked,
    )

def _make_result(
    refs_checked: int,
    commits_checked: int,
    snapshots_checked: int,
    objects_checked: int,
    signatures_checked: int,
    failures: list[VerifyFailure],
    *,
    shallow_commits: int = 0,
    promised_objects: int = 0,
    is_shallow: bool = False,
    promisor_remotes: list[str] | None = None,
    nothing_checked: bool = False,
) -> VerifyResult:
    """Construct a :class:`VerifyResult` from the walk counters."""
    return VerifyResult(
        refs_checked=refs_checked,
        commits_checked=commits_checked,
        snapshots_checked=snapshots_checked,
        objects_checked=objects_checked,
        signatures_checked=signatures_checked,
        shallow_commits=shallow_commits,
        promised_objects=promised_objects,
        is_shallow=is_shallow,
        promisor_remotes=list(promisor_remotes) if promisor_remotes else [],
        all_ok=len(failures) == 0,
        nothing_checked=nothing_checked,
        failures=failures,
    )
