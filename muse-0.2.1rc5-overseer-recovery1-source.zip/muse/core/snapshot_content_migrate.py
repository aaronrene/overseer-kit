"""Unified-store snapshot-content-ID migration — muse#83.

Standalone, explicitly-invoked repair tool for a class of corruption
distinct from `muse.core.migrate`'s v1->v2 commit-ID-formula and
legacy-directory-layout migrations: a commit whose *declared*
``snapshot_id`` never matched its own manifest, since the moment it was
created (found during musehub#134's investigation — see
``docs/issues/snapshot-content-id-migration-plan.md``).

`muse.core.migrate`'s existing snapshot/commit ID recomputation
(``migrate_snapshot_ids`` / ``migrate_commit_ids``) only reads the *legacy*
pre-unified-object-store layout (``.muse/snapshots/sha256/*.msgpack``,
``.muse/commits/sha256/*.msgpack``); a repo already migrated to the unified
``.muse/objects/`` store is untouched by those functions. The `migrate()`
orchestrator's own commit rewrite (`_make_canonical_dict`) reads
``snapshot_id`` straight off the existing record and never validates it
against the manifest. Nothing in the existing migration engine detects or
repairs this condition. This module does, and only this.

Deliberately NOT folded into `muse code migrate`'s default pass list — this
is a one-time repair for one known corruption event, not a condition that
should ever recur once musehub#134's write-path fix is deployed. Wiring it
into the general migration path would risk it firing unexpectedly against
unrelated repos.

Non-negotiable invariants (see the plan doc for full rationale):
  1. Non-destructive — old objects are never deleted, only new corrected
     objects are added under their newly-computed IDs.
  2. A snapshot whose declared ID already reproduces its manifest is left
     completely untouched — no id_map entry, no write.
  3. Every commit whose ID changes (directly, via a corrected snapshot, or
     transitively, via a rewritten parent) is re-signed with the current
     signing identity. A stale signature over a superseded commit_id is a
     silent authenticity regression.
  4. Refs, remote-tracking refs, and reflogs are updated via the existing,
     already-tested generic passes in `muse.core.migrate`.
"""

from __future__ import annotations

import json
import logging
import pathlib
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from muse.core.ids import hash_commit, hash_snapshot
from muse.core.migrate import (
    _collect_all_commits,
    _committed_at_iso,
    _migrate_refs,
    _migrate_reflogs,
    _migrate_remote_refs,
    _topological_sort,
)
from muse.core.object_store import object_path
from muse.core.paths import objects_dir
from muse.core.provenance import encode_public_key, provenance_payload, sign_commit_ed25519

if TYPE_CHECKING:
    from muse.core.transport import SigningIdentity

logger = logging.getLogger(__name__)

_IdMap = dict[str, str]


@dataclass
class SnapshotContentMigrateResult:
    """Result of :func:`migrate_snapshot_content_ids`."""

    id_map: _IdMap = field(default_factory=dict)
    snapshots_written: int = 0
    snapshots_skipped: int = 0
    dry_run: bool = False


def migrate_snapshot_content_ids(
    repo_root: pathlib.Path,
    dry_run: bool = False,
) -> SnapshotContentMigrateResult:
    """Detect and correct unified-store snapshots whose declared ID does not
    reproduce their own manifest.

    For each ``snapshot <size>\\0<json>`` object in ``.muse/objects/sha256/``:

    1. Recomputes ``hash_snapshot(manifest, directories)`` from the object's
       own stored content.
    2. If the recomputed ID matches the declared ``snapshot_id``: does
       nothing. This is the common case — 1427 of 1429 snapshots on
       ``gabriel/musehub`` fall here.
    3. If it does not match: records ``old_id -> new_id`` and writes a
       corrected copy of the object under the new ID. The old object is
       never deleted (invariant 1).

    Does not read ``.muse/snapshots/`` (the legacy layout) at all — that is
    `muse.core.migrate.migrate_snapshot_ids`'s job, unaffected by this
    function.

    Args:
        repo_root: Repository root (contains ``.muse/``).
        dry_run:   When True, compute the id_map but write nothing.

    Returns:
        :class:`SnapshotContentMigrateResult` with the id_map and write counts.
    """
    result = SnapshotContentMigrateResult(dry_run=dry_run)
    obj_dir = objects_dir(repo_root) / "sha256"
    if not obj_dir.exists():
        return result

    for path in sorted(obj_dir.glob("*/*")):
        if not path.is_file():
            continue
        try:
            data = path.read_bytes()
        except OSError as exc:
            logger.warning("Skipping unreadable object %s: %s", path, exc)
            continue
        if not data.startswith(b"snapshot "):
            continue
        try:
            null_idx = data.index(b"\x00")
            raw = json.loads(data[null_idx + 1:])
        except (ValueError, UnicodeDecodeError) as exc:
            logger.warning("Skipping unparsable snapshot %s: %s", path, exc)
            continue

        old_id: str = raw.get("snapshot_id", "")
        if not old_id:
            continue

        manifest: dict[str, str] = dict(raw.get("manifest") or {})
        directories: list[str] = list(raw.get("directories") or [])
        recomputed = hash_snapshot(manifest, directories or None)

        if recomputed == old_id:
            continue  # already correct — provably untouched (invariant 2)

        result.id_map[old_id] = recomputed

        new_path = object_path(repo_root, recomputed)
        if new_path.exists():
            result.snapshots_skipped += 1
            continue

        if not dry_run:
            updated = dict(raw)
            updated["snapshot_id"] = recomputed
            payload = json.dumps(updated, separators=(",", ":")).encode()
            header = f"snapshot {len(payload)}\0".encode()
            new_path.parent.mkdir(parents=True, exist_ok=True)
            new_path.write_bytes(header + payload)

        result.snapshots_written += 1

    return result


@dataclass
class CommitContentMigrateResult:
    """Result of :func:`migrate_commit_ids_cascade`."""

    id_map: _IdMap = field(default_factory=dict)
    commits_written: int = 0
    commits_skipped: int = 0
    commits_signed: int = 0
    dry_run: bool = False


def migrate_commit_ids_cascade(
    repo_root: pathlib.Path,
    snapshot_id_map: _IdMap,
    signing_identity: "SigningIdentity",
    dry_run: bool = False,
) -> CommitContentMigrateResult:
    """Cascade a snapshot-ID correction through the commit DAG, re-signing
    every affected commit.

    A commit is affected (gets a new ``commit_id`` and is re-signed) when:
      - its own ``snapshot_id`` is a key in *snapshot_id_map*, OR
      - either parent's ``commit_id`` was itself rewritten by this same pass
        (transitive cascade, resolved in topological order).

    Every unaffected commit is left completely untouched — same object,
    same ID, same signature (invariant: no changes outside the blast
    radius).

    Unlike `muse.core.migrate.migrate_commit_ids` (which recomputes
    `commit_id` but never touches `signature`/`signer_public_key`), every
    commit whose ID changes here is re-signed with *signing_identity* --
    a stale signature over a superseded commit_id is a silent authenticity
    regression, not a cosmetic detail.

    Args:
        repo_root:        Repository root (contains ``.muse/``).
        snapshot_id_map:  Old snapshot ID -> new snapshot ID, from
                          :func:`migrate_snapshot_content_ids`.
        signing_identity: Identity used to re-sign every affected commit.
        dry_run:          When True, compute the id_map but write nothing.

    Returns:
        :class:`CommitContentMigrateResult` with the id_map and write counts.
    """
    result = CommitContentMigrateResult(dry_run=dry_run)
    all_commits = _collect_all_commits(repo_root)
    order = _topological_sort(all_commits)

    _, pub_str = encode_public_key(signing_identity.private_key)  # type: ignore[arg-type]

    def _resolve(old_id: str, snap_map: _IdMap, commit_map: _IdMap) -> tuple[list[str], str, bool]:
        raw, _ = all_commits[old_id]
        p1 = raw.get("parent_commit_id")
        p2 = raw.get("parent2_commit_id")
        new_p1 = commit_map.get(p1, p1) if p1 else None
        new_p2 = commit_map.get(p2, p2) if p2 else None
        parent_ids = [x for x in (new_p1, new_p2) if x]

        old_snap = raw.get("snapshot_id", "")
        new_snap = snap_map.get(old_snap, old_snap)

        affected = (new_snap != old_snap) or (new_p1 != p1) or (new_p2 != p2)
        return parent_ids, new_snap, affected

    # Pass 1: build the id_map (parents-before-children order — a parent's
    # new ID is already known when its children are processed).
    commit_id_map: _IdMap = {}
    for old_id in order:
        raw, _ = all_commits[old_id]
        parent_ids, new_snap, affected = _resolve(old_id, snapshot_id_map, commit_id_map)
        committed_at_iso = _committed_at_iso(raw)
        signer = pub_str if affected else (raw.get("signer_public_key", "") or "")
        new_id = hash_commit(
            parent_ids=parent_ids,
            snapshot_id=new_snap,
            message=raw.get("message", ""),
            committed_at_iso=committed_at_iso,
            author=raw.get("author", ""),
            signer_public_key=signer,
        )
        if new_id != old_id:
            commit_id_map[old_id] = new_id

    result.id_map = dict(commit_id_map)

    # Pass 2: write corrected + re-signed records.
    for old_id in order:
        new_id = commit_id_map.get(old_id, old_id)
        if new_id == old_id:
            continue  # untouched — outside the blast radius

        raw, _ = all_commits[old_id]
        obj_path = object_path(repo_root, new_id)
        if obj_path.exists():
            result.commits_skipped += 1
            continue

        p1 = raw.get("parent_commit_id")
        p2 = raw.get("parent2_commit_id")
        new_p1 = commit_id_map.get(p1, p1) if p1 else None
        new_p2 = commit_id_map.get(p2, p2) if p2 else None
        old_snap = raw.get("snapshot_id", "")
        new_snap = snapshot_id_map.get(old_snap, old_snap)
        committed_at_iso = _committed_at_iso(raw)
        author = raw.get("author", "")

        payload = provenance_payload(
            commit_id=new_id,
            author=author,
            agent_id=raw.get("agent_id", ""),
            model_id=raw.get("model_id", ""),
            toolchain_id=raw.get("toolchain_id", ""),
            prompt_hash=raw.get("prompt_hash", ""),
            committed_at=committed_at_iso,
        )
        sig = sign_commit_ed25519(payload, signing_identity.private_key)  # type: ignore[arg-type]

        if not dry_run:
            updated = dict(raw)
            updated["commit_id"] = new_id
            updated["snapshot_id"] = new_snap
            updated["parent_commit_id"] = new_p1
            updated["parent2_commit_id"] = new_p2
            updated["committed_at"] = committed_at_iso
            updated["signature"] = sig
            updated["signer_public_key"] = pub_str
            payload_json = json.dumps(updated, separators=(",", ":"), default=str).encode()
            header = f"commit {len(payload_json)}\0".encode()
            obj_path.parent.mkdir(parents=True, exist_ok=True)
            obj_path.write_bytes(header + payload_json)

        result.commits_written += 1
        result.commits_signed += 1

    return result


@dataclass
class SnapshotContentIdMigrationResult:
    """Combined result of the full snapshot-content-ID migration."""

    snapshot_id_map: _IdMap = field(default_factory=dict)
    commit_id_map: _IdMap = field(default_factory=dict)
    snapshots_written: int = 0
    commits_written: int = 0
    commits_signed: int = 0
    refs_updated: int = 0
    remote_refs_updated: int = 0
    reflogs_updated: int = 0
    dry_run: bool = False


def migrate_snapshot_content_and_cascade(
    repo_root: pathlib.Path,
    signing_identity: "SigningIdentity",
    dry_run: bool = False,
) -> SnapshotContentIdMigrationResult:
    """Full repair: detect+correct snapshot IDs, cascade+resign commits,
    then update refs/remote-refs/reflogs to match.

    Composes :func:`migrate_snapshot_content_ids`,
    :func:`migrate_commit_ids_cascade`, and the existing generic
    `muse.core.migrate` ref/reflog passes (reused unchanged — they are
    already generic over any ``id_map: dict[str, str]``).
    """
    snap_result = migrate_snapshot_content_ids(repo_root, dry_run=dry_run)
    commit_result = migrate_commit_ids_cascade(
        repo_root, snap_result.id_map, signing_identity, dry_run=dry_run,
    )
    refs_updated = _migrate_refs(repo_root, commit_result.id_map, dry_run=dry_run)
    remote_refs_updated = _migrate_remote_refs(repo_root, commit_result.id_map, dry_run=dry_run)
    reflogs_updated = _migrate_reflogs(repo_root, commit_result.id_map, dry_run=dry_run)

    return SnapshotContentIdMigrationResult(
        snapshot_id_map=snap_result.id_map,
        commit_id_map=commit_result.id_map,
        snapshots_written=snap_result.snapshots_written,
        commits_written=commit_result.commits_written,
        commits_signed=commit_result.commits_signed,
        refs_updated=refs_updated,
        remote_refs_updated=remote_refs_updated,
        reflogs_updated=reflogs_updated,
        dry_run=dry_run,
    )
