"""muse.core.secp256k1_sign — BIP32 secp256k1 derivation, EIP-191 signing, AVAX addresses.

All cryptographic operations delegate to battle-tested, audited libraries:

- ``hmac`` + ``hashlib`` (Python stdlib) — HMAC-SHA512 for BIP32 child derivation
- ``eth_keys`` (Ethereum Foundation) — secp256k1 signing, recovery, address derivation
- ``Crypto.Hash.keccak`` (pycryptodome) — keccak256 for EVM address derivation

Nothing in this module implements cryptographic primitives.

BIP32 Derivation
----------------
Derives secp256k1 keys from a BIP39 seed via the standard BIP32 HD wallet
algorithm (``key="Bitcoin seed"``).  Supports both hardened (``index >= 2^31``)
and unhardened derivation at every path level.

Path structure used by Muse
---------------------------
::

    m / 44' / 60' / account' / 0 / index    — AVAX C-Chain (EVM)
    │    │    │      │          │    └──── Address index (unhardened, 0=default)
    │    │    │      │          └───────── Change (unhardened, 0=external)
    │    │    │      └──────────────────── Account (hardened)
    │    │    └─────────────────────────── Coin type 60 = Ethereum / EVM
    │    └──────────────────────────────── Purpose 44 (BIP44)
    └───────────────────────────────────── Master key ("Bitcoin seed" HMAC root)

This path is compatible with MetaMask, Ledger, Trezor, and all EVM tooling.

EIP-191 Signing
---------------
Signs a UTF-8 message with the Ethereum personal_sign prefix::

    "\\x19Ethereum Signed Message:\\n" + str(len(msg)) + msg

The signature is a 65-byte compact secp256k1 signature ``(r || s || v)`` where
``v ∈ {27, 28}`` (legacy Ethereum recovery ID).  This is the format accepted
by ``ecrecover`` on EVM chains and the Avalanche contract layer.

AVAX C-Chain Addresses
-----------------------
Derived from the secp256k1 uncompressed public key via::

    uncompressed = public_key.to_uncompressed_bytes()  # 64 bytes (no prefix)
    address_bytes = keccak256(uncompressed)[12:]        # last 20 bytes
    address = eip55_checksum(address_bytes.hex())

This is identical to the standard Ethereum/EVM address format.

Examples
--------
::

    from muse.core.bip39 import mnemonic_to_seed
    from muse.core.secp256k1_sign import derive_avax_key, avax_c_chain_address, eip191_sign

    seed = mnemonic_to_seed("abandon abandon abandon abandon abandon "
                            "abandon abandon abandon abandon abandon abandon about")

    key = derive_avax_key(seed, account=0, index=0)
    address = avax_c_chain_address(key.public_key)
    # "0x9858EfFD232B4033E47d90003D41EC34EcaedA94"

    sig = eip191_sign(key, "Hello Muse")
    assert len(sig) == 65
"""

import hashlib
import hmac
import struct
from dataclasses import dataclass

from Crypto.Hash import keccak as _keccak  # pycryptodome — battle-tested Keccak
from eth_keys import keys as _eth_keys  # Ethereum Foundation secp256k1

# ---------------------------------------------------------------------------
# Constants — all public secp256k1 parameters (not secrets)
# ---------------------------------------------------------------------------

#: secp256k1 group order n (prime — from SEC 2 specification).
_SECP256K1_N: int = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141

#: BIP32 HMAC key for secp256k1 master key derivation.
_BIP32_BITCOIN_SEED: bytes = b"Bitcoin seed"

#: BIP44 purpose index (hardened).
_BIP44_PURPOSE: int = 44

#: BIP44 coin type for Ethereum / AVAX C-Chain (hardened).
_COIN_TYPE_ETH: int = 60

#: Hardened index offset — indices >= this value are hardened.
_HARDENED: int = 0x80000000

# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class Bip32Error(ValueError):
    """Raised when BIP32 derivation fails.

    Common causes:
    - Derived child key scalar is zero or >= secp256k1_n (astronomically rare).
    - Unhardened derivation attempted on an invalid key.
    - Malformed derivation path.
    """

# ---------------------------------------------------------------------------
# Internal: BIP32 key node
# ---------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class _Bip32Node:
    """Internal BIP32 key node: private scalar + chain code.

    Attributes:
        private_int:  Private key scalar (integer, 0 < scalar < n).
        chain_code:   32-byte BIP32 chain code.
    """

    private_int: int
    chain_code: bytes

def _compressed_pubkey(private_int: int) -> bytes:
    """Return the 33-byte compressed SEC public key for a secp256k1 private scalar.

    Uses ``eth_keys`` to derive the public key — no custom EC math.

    Args:
        private_int: Private key scalar (0 < scalar < secp256k1_n).

    Returns:
        33-byte compressed point in SEC format (02/03 prefix).
    """
    priv = _eth_keys.PrivateKey(private_int.to_bytes(32, "big"))
    return priv.public_key.to_compressed_bytes()  # 33 bytes: 02/03 || x_be32

def _derive_child(node: _Bip32Node, index: int) -> _Bip32Node:
    """Derive a BIP32 child node at *index* (hardened or unhardened).

    Args:
        node:  Parent BIP32 node.
        index: Child index.  Use ``index | 0x80000000`` for hardened.

    Returns:
        Child :class:`_Bip32Node`.

    Raises:
        Bip32Error: If the derived scalar is invalid (zero or >= n).
    """
    if index >= _HARDENED:
        # Hardened: data = 0x00 || parent_private_key_bytes || index_be4
        data = b"\x00" + node.private_int.to_bytes(32, "big") + struct.pack(">I", index)
    else:
        # Unhardened: data = compressed_parent_pubkey || index_be4
        data = _compressed_pubkey(node.private_int) + struct.pack(">I", index)

    I = hmac.new(node.chain_code, data, hashlib.sha512).digest()  # noqa: N806
    IL, IR = I[:32], I[32:]  # noqa: N806

    IL_int = int.from_bytes(IL, "big")  # noqa: N806
    if IL_int >= _SECP256K1_N:
        raise Bip32Error(f"BIP32: IL >= secp256k1_n at index {index} — retry with next index")

    child_int = (IL_int + node.private_int) % _SECP256K1_N
    if child_int == 0:
        raise Bip32Error(f"BIP32: child scalar is zero at index {index} — retry with next index")

    return _Bip32Node(private_int=child_int, chain_code=IR)

def _parse_path(path: str) -> list[int]:
    """Parse a BIP32 path string into a list of index integers.

    ``'`` suffix means hardened (``index | 0x80000000``).

    Args:
        path: Path string, e.g. ``"m/44'/60'/0'/0/0"``.

    Returns:
        List of index integers.

    Raises:
        Bip32Error: If the path is malformed.
    """
    if not path.startswith("m"):
        raise Bip32Error(f"BIP32 path must start with 'm': {path!r}")
    parts = path.lstrip("m").lstrip("/").split("/")
    indices: list[int] = []
    for part in parts:
        if not part:
            continue
        hardened = part.endswith("'")
        raw = part.rstrip("'")
        try:
            idx = int(raw)
        except ValueError:
            raise Bip32Error(f"Invalid BIP32 path component: {part!r}")
        if idx < 0:
            raise Bip32Error(f"Negative BIP32 index: {idx}")
        indices.append(idx | _HARDENED if hardened else idx)
    return indices

# ---------------------------------------------------------------------------
# Public: BIP32 derivation
# ---------------------------------------------------------------------------

def bip32_master_key(seed: bytes) -> _Bip32Node:
    """Derive the BIP32 secp256k1 master private key from a 64-byte BIP39 seed.

    Uses HMAC-SHA512 with ``key="Bitcoin seed"`` per the BIP32 specification.

    Args:
        seed: 64-byte BIP39 seed from :func:`muse.core.bip39.mnemonic_to_seed`.

    Returns:
        :class:`_Bip32Node` (private scalar + chain code) for the master key.

    Raises:
        Bip32Error: If the derived master scalar is zero or >= secp256k1_n
            (practically impossible with any real seed).

    Examples::

        seed = mnemonic_to_seed("abandon abandon ... about")
        master = bip32_master_key(seed)
    """
    I = hmac.new(_BIP32_BITCOIN_SEED, seed, hashlib.sha512).digest()  # noqa: N806
    IL, IR = I[:32], I[32:]  # noqa: N806
    IL_int = int.from_bytes(IL, "big")  # noqa: N806
    if IL_int == 0 or IL_int >= _SECP256K1_N:
        raise Bip32Error("BIP32: master key scalar is invalid — seed is unusable")
    return _Bip32Node(private_int=IL_int, chain_code=IR)

def bip32_derive_path(seed: bytes, path: str) -> _Bip32Node:
    """Derive a BIP32 secp256k1 key at an arbitrary path from a BIP39 seed.

    Args:
        seed: 64-byte BIP39 seed.
        path: BIP32 path string, e.g. ``"m/44'/60'/0'/0/0"``.

    Returns:
        :class:`_Bip32Node` at the requested path.

    Raises:
        Bip32Error: If the path is malformed or derivation fails.

    Examples::

        node = bip32_derive_path(seed, "m/44'/60'/0'/0/0")
    """
    node = bip32_master_key(seed)
    for idx in _parse_path(path):
        node = _derive_child(node, idx)
    return node

def derive_avax_key(
    seed: bytes,
    account: int = 0,
    index: int = 0,
) -> _eth_keys.PrivateKey:
    """Derive the AVAX C-Chain (EVM) signing key at BIP44 path ``m/44'/60'/account'/0/index``.

    This path is compatible with MetaMask, Ledger Ethereum app, Trezor, and all
    EVM tooling.  The derived key can sign EIP-191 messages and EIP-155
    transactions accepted by Avalanche C-Chain.

    Args:
        seed:    64-byte BIP39 seed from :func:`muse.core.bip39.mnemonic_to_seed`.
        account: BIP44 account index (>= 0, hardened in path).  Default: 0.
        index:   Address index within the account (>= 0, unhardened).  Default: 0.

    Returns:
        ``eth_keys.PrivateKey`` on secp256k1 — ready for signing and address derivation.

    Raises:
        Bip32Error: If any derivation step produces an invalid scalar.

    Examples::

        seed = mnemonic_to_seed("abandon ... about")
        key = derive_avax_key(seed)
        address = avax_c_chain_address(key.public_key)
        # "0x9858EfFD232B4033E47d90003D41EC34EcaedA94"
    """
    path = f"m/{_BIP44_PURPOSE}'/{_COIN_TYPE_ETH}'/{account}'/0/{index}"
    node = bip32_derive_path(seed, path)
    return _eth_keys.PrivateKey(node.private_int.to_bytes(32, "big"))

# ---------------------------------------------------------------------------
# Public: AVAX / EVM addresses
# ---------------------------------------------------------------------------

def keccak256(data: bytes) -> bytes:
    """Return the 32-byte Keccak-256 digest of *data*.

    Uses ``pycryptodome`` (``Crypto.Hash.keccak``) — the battle-tested
    Keccak implementation.  This is Ethereum's keccak256, **not** FIPS SHA3-256
    (they use different padding).

    Args:
        data: Arbitrary bytes to hash.

    Returns:
        32-byte Keccak-256 digest.

    Examples::

        assert keccak256(b"").hex() == "c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470"
    """
    h = _keccak.new(digest_bits=256)
    h.update(data)
    return h.digest()

def eip55_checksum(address_hex: str) -> str:
    """Apply EIP-55 mixed-case checksum encoding to a hex Ethereum address.

    Args:
        address_hex: 40-character lowercase hex string (without ``0x`` prefix).

    Returns:
        EIP-55 checksummed address with ``0x`` prefix, e.g. ``"0xDe0B295..."``.

    Examples::

        eip55_checksum("de0b295669a9fd93d5f28d9ec85e40f4cb697bae")
        # "0xDe0B295669a9FD93d5F28D9Ec85E40f4cb697BAE"
    """
    addr_lower = address_hex.lower()
    checksum_hash = keccak256(addr_lower.encode("ascii")).hex()
    result = "".join(
        c.upper() if int(checksum_hash[i], 16) >= 8 else c
        for i, c in enumerate(addr_lower)
    )
    return f"0x{result}"

def avax_c_chain_address(public_key: _eth_keys.PublicKey) -> str:
    """Derive the AVAX C-Chain (EVM) address from a secp256k1 public key.

    Delegates entirely to ``eth_keys.PublicKey.to_checksum_address()`` which
    computes ``keccak256(x || y)[12:]`` and applies EIP-55 encoding internally.

    Args:
        public_key: ``eth_keys.PublicKey`` on secp256k1.

    Returns:
        EIP-55 checksummed ``0x``-prefixed address string.

    Examples::

        key = derive_avax_key(seed)
        addr = avax_c_chain_address(key.public_key)
        # "0x9858EfFD232B4033E47d90003D41EC34EcaedA94"
    """
    return public_key.to_checksum_address()

# ---------------------------------------------------------------------------
# Public: EIP-191 signing
# ---------------------------------------------------------------------------

def eip191_message(message: str | bytes) -> bytes:
    """Build the EIP-191 canonical bytes for ``personal_sign``.

    Prepends the Ethereum personal-sign prefix so the message cannot be
    confused with a raw transaction::

        b"\\x19Ethereum Signed Message:\\n" + str(len(msg)).encode() + msg

    Args:
        message: UTF-8 string or raw bytes to sign.

    Returns:
        Prefixed bytes ready for keccak256 hashing and signing.

    Examples::

        msg = eip191_message("Hello Muse")
        # b"\\x19Ethereum Signed Message:\\n10Hello Muse"
    """
    msg_bytes = message.encode("utf-8") if isinstance(message, str) else message
    prefix = f"\x19Ethereum Signed Message:\n{len(msg_bytes)}".encode("utf-8")
    return prefix + msg_bytes

def eip191_sign(private_key: _eth_keys.PrivateKey, message: str | bytes) -> bytes:
    """Sign a message with EIP-191 ``personal_sign`` encoding.

    The returned 65-byte signature is in ``(r || s || v)`` compact form where
    ``v ∈ {27, 28}`` (legacy Ethereum recovery ID).  This is the format
    accepted by ``ecrecover`` on EVM chains including Avalanche C-Chain.

    Signing is delegated entirely to ``eth_keys`` (Ethereum Foundation library).

    Args:
        private_key: ``eth_keys.PrivateKey`` (e.g. from :func:`derive_avax_key`).
        message: UTF-8 string or bytes to sign.

    Returns:
        65-byte signature: ``r`` (32 bytes) + ``s`` (32 bytes) + ``v`` (1 byte,
        value 27 or 28).

    Examples::

        key = derive_avax_key(seed)
        sig = eip191_sign(key, "MPAY2\\ngabriel\\nalice\\n0.001\\nAVAX\\nnonce\\n1234")
        assert len(sig) == 65
    """
    digest = keccak256(eip191_message(message))
    sig = private_key.sign_msg_hash(digest)
    # eth_keys v is 0 or 1; EVM ecrecover expects 27 or 28.
    sig_bytes = sig.to_bytes()  # r(32) || s(32) || v(0 or 1)
    return sig_bytes[:64] + bytes([sig_bytes[64] + 27])

def eip191_verify(
    signature: bytes,
    message: str | bytes,
    expected_address: str,
) -> bool:
    """Verify an EIP-191 signature against an expected AVAX C-Chain address.

    Recovers the signer's public key via ``eth_keys`` and checks that the
    derived EVM address matches *expected_address*.  No custom EC math.

    Args:
        signature:        65-byte EIP-191 signature from :func:`eip191_sign`.
        message:          The original message (string or bytes).
        expected_address: EIP-55 checksummed ``0x``-prefixed address, e.g.
            ``"0x9858EfFD232B4033E47d90003D41EC34EcaedA94"``.

    Returns:
        ``True`` if the signature was produced by *expected_address*.

    Examples::

        key = derive_avax_key(seed)
        sig = eip191_sign(key, "Hello Muse")
        assert eip191_verify(sig, "Hello Muse", avax_c_chain_address(key.public_key))
    """
    if len(signature) != 65:
        return False

    v_byte = signature[64]
    if v_byte not in (27, 28):
        return False

    # Convert v from 27/28 back to 0/1 for eth_keys.
    eth_sig_bytes = signature[:64] + bytes([v_byte - 27])
    digest = keccak256(eip191_message(message))

    try:
        sig = _eth_keys.Signature(signature_bytes=eth_sig_bytes)
        recovered_pub = sig.recover_public_key_from_msg_hash(digest)
        return avax_c_chain_address(recovered_pub).lower() == expected_address.lower()
    except Exception:
        return False
