"""Multi-format documentation renderer for ``muse code docs``.

Converts a :class:`~muse.core.doc_extractor.DocReport` into one of four
output formats:

``json``
    Machine-readable, AI-ready.  The full :class:`DocReport` TypedDict
    serialised as pretty-printed JSON.  Suitable for ingestion by LLMs,
    RAG pipelines, and downstream tooling.

``html``
    Standalone HTML page with an inline sidebar TOC, health bars, version
    badges, caller/callee sections, and linked test lists.  Zero external
    dependencies — a single file that opens in any browser.

``markdown``
    GitHub-compatible Markdown with a generated table of contents, one
    ``##`` heading per symbol, and structured sections for callers, callees,
    version history, and test linkage.

``text``
    Terminal-friendly columnar table similar to ``muse code symbols``, with
    health score, stale indicator, and doc-debt summary.

Security
--------
All user-visible strings (symbol names, docstrings, file paths) are escaped
appropriately before embedding in HTML or JSON output.  The renderer never
evaluates or executes any string from the report.

Performance
-----------
Renderers operate in a single linear pass over the ``symbols`` list.
On a 400-symbol report the HTML renderer completes in <10 ms.
"""

import html as _html_module
import json
import logging
from typing import Literal, TypedDict

from muse.core.doc_extractor import DocReport, DocSummary, SymbolDoc

type _BadgeMap = dict[str, str]
logger = logging.getLogger(__name__)

RenderFormat = Literal["json", "html", "markdown", "text"]
"""Supported output formats for :func:`render`."""

# ---------------------------------------------------------------------------
# JSON renderer
# ---------------------------------------------------------------------------

def render_json(report: DocReport) -> str:
    """Return the full *report* as pretty-printed JSON.

    The output is structured identically to the :class:`DocReport` TypedDict —
    every field is present, making it directly usable by LLMs and agent
    pipelines.

    Args:
        report: The documentation report to serialise.
    """
    return json.dumps(report, indent=2, ensure_ascii=False)

# ---------------------------------------------------------------------------
# Text renderer
# ---------------------------------------------------------------------------

_HEALTH_BAR_WIDTH = 10

def _health_bar(score: float) -> str:
    """Return a compact ASCII health bar, e.g. ``[████████░░]``."""
    filled = round(score * _HEALTH_BAR_WIDTH)
    empty = _HEALTH_BAR_WIDTH - filled
    return f"[{'█' * filled}{'░' * empty}]"

def _stale_flag(doc: SymbolDoc) -> str:
    return "⚠" if "stale_impl" in doc["doc_health_reasons"] else " "

def render_text(report: DocReport) -> str:
    """Return a terminal-friendly columnar view of *report*.

    Columns: HEALTH  ST  KIND       NAME                              FILE
    Health bar + score, stale flag, symbol kind, name, file path.

    Args:
        report: The documentation report to render.
    """
    lines: list[str] = []
    s = report["summary"]

    lines.append(
        f"Muse docs — commit {report['commit_id']}  "
        f"generated {report['generated_at'][:19]}"
    )
    lines.append(
        f"  symbols={s['total_symbols']}  "
        f"documented={s['documented']}  "
        f"undocumented={s['undocumented']}  "
        f"stale={s['stale_count']}  "
        f"avg_health={s['avg_health']:.2f}  "
        f"debt={s['doc_debt_score']:.2f}"
    )
    lines.append("")

    if not report["symbols"]:
        lines.append("  (no symbols)")
        return "\n".join(lines)

    header = f"{'HEALTH':17}  ST  {'KIND':14}  {'NAME':38}  FILE"
    lines.append(header)
    lines.append("-" * len(header))

    for doc in report["symbols"]:
        bar = _health_bar(doc["doc_health"])
        score = f"{doc['doc_health']:.2f}"
        health_col = f"{bar} {score}"
        stale = _stale_flag(doc)
        kind = doc["kind"][:14]
        name = doc["name"][:38]
        file_col = doc["file"]
        lines.append(f"{health_col:17}  {stale}   {kind:14}  {name:38}  {file_col}")

    if report["missing"]:
        lines.append("")
        lines.append(f"Missing docstrings ({len(report['missing'])} public symbols):")
        for m in report["missing"][:20]:
            lines.append(f"  [{m['caller_count']:3} callers]  {m['address']}")
        if len(report["missing"]) > 20:
            lines.append(f"  … and {len(report['missing']) - 20} more")

    if report["stale"]:
        lines.append("")
        lines.append(f"Potentially stale docstrings ({len(report['stale'])} symbols):")
        for st in report["stale"][:10]:
            lines.append(f"  {st['address']}")
        if len(report["stale"]) > 10:
            lines.append(f"  … and {len(report['stale']) - 10} more")

    return "\n".join(lines)

# ---------------------------------------------------------------------------
# Markdown renderer
# ---------------------------------------------------------------------------

_MD_KIND_BADGE: _BadgeMap = {
    "function": "fn",
    "async_function": "async fn",
    "class": "class",
    "method": "method",
    "async_method": "async method",
    "variable": "var",
    "import": "import",
    "section": "section",
    "rule": "rule",
}

def _md_health_indicator(score: float) -> str:
    """Return an emoji indicator for the health score."""
    if score >= 0.85:
        return "✅"
    if score >= 0.60:
        return "🟡"
    return "🔴"

def render_markdown(report: DocReport) -> str:
    """Return GitHub-compatible Markdown for *report*.

    Structure:
    - H1 header with commit and summary stats
    - Auto-generated TOC for all symbols
    - Per-symbol H2 sections with docstring, signature, callers, callees,
      version info, linked tests, and health score

    Args:
        report: The documentation report to render.
    """
    lines: list[str] = []
    s = report["summary"]

    lines.append("# Muse Documentation Report")
    lines.append("")
    lines.append(f"**Commit:** `{report['commit_id']}`  ")
    lines.append(f"**Generated:** {report['generated_at'][:19]}  ")
    lines.append(
        f"**Health:** avg={s['avg_health']:.2f}  "
        f"debt={s['doc_debt_score']:.2f}  "
        f"documented={s['documented']}/{s['total_symbols']}"
    )
    lines.append("")

    if report["symbols"]:
        lines.append("## Table of Contents")
        lines.append("")
        for doc in report["symbols"]:
            anchor = doc["address"].lower().replace(" ", "-").replace("/", "").replace("::", "--").replace(".", "")
            indicator = _md_health_indicator(doc["doc_health"])
            lines.append(f"- {indicator} [`{doc['qualified_name']}`](#{anchor})")
        lines.append("")

    for doc in report["symbols"]:
        anchor = doc["address"].lower().replace(" ", "-").replace("/", "").replace("::", "--").replace(".", "")
        kind_badge = _MD_KIND_BADGE.get(doc["kind"], doc["kind"])
        indicator = _md_health_indicator(doc["doc_health"])

        lines.append(f"## `{doc['qualified_name']}` {{#{anchor}}}")
        lines.append("")
        lines.append(
            f"> {indicator} **{kind_badge}** in `{doc['file']}`"
            f"  (lines {doc['lineno']}–{doc['end_lineno']})"
        )
        lines.append("")

        if doc["signature"]:
            lines.append("```python")
            lines.append(doc["signature"])
            lines.append("```")
            lines.append("")

        if doc["docstring"]:
            lines.append(doc["docstring"])
        else:
            lines.append("*No docstring.*")
        lines.append("")

        if doc["since_version"] or doc["since_commit"]:
            ver = doc["since_version"] or ""
            cid = doc["since_commit"] or ""
            lines.append(f"**Introduced:** {ver or cid}")
            lines.append("")

        if doc["last_changed_version"] or doc["last_changed_commit"]:
            ver = doc["last_changed_version"] or ""
            cid = doc["last_changed_commit"] or ""
            lines.append(f"**Last changed:** {ver or cid}")
            lines.append("")

        if doc["breaking_changes"]:
            lines.append("**Breaking changes:**")
            for bc in doc["breaking_changes"]:
                lines.append(f"- {bc}")
            lines.append("")

        if doc["callers"]:
            lines.append(f"**Called by** ({len(doc['callers'])}):")
            for c in doc["callers"][:10]:
                lines.append(f"- `{c}`")
            if len(doc["callers"]) > 10:
                lines.append(f"- *(+{len(doc['callers']) - 10} more)*")
            lines.append("")

        if doc["callees"]:
            lines.append(f"**Calls** ({len(doc['callees'])}):")
            for c in doc["callees"][:10]:
                lines.append(f"- `{c}`")
            if len(doc["callees"]) > 10:
                lines.append(f"- *(+{len(doc['callees']) - 10} more)*")
            lines.append("")

        if doc["linked_tests"]:
            lines.append(f"**Tests** ({len(doc['linked_tests'])}):")
            for t in doc["linked_tests"][:5]:
                lines.append(f"- `{t}`")
            if len(doc["linked_tests"]) > 5:
                lines.append(f"- *(+{len(doc['linked_tests']) - 5} more)*")
            lines.append("")

        reasons = doc["doc_health_reasons"]
        lines.append(
            f"**Doc health:** {doc['doc_health']:.2f}"
            + (f"  ({', '.join(reasons)})" if reasons else "")
        )
        lines.append("")
        lines.append("---")
        lines.append("")

    if report["missing"]:
        lines.append("## Missing Docstrings")
        lines.append("")
        lines.append(
            f"{len(report['missing'])} public symbol(s) lack docstrings "
            f"(sorted by caller count):"
        )
        lines.append("")
        lines.append("| Callers | Address |")
        lines.append("|---------|---------|")
        for m in report["missing"]:
            lines.append(f"| {m['caller_count']} | `{m['address']}` |")
        lines.append("")

    if report["stale"]:
        lines.append("## Stale Docstrings")
        lines.append("")
        lines.append(
            f"{len(report['stale'])} symbol(s) may have stale documentation:"
        )
        lines.append("")
        for st in report["stale"]:
            changed = "signature" if st["signature_changed"] else "body"
            lines.append(f"- `{st['address']}` — {changed} changed")
        lines.append("")

    return "\n".join(lines)

# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Muse Docs — {commit_short}</title>
<style>
:root {{
  --bg: #0d1117; --surface: #161b22; --border: #30363d;
  --text: #e6edf3; --muted: #8b949e; --accent: #58a6ff;
  --green: #3fb950; --yellow: #d29922; --red: #f85149;
  --code-bg: #1f2428; --font: system-ui, -apple-system, sans-serif;
  --mono: 'SFMono-Regular', Consolas, monospace;
}}
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{ background: var(--bg); color: var(--text); font-family: var(--font);
       display: flex; height: 100vh; overflow: hidden; }}
nav {{ width: 280px; min-width: 220px; background: var(--surface);
      border-right: 1px solid var(--border); overflow-y: auto;
      padding: 16px 0; flex-shrink: 0; }}
nav h2 {{ font-size: 11px; text-transform: uppercase; letter-spacing: 1px;
          color: var(--muted); padding: 0 16px 8px; }}
nav a {{ display: block; padding: 5px 16px; color: var(--muted);
         text-decoration: none; font-size: 13px; white-space: nowrap;
         overflow: hidden; text-overflow: ellipsis; }}
nav a:hover {{ color: var(--accent); background: rgba(88,166,255,.05); }}
main {{ flex: 1; overflow-y: auto; padding: 32px; }}
header {{ margin-bottom: 32px; }}
header h1 {{ font-size: 24px; margin-bottom: 8px; }}
.meta {{ color: var(--muted); font-size: 13px; }}
.stats {{ display: flex; gap: 24px; margin-top: 16px; flex-wrap: wrap; }}
.stat {{ background: var(--surface); border: 1px solid var(--border);
         border-radius: 6px; padding: 12px 16px; }}
.stat-value {{ font-size: 22px; font-weight: 600; }}
.stat-label {{ font-size: 11px; color: var(--muted); text-transform: uppercase; }}
section.symbol {{ background: var(--surface); border: 1px solid var(--border);
                  border-radius: 8px; padding: 20px; margin-bottom: 20px; }}
section.symbol h2 {{ font-size: 16px; font-family: var(--mono); margin-bottom: 6px; }}
.badge {{ display: inline-block; padding: 2px 8px; border-radius: 4px;
          font-size: 11px; font-weight: 600; text-transform: uppercase; }}
.badge-fn {{ background: #1f3a5f; color: var(--accent); }}
.badge-class {{ background: #2d1f5f; color: #d2a8ff; }}
.badge-method {{ background: #1a3a2a; color: var(--green); }}
.badge-var {{ background: #3a2a1a; color: #f0883e; }}
.badge-other {{ background: var(--border); color: var(--muted); }}
.health-bar {{ display: flex; align-items: center; gap: 8px; margin: 8px 0; }}
.health-track {{ flex: 1; max-width: 120px; height: 6px;
                 background: var(--border); border-radius: 3px; }}
.health-fill {{ height: 100%; border-radius: 3px; }}
.health-good {{ background: var(--green); }}
.health-mid {{ background: var(--yellow); }}
.health-bad {{ background: var(--red); }}
.health-score {{ font-size: 13px; color: var(--muted); }}
pre {{ background: var(--code-bg); border: 1px solid var(--border);
       border-radius: 6px; padding: 12px; overflow-x: auto;
       font-family: var(--mono); font-size: 13px; margin: 8px 0; }}
.docstring {{ background: var(--code-bg); border-left: 3px solid var(--accent);
              padding: 12px; border-radius: 0 6px 6px 0; margin: 12px 0;
              font-size: 14px; line-height: 1.6; white-space: pre-wrap; }}
.no-doc {{ color: var(--muted); font-style: italic; font-size: 13px; margin: 8px 0; }}
.section-title {{ font-size: 11px; text-transform: uppercase; color: var(--muted);
                  letter-spacing: 1px; margin: 12px 0 4px; }}
.pill-list {{ display: flex; flex-wrap: wrap; gap: 4px; }}
.pill {{ background: var(--code-bg); border: 1px solid var(--border);
         border-radius: 4px; padding: 2px 8px; font-family: var(--mono);
         font-size: 12px; color: var(--muted); }}
.version-badge {{ display: inline-block; background: #1a2a1a;
                  color: var(--green); border: 1px solid var(--green);
                  border-radius: 4px; padding: 2px 8px; font-size: 12px;
                  font-family: var(--mono); margin-right: 4px; }}
.stale-badge {{ background: #3a2a00; color: var(--yellow);
                border: 1px solid var(--yellow); border-radius: 4px;
                padding: 2px 8px; font-size: 11px; }}
.breaking {{ background: #3a1a1a; color: var(--red); border-radius: 4px;
             padding: 4px 8px; font-size: 12px; margin: 2px 0; }}
.missing-table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
.missing-table th, .missing-table td {{ text-align: left; padding: 6px 12px;
    border-bottom: 1px solid var(--border); }}
.missing-table th {{ color: var(--muted); font-size: 11px; text-transform: uppercase; }}
</style>
</head>
<body>
<nav>
  <h2>Symbols</h2>
  {nav_links}
</nav>
<main>
  <header>
    <h1>Muse Documentation</h1>
    <div class="meta">Commit <code>{commit_short}</code> &nbsp;·&nbsp; {generated_at}</div>
    <div class="stats">
      <div class="stat">
        <div class="stat-value">{total}</div>
        <div class="stat-label">Symbols</div>
      </div>
      <div class="stat">
        <div class="stat-value">{documented}</div>
        <div class="stat-label">Documented</div>
      </div>
      <div class="stat">
        <div class="stat-value">{undocumented}</div>
        <div class="stat-label">Missing</div>
      </div>
      <div class="stat">
        <div class="stat-value">{stale}</div>
        <div class="stat-label">Stale</div>
      </div>
      <div class="stat">
        <div class="stat-value">{avg_health}</div>
        <div class="stat-label">Avg Health</div>
      </div>
      <div class="stat">
        <div class="stat-value">{debt}</div>
        <div class="stat-label">Doc Debt</div>
      </div>
    </div>
  </header>
  {symbol_sections}
  {missing_section}
</main>
</body>
</html>
"""

_BADGE_CLASS: _BadgeMap = {
    "function": "badge-fn",
    "async_function": "badge-fn",
    "class": "badge-class",
    "method": "badge-method",
    "async_method": "badge-method",
    "variable": "badge-var",
}

def _e(s: str) -> str:
    """HTML-escape *s*."""
    return _html_module.escape(s, quote=True)

def _health_class(score: float) -> str:
    if score >= 0.75:
        return "health-good"
    if score >= 0.50:
        return "health-mid"
    return "health-bad"

def _render_symbol_html(doc: SymbolDoc) -> str:
    anchor = _e(doc["address"].replace(" ", "_"))
    kind_badge = _BADGE_CLASS.get(doc["kind"], "badge-other")
    kind_label = _e(doc["kind"].replace("_", " "))
    score_pct = int(doc["doc_health"] * 100)
    health_cls = _health_class(doc["doc_health"])

    parts: list[str] = []
    parts.append(f'<section class="symbol" id="{anchor}">')
    parts.append(
        f'  <h2><code>{_e(doc["qualified_name"])}</code>'
        f'  <span class="badge {kind_badge}">{kind_label}</span></h2>'
    )
    parts.append(
        f'  <div class="meta">{_e(doc["file"])} '
        f'  lines {doc["lineno"]}–{doc["end_lineno"]}</div>'
    )

    # Health bar
    parts.append('  <div class="health-bar">')
    parts.append('    <div class="health-track">')
    parts.append(
        f'      <div class="health-fill {health_cls}" '
        f'style="width:{score_pct}%"></div>'
    )
    parts.append("    </div>")
    parts.append(f'    <span class="health-score">{doc["doc_health"]:.2f}</span>')
    if "stale_impl" in doc["doc_health_reasons"]:
        parts.append('    <span class="stale-badge">⚠ stale</span>')
    parts.append("  </div>")

    # Version badges
    if doc["since_version"]:
        parts.append(
            f'  <span class="version-badge">since {_e(doc["since_version"])}</span>'
        )
    if doc["last_changed_version"]:
        parts.append(
            f'  <span class="version-badge">changed {_e(doc["last_changed_version"])}</span>'
        )

    # Signature
    if doc["signature"]:
        parts.append(f"  <pre>{_e(doc['signature'])}</pre>")

    # Docstring
    if doc["docstring"]:
        parts.append(f'  <div class="docstring">{_e(doc["docstring"])}</div>')
    else:
        parts.append('  <div class="no-doc">No docstring.</div>')

    # Breaking changes
    if doc["breaking_changes"]:
        parts.append('  <div class="section-title">Breaking Changes</div>')
        for bc in doc["breaking_changes"]:
            parts.append(f'  <div class="breaking">{_e(bc)}</div>')

    # Callers
    if doc["callers"]:
        parts.append(
            f'  <div class="section-title">Called by ({len(doc["callers"])})</div>'
        )
        parts.append('  <div class="pill-list">')
        for c in doc["callers"][:15]:
            parts.append(f'    <span class="pill">{_e(c)}</span>')
        if len(doc["callers"]) > 15:
            parts.append(
                f'    <span class="pill">+{len(doc["callers"]) - 15} more</span>'
            )
        parts.append("  </div>")

    # Callees
    if doc["callees"]:
        parts.append(
            f'  <div class="section-title">Calls ({len(doc["callees"])})</div>'
        )
        parts.append('  <div class="pill-list">')
        for c in doc["callees"][:15]:
            parts.append(f'    <span class="pill">{_e(c)}</span>')
        if len(doc["callees"]) > 15:
            parts.append(
                f'    <span class="pill">+{len(doc["callees"]) - 15} more</span>'
            )
        parts.append("  </div>")

    # Linked tests
    if doc["linked_tests"]:
        parts.append(
            f'  <div class="section-title">Tests ({len(doc["linked_tests"])})</div>'
        )
        parts.append('  <div class="pill-list">')
        for t in doc["linked_tests"][:8]:
            parts.append(f'    <span class="pill">{_e(t)}</span>')
        if len(doc["linked_tests"]) > 8:
            parts.append(
                f'    <span class="pill">+{len(doc["linked_tests"]) - 8} more</span>'
            )
        parts.append("  </div>")

    parts.append("</section>")
    return "\n".join(parts)

def render_html(report: DocReport) -> str:
    """Return a self-contained HTML page for *report*.

    The page includes an inline sidebar TOC, health bars, version badges,
    caller/callee pill lists, and linked test lists.  It has zero external
    dependencies and opens in any browser.

    Args:
        report: The documentation report to render.
    """
    s = report["summary"]

    nav_links_parts: list[str] = []
    for doc in report["symbols"]:
        anchor = _e(doc["address"].replace(" ", "_"))
        indicator = "✅" if doc["doc_health"] >= 0.75 else ("🟡" if doc["doc_health"] >= 0.50 else "🔴")
        nav_links_parts.append(
            f'  <a href="#{anchor}" title="{_e(doc["address"])}">'
            f'{indicator} {_e(doc["name"])}</a>'
        )

    symbol_sections = "\n".join(
        _render_symbol_html(doc) for doc in report["symbols"]
    )

    # Missing section
    missing_parts: list[str] = []
    if report["missing"]:
        missing_parts.append(
            f'<section class="symbol">'
            f'<h2>Missing Docstrings ({len(report["missing"])})</h2>'
            f'<table class="missing-table">'
            f"<tr><th>Callers</th><th>Address</th><th>Kind</th></tr>"
        )
        for m in report["missing"]:
            missing_parts.append(
                f"<tr><td>{m['caller_count']}</td>"
                f"<td><code>{_e(m['address'])}</code></td>"
                f"<td>{_e(m['kind'])}</td></tr>"
            )
        missing_parts.append("</table></section>")

    return _HTML_TEMPLATE.format(
        commit_short=_e(report["commit_id"]),
        generated_at=_e(report["generated_at"][:19]),
        total=s["total_symbols"],
        documented=s["documented"],
        undocumented=s["undocumented"],
        stale=s["stale_count"],
        avg_health=f"{s['avg_health']:.2f}",
        debt=f"{s['doc_debt_score']:.2f}",
        nav_links="\n".join(nav_links_parts),
        symbol_sections=symbol_sections,
        missing_section="\n".join(missing_parts),
    )

# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

def render(report: DocReport, fmt: RenderFormat) -> str:
    """Render *report* in the requested *fmt*.

    Args:
        report: The documentation report from :func:`~doc_extractor.extract_docs`.
        fmt:    Output format: ``"json"``, ``"html"``, ``"markdown"``, or ``"text"``.

    Returns:
        A string in the requested format, ready to write to a file or stdout.

    Raises:
        ValueError: When *fmt* is not one of the supported values.
    """
    if fmt == "json":
        return render_json(report)
    if fmt == "html":
        return render_html(report)
    if fmt == "markdown":
        return render_markdown(report)
    if fmt == "text":
        return render_text(report)
    raise ValueError(f"Unsupported render format: {fmt!r}")
