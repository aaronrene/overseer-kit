"""Object availability model for Muse repositories.

Every object referenced by a commit chain is in one of three states:

``PRESENT``
    The object's byte content exists in the local ``.muse/objects/`` store.
    It can be read, hashed, and served without any network access.

``PROMISED``
    The object is absent from the local store, but at least one *promisor
    remote* is configured.  The remote is expected to have the object and
    can serve it on demand.  A promised object is **not** an integrity
    failure — it is the normal state for a shallow or partial-clone repo.

``MISSING``
    The object is absent from the local store **and** no promisor remote is
    configured.  There is no known recovery path.  This is a genuine
    integrity failure.

Promisor remote convention
--------------------------
Any configured remote is implicitly a promisor unless it explicitly opts out
with ``promisor = false`` in ``.muse/config.toml``::

    [remotes.mirror]
    url = "http://mirror.internal/muse"
    promisor = false   # this remote is a dumb mirror, not authoritative

By contrast, all production remotes (``local``, ``staging``, etc.) are
promisors by default — they received the full object pack on every push and
can serve any object the local store lacks.

This mirrors git's promisor-remote concept (introduced for partial clones)
but uses a simpler default: *opted-in unless opted out*, which is the right
default for an agent-first platform where every push is to a trusted hub.

Integration with ``run_verify``
-------------------------------
``run_verify`` calls ``load_promisor_remotes`` once at startup, then uses
``object_state`` for every missing object it encounters:

- ``PRESENT``  → ``objects_checked`` counter incremented; hash verified.
- ``PROMISED`` → ``promised_objects`` counter incremented; not a failure.
- ``MISSING``  → appended to ``failures`` as ``kind="object"``.

In ``strict=True`` mode, ``PROMISED`` objects are treated as ``MISSING``.
"""

import pathlib
from enum import Enum

from muse.core.object_store import _object_path_with_fallback

class ObjectState(str, Enum):
    """Availability state of a single content-addressed object."""

    PRESENT = "present"
    """Bytes exist in the local ``.muse/objects/`` store."""

    PROMISED = "promised"
    """Absent locally but expected on at least one promisor remote."""

    MISSING = "missing"
    """Absent locally with no known recovery path."""

def object_state(
    root: pathlib.Path,
    obj_id: str,
    promisor_remotes: list[str],
) -> ObjectState:
    """Return the availability state of *obj_id* in *root*.

    Args:
        root:             Repository root (directory containing ``.muse/``).
        obj_id:           The ``sha256:``-prefixed content address to check.
        promisor_remotes: Names of remotes that are promisors.  Pass the
                          result of :func:`load_promisor_remotes`.

    Returns:
        ``PRESENT`` if the object file exists locally.
        ``PROMISED`` if absent but at least one promisor remote is configured.
        ``MISSING`` if absent and no promisor remote is configured.
    """
    if _object_path_with_fallback(root, obj_id).exists():
        return ObjectState.PRESENT
    if promisor_remotes:
        return ObjectState.PROMISED
    return ObjectState.MISSING

def load_promisor_remotes(root: pathlib.Path) -> list[str]:
    """Return the names of all promisor remotes configured for *root*.

    Reads ``.muse/config.toml``.  Every configured remote is a promisor by
    default; set ``promisor = false`` to opt a remote out.

    Returns an empty list when no remotes are configured or when all
    configured remotes have opted out.
    """
    try:
        from muse.cli.config import _config_path, _load_config  # type: ignore[attr-defined]
    except ImportError:
        return []

    try:
        config = _load_config(_config_path(root))
    except Exception:
        return []

    remotes = config.get("remotes")
    if not remotes:
        return []

    result: list[str] = []
    for name, entry in remotes.items():
        url = entry.get("url", "").strip()
        if not url:
            continue
        # Default is promisor=True; opt out with promisor=false
        if entry.get("promisor", True):
            result.append(name)
    return sorted(result)
