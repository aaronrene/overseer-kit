"""Garbage collection — prune unreachable objects from the object store.

Muse uses a content-addressed object store: every file snapshot is stored as a
SHA-256-addressed blob under ``.muse/objects/``.  Over time, after branch
deletions, rebases, and abandoned experiments, objects that are no longer
reachable from any live commit accumulate.  This module identifies and removes
them.

Reachability
------------
An object is *reachable* if it can be reached by following the graph from any
live ref (branch HEAD, tag, or the current HEAD):

    branch HEAD → CommitRecord → SnapshotRecord → manifest → object SHA-256

Any object not in the reachable set is *loose garbage* and is safe to delete.

``--full`` mode
---------------
By default ``muse gc`` only prunes file-content blobs (``.muse/objects/``).
With ``--full`` it also prunes:

- Orphaned commit objects (``.muse/objects/``) — commits not reachable
  from any live branch ref or tag by following ``parent_commit_id`` links.
- Orphaned snapshot objects (``.muse/objects/``) — snapshots not
  referenced by any reachable commit.

This mirrors ``git prune`` / ``git gc``, which removes all unreachable loose
objects regardless of type.

Safety
------
The GC walk is always performed **before** any deletion.  The ``dry_run``
option shows what *would* be deleted without touching the store, making it safe
to run frequently in CI or by agents to estimate bloat.

A ``grace_period_seconds`` guard (default 30 s) prevents deleting objects that
were written within the last N seconds.  This closes the TOCTOU window where a
concurrent ``muse commit`` has written a blob to the object store but not yet
created the commit record — without the grace period, GC would see the blob as
unreachable and delete it mid-commit, causing data loss.

Symlink safety
--------------
Every prefix directory and object file is checked with ``is_symlink()`` before
being treated as a real object.  A crafted symlink inside ``.muse/objects/``
cannot cause GC to read or delete files outside the repository.

Return value
------------
``GcResult`` is a typed dataclass with integer counts and the list of collected
IDs.  The CLI command renders it and can expose it as JSON.
"""

import json
import logging
import pathlib
import time
from collections import deque
from dataclasses import dataclass, field

import msgpack

from muse.core.types import long_id
from muse.core.paths import (
    tags_dir as _tags_dir,
    heads_dir as _heads_dir,
    shelf_dir as _shelf_dir,
    remotes_dir as _remotes_dir,
)
from muse.core.object_store import iter_stored_objects
from muse.core.refs import iter_branch_refs
from muse.core.io import MAX_MSGPACK_BYTES, zstd_decompress_if_needed as _zstd_decompress_if_needed
from muse.core.commits import (
    commit_path as _commit_path,
    get_all_commits,
)
from muse.core.snapshots import (
    read_snapshot,
    snapshot_path as _snapshot_path,
)
from muse.core.timing import start_timer
from muse.core.reflog import expire_reflog, list_reflog_refs
from muse.core.symlog import expire_symlog, list_symlog_symbols

logger = logging.getLogger(__name__)

_MAX_SHELF_BYTES: int = MAX_MSGPACK_BYTES

# Default number of seconds to protect recently-written objects from GC.
# See the "Safety" section of the module docstring.
_DEFAULT_GRACE_PERIOD_SECONDS: int = 30

# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class GcResult:
    """Statistics from one garbage-collection pass."""

    # Blob store (.muse/objects/)
    reachable_count: int = 0
    collected_count: int = 0
    collected_bytes: int = 0

    # Commits in unified store (.muse/objects/sha256/) — populated only with --full
    commits_reachable: int = 0
    commits_collected: int = 0
    commits_collected_bytes: int = 0

    # Snapshots in unified store (.muse/objects/sha256/) — populated only with --full
    snapshots_reachable: int = 0
    snapshots_collected: int = 0
    snapshots_collected_bytes: int = 0

    # Remote tracking refs (.muse/remotes/) — populated only with --full
    stale_remote_refs_collected: int = 0
    stale_remote_refs_bytes: int = 0

    # Reflog entries pruned by age during this GC pass
    reflog_expired: int = 0

    # Symlog entries pruned by age during this GC pass
    symlog_expired: int = 0

    duration_ms: float = 0.0
    grace_period_seconds: int = _DEFAULT_GRACE_PERIOD_SECONDS
    collected_ids: list[str] = field(default_factory=list)
    collected_commit_ids: list[str] = field(default_factory=list)
    collected_snapshot_ids: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    dry_run: bool = False
    full: bool = False

# ---------------------------------------------------------------------------
# Reachability walk — blobs (conservative: all commits in store)
# ---------------------------------------------------------------------------

def _collect_reachable_objects(
    repo_root: pathlib.Path,
) -> set[str]:
    """Return the set of all object SHA-256 IDs reachable from any live ref.

    Conservative strategy for the unified object store (all three types — blob,
    commit, snapshot — now live under ``objects/sha256/``):

    - All ``commit`` and ``snapshot`` typed objects are always reachable.
    - Every blob ID referenced by any snapshot manifest is reachable.
    - Malformed objects (no null-byte header) are kept (conservative).

    This mirrors the old behaviour where commits and snapshots lived in separate
    directories and were never candidates for blob-level GC.  Now that they
    share the store we must explicitly protect them.

    Snapshot manifests are read raw (no hash verification) so that objects are
    retained even when a snapshot's stored payload is corrupt — it is always
    safer to keep objects than to silently lose them.

    Shelf entries are also walked so shelved blobs are never GCed.
    """
    import json as _json_mod

    reachable: set[str] = set()

    # ── Unified object store walk ─────────────────────────────────────────────
    for oid, obj_file in iter_stored_objects(repo_root):
        if obj_file.is_symlink():
            continue
        try:
            raw = obj_file.read_bytes()
            null_idx = raw.index(b"\0")
            type_str = raw[:null_idx].decode(errors="replace").split(" ", 1)[0]
        except (ValueError, OSError):
            # Malformed or unreadable — keep conservatively.
            reachable.add(oid)
            continue

        if type_str == "commit":
            reachable.add(oid)
        elif type_str == "snapshot":
            reachable.add(oid)
            try:
                payload = raw[null_idx + 1:]
                data = _json_mod.loads(payload)
                manifest = data.get("manifest", {})
                if isinstance(manifest, dict):
                    for blob_oid in manifest.values():
                        if isinstance(blob_oid, str) and blob_oid:
                            reachable.add(long_id(blob_oid))
            except Exception as exc:
                logger.debug("gc: could not parse snapshot %s — skipped: %s", oid, exc)
        # blob objects are not added here — only added if referenced by a snapshot

    # ── Shelf ─────────────────────────────────────────────────────────────────
    _collect_shelf_objects(repo_root, reachable)

    return reachable

def _collect_shelf_objects(repo_root: pathlib.Path, reachable: set[str]) -> None:
    """Add object IDs from shelf entries into *reachable* in-place.

    Handles both new git-header+JSON files (no extension) and legacy
    ``.msgpack`` files.  Corrupt, oversized, or symlinked files are skipped
    with a warning so a single bad entry never blocks GC.
    """
    import json as _json
    from muse.core.io import safe_unpackb
    shelf = _shelf_dir(repo_root)
    if not shelf.is_dir():
        return
    for entry_path in shelf.glob("*/*"):
        if entry_path.name.startswith("."):
            continue
        if entry_path.suffix not in ("", ".msgpack"):
            continue
        if entry_path.is_symlink():
            logger.warning("⚠️ shelf entry %s is a symlink — skipping during GC walk", entry_path.name)
            continue
        try:
            size = entry_path.stat().st_size
            if size > _MAX_SHELF_BYTES:
                logger.warning("⚠️ shelf entry %s exceeds size limit — skipping", entry_path.name[:24])
                continue
            raw = entry_path.read_bytes()
            if entry_path.suffix == ".msgpack":
                data = safe_unpackb(raw)
            else:
                null_idx = raw.index(b"\0")
                data = _json.loads(raw[null_idx + 1:].decode("utf-8"))
            if not isinstance(data, dict):
                continue
            snapshot = data.get("snapshot")
            if isinstance(snapshot, dict):
                for object_id in snapshot.values():
                    if isinstance(object_id, str):
                        reachable.add(object_id)
        except OSError as exc:
            logger.warning(
                "⚠️ Could not read shelf entry %s during GC walk: %s",
                entry_path.name[:24], exc,
            )

# ---------------------------------------------------------------------------
# Reachability walk — commits + snapshots (for --full)
# ---------------------------------------------------------------------------

def _strip_prefix(id_str: str) -> str:
    """Return the bare hex ID, stripping any ``sha256:`` prefix.

    GC uses bare hex as the canonical form because that is what the filesystem
    stores (``commits/<hex>.msgpack``, ``snapshots/<hex>.msgpack``).  All IDs
    read from ref files, commit records, and tag records must be normalised
    through this function before being added to reachable sets or used to
    build file paths.
    """
    return long_id(id_str, strip=True)

def _collect_reachable_commits(repo_root: pathlib.Path) -> set[str]:
    """Return all prefixed commit IDs reachable from any live branch ref or tag.

    BFS through parent links using the unified object store (read_commit).
    Corrupt or missing commits are skipped — not added to reachable set and
    not deleted (the grace period covers that window).
    """
    from muse.core.commits import read_commit as _read_commit
    reachable: set[str] = set()

    # Collect all live tips: branch refs + tags
    tips: list[str] = [cid for _, cid in iter_branch_refs(repo_root) if cid]

    import json as _json
    tags_dir = _tags_dir(repo_root)
    if tags_dir.exists():
        for tag_path in tags_dir.glob("*/*/*/*"):
            if tag_path.suffix not in (".json", ".msgpack"):
                continue
            if tag_path.is_symlink() or not tag_path.is_file():
                continue
            try:
                if tag_path.suffix == ".json":
                    tag_data = _json.loads(tag_path.read_bytes().decode("utf-8"))
                else:
                    tag_data = msgpack.unpackb(tag_path.read_bytes(), raw=False)
                cid = tag_data.get("commit_id") or tag_data.get("target")
                if cid:
                    tips.append(long_id(cid))
            except Exception:
                pass

    # BFS through parent links via unified object store
    queue: deque[str] = deque(tips)
    while queue:
        cid = queue.popleft()
        if cid in reachable:
            continue
        reachable.add(cid)
        try:
            record = _read_commit(repo_root, cid)
        except Exception as exc:
            logger.warning("⚠️ Could not read commit %s during GC walk: %s", cid, exc)
            continue
        if record is None:
            continue
        if record.parent_commit_id:
            queue.append(long_id(record.parent_commit_id))
        if record.parent2_commit_id:
            queue.append(long_id(record.parent2_commit_id))

    return reachable

def _collect_reachable_snapshots(
    repo_root: pathlib.Path,
    reachable_commits: set[str],
) -> tuple[set[str], set[str]]:
    """Return ``(reachable_snapshot_ids, reachable_object_ids)`` from reachable commits.

    Reads commits from the unified object store. Also folds in any object IDs
    referenced by shelf entries.
    """
    from muse.core.commits import read_commit as _read_commit
    reachable_snaps: set[str] = set()
    reachable_objs: set[str] = set()

    for cid in reachable_commits:
        try:
            record = _read_commit(repo_root, cid)
        except Exception:
            continue
        if record is None:
            continue
        snap_id = long_id(record.snapshot_id)
        reachable_snaps.add(snap_id)
        snap = read_snapshot(repo_root, snap_id)
        if snap is not None:
            for object_id in snap.manifest.values():
                reachable_objs.add(long_id(object_id))
        else:
            # read_snapshot returned None — snapshot may be corrupt but still
            # contain valid object IDs. Walk the raw object to retain them.
            from muse.core.object_store import object_path as _obj_path
            obj_file = _obj_path(repo_root, snap_id)
            if obj_file.is_file() and not obj_file.is_symlink():
                try:
                    raw = obj_file.read_bytes()
                    null_idx = raw.index(b"\0")
                    payload = raw[null_idx + 1:]
                    raw_snap = json.loads(payload)
                    manifest = raw_snap.get("manifest", {})
                    if isinstance(manifest, dict):
                        for oid in manifest.values():
                            if isinstance(oid, str) and oid:
                                reachable_objs.add(long_id(oid))
                    logger.critical(
                        "❌ gc: snapshot %s failed hash verification — "
                        "its objects were retained conservatively. "
                        "Run `muse verify-pack` to audit the store.",
                        snap_id,
                    )
                except Exception as exc:
                    logger.critical(
                        "❌ gc: could not read corrupt snapshot %s — "
                        "some objects may have been lost: %s",
                        snap_id, exc,
                    )

    # Shelf snapshot IDs
    _collect_shelf_objects(repo_root, reachable_objs)

    return reachable_snaps, reachable_objs

# ---------------------------------------------------------------------------
# Store enumeration helpers
# ---------------------------------------------------------------------------

_HEX_CHARS: frozenset[str] = frozenset("0123456789abcdef")

def _is_hex(s: str) -> bool:
    """Return True iff every character of *s* is a lowercase hex digit."""
    return bool(s) and all(c in _HEX_CHARS for c in s)

def _list_stored_objects(
    repo_root: pathlib.Path,
    *,
    grace_period_seconds: int = _DEFAULT_GRACE_PERIOD_SECONDS,
) -> list[tuple[str, pathlib.Path]]:
    """Return ``(prefixed_object_id, path)`` for every valid SHA-256 object in the store.

    Only **real files** (not symlinks) whose name + parent prefix form a
    64-char lowercase hex string are included.  Stray files (editor temporaries,
    macOS ``.DS_Store``, etc.) are silently skipped.

    Symlink guard
    ~~~~~~~~~~~~~
    Both prefix directories and object files are rejected if they are symlinks.
    Without this guard a crafted symlink inside ``.muse/objects/`` could cause
    GC to ``unlink()`` a file anywhere on the filesystem — a silent data
    destruction vector.

    Grace period
    ~~~~~~~~~~~~
    Objects whose ``mtime`` is within *grace_period_seconds* seconds of now are
    excluded from the returned list even if they are not currently reachable.
    This closes the TOCTOU window where a concurrent ``muse commit`` has written
    a blob but not yet created the commit record.

    Args:
        repo_root:             Repository root (contains ``.muse/``).
        grace_period_seconds:  Number of seconds before an object becomes
                               eligible for collection.  Default: 30 s.
    """
    cutoff = time.time() - grace_period_seconds
    pairs: list[tuple[str, pathlib.Path]] = []

    for oid, obj_file in iter_stored_objects(repo_root, skip_symlinks=False):
        if obj_file.is_symlink():
            logger.warning("⚠️ object %s is a symlink — skipping during GC walk", oid)
            continue
        # Grace period: protect objects written in the last N seconds.
        try:
            if obj_file.stat().st_mtime > cutoff:
                continue
        except OSError:
            # File disappeared between iterdir() and stat() — skip.
            continue
        pairs.append((oid, obj_file))

    return pairs

def _list_stored_msgpack(
    directory: pathlib.Path,
    *,
    grace_period_seconds: int = _DEFAULT_GRACE_PERIOD_SECONDS,
) -> list[tuple[str, pathlib.Path]]:
    """Return ``(stem, path)`` for every non-symlink ``.msgpack`` file in *directory*.

    Applies the same grace-period and symlink guards as ``_list_stored_objects``.
    """
    if not directory.exists():
        return []

    cutoff = time.time() - grace_period_seconds
    pairs: list[tuple[str, pathlib.Path]] = []

    for p in directory.glob("*/*.msgpack"):
        if p.is_symlink() or not p.is_file():
            continue
        try:
            if p.stat().st_mtime > cutoff:
                continue
        except OSError:
            continue
        pairs.append((p.stem, p))

    return pairs

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_DEFAULT_REFLOG_EXPIRE_DAYS: int = 90
_DEFAULT_SYMLOG_EXPIRE_DAYS: int = 90


def run_gc(
    repo_root: pathlib.Path,
    *,
    dry_run: bool = False,
    grace_period_seconds: int = _DEFAULT_GRACE_PERIOD_SECONDS,
    full: bool = False,
    reflog_expire_days: int = _DEFAULT_REFLOG_EXPIRE_DAYS,
    symlog_expire_days: int = _DEFAULT_SYMLOG_EXPIRE_DAYS,
) -> GcResult:
    """Prune unreachable objects from the Muse object store.

    Args:
        repo_root:             Root of the Muse repository (``.muse/`` lives here).
        dry_run:               When ``True``, report what *would* be deleted
                               without actually removing anything.
        grace_period_seconds:  Objects written within the last N seconds are
                               never deleted, even if currently unreachable.
                               Protects concurrent ``muse commit`` operations.
                               Default: 30 s.
        full:                  When ``True``, also prune orphaned commit and
                               snapshot objects from ``.muse/objects/sha256/``,
                               mirroring ``git prune``.
        reflog_expire_days:    Reflog entries older than this many days are
                               pruned as part of the GC pass.  Default: 90.

    Returns:
        A ``GcResult`` with counts and the list of collected object IDs.
    """
    elapsed = start_timer()
    result = GcResult(dry_run=dry_run, grace_period_seconds=grace_period_seconds, full=full)

    # Capture warning log messages into result.warnings so callers (e.g. --json
    # output) can surface them without scraping stderr.
    class _WarningCapture(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            if record.levelno >= logging.WARNING:
                result.warnings.append(self.format(record))

    _capture_handler = _WarningCapture()
    _capture_handler.setFormatter(logging.Formatter("%(message)s"))
    _gc_logger = logging.getLogger(__name__)
    _gc_logger.addHandler(_capture_handler)

    try:
        _run_gc_inner(repo_root, result, dry_run=dry_run,
                      grace_period_seconds=grace_period_seconds, full=full,
                      reflog_expire_days=reflog_expire_days,
                      symlog_expire_days=symlog_expire_days)
    finally:
        _gc_logger.removeHandler(_capture_handler)

    result.duration_ms = elapsed()
    logger.info(
        "gc: %d reachable blobs, %d %s, full=%s, grace=%ds, %.1fms elapsed",
        result.reachable_count,
        result.collected_count,
        "would be removed" if dry_run else "removed",
        full,
        grace_period_seconds,
        result.duration_ms,
    )
    return result

def _run_gc_inner(
    repo_root: pathlib.Path,
    result: "GcResult",
    *,
    dry_run: bool,
    grace_period_seconds: int,
    full: bool,
    reflog_expire_days: int = _DEFAULT_REFLOG_EXPIRE_DAYS,
    symlog_expire_days: int = _DEFAULT_SYMLOG_EXPIRE_DAYS,
) -> None:
    """Core GC logic — separated so run_gc can wrap it with warning capture."""

    if full:
        # --full: tight reachability — only objects reachable from live refs.
        reachable_commits = _collect_reachable_commits(repo_root)
        reachable_snaps, reachable_objs = _collect_reachable_snapshots(
            repo_root, reachable_commits
        )

        result.commits_reachable = len(reachable_commits)
        result.snapshots_reachable = len(reachable_snaps)
        result.reachable_count = len(reachable_objs)

        # Walk unified object store — prune commits, snapshots, and blobs that
        # are not reachable from any live ref. All object types live under
        # .muse/objects/ after the unified-store migration.
        cutoff = time.time() - grace_period_seconds
        for oid, obj_path in iter_stored_objects(repo_root):
            if obj_path.is_symlink():
                continue
            try:
                if obj_path.stat().st_mtime > cutoff:
                    continue
            except OSError:
                continue
            # Determine object type from header
            try:
                raw = obj_path.read_bytes()
                null_idx = raw.index(b"\0")
                type_str = raw[:null_idx].decode(errors="replace").split(" ", 1)[0]
            except (ValueError, OSError):
                continue

            try:
                size = obj_path.stat().st_size
            except OSError:
                size = 0

            if type_str == "commit":
                if oid not in reachable_commits:
                    result.commits_collected += 1
                    result.commits_collected_bytes += size
                    result.collected_commit_ids.append(oid)
                    if not dry_run:
                        try:
                            obj_path.unlink()
                            try:
                                if not any(obj_path.parent.iterdir()):
                                    obj_path.parent.rmdir()
                            except OSError:
                                pass
                        except OSError as exc:
                            logger.warning("⚠️ Could not remove commit %s: %s", oid, exc)
            elif type_str == "snapshot":
                if oid not in reachable_snaps:
                    result.snapshots_collected += 1
                    result.snapshots_collected_bytes += size
                    result.collected_snapshot_ids.append(oid)
                    if not dry_run:
                        try:
                            obj_path.unlink()
                            try:
                                if not any(obj_path.parent.iterdir()):
                                    obj_path.parent.rmdir()
                            except OSError:
                                pass
                        except OSError as exc:
                            logger.warning("⚠️ Could not remove snapshot %s: %s", oid, exc)
            elif type_str == "blob":
                if oid not in reachable_objs:
                    result.collected_ids.append(oid)
                    result.collected_bytes += size
                    result.collected_count += 1
                    if not dry_run:
                        try:
                            obj_path.unlink()
                            try:
                                if not any(obj_path.parent.iterdir()):
                                    obj_path.parent.rmdir()
                            except OSError:
                                pass
                        except OSError as exc:
                            logger.warning("⚠️ Could not remove object %s: %s", oid, exc)

    else:
        # Default: conservative blob-only GC using all commits in the store.
        reachable = _collect_reachable_objects(repo_root)
        stored = _list_stored_objects(repo_root, grace_period_seconds=grace_period_seconds)

        result.reachable_count = len(reachable)

        for object_id, obj_path in stored:
            if object_id not in reachable:
                try:
                    size = obj_path.stat().st_size
                except OSError:
                    size = 0
                result.collected_ids.append(object_id)
                result.collected_bytes += size
                result.collected_count += 1
                if not dry_run:
                    try:
                        obj_path.unlink()
                        try:
                            if not any(obj_path.parent.iterdir()):
                                obj_path.parent.rmdir()
                        except OSError:
                            pass
                    except OSError as exc:
                        logger.warning(
                            "⚠️ Could not remove object %s: %s", object_id, exc
                        )

    # Reflog expiry — applies regardless of --full flag.
    _expire_all_reflogs(repo_root, result, reflog_expire_days, dry_run=dry_run)

    # Symlog expiry — applies regardless of --full flag.
    _expire_all_symlogs(repo_root, result, symlog_expire_days, dry_run=dry_run)


def _expire_all_reflogs(
    repo_root: pathlib.Path,
    result: "GcResult",
    expire_days: int,
    *,
    dry_run: bool,
) -> None:
    """Prune reflog entries older than *expire_days* from all log files.

    Accumulates the total number of expired entries into ``result.reflog_expired``.
    Individual file failures are logged as warnings and never abort the GC run.
    """
    # HEAD log
    try:
        expired, _ = expire_reflog(repo_root, None, expire_days, dry_run=dry_run)
        result.reflog_expired += expired
    except Exception as exc:
        logger.warning("⚠️ gc: could not expire HEAD reflog: %s", exc)

    # Per-branch logs
    for branch in list_reflog_refs(repo_root):
        try:
            expired, _ = expire_reflog(repo_root, branch, expire_days, dry_run=dry_run)
            result.reflog_expired += expired
        except Exception as exc:
            logger.warning("⚠️ gc: could not expire reflog for %s: %s", branch, exc)


def _expire_all_symlogs(
    repo_root: pathlib.Path,
    result: "GcResult",
    expire_days: int,
    *,
    dry_run: bool,
) -> None:
    """Prune symlog entries older than *expire_days* from all symbol journals.

    Accumulates the total number of expired entries into ``result.symlog_expired``.
    Individual file failures are logged as warnings and never abort the GC run.
    """
    for addr in list_symlog_symbols(repo_root):
        try:
            expired, _ = expire_symlog(repo_root, addr, expire_days, dry_run=dry_run)
            result.symlog_expired += expired
        except Exception as exc:
            logger.warning("⚠️ gc: could not expire symlog for %s: %s", addr, exc)

# ---------------------------------------------------------------------------
# Stale remote tracking ref pruning
# ---------------------------------------------------------------------------

def prune_stale_remote_refs(
    repo_root: pathlib.Path,
    configured_remote_names: set[str],
    result: GcResult,
    *,
    dry_run: bool,
) -> None:
    """Remove tracking-ref directories for remotes that are no longer configured.

    When a remote is removed with ``muse remote remove``, the directory
    ``.muse/remotes/<remote>/`` is left behind — tracking refs accumulate
    indefinitely.  This function deletes those orphaned directories.

    Only **real directories** (not symlinks) whose name does not appear in
    *configured_remote_names* are removed.  The walk is non-recursive against
    symlinks to prevent traversal attacks.

    Args:
        repo_root:               Repository root.
        configured_remote_names: Names of remotes currently in ``config.toml``.
        result:                  ``GcResult`` to update in-place.
        dry_run:                 When ``True``, count but do not delete.
    """
    remotes_root = _remotes_dir(repo_root)
    if not remotes_root.is_dir():
        return

    for entry in remotes_root.iterdir():
        if entry.is_symlink() or not entry.is_dir():
            continue
        if entry.name in configured_remote_names:
            continue
        # Stale remote directory — count and optionally delete all ref files.
        dir_bytes = 0
        ref_files: list[pathlib.Path] = []
        for ref_file in entry.rglob("*"):
            if ref_file.is_symlink() or not ref_file.is_file():
                continue
            try:
                dir_bytes += ref_file.stat().st_size
            except OSError:
                pass
            ref_files.append(ref_file)

        result.stale_remote_refs_collected += len(ref_files)
        result.stale_remote_refs_bytes += dir_bytes

        if not dry_run:
            for ref_file in ref_files:
                try:
                    ref_file.unlink()
                except OSError as exc:
                    logger.warning(
                        "⚠️ Could not remove stale remote ref %s: %s", ref_file, exc
                    )
            # Remove the now-empty directory tree.
            import shutil
            try:
                shutil.rmtree(entry, ignore_errors=True)
            except OSError as exc:
                logger.warning(
                    "⚠️ Could not remove stale remote dir %s: %s", entry.name, exc
                )
