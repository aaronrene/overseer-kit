"""muse/core/sparse.py — Sparse-checkout filter logic.

A sparse-checkout configuration is stored in ``.muse/sparse-checkout`` as a
JSON object::

    {"mode": "cone", "patterns": ["src/", "tests/"]}

Two modes are supported:

``cone``
    Each pattern is a directory prefix (e.g. ``"src/"``).  A file matches when:
    - it is at the repository root (no ``/`` in path), OR
    - its path starts with one of the stripped prefixes (``"src/"`` → ``"src/"``).

``pattern``
    Each pattern is a ``pathlib.PurePosixPath.match``-compatible glob
    (e.g. ``"**/*.py"``, ``"src/**"``).  A file matches when *any* pattern
    matches its POSIX path.

When no ``sparse-checkout`` file exists the repository is in *full* mode —
every file in a snapshot manifest is materialised.
"""

import fnmatch
import json
import pathlib
from typing import TypedDict

from muse.core.paths import muse_dir as _muse_dir
from muse.core.types import Manifest, load_json_file

class SparseConfig(TypedDict, total=False):
    mode: str
    patterns: list[str]

# ---------------------------------------------------------------------------
# Config I/O
# ---------------------------------------------------------------------------

def read_sparse_config(root: pathlib.Path) -> SparseConfig | None:
    """Read the sparse-checkout config from *root*/.muse/sparse-checkout.

    Returns ``None`` when sparse-checkout is not active.
    """
    cfg_path = _muse_dir(root) / "sparse-checkout"
    if not cfg_path.exists():
        return None
    return load_json_file(cfg_path)

def write_sparse_config(root: pathlib.Path, config: SparseConfig) -> None:
    """Persist *config* to *root*/.muse/sparse-checkout."""
    cfg_path = _muse_dir(root) / "sparse-checkout"
    cfg_path.write_text(json.dumps(config, indent=2), encoding="utf-8")

def remove_sparse_config(root: pathlib.Path) -> None:
    """Remove the sparse-checkout config (disable sparse mode)."""
    cfg_path = _muse_dir(root) / "sparse-checkout"
    if cfg_path.exists():
        cfg_path.unlink()

# ---------------------------------------------------------------------------
# Matching
# ---------------------------------------------------------------------------

def matches_sparse(rel_posix: str, patterns: list[str], *, mode: str = "cone") -> bool:
    """Return ``True`` when *rel_posix* should be materialised under *patterns*.

    Args:
        rel_posix: Repository-relative POSIX path (e.g. ``"src/foo.py"``).
        patterns:  List of cone-prefixes or glob patterns depending on *mode*.
        mode:      ``"cone"`` or ``"pattern"``.
    """
    if mode == "cone":
        # Root-level files always match in cone mode.
        if "/" not in rel_posix:
            return True
        for pat in patterns:
            prefix = f"{pat.rstrip('/')}/"
            if rel_posix.startswith(prefix):
                return True
        return False

    # pattern mode — fnmatch-style globs; support ** as zero-or-more path segments
    for pat in patterns:
        if fnmatch.fnmatch(rel_posix, pat):
            return True
        # Also try pathlib match which handles ** for path separators
        try:
            if pathlib.PurePosixPath(rel_posix).match(pat):
                return True
        except Exception:
            pass
    return False

# ---------------------------------------------------------------------------
# Manifest filtering
# ---------------------------------------------------------------------------

def filter_manifest_sparse(
    manifest: Manifest,
    patterns: list[str],
    *,
    mode: str = "cone",
) -> Manifest:
    """Return a copy of *manifest* containing only sparse-matching entries.

    Args:
        manifest: Full snapshot manifest (path → object_id).
        patterns: Sparse patterns.
        mode:     ``"cone"`` or ``"pattern"``.

    Returns:
        A new :class:`Manifest` with only the paths that match the sparse rules.
    """
    return {
        path: obj_id
        for path, obj_id in manifest.items()
        if matches_sparse(path, patterns, mode=mode)
    }
