"""Object compression and delta encoding for mpack wire transfer.

Tiers
-----
Tier 1a — zstd (preferred): ~3× faster than zlib at comparable ratios.
           Available when the ``zstandard`` package is installed.
           ``ZSTD_AVAILABLE`` is ``True`` when this tier is active.
Tier 1b — zlib (fallback): stdlib-only, always available.
Tier 2  — delta+zstd / delta+zlib: objects with a known base are
           delta-encoded first, then compressed.

Use :func:`choose_compression` to select the best available encoding,
:func:`compress_and_encode` to compress and get the encoding name, and
:func:`decompress_frame` to decompress using the encoding stored in the
mpack object's ``enc`` field.

Receivers must support both ``zstd`` and ``zlib`` — the ``enc`` field on
each mpack object signals which was used.
"""

import struct
import zlib

# ---------------------------------------------------------------------------
# zstd — optional fast compression tier
# ---------------------------------------------------------------------------

try:
    import zstandard as _zstd_mod
    ZSTD_AVAILABLE: bool = True
    _ZSTD_COMPRESSOR = _zstd_mod.ZstdCompressor(level=3)
    _ZSTD_DECOMPRESSOR = _zstd_mod.ZstdDecompressor()
except ImportError:
    ZSTD_AVAILABLE = False
    _zstd_mod = None  # type: ignore[assignment]
    _ZSTD_COMPRESSOR = None  # type: ignore[assignment]
    _ZSTD_DECOMPRESSOR = None  # type: ignore[assignment]

def compress_zstd(data: bytes) -> bytes:
    """Compress *data* with zstd at level 3 (speed/ratio balanced).

    Level 3 delivers roughly the same compression ratio as zlib level 6
    while compressing ~3× faster on source-code workloads.

    Falls back to :func:`compress_zlib` when the ``zstandard`` package
    is not installed (:data:`ZSTD_AVAILABLE` is ``False``).

    Args:
        data: Raw bytes to compress.

    Returns:
        Compressed bytes using zstd (or zlib as fallback).
    """
    if not ZSTD_AVAILABLE:
        return compress_zlib(data)
    return _ZSTD_COMPRESSOR.compress(data)

def decompress_zstd(data: bytes) -> bytes:
    """Decompress zstd-compressed *data*.

    Falls back to :func:`decompress_zlib` when the ``zstandard`` package
    is not installed — consistent with :func:`compress_zstd`'s fallback.

    Raises the underlying decompressor error on corrupt input so the
    caller can return 400 to the remote rather than storing garbage.

    Args:
        data: zstd-compressed bytes.

    Returns:
        Original uncompressed bytes.
    """
    if not ZSTD_AVAILABLE:
        return decompress_zlib(data)
    return _ZSTD_DECOMPRESSOR.decompress(data)

def choose_compression() -> str:
    """Return the best available compression encoding name.

    Returns ``"zstd"`` when the ``zstandard`` package is installed,
    ``"zlib"`` otherwise.  Use the returned string as the ``enc`` field
    value for mpack objects.
    """
    return "zstd" if ZSTD_AVAILABLE else "zlib"

def compress_and_encode(data: bytes) -> tuple[bytes, str]:
    """Compress *data* with the best available algorithm.

    Returns a ``(compressed_bytes, enc_name)`` tuple where ``enc_name``
    is ``"zstd"`` or ``"zlib"`` — ready to write into a mpack object's
    ``content`` and ``enc`` fields.

    Args:
        data: Raw bytes to compress.

    Returns:
        ``(compressed, enc)`` — compressed bytes and encoding name.
    """
    if ZSTD_AVAILABLE:
        return _ZSTD_COMPRESSOR.compress(data), "zstd"
    return zlib.compress(data, level=1), "zlib"

def decompress_frame(data: bytes, enc: str) -> bytes:
    """Decompress *data* using the encoding specified by *enc*.

    Dispatches on the ``enc`` field from a mpack object:

    * ``"zstd"``  → zstd decompression
    * ``"zlib"``  → zlib decompression
    * ``"raw"``   → no decompression; *data* returned as-is

    Args:
        data: Compressed (or raw) bytes from a mpack object.
        enc:  Encoding name from the object's ``enc`` field.

    Returns:
        Decompressed bytes.

    Raises:
        ValueError: *enc* is not a recognised encoding name.
    """
    if enc == "zstd":
        return decompress_zstd(data)
    if enc == "zlib":
        return zlib.decompress(data)
    if enc == "raw":
        return data
    raise ValueError(
        f"Unknown encoding {enc!r}. Supported: 'zstd', 'zlib', 'raw'. "
        "Delta encodings ('delta+zstd', 'delta+zlib') require a base object "
        "and must be handled by the caller."
    )

# Minimum byte-run length to emit a COPY instruction rather than DATA.
# 32 bytes covers most source-code line edits without excessive overhead.
_COPY_THRESHOLD = 32

def compress_zlib(data: bytes) -> bytes:
    """Compress *data* with zlib at level 1 (speed-optimised).

    Level 1 gives ~60 % reduction on source text with negligible CPU overhead
    at the throughput rates of a pack push (hundreds of objects per second).
    """
    return zlib.compress(data, level=1)

def decompress_zlib(data: bytes) -> bytes:
    """Decompress zlib-compressed *data*.

    Raises :class:`zlib.error` on corrupt input — let it propagate so the
    server returns 400 to the client rather than storing garbage.
    """
    return zlib.decompress(data)

def compute_delta(base: bytes, target: bytes) -> bytes:
    """Delta-encode *target* relative to *base*.

    Returns a zlib-compressed instruction stream.  Each instruction is one of:

    * ``COPY``: ``b'\\x00' + struct.pack('>II', offset, length)``
      — copy *length* bytes from *base* starting at *offset*.
    * ``DATA``: ``b'\\x01' + struct.pack('>I', length) + data_bytes``
      — emit *length* literal bytes verbatim.

    Algorithm:
        Build a hash table mapping every *_COPY_THRESHOLD*-byte chunk of
        *base* to its last position.  Walk *target* looking for matching
        chunks; extend each match forward as far as possible, then emit a
        single COPY instruction.  Unmatched bytes accumulate in a DATA buffer
        that is flushed whenever a COPY is emitted.

    Raises ``ValueError`` when the compressed delta is no smaller than
    ``zlib(target)`` — callers should fall back to raw encoding in that case.

    Args:
        base:   Previous version of the object (already stored on the remote).
        target: New version of the object to encode.

    Returns:
        Zlib-compressed binary instruction stream.
    """
    # Degenerate case: empty base → single DATA instruction.
    if not base:
        raw = b"\x01" + struct.pack(">I", len(target)) + target
        return zlib.compress(raw, level=1)

    # Build hash table: chunk → last position in base.
    table: dict[bytes, int] = {}
    for i in range(len(base) - _COPY_THRESHOLD + 1):
        table[base[i : i + _COPY_THRESHOLD]] = i

    parts: list[bytes] = []
    data_buf = bytearray()
    pos = 0

    while pos < len(target):
        # Try to find a matching chunk starting at *pos*.
        if pos + _COPY_THRESHOLD <= len(target):
            chunk = target[pos : pos + _COPY_THRESHOLD]
            base_pos = table.get(chunk)
            if base_pos is not None:
                # Extend match forward as far as bytes agree.
                length = _COPY_THRESHOLD
                while (
                    pos + length < len(target)
                    and base_pos + length < len(base)
                    and target[pos + length] == base[base_pos + length]
                ):
                    length += 1

                # Flush accumulated DATA before emitting COPY.
                if data_buf:
                    parts.append(
                        b"\x01" + struct.pack(">I", len(data_buf)) + bytes(data_buf)
                    )
                    data_buf = bytearray()

                parts.append(b"\x00" + struct.pack(">II", base_pos, length))
                pos += length
                continue

        # No match — accumulate literal byte.
        data_buf.append(target[pos])
        pos += 1

    # Flush trailing DATA.
    if data_buf:
        parts.append(b"\x01" + struct.pack(">I", len(data_buf)) + bytes(data_buf))

    delta = zlib.compress(b"".join(parts), level=1)
    if len(delta) >= len(zlib.compress(target, level=1)):
        raise ValueError("delta not profitable: delta >= zlib(target)")
    return delta

def apply_delta(base: bytes, delta_compressed: bytes) -> bytes:
    """Reconstruct the target by applying *delta_compressed* to *base*.

    Inverse of :func:`compute_delta`.  Parses the instruction stream produced
    by that function and assembles the target byte-for-byte.

    Args:
        base:              The base object bytes (fetched from storage).
        delta_compressed:  Zlib-compressed instruction stream.

    Returns:
        Reconstructed target bytes.

    Raises:
        zlib.error:  *delta_compressed* is corrupt.
        ValueError:  Unknown instruction type in stream.
        struct.error: Truncated instruction stream.
    """
    stream = zlib.decompress(delta_compressed)
    result = bytearray()
    pos = 0
    n = len(stream)

    while pos < n:
        instr_type = stream[pos]
        pos += 1

        if instr_type == 0:  # COPY
            offset, length = struct.unpack_from(">II", stream, pos)
            pos += 8
            result.extend(base[offset : offset + length])

        elif instr_type == 1:  # DATA
            (length,) = struct.unpack_from(">I", stream, pos)
            pos += 4
            result.extend(stream[pos : pos + length])
            pos += length

        else:
            raise ValueError(f"unknown delta instruction type: {instr_type:#04x} at stream offset {pos - 1}")

    return bytes(result)
