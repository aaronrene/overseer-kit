"""muse code type — type-health analysis engine.

Analyses Python type annotations using pure AST (no mypy subprocess).
Provides five distinct lenses on type health:

* **Health report** — per-symbol annotation coverage + aggregate score.
* **Any-blast-radius** — traces how a single ``Any`` annotation propagates
  through the call graph and silently disables type checking for callers.
* **Type drift** — coverage trend over commit history (improving / degrading).
* **Migration targets** — highest-leverage untyped symbols ranked by call-
  graph centrality; tells you where to type *next* for maximum ROI.
* **Type diff** — signature changes between two snapshots; detects widening
  (e.g. ``str → Any``) before merges.

All functions are synchronous, side-effect-free, and size-guarded.
"""

import ast
import datetime
import logging
import pathlib
from typing import TYPE_CHECKING

from muse.core.validation import MAX_AST_BYTES, contain_path
from muse.core.object_store import read_object
from muse.core.query_engine import CommitEvaluator, QueryMatch, walk_history
from muse.core.types import Manifest
from muse.core.commits import CommitRecord

type AnnotationMap = dict[str, "AnnotationSummary"]
from muse.plugins.code._callgraph import (
    ReverseGraph,
    build_reverse_graph,
    transitive_callers,
)
from muse.plugins.code._query import symbols_for_snapshot

if TYPE_CHECKING:
    from muse.core.symbol_cache import SymbolCache
    from muse.plugins.code.ast_parser import SymbolTree

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_MAX_BLAST_DEPTH = 10        # hard ceiling for any_blast_radius depth arg
_DEFAULT_BLAST_DEPTH = 5
_DEFAULT_MAX_DRIFT_COMMITS = 200
_DEFAULT_TOP_N = 20
_TYPED_KINDS = frozenset({"function", "async_function", "method", "async_method"})

# ---------------------------------------------------------------------------
# TypedDicts — public API shapes
# ---------------------------------------------------------------------------

from typing import TypedDict

class AnnotationSummary(TypedDict):
    """Type-annotation state for one callable symbol."""

    address: str
    kind: str
    return_annotation: str   # "" when missing
    return_is_any: bool
    params_total: int        # excludes self / cls
    params_annotated: int
    params_with_any: int
    type_score: float        # 0.0–1.0; 1.0 = fully annotated with no Any

class TypeHealthReport(TypedDict):
    """Aggregate type health for a snapshot."""

    total_symbols: int
    fully_typed: int
    partially_typed: int
    untyped: int
    any_count: int           # total Any occurrences (params + returns)
    coverage_fraction: float
    symbols: list[AnnotationSummary]

class AnyBlastNode(TypedDict):
    """One node in the Any-propagation call graph."""

    address: str
    depth: int
    any_reason: str          # "source_any" | "caller_of_any_symbol"

class TypeDriftPoint(TypedDict):
    """Type-health snapshot at one commit."""

    commit_id: str
    committed_at: str        # ISO-8601
    message: str
    coverage_fraction: float
    any_count: int
    delta_coverage: float    # vs previous commit in the series; 0.0 for first

class MigrationTarget(TypedDict):
    """A symbol worth typing next, ranked by call-graph ROI."""

    address: str
    caller_count: int        # transitive callers at depth ≤ 1 (direct callers)
    type_score: float
    priority_score: float    # caller_count * (1 - type_score); higher = more urgent

class TypeConflict(TypedDict):
    """A type-signature mismatch between two snapshots."""

    address: str
    signature_a: str
    signature_b: str
    change_kind: str         # "widened" | "narrowed" | "added" | "removed" | "changed"

# ---------------------------------------------------------------------------
# Internal helpers — annotation extraction
# ---------------------------------------------------------------------------

def _is_any(node: ast.expr | None) -> bool:
    """Return True when *node* represents ``Any`` or ``typing.Any``."""
    if node is None:
        return False
    if isinstance(node, ast.Name) and node.id == "Any":
        return True
    if (
        isinstance(node, ast.Attribute)
        and node.attr == "Any"
        and isinstance(node.value, ast.Name)
        and node.value.id in ("typing", "t")
    ):
        return True
    return False

def _annotation_str(node: ast.expr | None) -> str:
    """Return a string representation of an annotation node, or empty string."""
    if node is None:
        return ""
    try:
        return ast.unparse(node)
    except Exception:
        return "<unparseable>"

def _type_score(summary: AnnotationSummary) -> float:
    """Compute 0.0–1.0 type score for one callable.

    A symbol with no parameters and a missing return type scores 0.0.
    A fully annotated symbol with no Any scores 1.0.
    Any occurrences and missing annotations reduce the score proportionally.
    """
    slots = summary["params_total"] + 1  # +1 for return
    if slots == 0:
        return 1.0
    annotated = summary["params_annotated"] + (1 if summary["return_annotation"] else 0)
    any_hits = summary["params_with_any"] + (1 if summary["return_is_any"] else 0)
    # Start from the fraction annotated, then penalise Any usage.
    base = annotated / slots
    any_penalty = any_hits / slots
    return max(0.0, base - any_penalty * 0.5)

def _qualified_name(node: ast.FunctionDef | ast.AsyncFunctionDef, parents: list[str]) -> str:
    """Build a qualified name like ``ClassName.method`` from AST context."""
    parts = parents + [node.name]
    return ".".join(parts)

def _walk_functions(
    tree: ast.AST,
    parents: list[str] | None = None,
) -> list[tuple[ast.FunctionDef | ast.AsyncFunctionDef, str]]:
    """Recursively yield (node, qualified_name) for all callables in *tree*."""
    if parents is None:
        parents = []
    results: list[tuple[ast.FunctionDef | ast.AsyncFunctionDef, str]] = []
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            qname = _qualified_name(node, parents)
            results.append((node, qname))
            results.extend(_walk_functions(node, parents + [node.name]))
        elif isinstance(node, ast.ClassDef):
            results.extend(_walk_functions(node, parents + [node.name]))
    return results

def _extract_func_annotation(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
    file_path: str,
    qname: str,
) -> AnnotationSummary:
    """Extract annotation data from one function/method AST node."""
    args = node.args
    # Exclude self / cls from parameter counts (first arg of methods in classes).
    # We detect methods by checking if qname contains a dot.
    is_method = "." in qname
    all_args = args.posonlyargs + args.args + args.kwonlyargs
    if is_method and all_args and all_args[0].arg in ("self", "cls"):
        all_args = all_args[1:]
    # vararg / kwarg
    if args.vararg:
        all_args = all_args + [args.vararg]
    if args.kwarg:
        all_args = all_args + [args.kwarg]

    params_total = len(all_args)
    params_annotated = sum(1 for a in all_args if a.annotation is not None)
    params_with_any = sum(1 for a in all_args if _is_any(a.annotation))

    ret_ann = node.returns
    return_annotation = _annotation_str(ret_ann)
    return_is_any = _is_any(ret_ann)

    address = f"{file_path}::{qname}"
    kind = "async_function" if isinstance(node, ast.AsyncFunctionDef) else "function"
    if is_method:
        kind = "async_method" if isinstance(node, ast.AsyncFunctionDef) else "method"

    summary = AnnotationSummary(
        address=address,
        kind=kind,
        return_annotation=return_annotation,
        return_is_any=return_is_any,
        params_total=params_total,
        params_annotated=params_annotated,
        params_with_any=params_with_any,
        type_score=0.0,
    )
    summary["type_score"] = _type_score(summary)
    return summary

def extract_annotations(src: bytes, file_path: str) -> AnnotationMap:
    """Extract type-annotation data for all callables in *src*.

    Args:
        src:       Raw Python source bytes.
        file_path: Relative path (used as the address prefix).

    Returns:
        ``{address: AnnotationSummary}`` keyed by ``file_path::QualifiedName``.
        Empty dict on parse error or if no callables are present.

    Security: Refuses to parse files exceeding MAX_AST_BYTES.
    """
    if len(src) > MAX_AST_BYTES:
        logger.warning(
            "type_analysis: skipping %s — exceeds MAX_AST_BYTES (%d)",
            file_path,
            MAX_AST_BYTES,
        )
        return {}
    try:
        tree = ast.parse(src, filename=file_path)
    except SyntaxError as exc:
        logger.debug("type_analysis: syntax error in %s: %s", file_path, exc)
        return {}

    result: AnnotationMap = {}
    for node, qname in _walk_functions(tree):
        summary = _extract_func_annotation(node, file_path, qname)
        result[summary["address"]] = summary
    return result

def _signature_str(summary: AnnotationSummary) -> str:
    """Produce a compact signature string for conflict detection.

    Encodes enough information to distinguish widening (e.g. str→Any) even
    when the annotated-param *count* stays the same.
    """
    ret = summary["return_annotation"] or "?"
    # Include any-param count so "int→Any" shows up as a difference.
    any_note = f",any={summary['params_with_any']}" if summary["params_with_any"] > 0 else ""
    ret_any = ",retany" if summary["return_is_any"] else ""
    return (
        f"({summary['params_annotated']}/{summary['params_total']} params"
        f"{any_note}) -> {ret}{ret_any}"
    )

# ---------------------------------------------------------------------------
# Public API — five analysis modes
# ---------------------------------------------------------------------------

def compute_type_health(
    root: pathlib.Path,
    manifest: Manifest,
    *,
    file_filter: str | None = None,
    cache: SymbolCache | None = None,
) -> TypeHealthReport:
    """Compute aggregate type health for *manifest*.

    Args:
        root:        Repository root.
        manifest:    Snapshot manifest (path → object_id).
        file_filter: Optional path prefix filter (e.g. ``"muse/core"``).
        cache:       Optional shared SymbolCache.

    Returns:
        :class:`TypeHealthReport` with per-symbol summaries.
    """
    all_summaries: list[AnnotationSummary] = []
    total = fully_typed = partially_typed = untyped = any_count = 0

    for file_path, object_id in manifest.items():
        if not file_path.endswith(".py"):
            continue
        if file_filter and not file_path.startswith(file_filter):
            continue
        try:
            contain_path(root, file_path)
        except ValueError:
            logger.warning("type_analysis: unsafe path %s — skipping", file_path)
            continue

        raw = read_object(root, object_id)
        if raw is None:
            continue

        summaries = extract_annotations(raw, file_path)
        for s in summaries.values():
            all_summaries.append(s)
            total += 1
            any_count += s["params_with_any"] + (1 if s["return_is_any"] else 0)
            if s["type_score"] >= 0.99:
                fully_typed += 1
            elif s["type_score"] > 0.0:
                partially_typed += 1
            else:
                untyped += 1

    coverage = fully_typed / total if total > 0 else 0.0
    return TypeHealthReport(
        total_symbols=total,
        fully_typed=fully_typed,
        partially_typed=partially_typed,
        untyped=untyped,
        any_count=any_count,
        coverage_fraction=coverage,
        symbols=all_summaries,
    )

def any_blast_radius(
    root: pathlib.Path,
    manifest: Manifest,
    address: str,
    *,
    depth: int = _DEFAULT_BLAST_DEPTH,
    cache: SymbolCache | None = None,
) -> list[AnyBlastNode]:
    """Trace how an ``Any`` annotation at *address* propagates through callers.

    Looks up *address* in the snapshot, verifies it has at least one ``Any``
    annotation (return or parameter), then BFS through the reverse call graph
    to find all transitive callers that inherit the type uncertainty.

    Args:
        root:     Repository root.
        manifest: Snapshot manifest.
        address:  Symbol address (``"file.py::func"``).
        depth:    BFS depth limit (capped at _MAX_BLAST_DEPTH).
        cache:    Optional shared SymbolCache.

    Returns:
        List of :class:`AnyBlastNode`, ordered breadth-first (shallowest first).
        Empty list if the symbol has no ``Any`` annotations or is not found.
    """
    depth = min(depth, _MAX_BLAST_DEPTH)

    # Parse the source file to check the target symbol's annotations.
    if "::" not in address:
        logger.warning("type_analysis: invalid address %s", address)
        return []

    file_path, _qual = address.split("::", 1)
    if file_path not in manifest:
        logger.warning("type_analysis: %s not in snapshot manifest", file_path)
        return []

    raw = read_object(root, manifest[file_path])
    if raw is None:
        return []

    annotations = extract_annotations(raw, file_path)
    target = annotations.get(address)
    if target is None:
        logger.debug("type_analysis: address %s not found in parsed annotations", address)
        return []

    has_any = target["return_is_any"] or target["params_with_any"] > 0
    if not has_any:
        return []

    # Build the reverse call graph for the whole snapshot.
    rev: ReverseGraph = build_reverse_graph(root, manifest, cache=cache)

    # The bare name is the last component after the last dot in the qualified name.
    bare_name = _qual.split(".")[-1]

    callers_by_depth = transitive_callers(bare_name, rev, max_depth=depth)

    nodes: list[AnyBlastNode] = [
        AnyBlastNode(address=address, depth=0, any_reason="source_any")
    ]
    for d in sorted(callers_by_depth):
        for addr in callers_by_depth[d]:
            nodes.append(AnyBlastNode(address=addr, depth=d, any_reason="caller_of_any_symbol"))

    return nodes

def type_drift(
    root: pathlib.Path,
    branch: str,
    *,
    max_commits: int = _DEFAULT_MAX_DRIFT_COMMITS,
    since: datetime.datetime | None = None,
    file_filter: str | None = None,
) -> list[TypeDriftPoint]:
    """Return type-health trend across commit history on *branch*.

    Walks the commit graph oldest-to-newest and computes
    :class:`TypeHealthReport` for each commit's snapshot.

    Args:
        root:        Repository root.
        branch:      Branch name to walk.
        max_commits: Maximum commits to inspect (default 200).
        since:       Skip commits older than this timestamp.
        file_filter: Optional path prefix filter.

    Returns:
        List of :class:`TypeDriftPoint`, oldest first.  ``delta_coverage``
        is 0.0 for the first point, positive for improvement, negative for
        regression.
    """
    points: list[TypeDriftPoint] = []
    # Collect raw data via walk_history; we need manifest so load_manifest=True.

    def _evaluator(
        commit: CommitRecord,
        manifest: Manifest,
        repo_root: pathlib.Path,
    ) -> list[QueryMatch]:
        report = compute_type_health(repo_root, manifest, file_filter=file_filter)
        # Encode report in the QueryMatch extra field so walk_history can return it.
        # We use a sentinel detail and pack the numbers into extra.
        return [
            QueryMatch(
                commit_id=commit.commit_id,
                author=commit.author,
                committed_at=commit.committed_at.isoformat(),
                branch=commit.branch,
                detail="type_drift",
                extra={
                    "coverage": str(report["coverage_fraction"]),
                    "any_count": str(report["any_count"]),
                    "message": commit.message,
                },
            )
        ]

    matches = walk_history(
        root,
        branch,
        _evaluator,
        max_commits=max_commits,
        since=since,
        load_manifest=True,
    )

    # walk_history returns newest-first; reverse for chronological order.
    matches_asc = list(reversed(matches))

    prev_coverage = 0.0
    for i, m in enumerate(matches_asc):
        extra = m.get("extra", {})
        cov = float(extra.get("coverage", "0"))
        delta = cov - prev_coverage if i > 0 else 0.0
        points.append(
            TypeDriftPoint(
                commit_id=m["commit_id"],
                committed_at=m["committed_at"],
                message=extra.get("message", ""),
                coverage_fraction=cov,
                any_count=int(extra.get("any_count", "0")),
                delta_coverage=delta,
            )
        )
        prev_coverage = cov

    return points

def migration_targets(
    root: pathlib.Path,
    manifest: Manifest,
    *,
    top_n: int = _DEFAULT_TOP_N,
    file_filter: str | None = None,
    cache: SymbolCache | None = None,
) -> list[MigrationTarget]:
    """Rank untyped/poorly-typed symbols by call-graph centrality.

    A symbol that is called by many other symbols AND has a low type score
    is the highest-leverage target: typing it propagates type safety to the
    most callers for the least effort.

    Args:
        root:        Repository root.
        manifest:    Snapshot manifest.
        top_n:       Maximum targets to return (default 20).
        file_filter: Optional path prefix filter.
        cache:       Optional shared SymbolCache.

    Returns:
        List of :class:`MigrationTarget` sorted descending by priority_score.
    """
    report = compute_type_health(root, manifest, file_filter=file_filter, cache=cache)

    # Only consider symbols that aren't fully typed.
    candidates = [s for s in report["symbols"] if s["type_score"] < 0.99]
    if not candidates:
        return []

    # Build reverse graph once.
    rev: ReverseGraph = build_reverse_graph(root, manifest, cache=cache)

    targets: list[MigrationTarget] = []
    for s in candidates:
        bare = s["address"].split("::")[-1].split(".")[-1]
        direct = rev.get(bare, [])
        caller_count = len(direct)
        priority = caller_count * (1.0 - s["type_score"])
        targets.append(
            MigrationTarget(
                address=s["address"],
                caller_count=caller_count,
                type_score=s["type_score"],
                priority_score=priority,
            )
        )

    targets.sort(key=lambda t: t["priority_score"], reverse=True)
    return targets[:top_n]

def type_diff(
    root: pathlib.Path,
    manifest_a: Manifest,
    manifest_b: Manifest,
    *,
    file_filter: str | None = None,
    cache: SymbolCache | None = None,
) -> list[TypeConflict]:
    """Compare type signatures between two snapshots.

    Detects:
    * **widened** — annotation became looser (e.g. ``str`` → ``Any``).
    * **narrowed** — annotation became stricter (e.g. ``Any`` → ``str``).
    * **changed** — annotation changed but neither clearly widened nor narrowed.
    * **added** — symbol exists in B but not A (new code).
    * **removed** — symbol exists in A but not B (deleted code).

    Args:
        root:        Repository root.
        manifest_a:  "Before" snapshot manifest (e.g. target branch HEAD).
        manifest_b:  "After" snapshot manifest (e.g. current HEAD).
        file_filter: Optional path prefix filter.
        cache:       Optional shared SymbolCache.

    Returns:
        List of :class:`TypeConflict`, empty when signatures are identical.
    """
    def _load(manifest: Manifest) -> AnnotationMap:
        out: AnnotationMap = {}
        for file_path, oid in manifest.items():
            if not file_path.endswith(".py"):
                continue
            if file_filter and not file_path.startswith(file_filter):
                continue
            raw = read_object(root, oid)
            if raw is None:
                continue
            out.update(extract_annotations(raw, file_path))
        return out

    ann_a = _load(manifest_a)
    ann_b = _load(manifest_b)

    conflicts: list[TypeConflict] = []
    all_addrs = set(ann_a) | set(ann_b)

    for addr in sorted(all_addrs):
        if addr in ann_a and addr not in ann_b:
            conflicts.append(
                TypeConflict(
                    address=addr,
                    signature_a=_signature_str(ann_a[addr]),
                    signature_b="",
                    change_kind="removed",
                )
            )
            continue
        if addr not in ann_a and addr in ann_b:
            conflicts.append(
                TypeConflict(
                    address=addr,
                    signature_a="",
                    signature_b=_signature_str(ann_b[addr]),
                    change_kind="added",
                )
            )
            continue

        sa, sb = ann_a[addr], ann_b[addr]
        sig_a = _signature_str(sa)
        sig_b = _signature_str(sb)
        if sig_a == sig_b:
            continue

        # Classify: widening = score went down (less typed / more Any).
        # Narrowing = score went up.
        score_delta = sb["type_score"] - sa["type_score"]
        if score_delta < -0.05:
            kind = "widened"
        elif score_delta > 0.05:
            kind = "narrowed"
        else:
            kind = "changed"

        conflicts.append(
            TypeConflict(
                address=addr,
                signature_a=sig_a,
                signature_b=sig_b,
                change_kind=kind,
            )
        )

    return conflicts
