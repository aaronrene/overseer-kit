"""Terminal output helpers shared across CLI commands.

Provides colour detection that respects ``NO_COLOR`` (https://no-color.org/),
``TERM=dumb``, and the ``sys.stdout.isatty()`` check, so raw ANSI never leaks
into pipes or logs.
"""

import os
import sys

def use_color() -> bool:
    """Return ``True`` only when colour output is appropriate.

    Respects ``NO_COLOR`` (https://no-color.org/), ``TERM=dumb``, and the
    ``sys.stdout.isatty()`` check so raw ANSI never leaks into pipes or logs.
    """
    if os.environ.get("NO_COLOR") or os.environ.get("TERM") == "dumb":
        return False
    return sys.stdout.isatty()
