"""muse.core.version_tags — protocol-native semantic version tags.

Version tags are lightweight, local-first named pointers from a semantic
version string (e.g. ``v0.2.0-rc14``) to a commit.  They live under
``.muse/version-tags/`` and are independent of the label-annotation system
in :mod:`muse.core.tags` and the MuseHub-aware release system in
:mod:`muse.core.releases`.

Public API
----------
SemVerTag
    Parsed version components — imported from :mod:`muse.core.semver`.

semver_key
    Sort-key function for proper SemVer 2.0 precedence ordering.

VersionTagDict
    JSON-serialisable TypedDict for wire format.

VersionTagRecord
    Frozen dataclass; ``to_dict`` / ``from_dict`` for serialisation.

compute_version_tag_id
    Content-addressed ``sha256:`` ID derivation.

_validate_version_tag_name
    Validate a version tag string before writing or CLI dispatch.

version_tags_dir / version_tag_path
    On-disk path helpers.

write_version_tag / read_version_tag
    Core I/O.

list_version_tags
    Enumerate all tags sorted by SemVer precedence (latest first).

delete_version_tag
    Remove a tag file atomically.
"""
from __future__ import annotations

import datetime
import json as _json
import logging
import pathlib
import re
from dataclasses import dataclass, field
from typing import TypedDict

from muse.core.io import _write_json_atomic
from muse.core.paths import muse_dir
from muse.core.record_helpers import _int_val, _str_val
from muse.core.semver import SemVerTag, parse_semver
from muse.core.types import MsgpackDict, content_hash

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Maximum character length for a version tag name (``v0.2.0-rc14`` is 12).
_MAX_VERSION_TAG_LEN: int = 128

#: Subdirectory name under ``.muse/`` for version tag storage.
_VERSION_TAGS_SUBDIR: str = "version-tags"

# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------

def version_tags_dir(root: pathlib.Path) -> pathlib.Path:
    """Return ``.muse/version-tags/`` — the version tag storage directory."""
    return muse_dir(root) / _VERSION_TAGS_SUBDIR


def version_tag_path(root: pathlib.Path, tag: str) -> pathlib.Path:
    """Return the on-disk path for *tag*'s JSON file.

    Raises :exc:`ValueError` on path-traversal characters (``..``, ``/``,
    ``\\``, or null bytes) so callers never need to sanitise separately.
    """
    if ".." in tag or "/" in tag or "\\" in tag or "\x00" in tag:
        raise ValueError(
            f"Invalid version tag name {tag!r}: contains path-traversal characters."
        )
    return version_tags_dir(root) / f"{tag}.json"


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def _validate_version_tag_name(name: str) -> str:
    """Return *name* unchanged if it is a valid version tag; raise :exc:`ValueError` otherwise.

    Rules:
    - Not empty.
    - Must start with ``"v"``.
    - Max :data:`_MAX_VERSION_TAG_LEN` characters.
    - No whitespace, control characters, ``/``, ``\\``, or null bytes.
    - No ``..`` component (path-traversal guard).
    - Must parse cleanly as SemVer 2.0.
    """
    if not name:
        raise ValueError("Version tag name must not be empty.")
    if len(name) > _MAX_VERSION_TAG_LEN:
        raise ValueError(
            f"Version tag name too long ({len(name)} chars); maximum is {_MAX_VERSION_TAG_LEN}."
        )
    if not name.startswith("v"):
        raise ValueError(
            f"Version tag must start with 'v' (e.g. 'v0.2.0-rc14'), got: {name!r}"
        )
    if re.search(r"[\x00-\x1f\x7f\s/\\]", name):
        raise ValueError(
            "Version tag name contains forbidden characters "
            "(no whitespace, control characters, or path separators)."
        )
    if ".." in name:
        raise ValueError("Version tag name must not contain '..'.")
    # Delegates full SemVer structural validation to the existing parser.
    parse_semver(name)
    return name


# ---------------------------------------------------------------------------
# Semver precedence ordering
# ---------------------------------------------------------------------------

def semver_key(sv: SemVerTag) -> tuple:
    """Return a comparable sort key for *sv* that implements SemVer 2.0 precedence.

    Use ``reverse=True`` when sorting a list to get latest-first order::

        sorted(records, key=lambda r: semver_key(r.semver), reverse=True)

    Precedence tier (descending):
        stable (3) > rc (2) > beta (1) > alpha (0) > generic pre-release (-1)

    Within each tier, higher numbers beat lower.  Build metadata is ignored
    per SemVer 2.0 §10.
    """
    major, minor, patch = sv["major"], sv["minor"], sv["patch"]
    pre = sv["pre"]  # build metadata in sv["build"] is intentionally ignored

    # Stable release — no pre-release identifier.
    if not pre:
        return (major, minor, patch, 3, 0, "")

    # rc<N>
    m = re.fullmatch(r"rc(\d+)", pre)
    if m:
        return (major, minor, patch, 2, int(m.group(1)), "")

    # beta or beta.<N>
    m = re.fullmatch(r"beta(?:\.(\d+))?", pre)
    if m:
        n = int(m.group(1)) if m.group(1) else 0
        return (major, minor, patch, 1, n, "")

    # alpha or alpha.<N>
    m = re.fullmatch(r"alpha(?:\.(\d+))?", pre)
    if m:
        n = int(m.group(1)) if m.group(1) else 0
        return (major, minor, patch, 0, n, "")

    # Generic pre-release: sort lexicographically below alpha.
    return (major, minor, patch, -1, 0, pre)


# ---------------------------------------------------------------------------
# Wire-format TypedDict
# ---------------------------------------------------------------------------

class VersionTagDict(TypedDict):
    """JSON-serialisable representation of a :class:`VersionTagRecord`."""

    tag_id:     str
    repo_id:    str
    tag:        str
    semver:     SemVerTag
    commit_id:  str
    created_at: str
    author:     str
    message:    str


# ---------------------------------------------------------------------------
# ID derivation
# ---------------------------------------------------------------------------

def compute_version_tag_id(repo_id: str, tag: str) -> str:
    """Return the content-addressed ``sha256:`` ID for a version tag.

    The ID is derived from the two fields that uniquely identify a version
    tag: the repository and the version string.  Same inputs always produce
    the same ID — creating the same tag twice is idempotent.
    """
    return content_hash({"repo_id": repo_id, "tag": tag})


# ---------------------------------------------------------------------------
# VersionTagRecord dataclass
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class VersionTagRecord:
    """A protocol-native semantic version tag pointing to a commit.

    Immutable: use ``to_dict`` / ``from_dict`` for serialisation and
    ``write_version_tag`` / ``read_version_tag`` for persistence.
    """

    tag_id:     str
    repo_id:    str
    tag:        str
    semver:     SemVerTag
    commit_id:  str
    created_at: datetime.datetime
    author:     str
    message:    str = field(default="")

    def to_dict(self) -> VersionTagDict:
        """Serialise to a JSON-compatible dict."""
        return VersionTagDict(
            tag_id=self.tag_id,
            repo_id=self.repo_id,
            tag=self.tag,
            semver=self.semver,
            commit_id=self.commit_id,
            created_at=self.created_at.isoformat(),
            author=self.author,
            message=self.message,
        )

    @classmethod
    def from_dict(cls, d: "MsgpackDict | VersionTagDict") -> "VersionTagRecord":
        """Deserialise from a plain dict.

        Missing or malformed fields produce sensible fallbacks rather than
        raising — same defensive pattern as :meth:`TagRecord.from_dict`.
        """
        created_at_str = _str_val(d, "created_at")
        try:
            created_at = datetime.datetime.fromisoformat(created_at_str)
        except ValueError:
            created_at = datetime.datetime.now(datetime.timezone.utc)

        # Parse the nested semver dict; fall back to parsing from the tag string.
        semver_raw = d.get("semver")
        if isinstance(semver_raw, dict):
            sv: SemVerTag = SemVerTag(
                major=_int_val(semver_raw, "major"),
                minor=_int_val(semver_raw, "minor"),
                patch=_int_val(semver_raw, "patch"),
                pre=_str_val(semver_raw, "pre"),
                build=_str_val(semver_raw, "build"),
            )
        else:
            tag_str = _str_val(d, "tag")
            try:
                sv = parse_semver(tag_str)
            except ValueError:
                sv = SemVerTag(major=0, minor=0, patch=0, pre="", build="")

        return cls(
            tag_id=_str_val(d, "tag_id"),
            repo_id=_str_val(d, "repo_id"),
            tag=_str_val(d, "tag"),
            semver=sv,
            commit_id=_str_val(d, "commit_id"),
            created_at=created_at,
            author=_str_val(d, "author"),
            message=_str_val(d, "message"),
        )


# ---------------------------------------------------------------------------
# I/O
# ---------------------------------------------------------------------------

def write_version_tag(root: pathlib.Path, record: VersionTagRecord) -> None:
    """Atomically write *record* to ``.muse/version-tags/<tag>.json``.

    Creates the directory on first write.  A second call with the same tag
    overwrites the previous record (idempotent by intent — use
    ``read_version_tag`` first if you want the duplicate-guard semantics that
    the CLI enforces).
    """
    vtags_dir = version_tags_dir(root)
    vtags_dir.mkdir(parents=True, exist_ok=True)
    path = version_tag_path(root, record.tag)
    _write_json_atomic(path, dict(record.to_dict()))


def read_version_tag(root: pathlib.Path, tag: str) -> VersionTagRecord | None:
    """Read *tag* from disk; return ``None`` if the file does not exist.

    Raises on corrupt JSON so the caller can decide whether to delete and
    re-create rather than silently swallowing data loss.
    """
    path = version_tag_path(root, tag)
    if not path.exists():
        return None
    data = _json.loads(path.read_text(encoding="utf-8"))
    return VersionTagRecord.from_dict(data)


def list_version_tags(root: pathlib.Path) -> list[VersionTagRecord]:
    """Return all version tags sorted by SemVer precedence (latest first).

    Non-JSON files in the directory are silently skipped.  Corrupt JSON
    files emit a warning and are also skipped — a single corrupted entry
    should not prevent reading the rest.
    """
    vtags_dir = version_tags_dir(root)
    if not vtags_dir.exists():
        return []

    records: list[VersionTagRecord] = []
    for path in vtags_dir.iterdir():
        if not path.is_file() or path.suffix != ".json":
            continue
        try:
            data = _json.loads(path.read_text(encoding="utf-8"))
            records.append(VersionTagRecord.from_dict(data))
        except Exception:
            logger.warning("Skipping corrupt version tag file: %s", path)

    return sorted(records, key=lambda r: semver_key(r.semver), reverse=True)


def delete_version_tag(root: pathlib.Path, tag: str) -> bool:
    """Remove the version tag file for *tag*.

    Returns ``True`` if the file was deleted, ``False`` if it did not exist.
    Idempotent: calling with a non-existent tag is not an error.
    """
    path = version_tag_path(root, tag)
    if not path.exists():
        return False
    path.unlink()
    return True
