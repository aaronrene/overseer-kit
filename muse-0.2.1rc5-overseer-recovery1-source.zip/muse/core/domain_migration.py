"""Domain integer migration — re-derive identity keys at new hash-derived HD paths.

Pre-Phase-1 Muse used sequential domain integers (0–6).  Phase 1 switched to
hash-derived integers computed from the canonical name string.  Users who have
keys derived at the old paths must re-derive at the new paths and re-register
with every hub they use.

Public API
----------

``is_legacy_hd_path(hd_path)``
    Returns True if *hd_path* contains one of the known sequential domain
    integers (0–6, excluding 5) in the domain segment.

``new_path_for_legacy(hd_path)``
    Returns the equivalent path with the hash-derived domain integer.
    Raises ``ValueError`` for unknown or non-legacy paths.

``derive_fingerprint_at_path(seed, hd_path)``
    Derives the Ed25519 public-key fingerprint at an arbitrary HD path.

``scan_for_legacy(identity_map)``
    Returns the list of hub keys in *identity_map* whose ``hd_path`` is legacy.

``build_plans(identity_map)``
    Returns one :class:`MigrationPlan` per legacy entry.

``run_migration(identity_map, seed, hub_register_fn, dry_run)``
    Drives the full migration, optionally calling *hub_register_fn* for each
    entry, and mutating *identity_map* in place on a live run.
    Returns a list of :class:`MigrationResult`.
"""

import logging
import re
from collections.abc import Mapping
from dataclasses import dataclass, field

from muse.core.hdkeys import (
    DOMAIN_IDENTITY,
    DOMAIN_PAYMENTS,
    DOMAIN_CODE,
    DOMAIN_MUSIC,
    DOMAIN_MIDI,
    DOMAIN_BLOCKCHAIN,
    muse_path,
)
from muse.core.slip010 import MUSE_PURPOSE

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Old → new mapping
# ---------------------------------------------------------------------------

OLD_DOMAIN_NAMES: dict[int, str] = {
    0: "muse/identity",
    1: "muse/payments",
    2: "muse/code",
    3: "muse/music",
    4: "muse/midi",
    6: "muse/blockchain",
}

_OLD_TO_NEW: dict[int, int] = {
    0: DOMAIN_IDENTITY,
    1: DOMAIN_PAYMENTS,
    2: DOMAIN_CODE,
    3: DOMAIN_MUSIC,
    4: DOMAIN_MIDI,
    6: DOMAIN_BLOCKCHAIN,
}

# Matches a full Muse HD path and captures all six hardened segments.
# Format: m/<purpose>'/<domain>'/<entity_type>'/<entity_id>'/<role>'/<index>'
_PATH_RE = re.compile(
    r"^m/(\d+)'"
    r"/(\d+)'"
    r"/(\d+)'"
    r"/(\d+)'"
    r"/(\d+)'"
    r"/(\d+)'$"
)

def _parse_path(hd_path: str) -> tuple[int, int, int, int, int, int] | None:
    """Parse *hd_path* into its six integer segments, or return None."""
    m = _PATH_RE.match(hd_path.strip())
    if not m:
        return None
    return tuple(int(m.group(i)) for i in range(1, 7))  # type: ignore[return-value]

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def is_legacy_hd_path(hd_path: str) -> bool:
    """Return True if *hd_path* uses a pre-Phase-1 sequential domain integer (0–6).

    Only paths with the Muse purpose index and a domain in the known old set
    (integers 0 through 6) are considered legacy.  Unknown integers, wrong
    purpose, and malformed paths all return False.
    """
    parsed = _parse_path(hd_path)
    if parsed is None:
        return False
    purpose, domain, *_ = parsed
    return purpose == MUSE_PURPOSE and domain in _OLD_TO_NEW

def new_path_for_legacy(hd_path: str) -> str:
    """Return the equivalent HD path with the hash-derived domain integer.

    Raises
    ------
    ValueError
        If *hd_path* is not a recognised legacy path (wrong purpose, domain
        not in 0–6, or malformed format).
    """
    parsed = _parse_path(hd_path)
    if parsed is None:
        raise ValueError(f"Cannot parse HD path: {hd_path!r}")
    purpose, old_domain, entity_type, entity_id, role, index = parsed
    if purpose != MUSE_PURPOSE:
        raise ValueError(f"Not a Muse HD path (wrong purpose {purpose}): {hd_path!r}")
    if old_domain not in _OLD_TO_NEW:
        raise ValueError(f"Unknown legacy domain integer {old_domain}: {hd_path!r}")
    new_domain = _OLD_TO_NEW[old_domain]
    return muse_path(new_domain, entity_type, entity_id, role, index)

def derive_fingerprint_at_path(seed: bytes, hd_path: str) -> str:
    """Derive the Ed25519 public-key fingerprint at an arbitrary SLIP-0010 HD path.

    Returns a canonical ``sha256:<64-hex>`` string.  The private key bytes
    are zeroed immediately after use.

    Parameters
    ----------
    seed:
        64-byte BIP39 root seed from :func:`muse.core.bip39.mnemonic_to_seed`.
    hd_path:
        SLIP-0010 derivation path string (e.g. ``"m/1075233755'/1660078172'/..."``).
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

    from muse.core.slip010 import derive_path
    from muse.core.types import public_key_fingerprint

    if _parse_path(hd_path) is None:
        raise ValueError(f"Cannot parse HD path for derivation: {hd_path!r}")

    dk = derive_path(seed, hd_path)
    try:
        private_key = Ed25519PrivateKey.from_private_bytes(dk.private_bytes)
    finally:
        dk.zero()

    public_key = private_key.public_key()
    raw = public_key.public_bytes(Encoding.Raw, PublicFormat.Raw)
    return public_key_fingerprint(raw)

# ---------------------------------------------------------------------------
# Scanning
# ---------------------------------------------------------------------------

def scan_for_legacy(identity_map: Mapping[str, Mapping[str, object]]) -> list[str]:
    """Return hub keys in *identity_map* whose ``hd_path`` is a legacy path.

    Entries without an ``hd_path`` field are silently skipped — they may be
    pre-HD legacy entries that need a different migration path.
    """
    result = []
    for hub_key, entry in identity_map.items():
        hd_path = entry.get("hd_path", "")
        if hd_path and is_legacy_hd_path(hd_path):
            result.append(hub_key)
    return result

# ---------------------------------------------------------------------------
# Plan and Result
# ---------------------------------------------------------------------------

@dataclass
class MigrationPlan:
    """Describes a single identity entry that needs migration."""

    hub_key: str
    old_hd_path: str
    new_hd_path: str
    old_domain_int: int
    new_domain_int: int
    domain_name: str

@dataclass
class MigrationResult:
    """Outcome of migrating a single identity entry."""

    hub_key: str
    old_fingerprint: str
    new_fingerprint: str
    old_hd_path: str
    new_hd_path: str
    hub_registered: bool

def build_plans(identity_map: Mapping[str, Mapping[str, object]]) -> list[MigrationPlan]:
    """Return one :class:`MigrationPlan` per legacy entry in *identity_map*."""
    plans = []
    for hub_key in scan_for_legacy(identity_map):
        entry = identity_map[hub_key]
        old_path = entry["hd_path"]
        parsed = _parse_path(old_path)
        assert parsed is not None
        old_domain = parsed[1]
        new_domain = _OLD_TO_NEW[old_domain]
        plans.append(MigrationPlan(
            hub_key=hub_key,
            old_hd_path=old_path,
            new_hd_path=new_path_for_legacy(old_path),
            old_domain_int=old_domain,
            new_domain_int=new_domain,
            domain_name=OLD_DOMAIN_NAMES[old_domain],
        ))
    return plans

# ---------------------------------------------------------------------------
# Migration runner
# ---------------------------------------------------------------------------

def run_migration(
    identity_map: dict[str, dict],
    seed: bytes,
    hub_register_fn: "Any",  # noqa: F821
    dry_run: bool = True,
    skip_register: bool = False,
) -> list[MigrationResult]:
    """Drive the full domain integer migration.

    For each legacy entry in *identity_map*:

    1. Derive the new fingerprint at the hash-derived HD path.
    2. If not dry-run and not skip-register, call
       ``hub_register_fn(hub_key, new_fingerprint, new_hd_path, entry)``.
    3. Update *identity_map* in place — but only when the hub actually has
       the new key, or the caller explicitly asked to skip hub registration
       — see ``muse.core.hub_scoping_migration.run_migration`` for the full
       rationale (identical shared-shim risk: a failed registration must
       never leave identity.toml pointing at a key the hub doesn't have,
       while an explicit skip is a deliberate, different case).
    4. Append a :class:`MigrationResult` to the return list.

    Parameters
    ----------
    identity_map:
        The full identity map (hub key → entry dict).  Mutated in place on a
        live run when registration succeeds (or is explicitly skipped);
        untouched during dry-run or on a failed registration attempt.
    seed:
        64-byte BIP39 root seed.
    hub_register_fn:
        Callable ``(hub_key, new_fingerprint, new_hd_path, entry) -> bool``.
        Should return True on success, raise or return False on failure.
        Not called during dry-run or when *skip_register* is set.
    dry_run:
        When True, compute results but make no writes and skip hub calls.
    skip_register:
        When True (and not dry-run), re-derive keys and update
        *identity_map* but never call *hub_register_fn*.

    Returns
    -------
    list[MigrationResult]
        One entry per legacy identity found.  Empty list when nothing needed migration.
    """
    plans = build_plans(identity_map)
    results: list[MigrationResult] = []

    for plan in plans:
        entry = identity_map[plan.hub_key]
        old_fp = entry.get("fingerprint", "")
        new_fp = derive_fingerprint_at_path(seed, plan.new_hd_path)

        hub_registered = False
        if not dry_run:
            if not skip_register:
                try:
                    outcome = hub_register_fn(plan.hub_key, new_fp, plan.new_hd_path, entry)
                    hub_registered = bool(outcome)
                except Exception as exc:
                    logger.warning("hub_register_fn failed for %s: %s", plan.hub_key, exc)
                    hub_registered = False
            # Only mutate local state once the hub actually has the new key,
            # or the caller explicitly asked to skip hub registration — see
            # muse.core.hub_scoping_migration.run_migration for the full
            # rationale (identical shared-shim risk: a failed registration
            # must never leave identity.toml pointing at a key the hub
            # doesn't have).
            if hub_registered or skip_register:
                entry["fingerprint"] = new_fp
                entry["hd_path"] = plan.new_hd_path

        results.append(MigrationResult(
            hub_key=plan.hub_key,
            old_fingerprint=old_fp,
            new_fingerprint=new_fp,
            old_hd_path=plan.old_hd_path,
            new_hd_path=plan.new_hd_path,
            hub_registered=hub_registered,
        ))

    return results
