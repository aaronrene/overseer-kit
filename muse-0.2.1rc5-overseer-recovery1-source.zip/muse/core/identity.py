"""Global identity store — ``~/.muse/identity.toml``.

Ed25519 key-pair credentials are kept here, separate from per-repository
configuration.  This means keys are never accidentally committed to
version control, and a single identity can authenticate across all
repositories on the same hub.

Why global, not per-repo
-------------------------
Muse makes identity a first-class, machine-scoped concept.
The repository knows *where* the hub is (``[hub] url`` in config.toml).
The machine knows *who you are* (this file).  The two concerns are
deliberately separated.

Identity types
--------------
``type = "human"``
    A person.  Authenticated via Ed25519 key pair.

``type = "agent"``
    An autonomous process.  The ``capabilities`` field reflects what the
    agent is allowed to do, enabling self-inspection before attempting an
    operation.  The ``provisioned_by`` field records the human handle that
    authorised this agent, establishing the trust chain at provisioning time.

File format
-----------
TOML with one section per hub hostname or compound ``hostname#agent_id`` key::

    ["localhost:1337"]
    type        = "human"
    handle      = "gabriel"
    key_path    = "/Users/gabriel/.muse/keys/localhost:1337.pem"
    algorithm   = "ed25519"
    fingerprint = "<sha256hex>"

    ["localhost:1337#agentception-abc123"]
    type          = "agent"
    handle        = "agentception-abc123"
    key_path      = "/Users/gabriel/.muse/keys/localhost:1337__agentception-abc123.pem"
    algorithm     = "ed25519"
    fingerprint   = "<sha256hex>"
    provisioned_by = "gabriel"
    capabilities  = ["push", "pull"]

Compound key format
-------------------
``"hostname#agent_id"`` — the ``#`` separator is not a valid hostname
character so it unambiguously separates the hub from the agent handle.
Human entries use the bare hostname; agent entries append ``#<agent_id>``.

Security model
--------------
- ``~/.muse/`` is created with mode 0o700 (user-only directory).
- ``~/.muse/identity.toml`` is written with mode 0o600 **from the first
  byte** — using ``os.open()`` + ``os.fchmod()`` before any data is written,
  eliminating the TOCTOU window that ``write_text()`` + ``chmod()`` creates.
- Writes are atomic: data goes to a temp file in the same directory, then
  ``os.replace()`` renames it over the target.  A kill signal during write
  leaves the old file intact, never a partial file.
- Symlink guard: if the target path is already a symlink, write is refused.
  This blocks symlink-based credential-overwrite attacks.
- The file is never read or written as part of a repository snapshot.
"""

import contextlib
import fcntl
import logging
import os
import pathlib
import stat
import tempfile
import tomllib
from collections.abc import Generator
from typing import TypedDict

from muse.core.paths import user_muse_dir as _user_muse_dir, user_identity_toml_path as _user_identity_toml_path

logger = logging.getLogger(__name__)

_IDENTITY_DIR = _user_muse_dir()
_IDENTITY_FILE = _user_identity_toml_path()

type _IdentityMap = dict[str, "IdentityEntry"]

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

class IdentityEntry(TypedDict, total=False):
    """One authenticated identity, keyed by hub hostname in identity.toml.

    Human entry (``~/.muse/identity.toml``)::

        ["localhost:1337"]
        type        = "human"
        handle      = "gabriel"
        key_path    = "/Users/gabriel/.muse/keys/localhost:1337.pem"
        algorithm   = "ed25519"
        fingerprint = "<sha256hex>"

    Agent entry (compound key ``hostname#agent_id``)::

        ["localhost:1337#agentception-abc123"]
        type           = "agent"
        handle         = "agentception-abc123"
        key_path       = "/Users/gabriel/.muse/keys/localhost:1337__agentception-abc123.pem"
        algorithm      = "ed25519"
        fingerprint    = "<sha256hex>"
        provisioned_by = "gabriel"
        capabilities   = ["push", "pull"]
    """

    type: str             # "human" | "agent"
    handle: str           # hub-assigned handle, e.g. "gabriel" or "agentception-abc123"
    algorithm: str        # "ed25519" | "ml-dsa-65"
    fingerprint: str      # sha256:<64-hex> fingerprint of public key
    capabilities: list[str]  # agent capability strings (empty for humans)
    provisioned_by: str   # for agents: handle of the human who provisioned this key
    # HD wallet provenance (present only when key was derived via BIP39/SLIP-0010)
    hd_path: str                     # SLIP-0010 derivation path
    provisioned_by_fingerprint: str  # agent keys: sha256:<64-hex> fingerprint of operator key
    # In-memory only — never persisted to TOML
    mnemonic: str                    # injected at load time from keychain; not written to disk

# ---------------------------------------------------------------------------
# Path helper
# ---------------------------------------------------------------------------

def get_identity_path() -> pathlib.Path:
    """Return the path to the global identity file (``~/.muse/identity.toml``)."""
    return _IDENTITY_FILE

def _identity_key(hostname: str, agent_id: str | None = None) -> str:
    """Build the TOML section key for a given hostname and optional agent_id.

    Human identities:  ``"localhost:1337"``
    Agent identities:  ``"localhost:1337#agentception-abc123"``

    The ``#`` character is not valid in a hostname so it unambiguously marks
    the boundary between hub and agent handle.
    """
    if agent_id:
        return f"{hostname}#{agent_id}"
    return hostname

# ---------------------------------------------------------------------------
# URL → hostname normalisation
# ---------------------------------------------------------------------------

def hostname_from_url(url: str) -> str:
    """Normalise *url* to a lowercase hostname suitable for use as a dict key.

    Security properties
    -------------------
    - Strips the scheme (``https://``), so different scheme representations of
      the same host resolve to the same key.
    - Strips userinfo (``user:password@``) — embedded credentials in a URL are
      never stored as part of the hostname key.
    - Normalises to lowercase — DNS is case-insensitive, so ``MUSEHUB.AI``
      and ``musehub.ai`` are the same host and must resolve to the same entry.

    Examples::

        "https://musehub.ai/repos/x"      → "musehub.ai"
        "https://admin:s3cr3t@musehub.ai" → "musehub.ai"
        "MUSEHUB.AI"                       → "musehub.ai"
        "https://musehub.ai"               → "musehub.ai"
        "musehub.ai:8443"                  → "musehub.ai:8443"
    """
    stripped = url.strip().rstrip("/")
    # Remove scheme.
    if "://" in stripped:
        stripped = stripped.split("://", 1)[1]
    # Remove userinfo (user:password@) — never embed credentials in the key.
    if "@" in stripped:
        stripped = stripped.rsplit("@", 1)[1]
    # Keep only host[:port], strip any path.
    hostname = stripped.split("/")[0]
    # Normalise to lowercase — DNS is case-insensitive.
    return hostname.lower()

# ---------------------------------------------------------------------------
# TOML serialiser (write-side — stdlib tomllib is read-only)
# ---------------------------------------------------------------------------

def _toml_escape(value: str) -> str:
    """Escape a string value for embedding in a TOML double-quoted string."""
    return value.replace("\\", "\\\\").replace('"', '\\"')

def _dump_identity(identities: _IdentityMap) -> str:
    """Serialise a hostname → entry mapping to TOML text.

    All hostnames are quoted in the section header so that dotted names
    (e.g. ``musehub.ai``) are treated as literal keys, not nested tables.
    All string values are TOML-escaped to prevent injection.
    """
    lines: list[str] = []
    for hostname in sorted(identities):
        entry = identities[hostname]
        # Always quote the section key — dotted names are literal, not nested.
        lines.append(f'["{_toml_escape(hostname)}"]')
        t = entry.get("type", "")
        if t:
            lines.append(f'type = "{_toml_escape(t)}"')
        handle = entry.get("handle", "")
        if handle:
            lines.append(f'handle = "{_toml_escape(handle)}"')
        algorithm = entry.get("algorithm", "")
        if algorithm:
            lines.append(f'algorithm = "{_toml_escape(algorithm)}"')
        fingerprint = entry.get("fingerprint", "")
        if fingerprint:
            lines.append(f'fingerprint = "{_toml_escape(fingerprint)}"')
        provisioned_by = entry.get("provisioned_by", "")
        if provisioned_by:
            lines.append(f'provisioned_by = "{_toml_escape(provisioned_by)}"')
        caps = entry.get("capabilities") or []
        if caps:
            caps_str = ", ".join(f'"{_toml_escape(c)}"' for c in caps)
            lines.append(f"capabilities = [{caps_str}]")
        # HD wallet provenance — only written when present
        # mnemonic is NEVER written to disk — it lives only in the OS keychain
        hd_path = entry.get("hd_path", "")
        if hd_path:
            lines.append(f'hd_path = "{_toml_escape(hd_path)}"')
        provisioned_by_fingerprint = entry.get("provisioned_by_fingerprint", "")
        if provisioned_by_fingerprint:
            lines.append(f'provisioned_by_fingerprint = "{_toml_escape(provisioned_by_fingerprint)}"')
        lines.append("")
    return "\n".join(lines)

# ---------------------------------------------------------------------------
# Load / save
# ---------------------------------------------------------------------------

def _load_all(path: pathlib.Path) -> _IdentityMap:
    """Load all identity entries from *path*.  Returns empty dict if absent."""
    if not path.is_file():
        return {}
    try:
        with path.open("rb") as fh:
            raw = tomllib.load(fh)
    except Exception as exc:  # noqa: BLE001
        # Log only the exception *type*, never its message — a TOML parse
        # error surfaced by tomllib includes the offending line, which can
        # contain a fragment of the token being written when the file is corrupt.
        logger.warning(
            "⚠️ Failed to parse identity file %s (%s — run `muse auth register` to re-authenticate)",
            path,
            type(exc).__name__,
        )
        return {}

    result: _IdentityMap = {}
    for hostname, raw_entry in raw.items():
        if not isinstance(raw_entry, dict):
            continue
        entry: IdentityEntry = {}
        t = raw_entry.get("type")
        if isinstance(t, str):
            entry["type"] = t
        handle = raw_entry.get("handle")
        if isinstance(handle, str):
            entry["handle"] = handle
        key_path = raw_entry.get("key_path")
        if isinstance(key_path, str):
            entry["key_path"] = key_path
        algorithm = raw_entry.get("algorithm")
        if isinstance(algorithm, str):
            entry["algorithm"] = algorithm
        fingerprint = raw_entry.get("fingerprint")
        if isinstance(fingerprint, str):
            entry["fingerprint"] = fingerprint
        caps = raw_entry.get("capabilities")
        if isinstance(caps, list):
            entry["capabilities"] = [str(c) for c in caps if isinstance(c, str)]
        provisioned_by = raw_entry.get("provisioned_by")
        if isinstance(provisioned_by, str):
            entry["provisioned_by"] = provisioned_by
        # mnemonic is never read from TOML — it comes from the keychain at call time
        hd_path = raw_entry.get("hd_path")
        if isinstance(hd_path, str):
            entry["hd_path"] = hd_path
        provisioned_by_fingerprint = raw_entry.get("provisioned_by_fingerprint")
        if isinstance(provisioned_by_fingerprint, str):
            entry["provisioned_by_fingerprint"] = provisioned_by_fingerprint
        result[hostname] = entry

    return result

@contextlib.contextmanager
def _identity_write_lock() -> Generator[None, None, None]:
    """Acquire an exclusive advisory write-lock on the identity store.

    Uses a dedicated lock file (``~/.muse/.identity.lock``) so that the lock
    survives the atomic rename of ``identity.toml`` itself.

    Advisory (cooperative) locking protects all Muse processes that use this
    lock against concurrent read-modify-write races.  Direct file edits by
    external tools bypass the lock — that is acceptable; the user is then
    responsible for data consistency.

    POSIX-only (``fcntl.flock``).  The lock is blocking with no timeout;
    CLI commands are short-lived and lock contention is expected to be brief.
    """
    lock_path = _IDENTITY_DIR / ".identity.lock"
    _IDENTITY_DIR.mkdir(parents=True, exist_ok=True)
    # Create the lock file with owner-only permissions; O_CLOEXEC prevents
    # child processes from inheriting the file descriptor.
    lock_fd = os.open(
        str(lock_path),
        os.O_CREAT | os.O_WRONLY | os.O_CLOEXEC,
        stat.S_IRUSR | stat.S_IWUSR,
    )
    try:
        fcntl.flock(lock_fd, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
    finally:
        os.close(lock_fd)

def _save_all(identities: _IdentityMap, path: pathlib.Path) -> None:
    """Write *identities* to *path* securely.

    Security guarantees
    -------------------
    1. **Symlink guard** — refuses to write if *path* is already a symlink,
       preventing an attacker from pre-placing a symlink to a file they want
       overwritten.
    2. **0o700 directory** — ``~/.muse/`` is restricted to the owner so other
       local users cannot list or traverse it.
    3. **0o600 from byte zero** — the temp file is ``fchmod``-ed to 0o600
       *before* any data is written, eliminating the TOCTOU window that
       ``write_text()`` + ``chmod()`` creates.
    4. **Atomic rename** — ``os.replace()`` swaps the temp file over the
       target atomically; a kill signal during write leaves the old file intact.
    """
    dir_path = path.parent

    # 1. Create ~/.muse/ with owner-only permissions (0o700).
    dir_path.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(dir_path, stat.S_IRWXU)  # 0o700
    except OSError as exc:
        logger.warning("⚠️ Could not set permissions on %s: %s", dir_path, exc)

    # 2. Symlink guard — never follow a symlink placed at the target path.
    if path.is_symlink():
        raise OSError(
            f"Security: {path} is a symlink. "
            "Refusing to write credentials to a symlink target."
        )

    text = _dump_identity(identities)

    # 3. Write to a temp file in the same directory (same fs → atomic rename).
    #    Set 0o600 via fchmod *before* writing any data.
    fd, tmp_path_str = tempfile.mkstemp(dir=dir_path, prefix=".identity-tmp-")
    tmp_path = pathlib.Path(tmp_path_str)
    try:
        os.fchmod(fd, stat.S_IRUSR | stat.S_IWUSR)  # 0o600 before any data
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        # 4. Atomic rename — old file stays intact if we crash before this.
        os.replace(tmp_path, path)
    except Exception:
        try:
            tmp_path.unlink(missing_ok=True)
        except OSError:
            pass
        raise

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_identity(hub_url: str, agent_id: str | None = None) -> IdentityEntry | None:
    """Return the stored identity for *hub_url* (and optional *agent_id*), or ``None``.

    The URL is normalised to a hostname before lookup, so
    ``https://musehub.ai/repos/x`` and ``musehub.ai`` resolve to the same
    entry.

    For human (non-agent) entries, the mnemonic is fetched from the OS keychain
    and injected into the returned entry under the ``mnemonic`` key.
    The mnemonic is never read from the TOML file.

    Args:
        hub_url:  Hub URL or bare hostname.
        agent_id: Agent handle (e.g. ``"agentception-abc123"``).  When
                  supplied the lookup key is ``"hostname#agent_id"``,
                  i.e. the agent's dedicated entry rather than the human's.

    Returns:
        :class:`IdentityEntry` if an identity is stored, else ``None``.
    """
    hostname = hostname_from_url(hub_url)
    key = _identity_key(hostname, agent_id)
    entry = _load_all(_IDENTITY_FILE).get(key)
    if entry is None:
        return None
    # Inject mnemonic from keychain for human entries
    if not agent_id:
        from muse.core.keychain import load as kc_load
        mnemonic = kc_load()
        if mnemonic:
            entry = dict(entry)  # type: ignore[assignment]
            entry["mnemonic"] = mnemonic
    return entry

def save_identity(
    hub_url: str,
    entry: IdentityEntry,
    agent_id: str | None = None,
    mnemonic: str | None = None,
) -> None:
    """Store *entry* as the identity for *hub_url* (and optional *agent_id*).

    The entire read-modify-write cycle is wrapped in an exclusive advisory
    lock so that concurrent ``muse auth register`` calls (e.g. from parallel
    agents) cannot race and overwrite each other's entries.

    Creates ``~/.muse/identity.toml`` with mode 0o600 if it does not exist.

    When *mnemonic* is provided it is stored in the OS keychain (never in the
    TOML file).

    Args:
        hub_url:  Hub URL or bare hostname.
        entry:    Identity data to store.  Must not contain a ``"mnemonic"``
                  key — pass *mnemonic* as the separate keyword argument.
        agent_id: When supplied, the entry is stored under the compound key
                  ``"hostname#agent_id"`` rather than the bare hostname.
        mnemonic: BIP39 mnemonic phrase.  Stored in the OS keychain; the TOML
                  file is never touched.  When keychain is disabled (CI/test)
                  the mnemonic is ephemeral for the lifetime of the process.
    """
    if mnemonic:
        from muse.core.keychain import store as kc_store, is_available as kc_avail
        if kc_avail():
            kc_store(mnemonic)
        elif os.environ.get("MUSE_KEYCHAIN_BACKEND") != "disabled":
            logger.warning(
                "⚠️ Keychain is unavailable — mnemonic is ephemeral and will not "
                "survive process exit. Install a keyring backend or check your OS keychain "
                "configuration. Run `muse auth keygen` again once the keychain is operational.",
            )
        # Strip mnemonic from the dict we write to TOML regardless of keychain availability.
        entry = dict(entry)  # type: ignore[assignment]
        entry.pop("mnemonic", None)  # type: ignore[misc]
    elif "mnemonic" in entry:  # type: ignore[operator]
        # Ensure mnemonic never sneaks into TOML even if caller put it in entry
        entry = dict(entry)  # type: ignore[assignment]
        entry.pop("mnemonic", None)  # type: ignore[misc]

    hostname = hostname_from_url(hub_url)
    key = _identity_key(hostname, agent_id)
    with _identity_write_lock():
        identities = _load_all(_IDENTITY_FILE)
        identities[key] = entry
        _save_all(identities, _IDENTITY_FILE)
    logger.info("✅ Identity for %s saved", key)

def clear_identity(hub_url: str, agent_id: str | None = None) -> bool:
    """Remove the stored identity for *hub_url* (and optional *agent_id*).

    The entire read-modify-write cycle is wrapped in an exclusive advisory
    lock (see :func:`save_identity`).

    Args:
        hub_url:  Hub URL or bare hostname.
        agent_id: When supplied, removes the agent's compound-key entry.

    Returns:
        ``True`` if an entry was removed, ``False`` if no entry existed.
    """
    hostname = hostname_from_url(hub_url)
    key = _identity_key(hostname, agent_id)
    with _identity_write_lock():
        identities = _load_all(_IDENTITY_FILE)
        if key not in identities:
            return False
        del identities[key]
        _save_all(identities, _IDENTITY_FILE)
    logger.info("✅ Identity for %s cleared", key)
    return True

def resolve_signing_identity(
    hub_url: str,
    agent_id: str | None = None,
) -> "tuple[str, object] | None":
    """Return ``(handle, private_key)`` for *hub_url*, or ``None``.

    Derives the Ed25519 private key from the mnemonic stored in the OS keychain
    at call time — no PEM file is ever read or written.

    Resolution order when *agent_id* is provided:
    1. Agent-specific entry (``"hostname#agent_id"``) — used if present.
    2. Human entry (bare hostname) — fallback.

    When *agent_id* is ``None``, only the human (bare-hostname) entry is tried.

    Returns ``None`` when no identity is configured, the entry has no ``hd_path``,
    or the keychain has no mnemonic.

    Args:
        hub_url:  Hub URL or bare hostname.
        agent_id: Optional agent handle to look up a dedicated agent key first.

    Returns:
        ``(handle, Ed25519PrivateKey)`` tuple, or ``None``.
    """
    from muse.core.keychain import load as kc_load
    from muse.core.bip39 import mnemonic_to_seed
    from muse.core.slip010 import derive_path, to_ed25519_private_key

    def _derive(entry: "IdentityEntry") -> "tuple[str, object] | None":
        handle = entry.get("handle", "")
        hd_path = entry.get("hd_path", "")
        if not handle or not hd_path:
            return None
        mnemonic = kc_load()
        if not mnemonic:
            return None
        seed = mnemonic_to_seed(mnemonic)
        dk = derive_path(seed, hd_path)
        try:
            private_key = to_ed25519_private_key(dk)
        except Exception:
            return None
        finally:
            dk.zero()
        return handle, private_key

    # 1. Try agent-specific entry when an agent_id is given.
    if agent_id:
        agent_entry = load_identity(hub_url, agent_id=agent_id)
        if agent_entry is not None:
            result = _derive(agent_entry)
            if result is not None:
                logger.debug("✅ Agent signing key resolved: handle=%s", result[0])
                return result

    # 2. Fall back to the human entry.
    human_entry = load_identity(hub_url)
    if human_entry is None:
        return None

    result = _derive(human_entry)
    if result is None:
        return None

    if agent_id:
        logger.debug(
            "⚠️ No dedicated key for agent '%s' — signing with human key (handle=%s). "
            "Run `muse auth keygen --agent-id %s` to provision a dedicated agent key.",
            agent_id, result[0], agent_id,
        )
    return result

def list_all_identities() -> _IdentityMap:
    """Return all stored identities keyed by hub hostname.

    Returns an empty dict if the identity file does not exist.
    """
    return _load_all(_IDENTITY_FILE)

def clear_all_identities() -> list[str]:
    """Remove every stored identity in a single atomic write.

    The entire read-modify-write cycle is wrapped in an exclusive advisory
    lock (see :func:`save_identity`) so no concurrent process can race.

    This is O(1) writes regardless of how many identities are stored —
    far cheaper than calling :func:`clear_identity` in a loop, which does
    N separate lock → read → write cycles.

    Returns:
        Sorted list of hostnames that were removed.  Empty list if the
        identity file did not exist or contained no entries.
    """
    with _identity_write_lock():
        identities = _load_all(_IDENTITY_FILE)
        if not identities:
            return []
        removed = sorted(identities.keys())
        _save_all({}, _IDENTITY_FILE)
    logger.info("✅ All identities cleared (%d hub(s))", len(removed))
    return removed
