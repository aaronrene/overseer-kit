"""Shallow graft management for Muse repositories.

A *shallow* repository is one whose local history is intentionally incomplete.
The ``.muse/shallow`` file lists the boundary commits: commits whose own
snapshots and objects are expected to be present locally, but whose parents
are not.  The BFS walk in ``run_verify`` stops at these grafts — it does not
descend into history beyond the recorded boundary.

File format::

    # one sha256:-prefixed commit ID per line
    sha256:abc123...
    sha256:def456...

Lines starting with ``#`` and blank lines are ignored.  IDs are stored
sorted to keep diffs deterministic.

This mirrors git's ``.git/shallow`` convention and enables the same workflows:

- **Shallow clones**: pull only the last N commits; mark the boundary.
- **Partial pull**: receive new work without fetching full history.
- **Unshallow**: ``remove_shallow`` on all grafts to restore full history.

Integration with ``run_verify``
-------------------------------
The BFS walk reads the shallow set once at startup.  When it would enqueue
a parent commit whose ID is in the shallow set, it increments
``shallow_commits`` and does not enqueue that parent's own parents —
stopping the walk at the declared boundary.

Integration with ``muse pull``
------------------------------
When a pull advances the local history, the shallow boundary should be
updated:

- Remove the old tip from the shallow set (it is now interior history).
- Add the new graft point if the pull was depth-limited.
- If the pull was unbounded (``--unshallow``), remove all grafts.
"""

import pathlib

from muse.core.paths import shallow_path as _shallow_path

shallow_path = _shallow_path

def read_shallow(root: pathlib.Path) -> frozenset[str]:
    """Return the set of shallow graft commit IDs.

    Returns an empty frozenset when no ``.muse/shallow`` file exists or when
    the file is empty.  Comment lines (``#``) and blank lines are silently
    skipped.
    """
    p = _shallow_path(root)
    if not p.exists():
        return frozenset()
    ids: set[str] = set()
    for line in p.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith("#"):
            ids.add(stripped)
    return frozenset(ids)

def write_shallow(root: pathlib.Path, commit_ids: set[str]) -> None:
    """Atomically write the shallow graft file.

    Sorts IDs before writing so the file is deterministic and diffs cleanly.
    Creates ``.muse/`` if it does not exist.  Writing an empty set produces
    an empty file (``is_shallow`` returns ``False`` in that case).
    """
    p = _shallow_path(root)
    p.parent.mkdir(parents=True, exist_ok=True)
    content = "\n".join(sorted(commit_ids)) + "\n" if commit_ids else ""
    p.write_text(content, encoding="utf-8")

def add_shallow(root: pathlib.Path, commit_id: str) -> None:
    """Add *commit_id* to the shallow graft set.  Idempotent."""
    current = set(read_shallow(root))
    current.add(commit_id)
    write_shallow(root, current)

def remove_shallow(root: pathlib.Path, commit_id: str) -> None:
    """Remove *commit_id* from the shallow graft set.  No-op if absent."""
    current = set(read_shallow(root))
    current.discard(commit_id)
    write_shallow(root, current)

def is_shallow(root: pathlib.Path) -> bool:
    """Return ``True`` when ``.muse/shallow`` exists and contains at least
    one commit ID.
    """
    return bool(read_shallow(root))
