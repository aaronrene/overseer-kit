"""Standard JSON envelope for all muse CLI commands.

Every ``muse`` command that emits JSON includes these six fields so agents
can parse results uniformly without knowing anything about the specific command:

``muse_version``  — the installed muse package version (e.g. ``"0.2.0rc3"``).
``schema``        — per-endpoint integer, starts at ``1``, only incremented on
                    breaking shape changes.  Agents can branch on ``schema < 2``.
``exit_code``     — process exit code embedded in the payload (0 = success).
``duration_ms``   — wall-clock milliseconds for the operation (float).
``timestamp``     — ISO-8601 UTC timestamp when the response was produced.
``warnings``      — list of non-fatal warning strings that would otherwise
                    be lost when stderr is discarded in JSON mode.

Usage::

    from muse.core.envelope import make_envelope
    from muse.core.timing import start_timer

    elapsed = start_timer()
    # ... do work, collect warnings ...
    out = {
        **make_envelope(elapsed, exit_code=0, warnings=warns),
        "symbols": [...],   # domain-specific fields follow
    }
    print(json.dumps(out))
"""

import datetime
from collections.abc import Callable
from typing import TypedDict

from muse import __version__
from muse.core.types import JsonValue as JsonValue  # re-exported for convenience

class EnvelopeJson(TypedDict):
    """Base TypedDict for every muse JSON response.

    Inherit from this in every command-specific TypedDict so the full
    wire shape is self-documenting and MuseHub can import it as the
    canonical contract base::

        class _MyCommandJson(EnvelopeJson):
            my_field: str
            count: int
    """

    muse_version: str
    schema: int
    exit_code: int
    duration_ms: float
    timestamp: str
    warnings: list[str]

def make_envelope(
    elapsed: Callable[[], float],
    *,
    exit_code: int = 0,
    schema: int = 1,
    warnings: list[str] | None = None,
) -> EnvelopeJson:
    """Return the six standard envelope fields for a muse JSON response.

    Args:
        elapsed:   Callable returned by :func:`muse.core.timing.start_timer`.
                   Called once to capture ``duration_ms``.
        exit_code: Process exit code to embed (default ``0``).
        schema:    Per-endpoint schema integer (default ``1``).  Increment
                   only on breaking shape changes.
        warnings:  Optional list of non-fatal warning strings.  Defaults to
                   an empty list.

    Returns:
        A plain ``dict`` with exactly six keys: ``muse_version``, ``schema``,
        ``exit_code``, ``duration_ms``, ``timestamp``, ``warnings``.
    """
    now = datetime.datetime.now(datetime.timezone.utc)
    ts = now.strftime("%Y-%m-%dT%H:%M:%S.") + f"{now.microsecond // 1000:03d}Z"
    return {
        "muse_version": __version__,
        "schema": schema,
        "exit_code": exit_code,
        "duration_ms": elapsed(),
        "timestamp": ts,
        "warnings": warnings if warnings is not None else [],
    }
