"""muse.core.tags — tag layer for the Muse VCS.

Everything that reads, writes, or queries tag records lives here.

Public API
----------
TagDict
    JSON-serialisable TypedDict for TagRecord wire format.

TagRecord
    Immutable tag dataclass with to_dict / from_dict.

compute_tag_id
    Content-addressed ID derivation for tags.

tag_path
    On-disk path helper.

write_tag / _read_tag_or_migrate
    Core tag I/O (write + read with legacy msgpack migration).

get_tags_for_commit / delete_tag / get_all_tags / get_tag_by_name
    Query and mutation helpers.
"""
from __future__ import annotations

import datetime
import json as _json
import logging
import pathlib
from dataclasses import dataclass, field
from typing import TypedDict

from muse.core.io import _read_msgpack_dict, _write_json_atomic
from muse.core.paths import tags_dir as _tags_dir
from muse.core.record_helpers import _str_val
from muse.core.types import Manifest, MsgpackDict, content_hash, short_id, split_id

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Wire-format TypedDict
# ---------------------------------------------------------------------------

class TagDict(TypedDict, total=False):
    """JSON-serialisable representation of a TagRecord."""

    tag_id: str
    repo_id: str
    commit_id: str
    tag: str
    created_at: str
    message: str
    signature: str
    signer_public_key: str
    signer_key_id: str


# ---------------------------------------------------------------------------
# ID derivation
# ---------------------------------------------------------------------------

def compute_tag_id(repo_id: str, commit_id: str, tag: str) -> str:
    """Return the content-addressed ``sha256:`` ID for a tag.

    The ID is derived from the three fields that uniquely identify a tag:
    its repository, the commit it points to, and its name.  Same inputs
    always produce the same ID — creating the same tag twice is idempotent.
    """
    return content_hash({"commit_id": commit_id, "repo_id": repo_id, "tag": tag})


# ---------------------------------------------------------------------------
# TagRecord dataclass
# ---------------------------------------------------------------------------

@dataclass
class TagRecord:
    """A semantic tag attached to a commit."""

    tag_id: str
    repo_id: str
    commit_id: str
    tag: str
    created_at: datetime.datetime = field(
        default_factory=lambda: datetime.datetime.now(datetime.timezone.utc)
    )
    message: str = ""
    signature: str = ""
    signer_public_key: str = ""
    signer_key_id: str = ""

    def to_dict(self) -> TagDict:
        return TagDict(
            tag_id=self.tag_id,
            repo_id=self.repo_id,
            commit_id=self.commit_id,
            tag=self.tag,
            created_at=self.created_at.isoformat(),
            message=self.message,
            signature=self.signature,
            signer_public_key=self.signer_public_key,
            signer_key_id=self.signer_key_id,
        )

    @classmethod
    def from_dict(cls, d: "MsgpackDict | TagDict") -> "TagRecord":
        """Deserialise a :class:`TagRecord` from a plain dict."""
        created_at_str = _str_val(d, "created_at")
        try:
            created_at = datetime.datetime.fromisoformat(created_at_str)
        except ValueError:
            created_at = datetime.datetime.now(datetime.timezone.utc)
        return cls(
            repo_id=_str_val(d, "repo_id"),
            commit_id=_str_val(d, "commit_id"),
            tag=_str_val(d, "tag"),
            tag_id=_str_val(d, "tag_id") or compute_tag_id(
                _str_val(d, "repo_id"), _str_val(d, "commit_id"), _str_val(d, "tag")
            ),
            created_at=created_at,
            message=_str_val(d, "message"),
            signature=_str_val(d, "signature"),
            signer_public_key=_str_val(d, "signer_public_key"),
            signer_key_id=_str_val(d, "signer_key_id"),
        )


# ---------------------------------------------------------------------------
# Path helper
# ---------------------------------------------------------------------------

def tag_path(repo_root: pathlib.Path, repo_id: str, tag_id: str) -> pathlib.Path:
    """Return the on-disk path for a tag record.

    Path shape: ``.muse/tags/<repo-algo>/<repo-hex>/<tag-algo>/<tag-hex>.json``

    Both the repo and the tag carry independent algorithm segments.  This
    handles heterogeneous hashing across time — a repo created with sha256
    can hold tags hashed with blake3 and the path encodes both without
    ambiguity.  No colon ever appears in a filename segment, making the layout
    safe on Windows.

    Args:
        repo_root: Repository root directory.
        repo_id:   A ``<algo>:<hex>`` repo ID, or bare 64-char hex.
        tag_id:    A ``<algo>:<hex>`` tag ID, or bare 64-char hex.

    Returns:
        Absolute path to the JSON file for this tag.
    """
    r_algo, r_hex = split_id(repo_id)
    t_algo, t_hex = split_id(tag_id)
    return _tags_dir(repo_root) / r_algo / r_hex / t_algo / f"{t_hex}.json"


# ---------------------------------------------------------------------------
# Tag I/O
# ---------------------------------------------------------------------------

def write_tag(repo_root: pathlib.Path, tag: TagRecord) -> None:
    """Persist a tag record to ``.muse/tags/<repo-algo>/<repo-hex>/<tag-algo>/<tag-hex>.json``."""
    path = tag_path(repo_root, tag.repo_id, tag.tag_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    _write_json_atomic(path, tag.to_dict())
    logger.debug("✅ Stored tag %r on commit %s", tag.tag, short_id(tag.commit_id))


def _read_tag_or_migrate(path: pathlib.Path) -> "TagRecord | None":
    """Read a tag from *path*, handling both .json and legacy .msgpack files.

    If *path* is a .msgpack file, the record is silently migrated to .json
    and the old file deleted.
    """
    try:
        if path.suffix == ".json":
            d: MsgpackDict = _json.loads(path.read_bytes().decode("utf-8"))
        else:
            d = _read_msgpack_dict(path)
            json_path = path.with_suffix(".json")
            _write_json_atomic(json_path, d)
            path.unlink(missing_ok=True)
        return TagRecord.from_dict(d)
    except Exception:
        return None


def get_tags_for_commit(
    repo_root: pathlib.Path, repo_id: str, commit_id: str
) -> list[TagRecord]:
    """Return all tags attached to *commit_id*."""
    r_algo, r_hex = split_id(repo_id)
    repo_dir = _tags_dir(repo_root) / r_algo / r_hex
    if not repo_dir.exists():
        return []
    results: list[TagRecord] = []
    for path in repo_dir.glob("*/*"):
        if path.suffix not in (".json", ".msgpack"):
            continue
        record = _read_tag_or_migrate(path)
        if record is not None and record.commit_id == commit_id:
            results.append(record)
    return results


def delete_tag(repo_root: pathlib.Path, repo_id: str, tag_id: str) -> bool:
    """Delete the tag file identified by *tag_id*; return True if it existed."""
    path = tag_path(repo_root, repo_id, tag_id)
    if path.exists():
        path.unlink()
        logger.debug("🗑️ Deleted tag %s", tag_id)
        return True
    return False


def get_all_tags(repo_root: pathlib.Path, repo_id: str) -> list[TagRecord]:
    """Return all tags in this repository.

    Handles both current .json files and legacy .msgpack files, migrating
    the latter to .json on first read.  Corrupt files are skipped.
    """
    r_algo, r_hex = split_id(repo_id)
    repo_dir = _tags_dir(repo_root) / r_algo / r_hex
    if not repo_dir.exists():
        return []
    results: list[TagRecord] = []
    for path in repo_dir.glob("*/*"):
        if path.suffix not in (".json", ".msgpack"):
            continue
        record = _read_tag_or_migrate(path)
        if record is not None:
            results.append(record)
        else:
            logger.critical("❌ Corrupt tag file %s — skipped in listing", path)
    return results


def get_tag_by_name(
    repo_root: pathlib.Path, repo_id: str, tag_name: str
) -> "TagRecord | None":
    """Return the first tag whose ``tag`` field matches *tag_name*, or ``None``."""
    for record in get_all_tags(repo_root, repo_id):
        if record.tag == tag_name:
            return record
    return None
