"""Monotonic timing utility for agent-facing JSON output.

Every ``muse`` command that emits JSON includes ``duration_ms`` and
``exit_code`` so agents can measure latency and check results without
inspecting the process exit status separately.

Usage::

    elapsed = start_timer()
    # ... do work ...
    output["duration_ms"] = elapsed()
    output["exit_code"] = 0
"""

import time
from collections.abc import Callable

def start_timer() -> Callable[[], float]:
    """Capture a monotonic start time and return an elapsed-ms callable.

    Returns:
        A zero-argument callable that, when called, returns the number of
        milliseconds elapsed since ``start_timer()`` was called, rounded
        to three decimal places.

    Example::

        elapsed = start_timer()
        do_work()
        ms = elapsed()   # e.g. 12.345
    """
    t0 = time.monotonic()
    return lambda: round((time.monotonic() - t0) * 1000, 3)
