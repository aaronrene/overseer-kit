"""Code-domain HarmonyPlugin — normalized token-bag similarity.

``CodePlugin``
    Implements the :class:`~muse.core.harmony.engine.HarmonyPlugin` protocol
    for code-domain conflict patterns.  Computes Tanimoto similarity on
    normalized token multisets produced by :func:`code_fingerprint`.

``code_fingerprint(source)``
    Converts a code snippet into a sorted, space-separated string of
    normalized tokens.  Pass the result as ``--semantic-fingerprint`` when
    recording a code-domain conflict pattern.

Normalization rules
-------------------

===================  ===========
Raw token            Normalized
===================  ===========
Python keyword       preserved as-is (``def``, ``class``, ``return``, …)
Identifier           ``ID``
String literal       ``STR``
Number literal       ``NUM``
Operator / punctuation  preserved (``(``, ``+``, ``:``, ``->``, …)
Comment              stripped
Whitespace / indent  stripped
===================  ===========

Fingerprint format
------------------

The fingerprint is a **sorted** space-separated token list with repetitions
preserved (multiset encoding)::

    code_fingerprint("def foo(x): return x + 1")
    # → "( ) + : ID ID ID NUM def return"

Sorting makes the fingerprint order-independent: renaming all identifiers in
a function body does not change its structural fingerprint.

Similarity metric
-----------------

:class:`CodePlugin` uses the **Tanimoto coefficient** (multiset Jaccard)::

    sim(A, B) = |min(A, B)| / |max(A, B)|

where ``|min|`` is the sum of element-wise minimums and ``|max|`` the sum of
element-wise maximums across all distinct token types.

Tanimoto on multisets rewards shared token *frequencies*, not just shared
types — two functions with three ``ID`` tokens each score higher than a
function with three ``ID`` tokens vs one with ten.

Typical scores
~~~~~~~~~~~~~~

===========================================  =======
Structural relationship                      Score
===========================================  =======
Identical source (or same keywords + ops)     1.00
Same function, different identifier names     1.00
Same import pattern, different module name    1.00
Same function, one extra parameter            ~0.70
Same function, added docstring                ~0.65
Function body vs class skeleton               ~0.17
Completely unrelated                         <0.20
===========================================  =======

Fallback tokenizer
------------------

If the Python :mod:`tokenize` module raises :exc:`tokenize.TokenError`
(malformed or non-Python source), :func:`code_fingerprint` falls back to a
simple regex-based tokenizer that applies the same normalization rules.  This
handles SQL, YAML fragments, and other text-like conflict regions gracefully.

Usage example
-------------

::

    from muse.core.plugins.code_harmony import CodePlugin, code_fingerprint

    # When recording a conflict:
    fp = code_fingerprint(conflict_region_source)
    # → pass as --semantic-fingerprint to muse harmony record

    # When running the engine with code-aware similarity:
    result = resolve(root, pattern, plugin=CodePlugin())

Thread safety
-------------

Both :func:`code_fingerprint` and :class:`CodePlugin` are stateless — safe
for concurrent use without locking.
"""

import io
import keyword
import re
import tokenize
from collections import Counter

# ---------------------------------------------------------------------------
# Size guard — prevent OOM on adversarial inputs
# ---------------------------------------------------------------------------

#: Maximum source bytes processed by :func:`code_fingerprint`.
#: Input beyond this limit is silently truncated before tokenization.
_MAX_SOURCE_BYTES: int = 524_288  # 512 KiB

# ---------------------------------------------------------------------------
# Regex-based fallback tokenizer
# ---------------------------------------------------------------------------

#: Matches one token in a "code-like" string: comment, string, number,
#: identifier, or a single non-whitespace character (operator/punctuation).
_TOKEN_RE: re.Pattern[str] = re.compile(
    r"#[^\n]*"                   # Python/Ruby/Shell line comment → skip
    r'|//[^\n]*'                 # C/JS/Go line comment → skip
    r'|"(?:[^"\\]|\\.)*"'        # double-quoted string
    r"|'(?:[^'\\]|\\.)*'"        # single-quoted string
    r"|[0-9]+(?:\.[0-9]*)?"      # integer or decimal number
    r"|[A-Za-z_\u0080-\uFFFF][A-Za-z0-9_\u0080-\uFFFF]*"  # identifier (incl. unicode)
    r"|[^\s]",                   # single non-whitespace (operator/punctuation)
    re.UNICODE,
)

def _tokenize_fallback(source: str) -> list[str]:
    """Regex-based tokenizer for non-Python or malformed source."""
    tokens: list[str] = []
    for m in _TOKEN_RE.finditer(source):
        tok = m.group()

        # Skip comments
        if tok.startswith("#") or tok.startswith("//"):
            continue

        # String literals
        if tok.startswith(('"', "'")):
            tokens.append("STR")
            continue

        # Numbers
        if tok[0].isdigit():
            tokens.append("NUM")
            continue

        # Identifiers and keywords
        if tok[0].isalpha() or tok[0] == "_" or ord(tok[0]) > 127:
            tokens.append(tok if keyword.iskeyword(tok) else "ID")
            continue

        # Operators and punctuation (single chars and multi-char via OP)
        tokens.append(tok)

    return tokens

# ---------------------------------------------------------------------------
# Python tokenizer
# ---------------------------------------------------------------------------

#: Token types to silently drop during Python tokenization.
_SKIP_TYPES: frozenset[int] = frozenset({
    tokenize.COMMENT,
    tokenize.NEWLINE,
    tokenize.NL,
    tokenize.INDENT,
    tokenize.DEDENT,
    tokenize.ENCODING,
    tokenize.ENDMARKER,
})

def _tokenize_python(source: str) -> list[str]:
    """Tokenize Python source using :mod:`tokenize`, normalizing tokens.

    Falls back to :func:`_tokenize_fallback` on :exc:`tokenize.TokenError`.
    """
    # Strip null bytes — they cause tokenize to raise immediately
    source = source.replace("\x00", "")

    tokens: list[str] = []
    try:
        stream = io.StringIO(source)
        for tok_type, tok_string, _, _, _ in tokenize.generate_tokens(stream.readline):
            if tok_type in _SKIP_TYPES:
                continue
            if tok_type == tokenize.NAME:
                tokens.append(tok_string if keyword.iskeyword(tok_string) else "ID")
            elif tok_type == tokenize.STRING:
                tokens.append("STR")
            elif tok_type == tokenize.NUMBER:
                tokens.append("NUM")
            elif tok_type == tokenize.OP:
                tokens.append(tok_string)
            # OP covers all operators and punctuation; other types dropped
    except tokenize.TokenError:
        tokens = _tokenize_fallback(source)

    return tokens

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def code_fingerprint(source: str) -> str:
    """Return a normalized token-bag fingerprint for a code snippet.

    The fingerprint is a **sorted** space-separated string of normalized
    tokens (see module docstring for normalization rules).  Sorting makes it
    order-independent: renaming identifiers does not change the fingerprint.

    Input longer than :data:`_MAX_SOURCE_BYTES` is silently truncated.
    Malformed Python falls back to a regex-based tokenizer.

    Args:
        source: Raw source code of the conflict region.

    Returns:
        Sorted space-separated normalized token string, or ``""`` for empty /
        whitespace-only / comment-only input.

    Example::

        code_fingerprint("def foo(x): return x + 1")
        # → "( ) + : ID ID ID NUM def return"
    """
    if not source or not source.strip():
        return ""

    # Guard against oversized input
    if len(source.encode()) > _MAX_SOURCE_BYTES:
        source = source.encode()[:_MAX_SOURCE_BYTES].decode(errors="replace")

    tokens = _tokenize_python(source)
    return " ".join(sorted(tokens))

class CodePlugin:
    """HarmonyPlugin for code-domain conflict similarity.

    Implements the :class:`~muse.core.harmony.engine.HarmonyPlugin` structural
    protocol — no explicit inheritance required.

    Computes Tanimoto similarity on the token multisets encoded in two
    :func:`code_fingerprint` strings.  Returns values in ``[0.0, 1.0]``.

    Typical usage::

        from muse.core.plugins.code_harmony import CodePlugin
        from muse.core.harmony.engine import resolve, EngineConfig

        result = resolve(root, pattern, plugin=CodePlugin())
    """

    def similarity(self, fp_a: str, fp_b: str) -> float:
        """Tanimoto coefficient on token multisets.

        Args:
            fp_a: Fingerprint string from :func:`code_fingerprint`.
            fp_b: Fingerprint string from :func:`code_fingerprint`.

        Returns:
            Float in ``[0.0, 1.0]``.  ``1.0`` for identical token bags;
            ``0.0`` when one fingerprint is empty and the other is not.
        """
        if not fp_a and not fp_b:
            return 1.0
        if not fp_a or not fp_b:
            return 0.0

        ca = Counter(fp_a.split())
        cb = Counter(fp_b.split())

        all_tokens = set(ca) | set(cb)
        intersection = sum(min(ca[t], cb[t]) for t in all_tokens)
        union = sum(max(ca[t], cb[t]) for t in all_tokens)

        return intersection / union if union else 1.0
