"""Persistent implicit-edge cache — eliminates re-running framework plugins.

Architecture
------------
``build_implicit_edge_graph`` re-reads every Python blob and re-runs all
framework plugins (FastAPI, Flask, Celery) on every invocation: ~10 s for
a 779-file repo.  The result is fully determined by file content — the same
bytes always produce the same list of ``ImplicitEntryEdge`` objects.

``ImplicitEdgeCache`` exploits this by persisting a **per-file edge list**
keyed by the SHA-256 of the file bytes (``object_id`` from the manifest):

    key:   SHA-256 hex digest of raw Python file bytes (``object_id``)
    value: list of ``ImplicitEntryEdge`` objects for the file

Storing the complete per-file result means the warm path skips every
expensive operation: ``read_object``, ``parse_symbols``, and all plugin
``detect_entry_points`` calls.

Storage
-------
``.muse/cache/implicit_edges.json``::

    {
        "version": 2,
        "entries": {
            "<sha256-hex>": [
                {"framework_id": "fastapi", "symbol_address": "…",
                 "kind": "http-route", "metadata": {"method": "GET", "path": "/"}},
                …
            ]
        }
    }

Writes are atomic (Pattern A): ``mkstemp`` gives each writer a unique temp
file so two concurrent saves cannot interleave bytes; ``os.replace`` is the
atomic rename.

Typical lifecycle inside ``build_implicit_edge_graph``::

    cache = load_implicit_edge_cache(root)
    for file_path, obj_id in manifest.items():
        edges = cache.get(obj_id)
        if edges is None:
            raw = read_object(root, obj_id)
            edges = _run_plugins(file_path, raw)
            cache.put(obj_id, edges)
        for edge in edges:
            graph.setdefault(edge.symbol_address, []).append(edge)
    cache.save()
"""

import pathlib
from typing import TYPE_CHECKING

from muse.core.cache_base import MsgpackCache, _RawCacheMap
from muse.core.types import MsgpackValue

type _EdgeDict = dict[str, str]

if TYPE_CHECKING:
    from muse.plugins.code._framework import ImplicitEntryEdge

_CACHE_VERSION = 2
_CACHE_FILENAME = "implicit_edges.json"

# Required string fields in a serialised ImplicitEntryEdge dict.
_REQUIRED_STR_FIELDS = ("framework_id", "symbol_address", "kind")

def _edge_from_dict(raw: MsgpackValue) -> "ImplicitEntryEdge | None":
    """Deserialise a raw JSON dict to an ``ImplicitEntryEdge``, or None on error.

    Imports ``ImplicitEntryEdge`` lazily to avoid a circular import with
    ``muse.plugins.code._framework``.
    """
    if not isinstance(raw, dict):
        return None
    for field in _REQUIRED_STR_FIELDS:
        if not isinstance(raw.get(field), str):
            return None
    metadata = raw.get("metadata", {})
    if not isinstance(metadata, dict):
        metadata = {}
    from muse.plugins.code._framework import ImplicitEntryEdge  # lazy
    return ImplicitEntryEdge(
        framework_id=raw["framework_id"],
        symbol_address=raw["symbol_address"],
        kind=raw["kind"],
        metadata={str(k): str(v) for k, v in metadata.items()},
    )

def _edge_to_dict(edge: "ImplicitEntryEdge") -> _EdgeDict:
    """Serialise an ``ImplicitEntryEdge`` to a plain JSON-serialisable dict."""
    return {
        "framework_id": edge.framework_id,
        "symbol_address": edge.symbol_address,
        "kind": edge.kind,
        "metadata": dict(edge.metadata),
    }

class ImplicitEdgeCache(MsgpackCache):
    """Persistent JSON cache mapping object_id → list[ImplicitEntryEdge].

    ``ImplicitEntryEdge`` is imported lazily to avoid a circular import with
    ``muse.plugins.code._framework``.

    Inherits load/save/get/put/prune/size/empty from :class:`MsgpackCache`
    (Pattern A — mkstemp + replace).

    Typical lifecycle inside ``build_implicit_edge_graph``::

        cache = ImplicitEdgeCache.load(muse_dir)
        for file_path, object_id in manifest.items():
            edges = cache.get(object_id)
            if edges is None:
                raw = read_object(root, object_id)
                edges = _run_plugins(file_path, raw)
                cache.put(object_id, edges)
            for edge in edges:
                graph.setdefault(edge.symbol_address, []).append(edge)
        cache.save()

    Attributes
    ----------
    _cache_dir : pathlib.Path | None
        Absolute path to ``.muse/cache/``.  ``None`` for in-memory-only
        instances (``empty()``).  ``save()`` is a no-op when ``None``.
    _dirty : bool
        Set to ``True`` by ``put()`` and ``prune()`` when entries change.
        Reset to ``False`` by a successful ``save()``.
    """

    _CACHE_FILENAME = "implicit_edges.json"
    _CACHE_VERSION = 2
    _TEMP_PREFIX = ".implicit_edges_"

    @classmethod
    def _deserialize_entries(cls, raw: _RawCacheMap) -> _RawCacheMap:
        """Validate and convert raw JSON entries to typed edge lists.

        Each value must be a list of edge dicts; invalid edge lists are skipped.
        """
        entries: dict[str, list[ImplicitEntryEdge]] = {}
        for obj_id, edge_list_raw in raw.items():
            if not isinstance(obj_id, str):
                continue
            if not isinstance(edge_list_raw, list):
                continue
            edge_list: list[ImplicitEntryEdge] = []
            valid = True
            for raw_edge in edge_list_raw:
                edge = _edge_from_dict(raw_edge)
                if edge is None:
                    valid = False
                    break
                edge_list.append(edge)
            if valid:
                entries[obj_id] = edge_list
        return entries

    def _serialize_entries(self) -> _RawCacheMap:
        """Convert ImplicitEntryEdge objects to plain JSON-serialisable dicts."""
        return {
            obj_id: [_edge_to_dict(e) for e in edges]
            for obj_id, edges in self._entries.items()
        }

    # Type-narrowing overrides

    def get(self, object_id: str) -> "list[ImplicitEntryEdge] | None":
        """Return the cached edge list for *object_id*, or ``None`` on miss."""
        return self._entries.get(object_id)  # type: ignore[return-value]

    def put(self, object_id: str, edges: "list[ImplicitEntryEdge]") -> None:
        """Store *edges* under *object_id* and mark the cache dirty."""
        super().put(object_id, edges)

    def prune(self, live_ids: set[str]) -> None:
        """Remove entries whose object IDs are not in *live_ids*."""
        super().prune(live_ids)

def load_implicit_edge_cache(root: pathlib.Path) -> ImplicitEdgeCache:
    """Convenience loader: return an ``ImplicitEdgeCache`` for a repository root.

    Returns ``ImplicitEdgeCache.empty()`` when *root* has no ``.muse`` directory.
    """
    return ImplicitEdgeCache.from_root(root)  # type: ignore[return-value]
