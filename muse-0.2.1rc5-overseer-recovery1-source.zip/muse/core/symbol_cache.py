"""Persistent symbol-tree cache — eliminates re-parsing on every CLI invocation.

Architecture
------------
Every call to ``symbols_for_snapshot`` currently re-parses all semantic files
from their raw bytes: ~1,300 ms for a 400-file Python codebase.  The parse
result is fully determined by the file content — the same bytes always produce
the same ``SymbolTree``.

``SymbolCache`` exploits this by persisting the parse results keyed by the
SHA-256 of the file bytes (``object_id`` from the content-addressed object
store, or a freshly computed SHA-256 for working-tree reads).  On a warm cache
hit the parse step is skipped entirely; the full snapshot loads in ~22 ms
instead of ~1,300 ms — a 60× speedup.

Cache key
---------
The key is the 64-character lowercase SHA-256 hex digest of the **raw file
bytes**, which is:

* For committed files — the ``object_id`` from the snapshot manifest
  (content-addressed, so it is already the SHA-256 of the bytes).
* For working-tree files — ``hashlib.sha256(raw_bytes).hexdigest()``,
  computed from the bytes already read from disk.

Because the key is content-addressed, every hit is guaranteed correct.
A file edit produces a new SHA-256 → cache miss → fresh parse → new entry.
Old entries for changed files become dead weight but never produce wrong
results.

Storage
-------
``.muse/cache/symbols.json`` — a plain JSON document::

    {
        "version": 2,
        "entries": {
            "<sha256-hex>": {
                "<file::address>": {
                    "kind": "function",
                    "name": "run",
                    ...
                }
            }
        }
    }

Writes are atomic (Pattern A): ``mkstemp`` gives each writer a unique temp
file so two concurrent saves cannot interleave bytes; ``os.replace`` is the
atomic rename.

Pruning
-------
Entries accumulate as new file versions are committed.  The cache is naturally
bounded by the object store: once ``muse gc`` collects an object, its symbol
cache entry is dead weight.  A future ``muse gc`` integration can prune the
cache via :meth:`SymbolCache.prune`.  Until then, the cache grows at the rate
of unique file-content changes — typically kilobytes per commit.
"""

import hashlib
import pathlib
from typing import TypeGuard, get_args

from muse.core.cache_base import MsgpackCache, _RawCacheMap
from muse.core.types import MsgpackValue
from muse.plugins.code.ast_parser import SymbolKind, SymbolRecord, SymbolTree

type _SymbolTreeMap = dict[str, "SymbolTree"]

_CACHE_VERSION = 2
_CACHE_FILENAME = "symbols.json"

# All string fields in SymbolRecord, used for structural validation on load.
_STR_FIELDS: frozenset[str] = frozenset({
    "kind", "name", "qualified_name", "content_id",
    "body_hash", "signature_id", "metadata_id", "canonical_key",
})
_INT_FIELDS: frozenset[str] = frozenset({"lineno", "end_lineno"})
_VALID_KINDS: frozenset[str] = frozenset(get_args(SymbolKind))

def _object_id_of(raw: bytes) -> str:
    """Return the content-addressed ``sha256:`` ID of *raw* bytes."""
    from muse.core.types import blob_id
    return blob_id(raw)

def _is_symbol_record(obj: MsgpackValue) -> TypeGuard[SymbolRecord]:
    """Return ``True`` if *obj* is structurally a valid ``SymbolRecord``.

    Used during cache deserialization to validate entries from JSON without
    constructing a new dict — the validated dict IS the SymbolRecord at runtime.
    """
    if not isinstance(obj, dict):
        return False
    for field in _STR_FIELDS:
        if not isinstance(obj.get(field), str):
            return False
    for field in _INT_FIELDS:
        if not isinstance(obj.get(field), int):
            return False
    return obj["kind"] in _VALID_KINDS

class SymbolCache(MsgpackCache):
    """Persistent JSON cache mapping object_id → SymbolTree.

    Inherits load/save/get/put/prune/size/empty from :class:`MsgpackCache`
    (Pattern A — mkstemp + replace).

    Typical lifecycle inside ``symbols_for_snapshot``::

        cache = SymbolCache.load(muse_dir)
        for file_path, object_id in manifest.items():
            tree = cache.get(object_id)
            if tree is None:
                raw = read_object(root, object_id)
                tree = parse_symbols(raw, file_path)
                cache.put(object_id, tree)
        cache.save()

    Attributes
    ----------
    _cache_dir : pathlib.Path | None
        Absolute path to ``.muse/cache/``.  ``None`` for in-memory-only
        instances (``empty()``).  ``save()`` is a no-op when ``None``.
    _dirty : bool
        Set to ``True`` by ``put()`` and ``prune()`` when entries change.
        Reset to ``False`` by a successful ``save()``.
    """

    _CACHE_FILENAME = "symbols.json"
    _CACHE_VERSION = 2
    _TEMP_PREFIX = ".symbols_"

    @classmethod
    def _deserialize_entries(cls, raw: _RawCacheMap) -> _RawCacheMap:
        """Validate and convert raw JSON entries to a typed SymbolTree map.

        Each entry is a dict of address → SymbolRecord.  Invalid entries (wrong
        structure) are skipped so a partially corrupt file does not poison the
        whole cache.
        """
        entries: _SymbolTreeMap = {}
        for obj_id, tree_raw in raw.items():
            if not isinstance(obj_id, str) or not isinstance(tree_raw, dict):
                continue
            tree: SymbolTree = {}
            valid = True
            for addr, rec_raw in tree_raw.items():
                if not _is_symbol_record(rec_raw):
                    valid = False
                    break
                tree[addr] = rec_raw
            if valid:
                entries[obj_id] = tree
        return entries

    def _serialize_entries(self) -> _RawCacheMap:
        """Return ``_entries`` as-is — SymbolTree dicts are already JSON-serialisable."""
        return self._entries  # type: ignore[return-value]

    # Type-narrowing overrides (correctness identical to base; annotations differ)

    def get(self, object_id: str) -> SymbolTree | None:
        """Return the cached ``SymbolTree`` for *object_id*, or ``None`` on miss."""
        return self._entries.get(object_id)  # type: ignore[return-value]

    def put(self, object_id: str, tree: SymbolTree) -> None:
        """Store *tree* under *object_id* and mark the cache dirty."""
        super().put(object_id, tree)

    def prune(self, live_ids: set[str]) -> None:
        """Remove entries whose object IDs are not in *live_ids*.

        Call this from ``muse gc`` after identifying all reachable object IDs
        to keep the cache from growing unboundedly.
        """
        super().prune(live_ids)

def load_symbol_cache(root: pathlib.Path) -> SymbolCache:
    """Convenience loader: return a ``SymbolCache`` for a repository root.

    Returns ``SymbolCache.empty()`` when *root* has no ``.muse`` directory
    so callers never need to guard against a missing repo.
    """
    return SymbolCache.from_root(root)  # type: ignore[return-value]
