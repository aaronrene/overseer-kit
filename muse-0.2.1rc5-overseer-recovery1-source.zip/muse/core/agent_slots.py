"""Agent slot registry — track HD-derived agent accounts per hub.

Each hub maintains a monotonically-increasing account counter so that
new agent slots are assigned unique SLIP-0010 indices.  Once assigned,
an agent's account index is permanent — it enables ERC8004 on-chain
binding and reproducible keypair derivation.

Storage
-------
``~/.muse/agent-slots.toml``

TOML structure::

    [localhost:1337]
    next_account = 2

    [localhost:1337.slots]
    # name -> account index
    orchestra = 1

    [staging.musehub.ai]
    next_account = 1

Slot 0 is reserved for the orchestrator identity on each hub.
Named agent slots start at account 1.
"""

import contextlib
import fcntl
import os
import pathlib
import stat
import tempfile
from typing import Generator, TypedDict

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    import tomli as tomllib  # type: ignore[no-reuse-def]

from muse.core.identity import hostname_from_url
from muse.core.paths import user_agent_slots_path as _user_agent_slots_path, user_muse_dir as _user_muse_dir

type _SlotNames = dict[str, int]   # slot_name → account_index

class _HostBlock(TypedDict, total=False):
    next_account: int
    slots: _SlotNames

type _SlotsData = dict[str, _HostBlock]

_SLOTS_FILE = _user_agent_slots_path()
_SLOTS_DIR = _user_muse_dir()

class AgentSlot(TypedDict, total=False):
    """A registered agent slot within an HD key hierarchy."""

    name: str           # human-readable slot name, e.g. "orchestra"
    account: int        # SLIP-0010 account index within DOMAIN_IDENTITY
    hub: str            # hostname this slot was registered against
    msign_path: str     # full SLIP-0010 path for the MSign key

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _toml_escape(s: str) -> str:
    """Minimal TOML string escaping (backslash and double-quote)."""
    return s.replace("\\", "\\\\").replace('"', '\\"')

def _load_raw(path: pathlib.Path) -> _SlotsData:
    """Load the slots file as a raw dict. Returns empty dict if absent."""
    if not path.is_file():
        return {}
    try:
        with path.open("rb") as fh:
            return tomllib.load(fh)
    except Exception:
        return {}

def _dump(data: _SlotsData) -> str:
    """Serialise the slots dict back to TOML text."""
    lines: list[str] = []
    for hostname in sorted(data):
        block = data[hostname]
        if not isinstance(block, dict):
            continue
        lines.append(f'["{_toml_escape(hostname)}"]')
        next_acct = block.get("next_account", 1)
        lines.append(f"next_account = {int(next_acct)}")
        slots: _SlotNames = block.get("slots", {})
        if slots:
            lines.append(f'["{_toml_escape(hostname)}".slots]')
            for name in sorted(slots):
                lines.append(f'{name} = {int(slots[name])}')
        lines.append("")
    return "\n".join(lines)

@contextlib.contextmanager
def _write_lock() -> Generator[None, None, None]:
    """Exclusive advisory write-lock on the slots file."""
    lock_path = _SLOTS_DIR / ".agent-slots.lock"
    _SLOTS_DIR.mkdir(parents=True, exist_ok=True)
    lock_fd = os.open(
        str(lock_path),
        os.O_CREAT | os.O_WRONLY | os.O_CLOEXEC,
        stat.S_IRUSR | stat.S_IWUSR,
    )
    try:
        fcntl.flock(lock_fd, fcntl.LOCK_EX)
        yield
    finally:
        fcntl.flock(lock_fd, fcntl.LOCK_UN)
        os.close(lock_fd)

def _save(data: _SlotsData, path: pathlib.Path) -> None:
    """Atomically write the slots dict to *path* with mode 0o600."""
    _SLOTS_DIR.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise OSError(f"Security: {path} is a symlink — refusing to write.")
    text = _dump(data)
    fd, tmp_str = tempfile.mkstemp(dir=_SLOTS_DIR, prefix=".agent-slots-tmp-")
    tmp = pathlib.Path(tmp_str)
    try:
        os.fchmod(fd, stat.S_IRUSR | stat.S_IWUSR)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_next_account(hub_url: str) -> int:
    """Return and atomically increment the next available agent account index.

    Slot 0 is reserved for the orchestrator identity.  Named agent
    accounts start at 1 and are assigned sequentially — never reused.

    Args:
        hub_url: Hub URL or bare hostname.

    Returns:
        The next available account index (always >= 1).
    """
    hostname = hostname_from_url(hub_url)
    with _write_lock():
        data = _load_raw(_SLOTS_FILE)
        block = data.setdefault(hostname, {})
        current = int(block.get("next_account", 1))
        if current < 1:
            current = 1
        block["next_account"] = current + 1
        _save(data, _SLOTS_FILE)
    return current

def register_slot(hub_url: str, name: str, account: int) -> AgentSlot:
    """Register a named agent slot at the given account index.

    If a slot with *name* already exists it is overwritten with the new
    account index.  Account indices must be unique across the hub — callers
    should use :func:`get_next_account` to obtain a fresh index.

    Args:
        hub_url: Hub URL or bare hostname.
        name:    Human-readable slot label, e.g. ``"orchestra"``.
        account: SLIP-0010 account index (>= 1; 0 is reserved for service).

    Returns:
        The registered :class:`AgentSlot`.
    """
    from muse.core.hdkeys import DOMAIN_IDENTITY, ENTITY_AGENT, hub_index, muse_path  # noqa: PLC0415
    hostname = hostname_from_url(hub_url)
    msign_path = muse_path(DOMAIN_IDENTITY, ENTITY_AGENT, account, hub=hub_index(hostname))
    slot: AgentSlot = {
        "name": name,
        "account": account,
        "hub": hostname,
        "msign_path": msign_path,
    }
    with _write_lock():
        data = _load_raw(_SLOTS_FILE)
        block = data.setdefault(hostname, {})
        slots = block.setdefault("slots", {})
        slots[name] = account
        _save(data, _SLOTS_FILE)
    return slot

def list_slots(hub_url: str) -> list[AgentSlot]:
    """Return all registered agent slots for *hub_url*, sorted by account index.

    Args:
        hub_url: Hub URL or bare hostname.

    Returns:
        List of :class:`AgentSlot` dicts, possibly empty.
    """
    from muse.core.hdkeys import DOMAIN_IDENTITY, ENTITY_AGENT, hub_index, muse_path  # noqa: PLC0415
    hostname = hostname_from_url(hub_url)
    hub = hub_index(hostname)
    data = _load_raw(_SLOTS_FILE)
    block = data.get(hostname, {})
    slots_raw: _SlotNames = block.get("slots", {})
    result: list[AgentSlot] = []
    for name, account in slots_raw.items():
        msign_path = muse_path(DOMAIN_IDENTITY, ENTITY_AGENT, int(account), hub=hub)
        result.append(AgentSlot(
            name=name,
            account=int(account),
            hub=hostname,
            msign_path=msign_path,
        ))
    result.sort(key=lambda s: s["account"])
    return result

def peek_next_account(hub_url: str) -> int:
    """Return the next account index without incrementing it.

    Args:
        hub_url: Hub URL or bare hostname.

    Returns:
        The next available account index (always >= 1).
    """
    hostname = hostname_from_url(hub_url)
    data = _load_raw(_SLOTS_FILE)
    block = data.get(hostname, {})
    current = int(block.get("next_account", 1))
    return max(current, 1)
