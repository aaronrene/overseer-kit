"""muse.core.refs — ref and HEAD management for the Muse VCS.

Every place in Muse that reads or writes ``.muse/refs/`` or ``.muse/HEAD``
should be built on the primitives exported here.

Public API
----------
read_ref
    Read a single ref file and return the commit ID, or ``None`` when the file
    is absent, empty, or unreadable.  The canonical primitive for all ref-file
    I/O.

iter_branch_refs
    Generator that yields ``(branch_name, commit_id)`` pairs for every
    non-empty, non-symlink ref file under ``.muse/refs/heads/``.  The
    canonical primitive for iterating local branch heads.

write_branch_ref
    Atomically (optionally CAS) update a branch tip ref.

RefConflictError
    Raised when a CAS write finds the ref has advanced concurrently.

SymbolicHead / DetachedHead / HeadState
    Typed representations of ``.muse/HEAD`` content.

read_head / read_current_branch / write_head_branch / write_head_commit
    Typed HEAD I/O.

get_head_commit_id / resolve_any_ref / get_all_branch_heads
    Higher-level ref resolution helpers.

Design notes
------------
* ``read_ref`` is intentionally minimal — it does one thing and handles the
  two failure modes (missing file, empty content) that appear everywhere.
* ``iter_branch_refs`` skips symlinks so a crafted symlink inside
  ``.muse/refs/heads/`` cannot escape the repository root.
* Neither low-level function validates the commit ID format — callers that
  need validation should call ``validate_object_id`` from ``muse.core.types``
  after receiving the value.  Separating read from validate keeps this
  module dependency-free (no circular imports).
"""
from __future__ import annotations

import fcntl
import pathlib
import re
from collections.abc import Iterator
from typing import Literal, TypedDict

from muse.core.io import write_text_atomic
from muse.core.paths import heads_dir as _heads_dir, head_path as _head_path, ref_path as _ref_path, remotes_dir as _remotes_dir
from muse.core.types import BranchHeads
from muse.core.validation import validate_branch_name

_SENTINEL = object()  # distinct from None — distinguishes "not provided" from "no prior ref"

# ---------------------------------------------------------------------------
# RefConflictError
# ---------------------------------------------------------------------------

class RefConflictError(Exception):
    """Raised when a compare-and-swap ref write fails because the current ref
    value does not match the expected value — another writer advanced the branch
    between the caller's parent-read and this write attempt."""

# ---------------------------------------------------------------------------
# read_ref
# ---------------------------------------------------------------------------

def read_ref(path: pathlib.Path) -> str | None:
    """Read a ref file and return the commit ID string, or ``None``.

    Returns ``None`` when:
    - The file does not exist.
    - The file is empty or contains only whitespace.
    - The file cannot be read (``PermissionError``, ``OSError``).

    Parameters
    ----------
    path:
        Absolute path to the ref file (e.g.
        ``repo / ".muse" / "refs" / "heads" / "main"``).

    Returns
    -------
    str | None
        The stripped commit ID string (e.g. ``"sha256:abc…"``), or ``None``.

    Examples
    --------
    Read the tip of the ``main`` branch::

        from muse.core.refs import read_ref
        cid = read_ref(repo / ".muse" / "refs" / "heads" / "main")
        if cid is None:
            print("branch is empty or does not exist")
    """
    try:
        raw = path.read_text(encoding="utf-8", errors="strict").strip()
        if not raw:
            return None
        if not raw.startswith("sha256:"):
            return None
        return raw
    except (FileNotFoundError, PermissionError, OSError, UnicodeDecodeError):
        return None

# ---------------------------------------------------------------------------
# iter_branch_refs
# ---------------------------------------------------------------------------

def iter_branch_refs(repo_root: pathlib.Path) -> Iterator[tuple[str, str]]:
    """Yield ``(branch_name, commit_id)`` for every local branch ref.

    This is the **canonical branch-ref walker** for all of Muse.  All other
    iteration over ``.muse/refs/heads/`` should be built on top of this
    function.

    Parameters
    ----------
    repo_root:
        Repository root directory (contains ``.muse/``).

    Yields
    ------
    tuple[str, str]
        ``(branch_name, commit_id)`` pairs, where *branch_name* is the plain
        file name (e.g. ``"main"``, ``"dev"``, ``"feat/login"``) and
        *commit_id* is the non-empty commit ID string read from the ref file.

    Notes
    -----
    * Symlinks are skipped — a crafted symlink inside ``.muse/refs/heads/``
      cannot be used to read arbitrary files outside the repository.
    * Subdirectories are skipped (hierarchical ref namespaces are not yet
      supported; only flat branch names are yielded).
    * Empty or unreadable ref files are silently skipped.
    * Missing ``.muse/refs/heads/`` directory yields nothing rather than
      raising an exception.

    Examples
    --------
    Collect all branch tips::

        tips = {name: cid for name, cid in iter_branch_refs(repo_root)}

    Feed all tips into a multi-source BFS::

        from muse.core.graph import iter_ancestors
        tips = [cid for _, cid in iter_branch_refs(repo_root)]
        for commit in iter_ancestors(repo_root, tips):
            process(commit)
    """
    heads_dir = _heads_dir(repo_root)
    if not heads_dir.is_dir():
        return
    for ref_file in heads_dir.rglob("*"):
        if ref_file.is_symlink() or not ref_file.is_file():
            continue
        branch_name = ref_file.relative_to(heads_dir).as_posix()
        commit_id = read_ref(ref_file)
        if commit_id:
            yield branch_name, commit_id

# ---------------------------------------------------------------------------
# write_branch_ref
# ---------------------------------------------------------------------------

def write_branch_ref(
    repo_root: pathlib.Path,
    branch: str,
    commit_id: str,
    *,
    expected_id: str | None = _SENTINEL,
) -> None:
    """Atomically update the branch tip pointer in ``.muse/refs/heads/<branch>``.

    This is the **canonical** way to advance a branch ref.  All commands that
    record a new commit on a branch — ``commit``, ``merge``, ``cherry-pick``,
    ``revert``, ``reset``, ``pull``, ``rebase`` — must call this function
    rather than writing the ref file directly.

    Using a bare ``path.write_text()`` is forbidden for ref files because:
    * It is not atomic — a crash mid-write leaves a zero-length or partial file,
      orphaning all commits reachable only from this branch.
    * It is not fsynced — a power loss after the write syscall returns but
      before the page cache is flushed produces the same corruption.

    When *expected_id* is provided, the write is a compare-and-swap: it only
    proceeds if the current ref value matches *expected_id*.  Pass the
    ``parent_id`` read at the start of a commit so concurrent advances of the
    branch are detected and surfaced as ``RefConflictError`` rather than
    silently orphaning a commit.  Pass ``None`` to assert that no prior ref
    exists (first commit on a new branch).  Omit entirely for an unconditional
    write (legacy callers — prefer providing expected_id).

    Args:
        repo_root:   Repository root (parent of ``.muse/``).
        branch:      Branch name; validated before use.
        commit_id:   New tip commit ID.
        expected_id: Current ref value the caller observed.  When provided,
                     raises ``RefConflictError`` if the ref has changed.

    Raises:
        ValueError:        If *branch* or *commit_id* is invalid.
        RefConflictError:  If *expected_id* is provided and the current ref
                           does not match — another writer advanced the branch.
    """
    validate_branch_name(branch)
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", commit_id):
        raise ValueError(f"commit_id must be 'sha256:<64 hex chars>', got: {commit_id!r}")
    ref_file = _ref_path(repo_root, branch)

    if expected_id is not _SENTINEL:
        lock_path = ref_file.with_suffix(".lock")
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        with open(lock_path, "w") as _lock_fh:
            fcntl.flock(_lock_fh.fileno(), fcntl.LOCK_EX)
            try:
                current = read_ref(ref_file)
                if current != expected_id:
                    raise RefConflictError(
                        f"Branch '{branch}' has moved concurrently. "
                        f"Expected ref {expected_id if expected_id else 'None'}, "
                        f"found {current if current else 'None'}. "
                        "Pull the latest changes and retry your commit."
                    )
                write_text_atomic(ref_file, commit_id)
            finally:
                lock_path.unlink(missing_ok=True)
        return

    write_text_atomic(ref_file, commit_id)

# ---------------------------------------------------------------------------
# HEAD file — typed I/O
# ---------------------------------------------------------------------------
#
# Muse HEAD format
# ----------------
# The ``.muse/HEAD`` file is always one of two self-describing forms:
#
#   ref: refs/heads/<branch>    — symbolic ref; HEAD points to a branch
#   commit: <sha256>            — detached HEAD; HEAD points to a commit
#
# The ``ref:`` prefix is adopted from Git because it is the right design:
# a file that can hold two semantically different things should say which
# one it holds.  The ``commit:`` prefix for detached HEAD is a Muse
# extension — Git uses a bare SHA, which is ambiguous (SHA-1? SHA-256?).
# Muse makes the hash algorithm implicit in the prefix, leaving the door
# open for future algorithm identifiers without changing the parsing rule.
#
# There is no backward-compatibility layer; every write site uses
# ``write_head_branch`` / ``write_head_commit`` and every read site uses
# ``read_head`` / ``read_current_branch``.

class SymbolicHead(TypedDict):
    """HEAD points to a named branch."""

    kind: Literal["branch"]
    branch: str

class DetachedHead(TypedDict):
    """HEAD points directly to a commit (detached HEAD state)."""

    kind: Literal["commit"]
    commit_id: str

HeadState = SymbolicHead | DetachedHead

def read_head(repo_root: pathlib.Path) -> HeadState:
    """Parse ``.muse/HEAD`` and return a typed :data:`HeadState`.

    Raises :exc:`ValueError` for any content that does not match the two
    expected forms, and when the HEAD file does not exist (uninitialised or
    corrupt repository), so callers never receive an ambiguous raw string or
    an unhandled :exc:`FileNotFoundError`.
    """
    head_path = _head_path(repo_root)
    try:
        raw = head_path.read_text(encoding="utf-8").strip()
    except FileNotFoundError:
        raise ValueError(
            f"Repository HEAD file missing: {head_path}\n"
            "The repository may be uninitialised. Run 'muse init' to fix it."
        )
    if raw.startswith("ref: refs/heads/"):
        branch = raw.removeprefix("ref: refs/heads/").strip()
        validate_branch_name(branch)
        return SymbolicHead(kind="branch", branch=branch)
    if raw.startswith("commit: "):
        commit_id = raw.removeprefix("commit: ").strip()
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", commit_id):
            raise ValueError(f"Malformed commit ID in HEAD: {commit_id!r}")
        return DetachedHead(kind="commit", commit_id=commit_id)
    raise ValueError(
        f"Malformed HEAD: {raw!r}. "
        "Expected 'ref: refs/heads/<branch>' or 'commit: <sha256>'."
    )

def read_current_branch(repo_root: pathlib.Path) -> str:
    """Return the currently checked-out branch name.

    Raises :exc:`ValueError` when the repository is in detached HEAD state
    so callers that cannot operate without a branch get a clear error
    rather than silently receiving a commit ID as a branch name.
    """
    state = read_head(repo_root)
    if state["kind"] != "branch":
        raise ValueError(
            "Repository is in detached HEAD state. "
            "Run 'muse checkout <branch>' to return to a branch."
        )
    return state["branch"]

def write_head_branch(repo_root: pathlib.Path, branch: str) -> None:
    """Write a symbolic ref to ``.muse/HEAD`` atomically.

    Format: ``ref: refs/heads/<branch>`` — self-describing; the ``ref:``
    prefix unambiguously identifies the entry as a symbolic reference.

    Uses :func:`write_text_atomic` so a crash or power loss during ``muse
    checkout`` or ``muse init`` cannot corrupt or zero-out HEAD.
    """
    validate_branch_name(branch)
    write_text_atomic(_head_path(repo_root), f"ref: refs/heads/{branch}\n")

def write_head_commit(repo_root: pathlib.Path, commit_id: str) -> None:
    """Write a direct commit reference to ``.muse/HEAD`` atomically (detached HEAD).

    Format: ``commit: <sha256>`` — the ``commit:`` prefix is a Muse
    extension that makes the entry self-describing in all states.  Unlike
    Git (which stores a bare hash), this makes the hash type explicit and
    leaves room for future algorithm prefixes without parsing heuristics.

    Uses :func:`write_text_atomic` so a crash or power loss cannot zero-out HEAD.
    """
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", commit_id):
        raise ValueError(f"commit_id must be 'sha256:<64 hex chars>', got: {commit_id!r}")
    write_text_atomic(_head_path(repo_root), f"commit: {commit_id}\n")

# ---------------------------------------------------------------------------
# Higher-level ref resolution helpers
# ---------------------------------------------------------------------------

def get_head_commit_id(repo_root: pathlib.Path, branch: str) -> str | None:
    """Return the commit ID at HEAD of *branch*, or ``None`` for an empty branch."""
    validate_branch_name(branch)
    return read_ref(_ref_path(repo_root, branch))

def resolve_any_ref(repo_root: pathlib.Path, ref: str) -> str | None:
    """Resolve *ref* to a commit ID, checking local branches then remote tracking refs.

    Handles both plain branch names (``main``) and remote-tracking ref syntax
    (``origin/main``, ``remotes/origin/main``).  Returns ``None`` when the ref
    cannot be resolved.
    """
    # 1. Try as a local branch name first.
    try:
        cid = get_head_commit_id(repo_root, ref)
        if cid is not None:
            return cid
    except (ValueError, OSError):
        pass

    # 2. Try remote tracking ref.  Accepts two formats:
    #    "origin/main"          → .muse/remotes/origin/main
    #    "remotes/origin/main"  → .muse/remotes/origin/main
    parts = ref.split("/")
    if len(parts) >= 2:
        if parts[0] == "remotes":
            parts = parts[1:]
        if len(parts) >= 2:
            remote = parts[0]
            branch = "/".join(parts[1:])
            tracking_path = _remotes_dir(repo_root) / remote / branch
            cid = read_ref(tracking_path)
            if cid:
                return cid

    return None

def get_all_branch_heads(repo_root: pathlib.Path) -> BranchHeads:
    """Return a mapping of branch name → commit ID for every branch in *repo_root*.

    Reads all ref files under ``.muse/refs/heads/``.  Branches whose ref file
    is empty or contains an invalid commit ID are silently skipped.

    Args:
        repo_root: Repository root directory (contains ``.muse/``).

    Returns:
        ``{branch_name: commit_id}`` for every non-empty branch ref.
    """
    return dict(iter_branch_refs(repo_root))
