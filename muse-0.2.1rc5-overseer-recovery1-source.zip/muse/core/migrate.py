"""Full layout and commit-ID migration engine.

Migrates any Muse repository from legacy on-disk layouts to the canonical
current layout:

Old layout                             Canonical layout
--------------------------------------  ---------------------------------------
objects/<shard>/<rest>                  objects/sha256/<shard>/<rest>
commits/<hex>.msgpack                   commits/sha256/<hex>.msgpack
snapshots/<hex>.msgpack                 snapshots/sha256/<hex>.msgpack
branch ref: bare hex                    branch ref: sha256:<hex>
remote ref: bare hex or stale ID        remote ref: sha256:<current-hex>
repo_id: plain string (pre-sha256)      repo_id: sha256:<hex>
commit field: created_on_branch         commit field: branch
commit field: format_version < 8        commit field: format_version = 8
commit signature: bare base64url        commit signature: ed25519:<base64url>
commit_id: legacy formula               commit_id: hash_commit(...)

Entry points
------------
- :func:`migrate` — full execution or dry-run
- :class:`MigrateResult` — returned by :func:`migrate`
"""

import collections
import datetime
import json
import logging
import pathlib
import shutil
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import msgpack

from muse.core.paths import (
    commits_dir, heads_dir, logs_dir, muse_dir,
    objects_dir, rebase_merge_dir, remotes_dir,
    repo_json_path, snapshots_dir,
)
from muse.core.ids import hash_blob, hash_commit, hash_snapshot
from muse.core.types import b64url_decode, blob_id, encode_sig, long_id
from muse.core.refs import get_all_branch_heads, write_branch_ref

if TYPE_CHECKING:
    from muse.core.transport import SigningIdentity

logger = logging.getLogger(__name__)

type _IdMap = dict[str, str]
type _RawCommit = dict[str, str | int | float | bytes | datetime.datetime | None]


# ---------------------------------------------------------------------------
# Phase 7 — blob ID migration result
# ---------------------------------------------------------------------------

@dataclass
class BlobMigrateResult:
    """Result of :func:`migrate_blob_ids`."""
    id_map: dict[str, str] = field(default_factory=dict)
    blobs_written: int = 0
    blobs_skipped: int = 0
    dry_run: bool = False
type _CommitEntry = tuple[_RawCommit, pathlib.Path]
type _CommitIndex = dict[str, _CommitEntry]

# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class MigrateResult:
    id_map: dict[str, str] = field(default_factory=dict)
    commits_rewritten: int = 0
    blobs_migrated: int = 0
    legacy_dirs_removed: int = 0
    dry_run: bool = False
    commits_relocated: int = 0
    snapshots_relocated: int = 0
    refs_updated: int = 0
    remote_refs_updated: int = 0
    repo_id_updated: bool = False
    branch_fields_renamed: int = 0
    signatures_normalised: int = 0
    format_versions_bumped: int = 0
    reflogs_updated: int = 0
    commits_signed: int = 0
    unsigned_commits_skipped: int = 0
    # Phase 7 — unified object store backfill
    blobs_rewritten: int = 0
    snapshots_rewritten: int = 0
    commits_unified: int = 0

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _normalise_sig(sig: str) -> str:
    if not sig or sig.startswith("ed25519:"):
        return sig
    raw = b64url_decode(sig)
    return encode_sig("ed25519", raw)

def _committed_at_iso(raw: _RawCommit) -> str:
    val = raw.get("committed_at", "")
    if isinstance(val, datetime.datetime):
        return val.isoformat()
    return str(val)

def _collect_all_commits(root: pathlib.Path) -> _CommitIndex:
    """Read every commit file in the store.

    Returns a mapping of commit_id → (raw_dict, file_path).  Covers:
    - Legacy msgpack files in ``.muse/commits/sha256/``
    - Unified object store entries in ``.muse/objects/sha256/`` with a
      ``commit <size>\\0<json>`` header
    """
    result: _CommitIndex = {}

    # Legacy msgpack commits
    _dir = commits_dir(root)
    if _dir.exists():
        for path in _dir.rglob("*.msgpack"):
            try:
                raw = msgpack.unpackb(path.read_bytes(), raw=False)
                cid = raw.get("commit_id", "")
                if cid:
                    result[cid] = (raw, path)
            except Exception as exc:
                logger.warning("Skipping unreadable commit %s: %s", path, exc)

    # Unified object store commits (commit <size>\0<json>)
    obj_dir = objects_dir(root) / "sha256"
    if obj_dir.exists():
        for path in obj_dir.glob("*/*"):
            if not path.is_file():
                continue
            try:
                data = path.read_bytes()
                if not data.startswith(b"commit "):
                    continue
                nl = data.index(b"\x00")
                raw = json.loads(data[nl + 1:])
                cid = raw.get("commit_id", "")
                if cid and cid not in result:
                    result[cid] = (raw, path)
            except Exception as exc:
                logger.warning("Skipping unreadable object %s: %s", path, exc)

    return result

def _topological_sort(commits: _CommitIndex) -> list[str]:
    """Return commit IDs in topological order (parents before children)."""
    in_degree: dict[str, int] = {cid: 0 for cid in commits}
    children: dict[str, list[str]] = {cid: [] for cid in commits}

    for cid, (raw, _) in commits.items():
        for key in ("parent_commit_id", "parent2_commit_id"):
            pid = raw.get(key)
            if pid and pid in commits:
                in_degree[cid] = in_degree.get(cid, 0) + 1
                children[pid].append(cid)

    queue: collections.deque[str] = collections.deque(
        sorted(cid for cid, deg in in_degree.items() if deg == 0)
    )
    order: list[str] = []
    while queue:
        cid = queue.popleft()
        order.append(cid)
        for child in sorted(children.get(cid, [])):
            in_degree[child] -= 1
            if in_degree[child] == 0:
                queue.append(child)
    return order

def _make_canonical_dict(
    raw: _RawCommit,
    id_map: _IdMap,
    signing_identity: SigningIdentity | None = None,
    force_resign: bool = False,
) -> tuple[_RawCommit, str, bool]:
    """Build the canonical version of a raw commit dict.

    Returns ``(canonical_dict, new_commit_id, was_signed)``.
    ``was_signed`` is True when a new signature was created (unsigned commit,
    parent cascade, or ``force_resign``).
    """
    p1 = raw.get("parent_commit_id")
    p2 = raw.get("parent2_commit_id")
    new_p1 = id_map.get(p1, p1) if p1 else None
    new_p2 = id_map.get(p2, p2) if p2 else None

    parent_ids: list[str] = []
    if new_p1:
        parent_ids.append(new_p1)
    if new_p2:
        parent_ids.append(new_p2)

    snapshot_id: str = raw.get("snapshot_id", "")
    message: str = raw.get("message", "")
    committed_at_iso = _committed_at_iso(raw)
    author: str = raw.get("author", "")

    parents_changed = (new_p1 != p1) or (new_p2 != p2)
    is_unsigned = not raw.get("signature") and not raw.get("signer_public_key")
    # Re-sign when: (a) commit was unsigned, (b) parent IDs changed so the
    # old signature covers the wrong commit_id, or (c) force_resign is set.
    should_sign = signing_identity is not None and (is_unsigned or parents_changed or force_resign)

    # Normalise empty author to the signing identity's handle so every
    # resigned commit carries proper attribution baked into its content hash.
    if should_sign and signing_identity is not None and not author:
        author = signing_identity.handle

    if should_sign:
        from muse.core.provenance import encode_public_key, provenance_payload, sign_commit_ed25519
        _, pub_str = encode_public_key(signing_identity.private_key)  # type: ignore[arg-type]
        new_id = hash_commit(
            parent_ids=parent_ids,
            snapshot_id=snapshot_id,
            message=message,
            committed_at_iso=committed_at_iso,
            author=author,
            signer_public_key=pub_str,
        )
        payload = provenance_payload(
            commit_id=new_id,
            author=author,
            agent_id=raw.get("agent_id", ""),
            model_id=raw.get("model_id", ""),
            toolchain_id=raw.get("toolchain_id", ""),
            prompt_hash=raw.get("prompt_hash", ""),
            committed_at=committed_at_iso,
        )
        sig = sign_commit_ed25519(payload, signing_identity.private_key)  # type: ignore[arg-type]
    else:
        pub_str = raw.get("signer_public_key", "")
        new_id = hash_commit(
            parent_ids=parent_ids,
            snapshot_id=snapshot_id,
            message=message,
            committed_at_iso=committed_at_iso,
            author=author,
            signer_public_key=pub_str,
        )
        sig = _normalise_sig(raw.get("signature", ""))

    branch_val = raw.get("branch") or raw.get("created_on_branch") or "main"

    out = dict(raw)
    out["commit_id"] = new_id
    out["parent_commit_id"] = new_p1
    out["parent2_commit_id"] = new_p2
    out["author"] = author
    out["signature"] = sig
    out["branch"] = branch_val
    out["format_version"] = 8
    out["committed_at"] = committed_at_iso
    if should_sign:
        out["signer_public_key"] = pub_str
    out.pop("created_on_branch", None)
    out.pop("repo_id", None)

    return out, new_id, should_sign

def _canonical_commit_path(root: pathlib.Path, hex_id: str) -> pathlib.Path:
    return commits_dir(root) / "sha256" / f"{hex_id}.msgpack"

def _write_raw_commit(root: pathlib.Path, canonical: _RawCommit) -> None:
    hex_id = long_id(canonical["commit_id"], strip=True)
    path = _canonical_commit_path(root, hex_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(msgpack.packb(canonical, use_bin_type=True))

def _is_flat_commit_path(root: pathlib.Path, path: pathlib.Path) -> bool:
    _dir = commits_dir(root)
    try:
        rel = path.relative_to(_dir)
    except ValueError:
        return False
    return rel.parts[0] != "sha256"

def _migrate_objects(root: pathlib.Path, dry_run: bool) -> tuple[int, int]:
    _dir = objects_dir(root)
    if not _dir.exists():
        return 0, 0

    blobs_moved = 0
    dirs_removed = 0

    for entry in sorted(_dir.iterdir()):
        if not entry.is_dir() or entry.name == "sha256":
            continue
        prefix = entry.name
        for blob_path in sorted(entry.iterdir()):
            if not blob_path.is_file():
                continue
            rest = blob_path.name
            canonical = _dir / "sha256" / prefix / rest
            if canonical.exists():
                if not dry_run:
                    blob_path.unlink()
            else:
                if not dry_run:
                    canonical.parent.mkdir(parents=True, exist_ok=True)
                    blob_path.rename(canonical)
            blobs_moved += 1
        if not dry_run and entry.is_dir() and not any(entry.iterdir()):
            entry.rmdir()
            dirs_removed += 1

    return blobs_moved, dirs_removed

def _migrate_snapshots(root: pathlib.Path, dry_run: bool) -> int:
    snaps_dir = snapshots_dir(root)
    if not snaps_dir.exists():
        return 0
    count = 0
    for path in sorted(snaps_dir.iterdir()):
        if not path.is_file() or not path.name.endswith(".msgpack"):
            continue
        hex_id = path.stem
        canonical = snaps_dir / "sha256" / f"{hex_id}.msgpack"
        if canonical.exists():
            if not dry_run:
                path.unlink()
        else:
            if not dry_run:
                canonical.parent.mkdir(parents=True, exist_ok=True)
                path.rename(canonical)
        count += 1
    return count

def _normalise_ref_value(val: str, id_map: _IdMap) -> str:
    val = val.strip()
    val = long_id(val)
    return id_map.get(val, val)

def _migrate_refs(root: pathlib.Path, id_map: _IdMap, dry_run: bool) -> int:
    refs_dir = heads_dir(root)
    if not refs_dir.exists():
        return 0
    count = 0
    for path in sorted(refs_dir.rglob("*")):
        if not path.is_file():
            continue
        val = path.read_text(encoding="utf-8").strip()
        new_val = _normalise_ref_value(val, id_map)
        if new_val != val:
            count += 1
            if not dry_run:
                path.write_text(f"{new_val}\n", encoding="utf-8")
    return count

def _migrate_remote_refs(
    root: pathlib.Path, id_map: dict[str, str], dry_run: bool
) -> int:
    _dir = remotes_dir(root)
    if not _dir.exists():
        return 0
    count = 0
    for path in sorted(_dir.rglob("*")):
        if not path.is_file():
            continue
        val = path.read_text(encoding="utf-8").strip()
        new_val = _normalise_ref_value(val, id_map)
        if new_val != val:
            count += 1
            if not dry_run:
                path.write_text(f"{new_val}\n", encoding="utf-8")
    return count

def _migrate_repo_id(root: pathlib.Path, dry_run: bool) -> bool:
    repo_json = repo_json_path(root)
    if not repo_json.exists():
        return False
    data = json.loads(repo_json.read_text(encoding="utf-8"))
    rid = data.get("repo_id", "")
    if rid.startswith("sha256:"):
        return False
    new_id = blob_id(rid.encode())
    if not dry_run:
        data["repo_id"] = new_id
        repo_json.write_text(json.dumps(data), encoding="utf-8")
    return True

def _migrate_reflogs(
    root: pathlib.Path, id_map: dict[str, str], dry_run: bool
) -> int:
    _dir = logs_dir(root)
    if not _dir.exists():
        return 0
    count = 0
    for path in sorted(_dir.rglob("*")):
        if not path.is_file():
            continue
        content = path.read_text(encoding="utf-8")
        new_content = content
        for old_id, new_id in id_map.items():
            new_content = new_content.replace(old_id, new_id)
        if new_content != content:
            count += 1
            if not dry_run:
                path.write_text(new_content, encoding="utf-8")
    return count

# ---------------------------------------------------------------------------
# Phase 7 — blob ID migration
# ---------------------------------------------------------------------------

def migrate_blob_ids(
    repo_root: pathlib.Path,
    dry_run: bool = False,
) -> BlobMigrateResult:
    """Migrate raw (old-formula) blobs to muse-format at new hash_blob paths.

    For each blob stored with the pre-Phase-2 formula ``sha256(content)``,
    this function:

    1. Reads the raw bytes from the old object path.
    2. Detects whether the file is already muse-format (has a valid
       ``"blob <size>\\0"`` header whose declared size matches the payload).
    3. If old-format: writes ``"blob <size>\\0<content>"`` to the new object
       path derived from ``hash_blob(content)``.
    4. Builds and returns an old_id → new_id map for use by the snapshot
       migration pass.

    Non-destructive: old files are never deleted.

    Args:
        repo_root: Repository root (contains ``.muse/``).
        dry_run:   When True, compute the mapping but write nothing.

    Returns:
        :class:`BlobMigrateResult` with the ID map and write counts.
    """
    from muse.core.object_store import iter_stored_objects, object_path as _object_path

    result = BlobMigrateResult(dry_run=dry_run)

    for old_id, path in iter_stored_objects(repo_root):
        data = path.read_bytes()

        # Detect typed objects: "blob|snapshot|commit <size>\0<payload>".
        # Snapshot and commit objects must never be treated as blobs.
        null_idx = data.find(b"\0")
        if null_idx > 0:
            header = data[:null_idx].decode(errors="replace")
            parts = header.split(" ", 1)
            if len(parts) == 2 and parts[1].isdigit() and len(data) - null_idx - 1 == int(parts[1]):
                if parts[0] in ("snapshot", "commit"):
                    # Not a blob — skip entirely, never rewrite.
                    result.id_map[old_id] = old_id
                    result.blobs_skipped += 1
                    continue
                if parts[0] == "blob":
                    # Already muse-format blob — map to itself and skip.
                    result.id_map[old_id] = old_id
                    result.blobs_skipped += 1
                    continue

        # Old-format raw blob: compute the new muse-idiomatic ID.
        new_id = hash_blob(data)
        result.id_map[old_id] = new_id

        if new_id == old_id:
            result.blobs_skipped += 1
            continue

        new_path = _object_path(repo_root, new_id)
        if new_path.exists():
            # New blob already written — delete the stale old-format file.
            if not dry_run:
                path.unlink(missing_ok=True)
            result.blobs_skipped += 1
            continue

        if not dry_run:
            header_bytes = f"blob {len(data)}\0".encode()
            new_path.parent.mkdir(parents=True, exist_ok=True)
            new_path.write_bytes(header_bytes + data)
            # Remove the old-format file now that the new one is safely written.
            path.unlink(missing_ok=True)

        result.blobs_written += 1

    return result


# ---------------------------------------------------------------------------
# Phase 7 — snapshot ID migration
# ---------------------------------------------------------------------------

@dataclass
class SnapshotMigrateResult:
    """Result of :func:`migrate_snapshot_ids`."""
    id_map: dict[str, str] = field(default_factory=dict)
    snapshots_written: int = 0
    snapshots_skipped: int = 0
    dry_run: bool = False


def migrate_snapshot_ids(
    repo_root: pathlib.Path,
    blob_id_map: dict[str, str],
    dry_run: bool = False,
) -> SnapshotMigrateResult:
    """Migrate old-formula snapshots to muse-format in the unified object store.

    For each snapshot msgpack in ``.muse/snapshots/sha256/``:

    1. Reads the record and updates every manifest entry using *blob_id_map*
       (old blob ID → new blob ID).
    2. Recomputes the snapshot ID with the current ``hash_snapshot`` formula.
    3. Writes the updated record as JSON to ``.muse/objects/sha256/<2>/<62>``
       in ``"snapshot <size>\\0<json>"`` format.

    Non-destructive: old msgpack files are never deleted.

    Args:
        repo_root:   Repository root (contains ``.muse/``).
        blob_id_map: Old blob ID → new blob ID map from :func:`migrate_blob_ids`.
        dry_run:     When True, compute the mapping but write nothing.

    Returns:
        :class:`SnapshotMigrateResult` with the ID map and write counts.
    """
    from muse.core.object_store import object_path as _object_path

    result = SnapshotMigrateResult(dry_run=dry_run)
    snaps = snapshots_dir(repo_root) / "sha256"
    if not snaps.exists():
        return result

    from muse.core.io import zstd_decompress_if_needed

    for path in sorted(snaps.glob("*.msgpack")):
        try:
            raw = msgpack.unpackb(zstd_decompress_if_needed(path.read_bytes()), raw=False)
        except Exception as exc:
            logger.warning("Skipping unreadable snapshot %s: %s", path, exc)
            continue

        old_id: str = raw.get("snapshot_id", "")
        if not old_id:
            continue

        old_manifest: dict[str, str] = dict(raw.get("manifest") or {})
        new_manifest = {
            file_path: blob_id_map.get(oid, oid)
            for file_path, oid in old_manifest.items()
        }
        directories = raw.get("directories") or []
        new_snap_id = hash_snapshot(new_manifest, directories or None)
        result.id_map[old_id] = new_snap_id

        new_path = _object_path(repo_root, new_snap_id)
        if new_path.exists():
            result.snapshots_skipped += 1
            continue

        if not dry_run:
            updated = dict(raw)
            updated["snapshot_id"] = new_snap_id
            updated["manifest"] = new_manifest
            # created_at may be a datetime — normalise to ISO string for JSON.
            if hasattr(updated.get("created_at"), "isoformat"):
                updated["created_at"] = updated["created_at"].isoformat()
            payload = json.dumps(updated, separators=(",", ":")).encode()
            header = f"snapshot {len(payload)}\0".encode()
            new_path.parent.mkdir(parents=True, exist_ok=True)
            new_path.write_bytes(header + payload)

        result.snapshots_written += 1

    return result


# ---------------------------------------------------------------------------
# Phase 7 — commit ID migration
# ---------------------------------------------------------------------------

@dataclass
class CommitMigrateResult:
    """Result of :func:`migrate_commit_ids`."""
    id_map: dict[str, str] = field(default_factory=dict)
    commits_written: int = 0
    commits_skipped: int = 0
    dry_run: bool = False


def migrate_commit_ids(
    repo_root: pathlib.Path,
    snapshot_id_map: dict[str, str],
    dry_run: bool = False,
) -> CommitMigrateResult:
    """Migrate old-formula commits to muse-format in the unified object store.

    For each commit msgpack in ``.muse/commits/sha256/``:

    1. Reads the record and updates ``snapshot_id`` using *snapshot_id_map*.
    2. Updates parent commit IDs from the result's own ``id_map`` (two-pass:
       all new IDs are computed first, then files are written).
    3. Recomputes the commit ID with the current ``hash_commit`` formula.
    4. Writes the updated record as JSON to ``.muse/objects/sha256/<2>/<62>``
       in ``"commit <size>\\0<json>"`` format.

    Non-destructive: old msgpack files are never deleted.

    Args:
        repo_root:        Repository root (contains ``.muse/``).
        snapshot_id_map:  Old snapshot ID → new snapshot ID map from
                          :func:`migrate_snapshot_ids`.
        dry_run:          When True, compute the mapping but write nothing.

    Returns:
        :class:`CommitMigrateResult` with the ID map and write counts.
    """
    from muse.core.object_store import object_path as _object_path

    result = CommitMigrateResult(dry_run=dry_run)
    all_commits = _collect_all_commits(repo_root)
    order = _topological_sort(all_commits)

    # Pass 1: build the commit id_map (parents-before-children order ensures
    # parent IDs are already in id_map when processing each child).
    commit_id_map: dict[str, str] = {}
    for old_id in order:
        raw, _ = all_commits[old_id]
        p1 = raw.get("parent_commit_id")
        p2 = raw.get("parent2_commit_id")
        new_p1 = commit_id_map.get(p1, p1) if p1 else None
        new_p2 = commit_id_map.get(p2, p2) if p2 else None

        parent_ids: list[str] = [x for x in (new_p1, new_p2) if x]
        old_snap = raw.get("snapshot_id", "")
        new_snap = snapshot_id_map.get(old_snap, old_snap)
        committed_at_iso = _committed_at_iso(raw)

        new_id = hash_commit(
            parent_ids=parent_ids,
            snapshot_id=new_snap,
            message=raw.get("message", ""),
            committed_at_iso=committed_at_iso,
            author=raw.get("author", ""),
            signer_public_key=raw.get("signer_public_key", "") or "",
        )
        if new_id != old_id:
            commit_id_map[old_id] = new_id

    result.id_map = {**commit_id_map}

    # Pass 2: write updated records.
    for old_id in order:
        raw, _ = all_commits[old_id]
        p1 = raw.get("parent_commit_id")
        p2 = raw.get("parent2_commit_id")
        new_p1 = commit_id_map.get(p1, p1) if p1 else None
        new_p2 = commit_id_map.get(p2, p2) if p2 else None

        parent_ids = [x for x in (new_p1, new_p2) if x]
        old_snap = raw.get("snapshot_id", "")
        new_snap = snapshot_id_map.get(old_snap, old_snap)
        new_id = commit_id_map.get(old_id, old_id)
        committed_at_iso = _committed_at_iso(raw)

        obj_path = _object_path(repo_root, new_id)
        if obj_path.exists():
            result.commits_skipped += 1
            continue

        if not dry_run:
            updated = dict(raw)
            updated["commit_id"] = new_id
            updated["snapshot_id"] = new_snap
            updated["parent_commit_id"] = new_p1
            updated["parent2_commit_id"] = new_p2
            updated["committed_at"] = committed_at_iso
            updated.pop("created_on_branch", None)

            payload = json.dumps(updated, separators=(",", ":"), default=str).encode()
            header = f"commit {len(payload)}\0".encode()
            obj_path.parent.mkdir(parents=True, exist_ok=True)
            obj_path.write_bytes(header + payload)


        result.commits_written += 1

    return result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def migrate(
    root: pathlib.Path,
    dry_run: bool = False,
    signing_identity: SigningIdentity | None = None,
    force_resign: bool = False,
) -> MigrateResult:
    """Migrate a Muse repository to the canonical current layout.

    Args:
        root:             Repo root (contains ``.muse/``).
        dry_run:          When True, compute all changes and report them but
                          write nothing to disk.
        signing_identity: When provided, unsigned commits are signed with this
                          identity during migration.  Already-signed commits
                          are never re-signed.

    Returns:
        :class:`MigrateResult` with full migration summary.

    Raises:
        RuntimeError: If a merge or rebase is in progress.
    """
    if force_resign and signing_identity is None:
        raise ValueError(
            "force_resign=True requires a signing identity. "
            "Run `muse auth keygen && muse auth register`, or connect a hub "
            "with `muse hub connect` so credentials can be resolved."
        )
    if (muse_dir(root) / "MERGE_STATE").exists():
        raise RuntimeError(
            "A merge is in progress — finish or abort it before running migrate."
        )
    if rebase_merge_dir(root).exists():
        raise RuntimeError(
            "A rebase is in progress — finish or abort it before running migrate."
        )

    # --- repo.json ---
    repo_id_updated = _migrate_repo_id(root, dry_run=dry_run)

    # --- snapshots ---
    snapshots_relocated = _migrate_snapshots(root, dry_run=dry_run)

    # --- collect all commits (flat + canonical) ---
    all_commits = _collect_all_commits(root)
    order = _topological_sort(all_commits)

    id_map: dict[str, str] = {}
    commits_rewritten = 0
    commits_relocated = 0
    branch_fields_renamed = 0
    signatures_normalised = 0
    format_versions_bumped = 0
    commits_signed = 0
    unsigned_commits_skipped = 0

    # First pass: build id_map (must be complete before second pass).
    # Signing-aware: if signing_identity is provided, unsigned commits will
    # get a new signer_public_key baked into their commit_id.
    for old_id in order:
        raw, _ = all_commits[old_id]
        _, new_id, _ = _make_canonical_dict(raw, id_map, signing_identity, force_resign)
        if new_id != old_id:
            id_map[old_id] = new_id

    # Second pass: write canonical files, collect stats
    for old_id in order:
        raw, old_path = all_commits[old_id]
        canonical, new_id, was_signed = _make_canonical_dict(raw, id_map, signing_identity, force_resign)

        is_flat = _is_flat_commit_path(root, old_path)
        id_changed = new_id != old_id
        branch_renamed = "created_on_branch" in raw and "branch" not in raw
        sig_normalised = bool(raw.get("signature")) and not raw["signature"].startswith("ed25519:")
        fv_bumped = raw.get("format_version", 1) != 8
        is_unsigned = not raw.get("signature") and not raw.get("signer_public_key")
        has_repo_id = "repo_id" in raw

        if id_changed:
            commits_rewritten += 1
        if is_flat:
            commits_relocated += 1
        if branch_renamed:
            branch_fields_renamed += 1
        if sig_normalised:
            signatures_normalised += 1
        if fv_bumped:
            format_versions_bumped += 1
        if was_signed:
            commits_signed += 1
        elif is_unsigned and signing_identity is None:
            unsigned_commits_skipped += 1

        needs_write = id_changed or is_flat or branch_renamed or sig_normalised or fv_bumped or was_signed or has_repo_id
        if not dry_run and needs_write:
            _write_raw_commit(root, canonical)
            # Delete old file if it's at a different location than the new canonical path
            new_hex = long_id(new_id, strip=True)
            new_path = _canonical_commit_path(root, new_hex)
            if old_path != new_path and old_path.exists():
                old_path.unlink()

    # --- objects (legacy layout: objects/<shard> → objects/sha256/<shard>) ---
    blobs_migrated, legacy_dirs_removed = _migrate_objects(root, dry_run=dry_run)

    # --- Phase 7: ID chain migration (blobs → snapshots → commits) ---
    # Pass 1: rewrite raw blobs to muse-format at new hash_blob paths.
    blob_result = migrate_blob_ids(root, dry_run=dry_run)
    # Pass 2: update snapshot manifests with new blob IDs, write to object store.
    snap_result = migrate_snapshot_ids(root, blob_result.id_map, dry_run=dry_run)
    # Pass 3: update commit snapshot_id fields, recompute commit IDs, write to
    # object store and new msgpack paths.
    commit_result = migrate_commit_ids(root, snap_result.id_map, dry_run=dry_run)

    # Build the combined old→new ID map for ref and reflog updates.
    #
    # The existing loop maps  old_id → legacy_id  (parent cascade, signing).
    # Phase 7 maps            legacy_id → phase7_id  (full ID chain).
    #
    # A naïve merge ({**id_map, **commit_result.id_map}) only resolves one hop:
    # refs containing old_id would land at legacy_id, not phase7_id.  We need
    # the transitive closure: old_id → phase7_id in one step.
    combined_id_map: dict[str, str] = {}
    for old_id, legacy_id in id_map.items():
        final_id = commit_result.id_map.get(legacy_id, legacy_id)
        combined_id_map[old_id] = final_id
    # Also carry through any Phase 7 entries not covered by the legacy map
    # (commits that were already at their legacy form before this run).
    for legacy_id, phase7_id in commit_result.id_map.items():
        if legacy_id not in combined_id_map:
            combined_id_map[legacy_id] = phase7_id

    # --- branch refs ---
    refs_updated = _migrate_refs(root, combined_id_map, dry_run=dry_run)

    # --- remote refs ---
    remote_refs_updated = _migrate_remote_refs(root, combined_id_map, dry_run=dry_run)

    # --- reflogs ---
    reflogs_updated = _migrate_reflogs(root, combined_id_map, dry_run=dry_run)

    # --- remove legacy directories ---
    # All content has been written to the unified object store by this point.
    # Orphaned objects unreferenced by any branch will be collected by gc.
    if not dry_run:
        for legacy_dir in (commits_dir(root), snapshots_dir(root)):
            if legacy_dir.exists():
                shutil.rmtree(legacy_dir)

    return MigrateResult(
        id_map=combined_id_map,
        commits_rewritten=commits_rewritten,
        blobs_migrated=blobs_migrated,
        legacy_dirs_removed=legacy_dirs_removed,
        dry_run=dry_run,
        commits_relocated=commits_relocated,
        snapshots_relocated=snapshots_relocated,
        refs_updated=refs_updated,
        remote_refs_updated=remote_refs_updated,
        repo_id_updated=repo_id_updated,
        branch_fields_renamed=branch_fields_renamed,
        signatures_normalised=signatures_normalised,
        format_versions_bumped=format_versions_bumped,
        reflogs_updated=reflogs_updated,
        commits_signed=commits_signed,
        unsigned_commits_skipped=unsigned_commits_skipped,
        blobs_rewritten=blob_result.blobs_written,
        snapshots_rewritten=snap_result.snapshots_written,
        commits_unified=commit_result.commits_written,
    )
