"""patch_record.py — Content-addressed Muse patch objects.

A Muse patch (``.mpatch``) is a content-addressed, domain-aware, agent-first
exchange format for communicating a single commit's state change between
repositories or agents.

Unlike a traditional unified diff, a Muse patch:

- Is **content-addressed**: the ``patch_id`` is ``sha256(canonical JSON)`` so
  any tampering is immediately detectable.
- Carries **Cohen action labels**: every op includes an ``action_label`` field
  (``"inserted"``, ``"deleted"``, ``"modified"``, ``"moved"``, ``"renamed"``)
  derived from the Cohen Transform, giving agents immediate semantic context
  without parsing the diff.
- Embeds **agent provenance**: ``agent_id``, ``model_id``, ``signer_public_key``,
  and ``signature`` so every patch is traceable back to its creator.
- Declares **applicability**: the ``requires_snapshot`` field (the snapshot the
  repo must be at before applying), ``independent_dimensions`` (dimensions
  unaffected by this patch), and ``conflict_free`` (no detected overlap with
  concurrent changes).
- Is **domain-tagged**: the ``domain`` field lets apply-time validation verify
  the plugin is compatible before touching the working tree.
- Contains **manifest deltas**: ``from_manifest`` and ``to_manifest`` carry only
  the changed paths (not the full repo manifest), keeping patches lean.
- Lists **required objects**: the ``required_objects`` field names every object
  ID in ``to_manifest`` that the target repo must have (or fetch) before the
  patch can be applied.

Serialization
-------------
Patches are stored as UTF-8 JSON (not msgpack) for portability and human
inspectability.  The canonical JSON used for ``patch_id`` computation sorts all
keys, strips ``patch_id`` and signature-related fields (which sign the id, not
the other way round), and uses no separators (no whitespace).

Public API
----------
``PatchRecord``
    Dataclass holding all patch fields.

``compute_patch_id(record) -> str``
    Compute ``sha256:<hex>`` from the record's canonical JSON.  Call this with
    ``patch_id=""`` before embedding the id in the record.

``serialize_patch(record) -> bytes``
    Serialize to compact UTF-8 JSON bytes.

``deserialize_patch(data) -> PatchRecord``
    Deserialize from bytes.  Raises ``ValueError`` if the JSON is missing
    required fields.
"""

import json
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import TypedDict

from muse.core.types import content_hash, JsonValue

class PatchOp(TypedDict, total=False):
    """A single domain operation inside a PatchRecord, with Cohen action label."""

    op: str
    address: str
    position: int | None
    content_id: str
    content_summary: str
    action_label: str

class PatchApplicability(TypedDict, total=False):
    """Applicability metadata for a PatchRecord."""

    requires_snapshot: str
    independent_dimensions: list[str]
    conflict_free: bool

class PatchRecordDict(TypedDict):
    """Serialisable dict representation of a PatchRecord."""

    patch_id: str
    from_snapshot_id: str
    to_snapshot_id: str
    from_commit_id: str
    to_commit_id: str
    domain: str
    format_version: str
    created_at: str
    agent_id: str
    model_id: str
    signer_public_key: str
    signature: str
    intent: str
    sem_ver_bump: str
    breaking_changes: list[str]
    summary: str
    ops: list[PatchOp]
    files_added: list[str]
    files_modified: list[str]
    files_deleted: list[str]
    files_renamed: dict[str, str]
    required_objects: list[str]
    from_manifest: dict[str, str]
    to_manifest: dict[str, str]
    applicability: PatchApplicability
    blobs: dict[str, str]

# ---------------------------------------------------------------------------
# Dataclass
# ---------------------------------------------------------------------------

@dataclass
class PatchRecord:
    """A content-addressed Muse patch record.

    Fields
    ------
    patch_id
        ``sha256:<64-hex>`` identity of this patch.  Computed from the
        canonical JSON of the record with ``patch_id=""``,
        ``signature=""``, ``signer_public_key=""`` stripped.

    from_snapshot_id
        ``sha256:<64-hex>`` of the snapshot the patch departs from (the
        parent commit's snapshot, or an empty-repo sentinel for initial
        commits).  This is also ``applicability["requires_snapshot"]``.

    to_snapshot_id
        ``sha256:<64-hex>`` of the snapshot this patch produces.

    from_commit_id
        ``sha256:<64-hex>`` of the parent commit.  Empty string for the
        initial commit.

    to_commit_id
        ``sha256:<64-hex>`` of the commit this patch was generated from.

    domain
        Domain tag (``"code"``, ``"midi"``, …).

    format_version
        Schema version string, currently ``"1.0"``.

    created_at
        ISO-8601 timestamp when the patch was created.

    agent_id
        Agent type that produced this patch (``"claude-code"``, …).

    model_id
        Model version (``"claude-sonnet-4-6"``, …).

    signer_public_key
        Ed25519 public key (hex) of the signer.  Empty when unsigned.

    signature
        Ed25519 signature of ``patch_id`` (hex).  Empty when unsigned.

    intent
        Human-readable description of what this patch accomplishes.

    sem_ver_bump
        Semantic version impact: ``"major"``, ``"minor"``, or ``"patch"``.

    breaking_changes
        List of human-readable breaking change descriptions.

    summary
        Short human-readable summary (e.g. ``"2 modified files"``).

    ops
        List of DomainOp-compatible dicts, each enriched with an
        ``action_label`` field (Cohen extension).

    files_added
        Relative paths of files added by this patch.

    files_modified
        Relative paths of files modified by this patch.

    files_deleted
        Relative paths of files deleted by this patch.

    files_renamed
        Mapping of ``{old_path: new_path}`` for renames.

    required_objects
        ``sha256:`` IDs of all objects in ``to_manifest`` that an applying
        repo must possess.

    from_manifest
        Delta manifest for the "before" state — contains only paths that
        changed (deleted or modified).

    to_manifest
        Delta manifest for the "after" state — contains only paths that
        changed (added or modified).

    applicability
        Dict with:
        - ``requires_snapshot``: snapshot the repo must be at before applying
        - ``independent_dimensions``: dimensions not touched by this patch
        - ``conflict_free``: True if no overlap with concurrent changes was
          detected
    """

    patch_id: str
    from_snapshot_id: str
    to_snapshot_id: str
    from_commit_id: str
    to_commit_id: str
    domain: str
    format_version: str
    created_at: str
    agent_id: str
    model_id: str
    signer_public_key: str
    signature: str
    intent: str
    sem_ver_bump: str
    breaking_changes: list[str]
    summary: str
    ops: list[PatchOp]
    files_added: list[str]
    files_modified: list[str]
    files_deleted: list[str]
    files_renamed: dict[str, str]
    required_objects: list[str]
    from_manifest: dict[str, str]
    to_manifest: dict[str, str]
    applicability: PatchApplicability
    blobs: dict[str, str] = field(default_factory=dict)
    """object_id → base64-encoded content.

    Carries the raw bytes of every object listed in ``required_objects``
    (base64-encoded for JSON safety).  This makes a ``.mpatch`` file
    self-contained — the applying repo does not need to pre-fetch objects
    via a separate transfer (mpack, push/pull).

    Writers (``muse format-patch``) populate this field.
    Readers (``muse apply-patch``) write these blobs into the local object
    store before calling ``restore_object``.
    """

# ---------------------------------------------------------------------------
# patch_id computation
# ---------------------------------------------------------------------------

# Fields excluded from the canonical JSON used to compute patch_id.
# The signature signs the patch_id, not the other way round, so these
# must not influence the hash.
_EXCLUDED_FROM_ID = frozenset({"patch_id", "signature", "signer_public_key"})

def compute_patch_id(record: PatchRecord) -> str:
    """Return ``sha256:<64-hex>`` for *record*.

    The canonical form is compact JSON (no whitespace) with all keys sorted,
    ``patch_id``, ``signature``, and ``signer_public_key`` set to ``""``.

    Args:
        record: A :class:`PatchRecord` whose ``patch_id`` field may be ``""``
                (it is always ignored during computation).

    Returns:
        ``sha256:<64 hex>`` string.
    """
    raw = _record_to_dict(record)
    canonical: dict[str, JsonValue] = {}
    for k, v in raw.items():
        if k in _EXCLUDED_FROM_ID:
            canonical[k] = ""
        else:
            canonical[k] = v  # type: ignore[assignment]
    return content_hash(canonical)

# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------

def serialize_patch(record: PatchRecord) -> bytes:
    """Serialize *record* to compact UTF-8 JSON bytes.

    Args:
        record: The :class:`PatchRecord` to serialize.

    Returns:
        UTF-8 JSON bytes with no extra whitespace.
    """
    return json.dumps(_record_to_dict(record), separators=(",", ":")).encode("utf-8")

def deserialize_patch(data: bytes) -> PatchRecord:
    """Deserialize *data* from UTF-8 JSON bytes.

    Args:
        data: UTF-8 JSON produced by :func:`serialize_patch`.

    Returns:
        A :class:`PatchRecord`.

    Raises:
        ValueError: JSON is invalid, missing required fields, or wrong types.
        json.JSONDecodeError: *data* is not valid JSON.
    """
    d = json.loads(data)
    if not isinstance(d, dict):
        raise ValueError(f"Expected JSON object, got {type(d).__name__}")
    _require_str(d, "patch_id")
    return PatchRecord(
        patch_id=_str(d, "patch_id"),
        from_snapshot_id=_str(d, "from_snapshot_id"),
        to_snapshot_id=_str(d, "to_snapshot_id"),
        from_commit_id=_str(d, "from_commit_id"),
        to_commit_id=_str(d, "to_commit_id"),
        domain=_str(d, "domain"),
        format_version=_str(d, "format_version"),
        created_at=_str(d, "created_at"),
        agent_id=_str(d, "agent_id"),
        model_id=_str(d, "model_id"),
        signer_public_key=_str(d, "signer_public_key"),
        signature=_str(d, "signature"),
        intent=_str(d, "intent"),
        sem_ver_bump=_str(d, "sem_ver_bump"),
        breaking_changes=list(d.get("breaking_changes") or []),
        summary=_str(d, "summary"),
        ops=list(d.get("ops") or []),
        files_added=list(d.get("files_added") or []),
        files_modified=list(d.get("files_modified") or []),
        files_deleted=list(d.get("files_deleted") or []),
        files_renamed=dict(d.get("files_renamed") or {}),
        required_objects=list(d.get("required_objects") or []),
        from_manifest=dict(d.get("from_manifest") or {}),
        to_manifest=dict(d.get("to_manifest") or {}),
        applicability=dict(d.get("applicability") or {}),
        blobs=dict(d.get("blobs") or {}),
    )

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _record_to_dict(record: PatchRecord) -> PatchRecordDict:
    return {
        "patch_id": record.patch_id,
        "from_snapshot_id": record.from_snapshot_id,
        "to_snapshot_id": record.to_snapshot_id,
        "from_commit_id": record.from_commit_id,
        "to_commit_id": record.to_commit_id,
        "domain": record.domain,
        "format_version": record.format_version,
        "created_at": record.created_at,
        "agent_id": record.agent_id,
        "model_id": record.model_id,
        "signer_public_key": record.signer_public_key,
        "signature": record.signature,
        "intent": record.intent,
        "sem_ver_bump": record.sem_ver_bump,
        "breaking_changes": list(record.breaking_changes),
        "summary": record.summary,
        "ops": list(record.ops),
        "files_added": list(record.files_added),
        "files_modified": list(record.files_modified),
        "files_deleted": list(record.files_deleted),
        "files_renamed": dict(record.files_renamed),
        "required_objects": list(record.required_objects),
        "from_manifest": dict(record.from_manifest),
        "to_manifest": dict(record.to_manifest),
        "applicability": dict(record.applicability),
        "blobs": dict(record.blobs),
    }

def _str(d: Mapping[str, JsonValue], key: str) -> str:
    v = d.get(key, "")
    return str(v) if v is not None else ""

def _require_str(d: Mapping[str, JsonValue], key: str) -> None:
    if key not in d:
        raise ValueError(f"Missing required field: {key!r}")
