"""Tag-based commit description for ``muse describe``.

Walks backward from a commit through the ancestor graph and finds the nearest
semantic version tag.  Returns a human-readable label where the format depends
on the hop count:

- Exactly on a tag (distance=0):  ``v1.0.0``
- N commits past a tag:           ``v1.0.0-N-<abbrev hex>``  (no sha256: prefix)

When no eligible version tag is found (no stable tags, or no tags at all)
``DescribeResult.tag`` is ``None`` and ``distance`` is ``None``.

Pre-release filtering::

    include_pre=False (default) — only stable version tags are eligible
    include_pre=True  (--pre)   — all version tags are eligible

Walk budget::

    _MAX_WALK = 50_000 commits.

Tag-selection tie-breaking::

    When multiple tags point to the same commit the one with the highest
    semver precedence wins (``semver_key`` descending).
"""

import logging
import pathlib
from typing import TypedDict

from muse.core.types import split_id
from muse.core.commits import read_commit
from muse.core.version_tags import list_version_tags, VersionTagRecord, semver_key

logger = logging.getLogger(__name__)

_MAX_WALK = 50_000


class DescribeResult(TypedDict):
    """Result of describing a commit by its nearest version tag.

    Fields:
        commit_id:   Full SHA-256 hex of the described commit.
        tag:         Nearest version tag string, or ``None`` if no tag was found.
        distance:    Hop count from the tag's commit to this commit, or ``None``.
        short_sha:   First ``abbrev`` hex characters of the commit ID (no algo prefix).
        description: Human-readable description string, or ``None`` if no tag found.
        exact:       ``True`` when distance == 0 and tag is not ``None``.
    """

    commit_id: str
    tag: str | None
    distance: int | None
    short_sha: str
    description: str | None
    exact: bool


def describe_commit(
    root: pathlib.Path,
    repo_id: str,
    commit_id: str,
    *,
    include_pre: bool = False,
    first_parent: bool = False,
    abbrev: int = 8,
) -> DescribeResult:
    """Return a human-readable description of *commit_id* using version tags.

    Walks backward from *commit_id* through the parent chain using BFS and
    finds the nearest eligible version tag.

    When *include_pre* is ``False`` (the default) only stable version tags
    (no pre-release component) are eligible.  Set *include_pre=True* to
    include all version tags.

    Args:
        root:         Repository root directory.
        repo_id:      Repository content ID (used to look up version tags).
        commit_id:    Starting commit to describe (typically HEAD).
        include_pre:  Include pre-release version tags as eligible reference points.
        first_parent: Follow only the first-parent chain (skip merge second-parents).
        abbrev:       Length of the hex suffix in the description string (default 8).

    Returns:
        A :class:`DescribeResult` with the nearest tag name, hop count, and
        formatted description string.  When no eligible tag is found,
        ``tag``, ``distance``, and ``description`` are all ``None``.
    """
    algo, hex_str = split_id(commit_id)
    short_sha = hex_str[:abbrev]

    _no_tag = DescribeResult(
        commit_id=commit_id,
        tag=None,
        distance=None,
        short_sha=short_sha,
        description=None,
        exact=False,
    )

    # Load all version tags and filter by pre-release preference.
    all_vtags: list[VersionTagRecord] = list_version_tags(root)
    if not include_pre:
        all_vtags = [t for t in all_vtags if not t.semver["pre"]]

    if not all_vtags:
        return _no_tag

    # Build commit_id → best version tag map.  Multiple tags on the same
    # commit: keep the one with the highest semver precedence.
    tag_by_commit: dict[str, VersionTagRecord] = {}
    for vtag in all_vtags:
        existing = tag_by_commit.get(vtag.commit_id)
        if existing is None or semver_key(vtag.semver) > semver_key(existing.semver):
            tag_by_commit[vtag.commit_id] = vtag

    if not tag_by_commit:
        return _no_tag

    # BFS backward tracking hop distance per node.
    distances: dict[str, int] = {commit_id: 0}

    def _adjacency(cid: str) -> list[str]:
        rec = read_commit(root, cid)
        if rec is None:
            return []
        parents = [p for p in (rec.parent_commit_id, rec.parent2_commit_id) if p]
        if first_parent:
            parents = parents[:1]
        dist = distances.get(cid, 0)
        for p in parents:
            if p not in distances:
                distances[p] = dist + 1
        return parents

    from muse.core.graph import walk_dag

    nodes_yielded = 0
    for cid in walk_dag(commit_id, _adjacency, max_nodes=_MAX_WALK):
        nodes_yielded += 1
        dist = distances.get(cid, 0)
        if cid in tag_by_commit:
            vtag = tag_by_commit[cid]
            if dist == 0:
                description = vtag.tag
            else:
                description = f"{vtag.tag}-{dist}-{short_sha}"
            return DescribeResult(
                commit_id=commit_id,
                tag=vtag.tag,
                distance=dist,
                short_sha=short_sha,
                description=description,
                exact=(dist == 0),
            )

    if nodes_yielded >= _MAX_WALK:
        logger.warning("⚠️ describe: reached %d-commit walk limit", _MAX_WALK)
    return _no_tag
