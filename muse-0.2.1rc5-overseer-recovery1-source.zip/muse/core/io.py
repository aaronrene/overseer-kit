"""muse.core.io — raw filesystem I/O primitives.

Atomic writers, msgpack readers, and zstd helpers with no domain knowledge.
Every function here works purely in terms of ``pathlib.Path``, ``bytes``, and
primitive Python types — no commit records, snapshot manifests, or tag dicts.

All atomic writes follow the same crash-safety protocol:
    mkstemp → write → flush → fsync → rename

The fsync step is non-fatal on filesystems that do not support it (tmpfs,
certain Docker volumes).  Atomicity (torn-write protection) still holds via
the rename.
"""

from __future__ import annotations

import contextlib
import errno
import fcntl
import json as _json
import os
import pathlib
import sys
import tempfile

import msgpack

from muse.core.validation import assert_not_symlink
from muse.core.types import MsgpackValue

# ---------------------------------------------------------------------------
# Read safety constants
# ---------------------------------------------------------------------------

# Maximum size of a msgpack file that _read_msgpack will load into memory.
MAX_MSGPACK_BYTES: int = 64 * 1024 * 1024  # 64 MiB

# Upper bound for pack/mpack deserialization.  Pack files legitimately contain
# many binary blobs (raw file content), so they need a larger cap.
MAX_PACK_MSGPACK_BYTES: int = 512 * 1024 * 1024  # 512 MiB

# Per-value limits passed to msgpack.unpackb.
_MSGPACK_MAX_STR_LEN: int = 1_048_576           # 1 MiB per string value
_MSGPACK_MAX_BIN_LEN: int = 0                   # no binary blobs in store records
_MSGPACK_MAX_BIN_LEN_PACK: int = 256 * 1024 * 1024  # 256 MiB per blob in pack files
_MSGPACK_MAX_ARRAY_LEN: int = 1_000_000         # generous for large manifests
_MSGPACK_MAX_MAP_LEN: int = 1_000_000           # generous for 75k-file manifests

# ---------------------------------------------------------------------------
# Zstd compression helpers
# ---------------------------------------------------------------------------

# 4-byte zstd frame magic (little-endian 0xFD2FB528).  Self-describing: if a
# file starts with these bytes it is a zstd frame, otherwise raw bytes.
_ZSTD_MAGIC: bytes = b"\x28\xb5\x2f\xfd"

# Only compress when the payload exceeds this threshold.  Tiny payloads are
# left uncompressed — the overhead is not worth it.
_ZSTD_COMPRESS_THRESHOLD: int = 8_192  # bytes


def _zstd_compress(data: bytes) -> bytes:
    """Compress *data* with zstd level 3.

    Level 3 is the zstd default — good compression ratio with fast
    decompression.  The output frame begins with ``_ZSTD_MAGIC`` so callers
    can detect compressed files without any external flag.
    """
    import zstandard
    return zstandard.ZstdCompressor(level=3).compress(data)


def zstd_decompress_if_needed(data: bytes) -> bytes:
    """Return *data* decompressed if it is a zstd frame; otherwise unchanged.

    Detection uses the 4-byte zstd magic number, making the format
    self-describing and backward-compatible with uncompressed legacy files.
    """
    if data[:4] == _ZSTD_MAGIC:
        import zstandard
        return zstandard.ZstdDecompressor().decompress(data)
    return data

# ---------------------------------------------------------------------------
# Symlink-guard cache
# ---------------------------------------------------------------------------

# Parent directories that have already been validated as non-symlinks this
# process run.  Amortises the is_symlink() stat call across many writes to the
# same directory (e.g. object shards, tag buckets).
_validated_store_parents: set[str] = set()

# ---------------------------------------------------------------------------
# Msgpack deserialization
# ---------------------------------------------------------------------------

def safe_unpackb(
    raw: bytes,
    *,
    context: str = "",
    max_bytes: int = MAX_MSGPACK_BYTES,
    strict_map_key: bool = True,
    allow_binary: bool = False,
) -> MsgpackValue:
    """Deserialize msgpack bytes with strict, configurable safety limits.

    Single canonical entry-point for all in-memory msgpack deserialization.
    Every callsite that receives untrusted bytes must go through here.

    Args:
        raw:            Msgpack bytes to unpack.
        context:        Human-readable label for error messages.
        max_bytes:      Hard cap on ``len(raw)`` checked before any parsing.
        strict_map_key: When ``True`` only ``str`` keys are accepted in maps.
                        Set ``False`` only for legacy formats with integer keys.
        allow_binary:   When ``False`` binary blobs are rejected.  Set
                        ``True`` for pack/mpack payloads with blob content.

    Raises:
        ValueError: If ``len(raw)`` exceeds *max_bytes*.
        msgpack.UnpackException: If the bytes are not valid msgpack.
        msgpack.ExtraData: If there is trailing data after the top-level value.
    """
    n = len(raw)
    if n > max_bytes:
        label = f" ({context})" if context else ""
        raise ValueError(
            f"Msgpack payload{label} is {n:,} bytes — exceeds the "
            f"{max_bytes // (1024 * 1024)} MiB safety cap.  "
            "Possible size-bomb or corrupted input."
        )
    result: MsgpackValue = msgpack.unpackb(
        raw,
        raw=False,
        strict_map_key=strict_map_key,
        max_str_len=_MSGPACK_MAX_STR_LEN,
        max_bin_len=_MSGPACK_MAX_BIN_LEN_PACK if allow_binary else _MSGPACK_MAX_BIN_LEN,
        max_array_len=_MSGPACK_MAX_ARRAY_LEN,
        max_map_len=_MSGPACK_MAX_MAP_LEN,
    )
    return result


def read_msgpack_file(
    path: pathlib.Path,
    *,
    max_bytes: int = MAX_MSGPACK_BYTES,
    strict_map_key: bool = True,
    allow_binary: bool = False,
) -> MsgpackValue:
    """Read a msgpack file and deserialize it with strict safety limits.

    The file size is checked via ``os.stat`` *before* ``read_bytes()`` is
    called, so a multi-GiB file never causes an allocation.

    Raises:
        OSError: If the file size exceeds *max_bytes*.
        ValueError: Forwarded from :func:`safe_unpackb`.
        msgpack.UnpackException: If the file is not valid msgpack.
    """
    size = path.stat().st_size
    if size > max_bytes:
        raise OSError(
            f"Msgpack file {path.name!r} is {size:,} bytes — exceeds the "
            f"{max_bytes // (1024 * 1024)} MiB safety cap.  "
            "File may be corrupt or tampered."
        )
    return safe_unpackb(
        path.read_bytes(),
        context=path.name,
        max_bytes=max_bytes,
        strict_map_key=strict_map_key,
        allow_binary=allow_binary,
    )


def _read_msgpack(path: pathlib.Path) -> MsgpackValue:
    """Read and unpack a msgpack file, enforcing size and per-value limits.

    Raises :exc:`OSError` if the file exceeds :data:`MAX_MSGPACK_BYTES`.
    Callers that want ``None`` on failure should catch :exc:`Exception`.
    """
    size = path.stat().st_size
    limit = MAX_MSGPACK_BYTES
    if size > limit:
        raise OSError(
            f"Msgpack file {path.name!r} is {size:,} bytes — exceeds the "
            f"{limit:,} bytes read limit."
        )
    raw = zstd_decompress_if_needed(path.read_bytes())
    return safe_unpackb(raw, context=path.name, max_bytes=limit)


def _read_msgpack_dict(path: pathlib.Path) -> "dict[str, object]":
    """Read a msgpack file and return the top-level mapping.

    Raises :exc:`TypeError` if the deserialized value is not a ``dict``.
    Callers that want ``None`` on failure should catch :exc:`Exception`.
    """
    raw = _read_msgpack(path)
    if not isinstance(raw, dict):
        raise TypeError(
            f"Expected dict from {path}, got {type(raw).__name__!r}"
        )
    return raw  # type: ignore[return-value]

# ---------------------------------------------------------------------------
# Atomic writers
# ---------------------------------------------------------------------------

def write_text_atomic(
    path: pathlib.Path,
    text: str,
    encoding: str = "utf-8",
) -> None:
    """Write *text* to *path* atomically and durably.

    Uses mkstemp → flush → fsync → rename so every VCS state file is
    protected against torn writes and page-cache loss.  fsync failure is
    non-fatal on virtual filesystems (tmpfs, Docker volumes) — atomicity
    still holds.

    Raises:
        ValueError: If *path*'s parent directory is a symlink.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    assert_not_symlink(path.parent, label=f"write target parent ({path.parent.name}/)")
    fd, tmp_str = tempfile.mkstemp(dir=path.parent, prefix=".muse-tmp-")
    tmp = pathlib.Path(tmp_str)
    try:
        with os.fdopen(fd, "w", encoding=encoding) as fh:
            fh.write(text)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError as exc:
                if exc.errno not in (errno.EINVAL, None):
                    raise
        tmp.replace(path)
    except OSError:
        tmp.unlink(missing_ok=True)
        raise


def _fsync_robust(fd: int) -> None:
    """Call fsync/F_BARRIERFSYNC, ignoring EINVAL (unsupported filesystems)."""
    try:
        if sys.platform == "darwin":
            try:
                fcntl.fcntl(fd, 85)  # F_BARRIERFSYNC
            except OSError:
                os.fsync(fd)
        else:
            os.fsync(fd)
    except OSError as exc:
        if exc.errno != errno.EINVAL:
            raise


def _write_json_atomic(path: pathlib.Path, data: "dict[str, object]") -> None:
    """Serialize *data* to JSON and atomically replace *path*.

    Uses mkstemp → fsync → rename crash-safety.  UTF-8 encoded compact JSON,
    no trailing newline.
    """
    parent_str = str(path.parent)
    if parent_str not in _validated_store_parents:
        assert_not_symlink(path.parent, label=f"write target parent ({path.parent.name}/)")
        _validated_store_parents.add(parent_str)
    encoded = _json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    fd, tmp_str = tempfile.mkstemp(dir=path.parent, prefix=".muse-tmp-")
    tmp = pathlib.Path(tmp_str)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(encoded)
            fh.flush()
            _fsync_robust(fh.fileno())
        tmp.replace(path)
    except OSError:
        with contextlib.suppress(OSError):
            tmp.unlink()
        raise


def _write_shelf_header_atomic(path: pathlib.Path, data: "dict[str, object]") -> None:
    """Write a shelf entry using ``shelf <size>\\0<json>`` framing.

    Same git-object-style header as commits and snapshots in the unified
    object store.  Uses mkstemp+fsync+rename crash-safety.
    """
    parent_str = str(path.parent)
    if parent_str not in _validated_store_parents:
        assert_not_symlink(path.parent, label=f"write target parent ({path.parent.name}/)")
        _validated_store_parents.add(parent_str)
    json_bytes = _json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    header = f"shelf {len(json_bytes)}\0".encode("utf-8")
    payload = header + json_bytes
    fd, tmp_str = tempfile.mkstemp(dir=path.parent, prefix=".muse-tmp-")
    tmp = pathlib.Path(tmp_str)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(payload)
            fh.flush()
            _fsync_robust(fh.fileno())
        tmp.replace(path)
    except OSError:
        with contextlib.suppress(OSError):
            tmp.unlink()
        raise
